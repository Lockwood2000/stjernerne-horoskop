#!/bin/zsh
set -eu
cd "$(dirname "$0")"
if [[ -x .venv/bin/python ]]; then
  task_python=.venv/bin/python
elif [[ -x ../../work/venv/bin/python ]]; then
  task_python=../../work/venv/bin/python
else
  print 'Installer først miljøet som beskrevet i README.md.'
  read 'task_reply?Tryk Retur for at lukke.'
  exit 1
fi
if [[ ! -f build/libswe.dylib && ! -f build/libswe.so ]]; then
  "$task_python" scripts/build_native.py
fi
print 'Stjernerne starter lokalt på http://127.0.0.1:8765'
print 'Lad dette vindue stå åbent. Stop med Ctrl+C.'
(sleep 2; open 'http://127.0.0.1:8765') &
exec "$task_python" -m uvicorn app.main:app --host 127.0.0.1 --port 8765 --no-access-log --no-proxy-headers
