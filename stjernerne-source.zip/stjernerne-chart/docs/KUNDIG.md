# Kündig-snit · 15. oktober 2026

## Brug

Beregn et fødselshoroskop, vælg Fødselstid, åbn Kündigs metode, og tryk
Find Kündig-snit. Vælg ±30 minutter, ±1 time eller ±3 timer omkring originalen.
Hvert snit viser lokal dato, klokkeslæt, UTC-offset, MC/IC og snitpartnerne.
De tre nærmeste markeres udelukkende efter tidsafstand.

Vis i hjulet åbner snittet uden at ændre originalen. Behold kandidat føjer det
til Kandidater & begivenheder (maksimalt fem inklusive originalen). Gem i Mine
horoskoper for at beholde arbejdet. Der kan finjusteres med ±1 sekund.
Sekunder bevares ved genåbning, backup, import og begivenhedssammenligning.
Gamle backups med hele minutters forskydning understøttes fortsat.

## Metode og afgrænsning

Primær metodekilde: Electric Ephemeris, CORREX-vejledningen, side 6:
https://www.electric-ephemeris.dk/correx.pdf

Implementationens konvention følger vejledningens ekliptiske konjunktioner til
MC/IC, frem for fysisk kulmination med planetbredde. MC/IC-herskerne er
traditionelle: Mars i Skorpionen, Saturn i Vandbæreren, Jupiter i Fiskene.
Intervallet mellem tilstødende partnerakser deles i ti i siderisk tid
(rektascension). Planetstillingerne beregnes ved den enkelte snitrod. Et snit
accepteres kun i det tegnområde, hvis MC/IC-herskere er de aktuelle partnere.
En partner på MC/IC medtages, når herskerreglen er opfyldt.

Swiss Ephemeris leverer geocentriske tilsyneladende længdegrader, sand obliquitet
og tilsyneladende siderisk tid. Planetbredde sættes til nul i omregningen af
snitpartnerens længde til rektascension. Root-søgningen opdeles ved partneraksernes
rækkefølgeskift; hvert af de ti delingspunkter løses separat, så tætte snit ikke
forsvinder i et tidsraster. Resultater afrundes til nærmeste hele UTC-sekund;
sammenfaldende afrundede tidspunkter samles. Tidszone, fold og dokumenteret
historisk offset følger den eksisterende tidsmodel.

Koden er en selvstændig ny implementation. Ingen proprietær ARGUS/CORREX-kode,
symbolfont eller datafil er kopieret. Denne version er ikke sammenlignet med en
installation af ARGUS. Bonatti-snit, automatisk rangering, sikkerhedsscore og
Kündigs individuelle solnøgle er ikke inkluderet. Begivenhedssammenligningen
bruger fortsat de beskrevne langsomme transitter til AC/MC kl. 12 UTC, ikke et
komplet Kündig-prognosesystem. Snittene fastslår ikke et faktisk fødselstidspunkt.

## Verifikation

145 Python-tests og 27 JavaScript-tests bestod. Efter den sidste ændring til
backupvalidering blev de 11 berørte JavaScript-tests og syntakskontrol genkørt.

Nye tests omfatter analytisk kendte snit i en ensartet roterende model,
subsekundstæthed, forkastelse af falske rødder ved partneraksekrydsning,
MC-geometri på forskellige breddegrader, begrænset interval, API-validering,
preview/begivenhedsoverensstemmelse, UTC/lokal tid, sommertid, historisk offset
og dato-grænsen 1500. Backupvalidering afviser også kandidater, der efter
kanonisering ellers ville være dubletter.

Browserkontrol: tre snit for København 15. juni 1990 kl. 14:30 inden for ±1 time:
13:35:08, 14:27:38 og 15:19:09. Disse er regressionsværdier fra denne version,
ikke eksterne referenceværdier. To snit blev beholdt med en testbegivenhed,
sammenlignet, gemt, genåbnet efter genindlæsning, eksporteret til en rigtig JSON-fil,
importeret som kopi og genåbnet. Sekunder og begivenheden var bevaret.
Mobilkontrol ved 390 × 844 viste ingen vandret sideudvidelse; Find-knappen
var 49 px høj. Vis i hjulet viste den valgte tid 14:27:38.

Testdata var opdigtede; der er ikke tilføjet personlige fødselsdata i kilden.

## Kode og drift

Ny beregning: app/kundig.py og /api/rectify/kundig. Søgningen er begrænset til
±3 timer og genbruger samme sikkerhed, hastighedsgrænser og datakontrol som
øvrige API-kald. En lokal seks-timers søgning tog cirka 0,06 sekunder.

Tidsforskydninger bevares i det eksisterende backupformat som tal i minutter,
nu med valideret helt sekund som opløsning. Funktionen er baseret på offentlig
main fa2ab534ae8f5d492a5365364452c69207b1c368 og bevarer indlejringens klar-signal,
bibliotek, arkivposter og alle øvrige horoskoptyper. Ingen nye tjenester eller
pakkeafhængigheder. Den eksisterende AGPL-kildepakke omfatter hele tilføjelsen.
