# Transitter i den lokale prototype

Tilføjet 13. oktober 2026. Samme lokale server, Swiss Ephemeris og licensvilkår som fødselshoroskopet. Ingen nye tjenester eller udgifter.

## Brug

Slå **Vis transitter** til. Vælg dato og klokkeslæt i dansk tid (Europe/Copenhagen) eller UTC. Datoændringer opdaterer automatisk; **Opdatér** gentager beregningen. **Nu**, ± dag og ± uge flytter tidspunktet. Dag/uge-knapper bevarer vægurets klokkeslæt i den valgte zone, også hen over et sommertidsskift.

Den ferskenfarvede ydre ring viser 11 transitpositioner. Det indre hjul, huse og akser forbliver fødselshoroskopets. Transitpositioner er geocentriske og kræver intet nyt sted. En stiplet linje fremhæver et aspekt; fødselsaspekterne dæmpes. Fanen **Transitter** viser alle fundne hovedaspekter sorteret efter orb. Klik på en forbindelse for at se den i hjulet. SVG-download indeholder det aktuelle hjul og transitdato i titlen.

## Beregning og afgrænsning

POST `/api/transits` modtager `{birth: <Birth>, transit: {date, time, timezone, fold?}}`. Serveren genberegner fødselspositionerne frem for at stole på klientleverede længdegrader. Planetberegning er delt med den eksisterende fødselsmotor og beskyttet af samme lås og krav om Swiss-datafiler. Ingen automatisk fallback.

- Dato: 1900-01-01 til 2099-12-31. Tropisk, geocentrisk, True Node.
- Krydsaspekter fra hver transitplanet/-knude til hver fødselsplanet/-knude, inklusive samme planet. Konjunktion, sekstil, kvadrat, trigon og opposition.
- Fast orb 3°; højst 2° når en nordknude indgår. Det er denne prototypes indstilling, ikke en universel astrologisk standard.
- Nærmer sig/aftager er fortegnet på den øjeblikkelige orb-ændring, med fødselspositionen fastholdt og transitplanetens længdegradshastighed. Næsten stationær: absolut hastighed < 0,00001°/dag. Eksakt: orb < 0,0000001°. Det forudsiger ikke en senere eksakt passage.
- AC/MC-aspekter, transithuse, kalender med eksakte passager og fortolkninger er ikke implementeret.
- IANA-håndtering af ikke-eksisterende og dobbelte klokkeslæt. Før 1970 vises den eksisterende historikadvarsel. Langsigtet civil tid, fremtidige tidszoneregler og Jordens rotation er modeller, ikke kendte fremtidige observationer.

## Verifikation

84 Python-tests og 3 eksisterende JavaScript-tests består. De 27 nye transitcases dækker cross-chart-aspekter, orbgrænser, passage over 0°, retrograd bevægelse, oppositioner, næsten eksakte kontakter, egen fødselsdato, interval/validering, DST-gap/fold, samme tidspunkt i to zoner, sikkerhedsheaders og oprindelsesafvisning.

Tre nye epoker (2026-10-13, 2050-06-15, 2099-12-31) kontrolleres mod officiel `swetest`: alle 11 positioner og hastigheder, tolerance 0,000001°. De 10 fysiske planeter sammenlignes også med Astronomy Engine, tolerance 60 buesekunder, ved samme TT. Nordknuden har her kun Swiss CLI-kontrol.

En indledende sammenligning ved samme nominelle civile tidspunkt i 2099 gav ca. 65 buesekunders forskel for Månen. Tidsmodellernes TT var ca. 109 sekunder forskellige. Ved samme TT er den maksimale positionsforskel ca. 14,91 buesekunder i dette 2099-sæt. Testen adskiller derfor kontrol af efemerider fra kontrol af UTC/TT-konvertering; konverteringen kontrolleres mod Swiss CLI. Den uafhængige sammenligning er ikke en uafhængig validering af fremtidens civile tidsmodel.

Browserkontrol: datoskift og gentagne hurtige klik, aspektvalg, fold-valg ved vintertid, rydning ved ændrede fødselsdata, slå til/fra, responsiv mobilvisning, ingen vandret side-overløb. Afbrudte eller ældre svar kan ikke overskrive nyere valg. Fejl rydder transitvisningen, så gamle transitter ikke fremstår som aktuelle.


## Afspilning

Knappen **Afspil / Pause** flytter transitterne i skridt på 1 time, 1 dag eller 1 uge, frem eller tilbage. Hver beregnet visning står i mindst 1,2 sekunder, hvorefter næste skridt beregnes. Der er højst én igangværende forespørgsel. Dato, ring og aspektoversigt opdateres samlet ved et vellykket svar; hjulet forsvinder ikke mellem skridtene. Det valgte aspekt følges, mens det fortsat er inden for orb.

Afspilningen begynder kun på brugerens tryk. Pause, ændring af data og skjult browserfane stopper løkken og afviser sene svar. Ved serverfejl, datogrænsen eller et lokalt tidspunkt, der kræver afklaring ved sommertid/vintertid, pauser afspilningen. Skridtene følger vægurets lokale dato og tid, ikke nødvendigvis præcis 24 timers forløbet tid per dag ved et urskift. Brug UTC for ensartede tidsintervaller gennem disse skift.

Validering: 7 JavaScript-tests består, heraf 4 nye cases for kalendergrænser/skudår, ingen samtidige beregninger, pause/genstart med sene svar og stop ved fejl. Browserkontrol verificerede frem/baglæns bevægelse, pause, dato/hjul-sammenhæng og stop ved et ikke-eksisterende sommertidstidspunkt. Beregningsmotoren er uændret fra de 84 beståede Python-tests.
