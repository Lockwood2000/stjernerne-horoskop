# Bonatti-snit · 15. oktober 2026

## Brug

Fødselstid → Kündig & Bonatti → Snitmetode. Vælg begge metoder samlet eller
hver for sig. Intervallet er fortsat ±30 minutter, ±1 time eller ±3 timer.
Kortene viser metode, lokalt tidspunkt og den relevante Bonatti-planet og akse.
Kündig-partnere vises særskilt. Farver supplerer de skrevne metodenavne.
De tre nærmeste markeres efter tidsafstand i den valgte liste.

Vis i hjulet og Behold kandidat bruger samme sekundpræcise tidsmodel som før.
Et tidspunkt med begge metoder optager én kandidatplads. Kandidaternes mærker
vises også i begivenhedsoversigten og følger bibliotek, genåbning og backup/import.
De er oplysninger om det valgte snit, ikke en sikkerhedsscore. Ældre backups
uden mærker understøttes og får ikke opfundet en klassifikation.

## Metode og konvention

Primær kilde er Electric Ephemeris' ARGUS-manual, trykt side 79:
https://www.electric-ephemeris.dk/download/argus421.pdf

Bonatti-snittet beskrives som konjunktion eller opposition mellem en akse og en
planet. Her løses dette som planetkonjunktioner til AC, DC, MC og IC i tropisk
ekliptisk længde. Valgt planetgruppe: Solen, Månen, Merkur, Venus, Mars, Jupiter,
Saturn, Uranus, Neptun og Pluto. Nordknude, Chiron og dværgplaneter er udeladt
fra snitsøgningen; de kan fortsat vises i kandidatens almindelige horoskop.
Der bruges ingen herskerregel for Bonatti. Planetposition og akser genberegnes
for hvert prøvetidspunkt med samme Swiss-motor som horoskophjulet.

Det er ikke fysisk opgang/nedgang eller kulmination med planetbredde. Navnet
Bonatti dækker her den beskrevne softwarekonvention; der hævdes ikke en fuld
rekonstruktion af en historisk originalmetode eller identitet med en ARGUS-installation.

## Søgning og sammenfald

Intervallet deles i højst 30 sekunders trin. Hver planet og akse løses separat
ved bisektion til 0,00002 sekund. Springet ved ±180° i vinkelresidualet er ikke
en rod. DC/IC repræsenterer oppositionerne, så samme kontakt ikke tælles to gange.
Søgningen genbruger den eksisterende afgrænsning |breddegrad| < 66°.

Rødder afrundes til nærmeste hele UTC-sekund, før kandidater dannes. Alle
metodedefinitioner og kontakter i samme sekund bevares i ét kort. Det kan være
en eksakt fælles rod eller forskellige rødder, der afrundes til samme sekund.
Metodetællinger kan derfor tilsammen overstige antallet af unikke tidspunkter.
Resultaterne tilpasses fortsat kandidatens historiske tidszone og fold.

## Verifikation og drift

Tests dækker analytisk kendte aksekontakter, bevægelig planet, 360°-omslag,
intervalgrænser, tætte rødder, samtidige metodefund, API-standard og metodefiltre,
orb-/geometrioverensstemmelse med preview, begge halvkugler, høj breddegrad,
sommertid, historisk offset og nedre datogrænse. Backupvalideringen kontrollerer
at hvert mærke peger på et unikt, beholdt sekund og kun kendte metoder.

Regressionsprøve: København 15. juni 1990 kl. 14:30, ±1 time, giver tre Kündig-
og fem Bonatti-snit fordelt på syv unikke sekunder. 15:19:09 er fælles, med
Saturn på IC. Disse tal er implementationens testværdier, ikke eksterne ARGUS-referenceværdier.

Ingen nye pakker, betalinger, tjenester eller serverlagring. Den eksisterende
AGPL-kildepakke omfatter hele tilføjelsen; ingen proprietær kode er kopieret.
Udgivelsen kræver ingen ændring i Squarespaces sidekode eller venteskærm.

175 Python-tests og 31 JavaScript-tests bestod. Browserprøven omfattede begge
filtre, én kandidat fra hver metode samt et fælles snit, eventuel solnøgle,
gemning, genåbning og rigtig JSON-eksport/import med sekunder og mærker.
Genåbning af den importerede kopi bevarede 14:35:11, fire kandidater, en
prøvebegivenhed, metodevalget begge og de tre forskellige mærker. Mobilprøven
ved 390 × 844 havde sidebredde 390 uden vandret sideudvidelse, 49 px Find-knap
og 364 px hjul. Vis Bonatti-snit 14:44:33 opdaterede hjulet korrekt. Prøven
brugte kun fiktive data på den lokale testadresse.
