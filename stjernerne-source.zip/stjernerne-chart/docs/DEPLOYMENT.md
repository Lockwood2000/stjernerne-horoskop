# Separat udgivelse på Render

Ejeren har godkendt offentlig udgivelse og AGPL-kildedeling. Ingen betalte tjenester
må tilføjes uden særskilt godkendelse. Intet skal linkes fra Stjernernes hjemmeside.

`render.yaml` beskriver en separat Docker-webservice på **Free**. Kontroller den
aktuelle konto, arbejdsområdets kvoter, forbrug og eventuel båndbreddeafregning i
Render, før tjenesten oprettes. De eksisterende tjenester skal ikke ændres.

1. Kør tests og `python scripts/package_source.py` før hver udgivelse. Kildearkivet
   er et byggeinput og skal inkluderes i den kode, Render modtager.
2. Læg denne projektmappe i et separat repository. Ingen credentials, private
   brugerdata, mails, lokale miljøer eller screenshots med persondata må medtages.
3. Opret webservice fra Dockerfile; Free, region Frankfurt, port 8765 og health
   path `/api/health`. Ingen disk/database kræves. Kør én proces/instans.
4. Appen bruger automatisk `RENDER_EXTERNAL_URL` til origin-/hostkontrol.
   Hvis eget domæne bruges, sæt `PUBLIC_ORIGIN` og `ALLOWED_HOSTS` eksplicit.
5. Verificér HTTPS, `/source`, alle fire horoskopvisninger, fejlvisninger og mobil.
   Gem den faktisk publicerede versions identitet og opdatér STATUS.md.

Docker-wrapperen er bygget og live-testet på Render/Linux. Den endelige version
6e5fa73 er verificeret; se release.json og live-verification.json.

Ingen brug af proxy-headers til klientidentifikation: i denne første container
ser in-memory rate limit den direkte netværkspartner. Bag Render-proxyen kan
flere brugere derfor dele 120 API-forespørgsler/minut. Før større trafik bør en
verificeret edge-rate-limit eller korrekt betroet proxy-konfiguration etableres.
Der stoles ikke ukritisk på klientleverede X-Forwarded-For-headere.

Free-tjenester går ifølge Renders dokumentation i dvale efter 15 minutters
inaktivitet og kan bruge omtrent et minut på opstart. Gratis instanstimer deles
på workspace-niveau. Kontroller aktuelle vilkår i kontoen før oprettelse.
Kilde: https://render.com/docs/free og https://render.com/docs/web-services .

`noindex` beder søgemaskiner om ikke at indeksere; det er ikke adgangskontrol.
Kildepakken og appen er offentlige, når tjenesten er offentliggjort.

## Udgivelsesarkiv

Når GitHub overføres via browseren, indeholder udgivelsesrepositoryet hele
`stjernerne-source.zip` og Docker-wrapperen fra `deploy/Dockerfile`. Wrapperen
udpakker kildekoden, bygger den originale Swiss C-motor på Linux og kopierer
kun runtimefilerne samt det samme kildearkiv ind i den endelige container.
Koden kan altid udpakkes og arbejdes videre på som et almindeligt repository.
Ingen kildekode genereres eller hentes fra en ekstern server ved containeropstart.
