# Leveringsstatus · 13. oktober 2026

**Fungerende lokal prototype. Offentlig udgivelse er godkendt, men ikke gennemført.**

Selvstændig dansk HTML/CSS/JavaScript/SVG-app med Python/FastAPI og direkte
Swiss Ephemeris C-binding. Samme origin for brugerflade og API, iframe klar til
Squarespace. Lokale efemerider, skrifter og bydata; ingen tredjepartsopslag med fødselsdata.

Implementeret: fødselshoroskop, historiske tidszoneregler med DST-valg og manuel
korrektion, Placidus, True Node, positioner, retrogradstatus, aspekter, transitring,
datovalg, afspilning, solretur med opholdssted og sekundære progressioner med
Naibod-akser. Chiron, Ceres, Eris, Haumea og Makemake er tilvalgt som standard.
Hjulet har fået pastel-zodiak, originalt tegnede planetsymboler og tydeligere markører.

**Verifikation:** 111 Python- og 7 JavaScript-tests bestået. De oprindelige 50
planetpositioner er sammenlignet med en uafhængig motor (maks. 11,5229 buesekunder).
De nye himmellegemer er sammenlignet med Swiss-referenceprogrammet, ikke en
anden motor. Solretur, tidsnøgle, progressionens AC/MC-geometri og API-fejl er testet.

**Licens:** Ejeren har udtrykkeligt valgt gratis AGPL med adgang til generatorens
kildekode. `/source` leverer en kildepakke med byggevejledning, data, konfiguration,
Swiss-kilde og licensnotices. Stjernernes øvrige website, brandrettigheder og
uvedkommende systemer gives ikke en ny licens.

**Udgifter:** 0 kr. i nye køb. Der er ikke oprettet hosting eller betalt licens.
Eksisterende Render-konto er identificeret via mail; aktuel plan/pris og ledige
kvoter kan først bekræftes i kontrolpanelet. Render-login afventes. Den separate
service skal vælges som Free, og eventuelle delte kvoter/bandbredde skal kontrolleres.

**Privatliv og synlighed:** Ingen fødselsdata lagres i appen. Ingen adgangslog.
`noindex, nofollow, noarchive` er sat i HTML og HTTP-header. Ingen links eller
menuændringer på Stjernerne.dk/io. Et offentligt link er ikke adgangsbeskyttet.

**Begrænsninger:** Historiske tidszoner før 1970 kræver konkret kontrol; atlas er
ikke et historisk grænseatlas. Placidus afvises fra 66° nord/syd. Ingen universel
validering af samtlige huse mod en anden professionel pakke. Safari/iOS, Docker
og live Squarespace-integration er ikke testet. Render Free kan gå i dvale.

**Næste trin:** Login på eksisterende Render, verificér nul ekstra omkostninger,
placér appen i eget repository og udgiv separat service. Kontrollér HTTPS,
kilde-download, fødselshoroskop/transit/solretur/progression og mobilvisning på
live-linket. Send det verificerede link uden at tilføje det på Stjernernes hjemmeside.
