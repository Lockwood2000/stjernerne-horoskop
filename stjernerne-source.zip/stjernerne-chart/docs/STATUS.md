# Leveringsstatus · 13. oktober 2026

**Publiceret og verificeret:** https://stjernerne-horoskop.onrender.com

Kildekode: https://github.com/Lockwood2000/stjernerne-horoskop
Version: `8582acc2bf2936eabaf4aefaee23b35ee0214470`.
Synastri er publiceret og verificeret på live-serveren. AGPL-kildepakken kan
hentes direkte fra appens `/source`; hele den redigerbare kode er inkluderet.
Kildepakkens dokumenter er et snapshot før den afsluttende livekontrol; denne
leveringsmappe indeholder desuden den efterfølgende release- og testrapport.

## Funktioner

Fødselshoroskop med tidszoneregler, Placidus, True Node, positioner, retrogradstatus,
aspekter og SVG-download. Transitring med dato og afspilning. Solretur med valgt
opholdssted. Sekundære progressioner med én dag pr. år og Naibod-akser.
Synastri med to fødselshoroskoper, krydsaspekter og gensidige husplaceringer.
Chiron, Ceres, Eris, Haumea og Makemake er tilvalgt som standard.
Hjulet har pastelfarver, originale vektorsymboler og forbedrede markører.

## Drift og økonomi

Render Free i Frankfurt i ejerens tomme Hobby-workspace. Intet betalingskort,
ingen tidligere regninger og ingen betalte tjenester tilføjet. 0 $/måned for
den valgte instans. Ved inaktivitet kan opstart tage ca. et minut.
Gratis kvoter kontrolleret før oprettelse: 750 instanstimer, 5 GB trafik og
500 byggeminutter pr. måned, delt inden for dette workspace.
Den eksisterende Spørg Stjernerne-tjeneste i det andet workspace er uændret.

Intet link eller menupunkt er tilføjet til Stjernerne.dk/io. `noindex` er sat
i HTML og HTTP-header; det er et offentligt link uden adgangskode.
Fødselsdata lagres ikke af appen, og appens adgangslog er slået fra.

## Verifikation

123 Python- og 7 JavaScript-tests bestået plus en Linux-buildkontrol af
arbejdstråde. Den første deployment afslørede en Linux/Mac-forskel i Swiss'
thread-local tilstand; den er rettet ved understøttet TLSOFF-build og
proceslås. Den rettede version er kontrolleret via HTTPS for alle fem
horoskoptyper, fuld kildepakke, noindex og Origin-afvisning.
Browseren er afprøvet ved 390 og 1280 px samt med transitafspilning.

## Begrænsninger og videre arbejde

Historiske tidszoner før 1970 kræver konkret kontrol. Atlas er ikke et historisk
grænseatlas. Placidus afvises fra 66° nord/syd. De nye himmellegemer er valideret
mod Swiss-referenceprogrammet, ikke en anden motor. Progression bruger én
eksplicit Naibod-metode. Ingen Safari/iOS- eller live Squarespace-embedtest.
Før større offentlig trafik bør rate limit bag proxy, kapacitetsbehov og
faglige referencehoroskoper gennemgås. Ingen automatisk opgradering er bestilt.

## Ny tilføjelse: fødselstidskorrektion

Implementeret og lokalt testet: tidsforskydning, kandidatoversigt og daterede
livsbegivenheder med langsomme transitter til AC/MC. Se RECTIFICATION.md.
Denne kildepakke dannes før den efterfølgende livekontrol.
