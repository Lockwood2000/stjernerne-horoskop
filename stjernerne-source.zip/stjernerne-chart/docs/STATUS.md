# Leveringsstatus · 14. oktober 2026

**Publiceret og verificeret:** https://stjernerne-horoskop.onrender.com

Kildekode: https://github.com/Lockwood2000/stjernerne-horoskop
Version: `7fcd9632f1882dfbe7e8b95d8e9d692671a0e186`.
Synastri er publiceret og verificeret på live-serveren. AGPL-kildepakken kan
hentes direkte fra appens `/source`; hele den redigerbare kode er inkluderet.
Kildepakkens dokumenter er et snapshot før den afsluttende livekontrol; denne
leveringsmappe indeholder desuden den efterfølgende release- og testrapport.

## Funktioner

Fødselshoroskop med tidszoneregler, Placidus, True Node, positioner, retrogradstatus,
aspekter og SVG-download. Transitring med dato og afspilning. Solretur med valgt
opholdssted. Sekundære progressioner med én dag pr. år og Naibod-akser.
Synastri med to fødselshoroskoper, krydsaspekter og gensidige husplaceringer.
Chiron, Ceres, Eris, Haumea og Makemake er tilvalgt som standard.
Hjulet har pastelfarver, originale vektorsymboler og forbedrede markører.

## Drift og økonomi

Render Free i Frankfurt i ejerens tomme Hobby-workspace. Intet betalingskort,
ingen tidligere regninger og ingen betalte tjenester tilføjet. 0 $/måned for
den valgte instans. Ved inaktivitet kan opstart tage ca. et minut.
Gratis kvoter kontrolleret før oprettelse: 750 instanstimer, 5 GB trafik og
500 byggeminutter pr. måned, delt inden for dette workspace.
Den eksisterende Spørg Stjernerne-tjeneste i det andet workspace er uændret.

Dit horoskop er publiceret på https://www.stjernerne.io/dit-horoskop med link i
hovedmenuen og medlemsmenuen. Siden kræver ikke login. Render-appens `noindex`
er fortsat sat i HTML og HTTP-header; Squarespace-siden har sin egen SEO-indstilling.
Fødselsdata lagres ikke på serveren, og appens adgangslog er slået fra.

## Verifikation

123 Python- og 16 JavaScript-tests bestået plus en Linux-buildkontrol af
arbejdstråde. Den første deployment afslørede en Linux/Mac-forskel i Swiss'
thread-local tilstand; den er rettet ved understøttet TLSOFF-build og
proceslås. Den rettede version er kontrolleret via HTTPS for alle fem
horoskoptyper, fuld kildepakke, noindex og Origin-afvisning.
Browseren er afprøvet ved 390 og 1280 px samt med transitafspilning.

## Begrænsninger og videre arbejde

Historiske tidszoner før 1970 kræver konkret kontrol. Atlas er ikke et historisk
grænseatlas. Placidus afvises fra 66° nord/syd. De nye himmellegemer er valideret
mod Swiss-referenceprogrammet, ikke en anden motor. Progression bruger én
eksplicit Naibod-metode. Live Squarespace-indlejring er afprøvet i Chrome, også i inkognito uden login.
Squarespace-indlejringen er afprøvet i Chrome på 320, 375 og 390 pixels samt
liggende 844 × 390. Forbedringen af iframehøjden og kortere linktekst er publiceret og
kontrolleret på den offentlige side;
se MOBILE-QA.md for resultater og resterende kontroller. Safari/iOS og fysiske
telefoner er endnu ikke afprøvet.
Før større offentlig trafik bør rate limit bag proxy, kapacitetsbehov og
faglige referencehoroskoper gennemgås. Ingen automatisk opgradering er bestilt.

## Ny tilføjelse: fødselstidskorrektion

Publiceret og liveverificeret: tidsforskydning, kandidatoversigt og daterede
livsbegivenheder med langsomme transitter til AC/MC. Se RECTIFICATION.md.
Kildepakken blev dannet før livekontrollen; denne lokale leveringsmappe indeholder også den efterfølgende rapport.

## Lokalt bibliotek · 14. oktober 2026

Mine horoskoper gemmer valgte horoskoptyper, tidskandidater og begivenheder
lokalt i browseren. Backup/import, konfliktbeskyttelse og papirkurv er afprøvet.
Ingen serverdatabase eller betalt tjeneste tilføjet. Se LIBRARY.md.
Publiceret og liveverificeret: gemning og genåbning efter genindlæsning.
Se live-verification.json og release.json.

Den faktiske backupfil er efterfølgende flyttet fra Chrome til et separat
browserlager og genåbnet efter genindlæsning med begge tidskandidater og
livsbegivenheder bevaret. Ugyldig import blev afvist uden at ændre biblioteket.
Direkte app testet også ved 390 pixels. Import direkte i den publicerede
Squarespace-iframe er nu også verificeret med Chromes almindelige macOS-filvælger,
efterfulgt af genindlæsning, genåbning og begivenhedssammenligning på siden.
Fysiske mobilers filvælgere er fortsat uverificerede. Se BACKUP-QA.md.

## Navigation og brugertest · 14. oktober 2026

Ny navigation til fødselsoplysninger, hjul og bibliotek. Seks tydelige valg med
korte forklaringer; indstillinger kan foldes sammen. Mobilvisningen samler sig
om hjulet efter beregning. Stor hjulvisning med 100–220 % zoom, Escape og fokusretur.
Eksisterende biblioteksformat og beregningsmotor er uændrede.
Brugertestoplæg er udarbejdet; menneskelige deltagertests er ikke gennemført.

Navigation og zoom er publiceret på det eksisterende live-link og kontrolleret dér.
