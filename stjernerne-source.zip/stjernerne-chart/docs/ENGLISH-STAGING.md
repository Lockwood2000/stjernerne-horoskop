# English test environment

Prepared 16 October 2026 as a separate copy of the Stjernerne Chart Workshop.
This English test edition is not a replacement for the Danish production app.

## Preserved features

Original design, wheel and calculation conventions: tropical zodiac, Placidus,
True Node, Chiron, Ceres, Eris, Haumea and Makemake; transits and playback; solar
returns; secondary progressions with Naibod, whole-degree Kündig and centred
ARGUS keys; synastry; manual birth-time adjustments; Kündig and Bonatti sections;
candidates and life-event comparisons; local library, backup/import, restoration
and wheel download/zoom. The demonstration uses fictional birth details in London.

Labels, instructions, accessibility descriptions, server errors, dates and decimal
formatting are English. GeoNames place names keep their source spellings.

## Removed archive and isolation

The 189-person Danish birth-data archive, picker, public directory, deep-link
loader, supporting JavaScript, importer and archive-only tests/documentation are
absent, including from the corresponding source ZIP. No private charts, browser
libraries or life events are copied from production.

The English app uses a separate source directory, Git branch `english-test`,
Docker service, URL, IndexedDB database `stjernerne-en-test-library` and update
channel. The original input-only backup format remains compatible for explicit
import; there is no automatic reading or copying of the Danish library.

All browser calculation requests stay on the test origin. The production site
cannot make cross-origin API writes or embed this version by default. Search
engines are asked not to index it; that is not authentication. Corresponding
AGPL source and retained third-party notices are offered through `/source`.

## Verification

Original calculation tests are retained; language-dependent expectations are
updated and archive-only tests are removed. Additional staging tests cover
English content, archive absence, library separation, same-origin security and a
valid HTTP security header with no configured external frame parent.

Ten API scenarios were compared with the unchanged Danish source: 4,452 numeric
values were exactly equal locally. Covers natal, transits, solar return, three
progression methods, synastry, manual candidate, combined sections and ARGUS event
comparison. This tests translation regressions, not an independent ARGUS facit.
Eva's direct numerical ARGUS check remains pending in the original project.

## Hosting and cost

Before creating the service, the existing Render Hobby workspace showed one
service, 19.32/750 free instance hours, 278 MB/5 GB bandwidth, 9/500 pipeline
minutes, no payment card and $0.00 accrued/projected. Only a Free Docker service
is authorised. No paid resource, database, disk, upgrade or production-menu change.

Free services share workspace quotas with the Danish service. The test app may
sleep and need about a minute to start. No keepalive is configured. With no
payment method, exhausted free quotas cause suspension/build limits rather than
an automatic paid upgrade. Official details: https://render.com/docs/free .

Stripe Directory discovery was attempted. Its CLI/plugin was unavailable here;
the existing authenticated Render account and official Render documentation
provided the supported setup and current limits. No vendor account was created.

## Completed local checks

237 Python tests and 28 JavaScript tests passed. Browser checks covered all six
chart modes, transit playback, both solar keys, candidate/event comparison, local
save/reopen and backup/import with a second-resolution section and event. At
390×844 the document and scroll width were both 390 pixels. The large-wheel
dialog opened and closed correctly; the temporary viewport was reset.
Only fictional records were created on the local English origin.
