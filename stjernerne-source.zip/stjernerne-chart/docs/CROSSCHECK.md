# Uafhængig Kündig-krydskontrol · 15. oktober 2026

Dette dokument registrerer kontrollen af helgradsversionen før tilføjelsen af
ARGUS' centrerede solnøgle. Den nye valgmulighed beskrives i
SOLAR-KEY-VARIANTS.md. Den senere eksterne kontrol mod ARGUS-manualens
progressionsoutput findes i ARGUS-PROGRESSION-CROSSCHECK.md. Referenceværdierne
og den historiske kontrol nedenfor er bevaret.

## Resultat

Alle fire snit i en offentlig ARGUS-udskrift genfindes. Horoskopværkstedets
afrundede klokkeslæt er ét sekund tidligere i hver række. De uafrundede rødder
afviger med højst 1,085 sekund, og ARMC med højst cirka 1,3 buesekund.
Det er tæt numerisk overensstemmelse i dette eksempel, ikke bevis for identitet
med alle ARGUS-versioner eller korrekthed for alle datoer og steder.

Solnøglen stemmer med syv offentliggjorte taleksempler for **helgradskonventionen**
inden for ét buesekund pr. år. En dansk metodebeskrivelse angiver imidlertid,
at ARGUS bruger en grad centreret om den præcise fødselssol. Det er en anden
konvention end appens hele, indeholdende zodiakgrad. Derfor hævdes der ikke
numerisk ARGUS-identitet for solnøglen.

Ingen beregningsformel er ændret for at få tallene til at passe. Kontrollen
ændrer ingen gemte horoskoper og kræver ingen nye tjenester eller udgifter.

## 1. Eksternt ARGUS-eksempel: Richard Tarnas

Kilde: Eskild Rasmussen, [Kündig rectification](https://www.exploratoryastrology.dk/412065090/412065571).
Forfatteren oplyser, at han bruger ARGUS, og viser både radixdata og en
Kündig-snitliste. Tallene nedenfor er aflæst visuelt fra billederne
“The unrectified chart” og “Kündig cuts”; de er ikke genereret af vores kode.
Kilden kontrolleret 15. oktober 2026. Det er programmets offentlige udskrift,
som sammenlignes, ikke forfatterens vurdering af personens livsbegivenheder.

Inddata fra ARGUS-radix: 21. februar 1950 kl. 12:30:00, Genève, 46°12′ N,
6°09′ Ø, zone +01:00, Placidus. Testen bruger netop disse koordinater og et
eksplicit, kildeangivet offset på +60 minutter. Der hentes ikke nye koordinater
fra et byregister. UTC-tiden er 11:30:00. Testen bekræfter dermed overensstemmelse
med kildens tidszonevalg; den er ikke en uafhængig historisk tidszoneundersøgelse.

| ARGUS, lokal tid | Horoskopværksted, vist tid | Uafrundet tidsforskel | ARMC-forskel ved uafrundet rod |
|---|---|---:|---:|
| 11:42:46 | 11:42:45 | −0,715 s | +1,03″ |
| 13:04:14 | 13:04:13 | −1,084 s | +1,21″ |
| 14:12:04 | 14:12:03 | −0,759 s | +1,26″ |
| 14:44:38 | 14:44:37 | −0,595 s | −1,03″ |

Kildens ARMC-værdier er 317°37′18″, 338°02′33″, 355°02′55″ og 3°12′50″.
MC og AC er kun udskrevet til hele bueminutter; største afvigelser er
henholdsvis cirka 23,2″ og 31,4″, dvs. inden for ét trykt bueminut.

Testgrænserne er højst 2 sekunder for rå snitrod, 1 sekund for det afrundede
klokkeslæt, 2″ for rå ARMC og 60″ for de afrundede MC/AC-tabeller. Det er
praktiske sammenligningsgrænser for denne historiske udskrift, ikke en
dokumenteret nøjagtighedsgaranti fra ARGUS. ARMC sammenlignes ved den
uafrundede rod, så en efterfølgende afrunding af tiden ikke sammenblandes med
geometrien.

Den præcise årsag til tidsafvigelsen er ikke fastslået. ARGUS-version,
efemerider og alle tidsindstillinger fremgår ikke. Vi tilføjer derfor ikke en
vilkårlig korrektion på ét sekund og kalder ikke forskellen alene for afrunding.

**Kildens interval er inkonsistent:** Teksten siger to timer på hver side af
12:30, mens den sidste trykte række ligger kl. 14:44:38. De fire rækker
sammenlignes derfor med en søgning på ±3 timer. Vores yderligere snit kl.
09:48:36 og 15:10:14 ligger uden for det omtalte totimersinterval; den trykte
liste bruges ikke som en udtømmende reference for hele tretimersintervallet.

## 2. Solnøgle: uafhængige tal og forskellige konventioner

Christian Borups [Artikler om korrektion og prognose](https://astrologi-arkaden.dk/ebooks/christian-korrektion.pdf),
PDF-side 75–77 (talt fra 1), forklarer metoden og giver nedenstående nøgler.
PDF-side 76 er visuelt kontrolleret. Sammenligningen er geometrisk med
ekliptikahældningen 23°27′; den antager ikke en nøjagtig natal hældning for
alle artiklens eksempler.

| Solens indeholdende grad | Publiceret nøgle pr. år | Vores nøgle, afrundet |
|---|---|---|
| 0° Vædderen | 0°55′03″ | 0°55′03″ |
| 1° Vædderen | 0°55′03″ | 0°55′03″ |
| 2° Vædderen | 0°55′04″ | 0°55′04″ |
| 3° Vædderen | 0°55′05″ | 0°55′05″ |
| 0° Krebsen | 1°05′24″ | 1°05′24″ |
| 22° Vægten, Wilde | 0°56′21″ | 0°56′21″ |
| 7° Tvillingerne, JFK | 1°03′39″ | 1°03′39″ |

JFK-tallet kommer fra Bernd Muellers kommentar 3. august 2016 og Anthony Louis'
svar 4. august 2016 til [The Kundig Sun Key for Directing a Chart](https://tonylouis.wordpress.com/2016/07/30/the-kundig-sun-key-for-directing-a-chart/).
Mueller henviser til Kündigs bog, side 213, for den hele grads konvention.
Den originale bogside er ikke kontrolleret. Muellers afrundede RA-endepunkter
giver 1°03′38″ ved direkte subtraktion, mens hans angivne nøgle er 1°03′39″;
vores uafrundede geometriske værdi er 1°03′38,86″. Denne kildeafrunding er
derfor omfattet af testgrænsen på ét buesekund.

Borups omtrentlige håndberegnede Wilde-tabel giver MC 11°31′ Krebsen ved
30 år og 8°16′ Løven ved 60 år. Med artiklens natal-MC 15°34′ Tvillingerne
beregner vores geometri 11°30′01″ Krebsen og 8°15′26″ Løven. Begge er inden
for ét bueminut. Dette er en kontrol af nøgle/MC-geometrien med afrundede
inddata, ikke en fuld ARGUS-progression fra fødselsdato til begivenhedsdato.

### Vigtig forskel mellem varianter

Appens dokumenterede valg er:

    g = floor(natal sollængde)
    nøgle = RA(g + 1°) − RA(g)

Borups beskrivelse af ARGUS er:

    nøgle = RA(natal sollængde + 0°30′) − RA(natal sollængde − 0°30′)

De to varianter kan give lidt forskellige akser, især efter mange leveår.
De afrundede Wilde-tal kan ikke skelne mellem dem. ARGUS-manualens generelle
beskrivelse af én ekliptisk solgrad løser ikke i sig selv valget af gradgrænser.
Den nuværende funktion er derfor kontrolleret som helgradsvarianten og skal
ikke præsenteres som en verificeret kopi af ARGUS' centrerede solnøgle.
Planeterne i appen følger stadig almindelig direkte sekundærprogression;
solnøglen anvendes på ARMC og derfra akser og huse.

### Trykfejl og kildebegrænsninger

Borups værdi for 29° Vædderen, 0°57′55″, afviger med cirka 40″ fra
helgradsformlen (cirka 0°57′15″). Den bruges ikke som godkendt facit.
I det centrerede regneeksempel for 10°59′ angives desuden grænserne 9°29′
og 10°29′, hvor plus/minus 30′ ville give 10°29′ og 11°29′. Disse interne
uoverensstemmelser er grunde til at krydstjekke kilder frem for at tilpasse
vores formel til alle trykte tal.

Der er ikke kørt en selvstændig ARGUS-installation, og kontrollerne er ikke
en fuld validering af alle Kündig-prognoser, Bonatti, livsbegivenheder eller
hele dato-/breddegradsintervallet. Snit er astrologiske tidskandidater;
numerisk overensstemmelse dokumenterer ikke personens faktiske fødselstid.

## 3. Gentagelig test

Publicerede tal og kildeoplysninger ligger i
`tests/kundig-published-reference.json`. De 17 nye tests i
`tests/test_kundig_reference.py` kontrollerer fire uafrundede snit med geometri,
de fire afrundede tidspunkter gennem det offentlige API, syv solnøgler og
to omtrentlige MC-positioner. Referencefilen må ikke regenereres ud fra
vores egen motor.

Fra projektmappen med projektets Python-miljø:

    python -m pytest -q tests/test_kundig_reference.py
    python -m pytest -q

Resultat: **17 af 17 referencetests og 192 af 192 Python-tests bestod**.
Der var én eksisterende advarsel fra testbiblioteket om dets HTTP-klient;
ingen testfejl. JavaScript er uændret i denne beregningskontrol.

Den kontrollerede beregningskode er byte-identisk med kildepakken fra den
seneste udgivelse før kontrollen, SHA-256:
`566b1ee45ac2fd8f25ed834c67c62d8bc47d8fbe25d18e225262f977e760c15d`.
Denne gennemgang tilføjer testgrundlag og dokumentation; beregningskoden
og den eksisterende kildepakke er bevaret.

### Kontrol af den aktuelle liveversion

Det samme referenceinput er sendt til den eksisterende beregner på
`https://stjernerne-horoskop.onrender.com/api/rectify/kundig`. Alle seks
tidspunkter i tretimerssøgningen, metodeoplysninger og tidszoneoplysninger
stemmer med den lokale version. De fire publicerede ARGUS-rækker vises live
som 11:42:45, 13:04:13, 14:12:03 og 14:44:37. En forskel i MC/IC på cirka
0,0000073 buesekund mellem server og lokal maskine ligger på
flydende-talsniveau og ændrer ingen viste værdier.

Den offentlige `/source`-pakke er også hentet på ny: dens SHA-256 er identisk
med ovenstående. Filerne for snit, efemeridemotor, solnøgle, progressioner og
API er sammenlignet byte for byte med den testede kode. Kontrollen gælder
dermed den aktuelle liveberegner; der er ikke foretaget en ny deployment.
Den fulde måling og rå API-respons er gemt i arbejdsområdets
`work/crosscheck/results.json` og `work/crosscheck/live-cuts.json`.
