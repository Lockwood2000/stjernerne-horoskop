# Astrology University · fire personlige studieværksteder

Opdateret 16. oktober 2026. Den eksisterende lokale skoleversion er udbygget;
ingen ændringer i den oprindelige generator eller Institutets beregningsmoduler.

## Kursusgrundlag

Originale arbejdsøvelser med afsæt i offentlige beskrivelser. Betalingskursernes
lektioner og lærerfacit er ikke gengivet, og skolen har ikke godkendt udgaven.

| Værksted | Underviser / offentlig kilde | Faktisk funktion |
|---|---|---|
| Chart Synthesis | [Tony Howard og Karen Hamaker-Zondag](https://www.astrologyuniversity.com/shop/courses/chart-synthesis-101/) og [Planet–Sign Blending](https://www.astrologyuniversity.com/planet-sign-blending-course/) | Planet, tegn og hus; Sol/Måne/AC; dispositør og herskerkæde; valgbare aspekter; egne planetnoter og samlet syntese. |
| Your Year Ahead | [Kelly Surtees: Plan Your Year Ahead](https://www.astrologyuniversity.com/shop/search-by-astrologer/kelly-surtees/plan-2026-course/) og [Layering Progressions & Profections](https://www.astrologyuniversity.com/shop/search-by-astrologer/kelly-surtees/progressions-profections-france-2027/) | Årsprofection, aktiveret hus, traditionel årshersker, klikbar cyklus på tolv år, langsomme transitter og progressiv Måne på den valgte dato, dateret dagbog. |
| Prenatal Lunation | [Israel Ajose](https://www.astrologyuniversity.com/shop/search-by-astrologer/israel-ajose/the-prenatal-lunation/) | Sidste ny- eller fuldmåne før fødslen; begge luminarer; graden i fødselshusene; traditionel hersker; aspekter til radix; fødslens månefase; egne noter. |
| Relationship Dynamics | [Brian Clark: Relationship Astrology 101 – Synastry](https://www.astrologyuniversity.com/shop/four-year-courses/relationship-astrology-101-synastry/) | To egne fødselshoroskoper, synastrihjul, aspektfiltre og fremhævning, huse i begge retninger, tre refleksionsfelter. |

## Regler og afgrænsninger

- **Årsprofection:** afsluttet kalenderalder modulo tolv, hus 1 ved alder 0.
  Nyt år på fødselsdagen. Slutdatoen er eksklusiv. For fødsel 29. februar
  bruges 28. februar i almindelige år; denne lokale kalenderkonvention er
  udtrykkeligt beskrevet og tilskrives ikke Kellys kursus.
- **Huse og herskere:** årsprofection bruger altid Ascendantens tegn, Whole Sign
  og traditionelle herskere. Radix beholder brugerens valgte hussystem og
  dispositørindstilling. Alligevel kan årsherskeren dermed være en anden end
  en moderne tegnhersker valgt i radix.
- **Dagsbillede:** transitter beregnes kl. 12 UTC. Hvis fødslen på samme dato
  ligger senere, bruges selve fødselstidspunktet. Jupiter–Pluto og valgte
  måneknuder indgår. Sekundær progressiv Måne bruger den progressive Sol til
  fasevinklen, én efemeridedag pr. 365,2422 levede dage. Alle aspektorber følger
  brugerens indstillinger. Ingen månedlige profectioner eller søgning efter
  alle årets eksakte begivenheder; den eksisterende transitdagbog kan bruges
  til sidstnævnte.
- **Usikker tid:** ukendt tid giver ingen årsprofection eller progression;
  transitter til nominelle radixpositioner er stadig tilgængelige. Cirka-tid
  prøver 25 Ascendanter over intervallet og viser alternative tegn/herskere,
  når de forekommer. Dette er prøver, ikke en garanti for ekstreme værdier.
- **Prænatal lunation:** konjunktion eller opposition mellem apparent,
  geocentrisk tropisk Sol- og Månelængde. Sidste hændelse ved/før fødslen.
  Seks timers søgeintervaller, rodforfinelse til 0,25 sekund; UTC-visning.
  Numerisk præcision er ikke det samme som historisk tidsnøjagtighed.
- **Fuldmåneaksen:** begge luminarers grader vises. Værkstedets studiegrad,
  traditionelle hersker og aspekter bruger Månens ende af aksen. Det er en
  eksplicit implementeringskonvention; en undervisergodkendelse af skolens
  foretrukne fuldmånekonvention er en senere opgave.
- **Lunationshuse:** graden placeres i radixhusene, ikke huse for selve
  lunationsøjeblikket. Ukendt fødselstid udelader huse/akser. Krydses en
  lunation af fødselsintervallet, vises begge mulige prænatale hændelser.
- **Synastri:** B → A i aspektlisten, A som inderste hjul. Planetplaceringer i
  den andens huse vises i begge retninger; huse udelades, når modtagerens
  fødselstid er ukendt. Ingen kompatibilitetsscore eller automatisk
  relationsdom. Person B skal indtastes og beregnes; prøvefelter bruges ikke
  automatisk som en virkelig anden person.
- **Punkter:** værkstederne supplerer hovedhoroskopets valgte punkter med de ti
  hovedplaneter. De originale indstillinger i hovedhoroskopet ændres ikke.
- **Lagring:** `university` følger version 1-studiefilen, med bagudkompatibel
  standard ved gamle filer. Op til 60 notefelter à 3.000 tegn, inklusive
  planet- og datoopdelte noter. Gem/genåbn og JSON-eksport/import medtager
  person B, også når hovedhoroskopet senere står i natal-tilstand. Lagring
  sker først ved Gem; noteændringer markeres i værkstedet.

## Visuel identitet

[Skolens hjemmeside](https://www.astrologyuniversity.com/) bruger Libre Baskerville,
Montserrat, blå flader og grønne handlingsknapper. Den lokale udgave bruger de
allerede licenserede lokale skrifter, et blåt/grønt farvesystem, egne geometriske
SVG-illustrationer og fire forskellige arbejdsflader. Skolens logo og billeder
kopieres ikke. Dansk/engelsk, tastaturfokus og reduceret bevægelse understøttes.

Direkte indgange: `/university#study-rooms`, `#year-ahead`,
`#prenatal-lunation` og `#relationships`.

## Kontrolgrundlag

- Fire uafhængige månefaser fra [US Naval Observatory](https://aa.usno.navy.mil/calculated/moon/phases?date=2024-03-01&format=p&nump=8):
  10. marts 2024 kl. 09:00 UT, 25. marts kl. 07:00 UT, 8. april kl. 18:21 UT,
  23. april kl. 23:49 UT. Sammenligning inden for et minut.
- Aldre/huse fra [Kellys offentlige worksheet](https://kellysastrology.com/pdf/ProfectionsWorksheet.pdf)
  og hendes offentlige Adele-eksempel (alder 37, Krebs-Ascendant, andet hus,
  Løven og Solen). Der påstås ikke kontrol mod internt kursusfacit.
- Automatiske grænsetilfælde: fødselsdag, skuddag, før/efter lunation,
  usikkert tidspunkt, ukendt tidspunkt, moderne herskervalg, husvalg,
  intervalslutning 2099 og ugyldige data.
- JavaScript-kontrol: gamle filer, begge personers data, notesikkerhed,
  eksport/import, datogrænser og retningsbevarende relationsfiltre.

Kildearkiv før ændringerne:
`../school-chart-backups/before-university-workshops-2026-10-16.zip`.
