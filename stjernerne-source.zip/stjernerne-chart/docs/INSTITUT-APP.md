# Institut student app

The existing `/institut` workspace is installable without login. It keeps its
existing calculation engine, library, notes, JSON import/export and print views.
The University page does not advertise this app's manifest.

Students open the public Institut link and choose **Installér app** for device
instructions. Chromium shows a native install action when eligible. iPhone/iPad
use Safari → Share → Add to Home Screen; macOS Safari can Add to Dock.
Installation UI and storage behavior depend on the browser/OS version.

This is an online app: opening the workspace and calculating require internet.
Only a generic offline information page is cached by the service worker. Charts,
API responses, birth details and notes are never placed in that cache. Existing
saved study records stay in IndexedDB; export them for backup or transfer between
browsers, installations and devices. There is no login or cloud synchronization.
School profile settings remain proposals awaiting the school's validation.

The manifest, original celestial app icons and installation UI live in
`static/school/pwa`. `/institut-sw.js` has scope `/institut`. Network requests
remain fresh and updates arrive on reopening; no forced page reload interrupts
unsaved work. The worker only handles failed navigation to the Institut entry.
The offline cache is separately versioned and removes only its own old versions.

Verification: 426 Python tests and 64 JavaScript tests passed. Chrome on macOS
exposes the native installation action; the installation dialog and existing
chart rendering were checked locally. Physical iPhone/Android installation has
not been tested. The hosting plan may delay startup after server inactivity.

## Mobile interface, 17 October 2026

At widths up to 720 px the Institut workspace now has a home screen, recent
study cards and four bottom-navigation destinations: Home, Chart, Study rooms,
and My studies. Birth data has a separate view. Existing DOM form controls,
calculation calls and IndexedDB records remain the source of truth. Navigation
hides views without recreating form data or notes. Opening a saved record uses
the existing validation and recalculation path.

Exercises and chart visibility controls fold away on mobile; chart actions sit
below the wheel. On larger screens they return to their existing positions and
the full workspace is visible. All new interface pieces are excluded from print.
The UI follows the selected Danish/English language. No new service or cost.

Verified in Chrome at 375 px and 319 px (no horizontal page overflow), then at
883 px after a live resize (desktop controls restored). Tested calculate → chart,
save → home → recent study → reopen, notes retained across study-room navigation,
and PDF output with notes (zero page overflow). 426 Python and 64 JavaScript
checks passed. Physical iOS/Android testing remains outside this verification.
