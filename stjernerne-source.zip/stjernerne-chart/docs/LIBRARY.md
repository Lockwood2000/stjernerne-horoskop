# Mine horoskoper · 14. oktober 2026

## Brug

Åbn Mine horoskoper, giv horoskopet et navn, og vælg Gem som nyt. En gemning
indeholder de beregnede fødselsoplysninger, den valgte horoskoptype samt op til
fem tidskandidater og fem livsbegivenheder. Gem ændringer opdaterer den sidst
åbnede eller gemte post. Der gemmes ikke automatisk under indtastning.

Åbn genberegner horoskopet og gendanner felterne. Solreturens år/sted,
progressionens måltid, transitdato/tidszone/fold og synastriens person B/ringvalg
følger med, når den pågældende visning gemmes. Både originalens sekunder,
manuelle tidskilde, IANA-zone og foldvalg bevares. Tidskorrektion gendanner også
et aktuelt visningstidspunkt, der endnu ikke er tilføjet som beholdt kandidat.
Begivenhedssammenligningen beregnes igen med knappen Sammenlign.

Til papirkurv skjuler posten uden at slette den; Gendan bringer den tilbage.
Der er ingen permanent sletning i denne version. Biblioteket har plads til
100 poster inklusive papirkurven.

## Lokal lagring og backup

Lagringen er browserens IndexedDB, database `stjernerne-library`, version 1,
store `charts`. Ingen konti, central database eller automatisk synkronisering.
Oplysningerne er knyttet til appens origin og browserprofil. Lokal prototype,
Render-domænet, en anden browser og en senere iframe kan have separate lagre.
Brug eksport/import til flytning og åbn eventuelt generatoren direkte, hvis
indlejringsbrowseren begrænser lagring. Safari/iOS- og Squarespace-lagring er
ikke testet.

Data er ikke krypteret med en særskilt adgangskode; personer med adgang til
browserprofilen kan åbne biblioteket. Rydning af browserdata, privat browsing,
profilskift eller browserens lagerpolitik kan fjerne det. Eksportér derfor en
backup, hvis data skal bevares uafhængigt af browseren. En JSON-backup indeholder
læsbare fødselsdata og begivenheder og skal opbevares privat.

Eksport inkluderer alle gemte poster og papirkurvsstatus. Import opretter nye
kopier og bevarer eksisterende poster. Højst 1 MB og 100 poster pr. bibliotek;
hele filen valideres før nogen skriveoperation. Format/version er eksplicit,
og ukendte felter/versioner eller ugyldige data afvises. Beregningsresultater
fra importerede filer accepteres ikke; kun validerede inddata genberegnes.

Biblioteksnavne og begivenhedslabels sendes ikke til serveren. Når en post
åbnes, sendes dens fødselsdata og relevante datoer til den eksisterende
beregningsserver. Internet/serveradgang er nødvendig til genberegningen.
Den gemte post bevares, hvis genberegning fejler. Serveren gemmer fortsat ikke
fødselsdata eller begivenheder.

## Integritet og test

IndexedDB readwrite-transaktioner kontrollerer postens revision før ændring.
En ældre fane kan ikke overskrive en nyere revision; den kan åbne seneste post
eller gemme som ny. Import og antalskontrol ligger i samme transaktion, og en
fejl ruller hele skrivningen tilbage. BroadcastChannel opdaterer listerne i
andre faner uden at overskrive deres igangværende arbejde.

123 Python- og 16 JavaScript-tests dækker beregningsmotoren og importformatets
rundtur, alle horoskoptyper, fold/manuelle offsets, ugyldige datoer, antals- og
størrelsesgrænser, ukendte felter og afkobling fra mutable inputobjekter.
Browserprøver: gem/åbn efter genindlæsning, kandidat- og begivenhedsgendannelse,
to-fane-konflikt, eksport/import som kopi, afvisning af en delvist ugyldig
backup, papirkurv/gendannelse, synastri med omvendte ringe, transitter med
tabel, solretur/progression samt 390 px uden vandret side-overflow.
