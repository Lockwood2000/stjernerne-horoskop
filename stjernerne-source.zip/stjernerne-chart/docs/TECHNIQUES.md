# Solretur, sekundære progressioner og ekstra himmellegemer

## Brug

Vælg **Horoskoptype** over hjulet, efter fødselshoroskopet er beregnet.
Solretur kræver årstal og opholdssted (som standard fødested). Sekundære
progressioner kræver måldato og klokkeslæt i UTC. Begge viser et selvstændigt
horoskop med positioner, huse, interne aspekter og SVG-download.
Skift tilbage til Fødselshoroskop og transitter for transitring og afspilning.

Chiron, Ceres, Eris, Haumea og Makemake er tilvalgt som standard og kan samlet
slås fra i fødselsformularen. De medregnes også i transitter, solretur og progressioner.

## Metoder

Solretur: tropisk, tilsyneladende geocentrisk sollængde lig med den natale
sollængde. Newton-iteration med Swiss Ephemeris' solhastighed; tolerance 1e-8°.
Ingen præcessionskorrektion. Det samme globale returøjeblik bruges uanset sted;
valgt sted bestemmer Placidus-huse, AC/MC og lokal tidsvisning.

Sekundære progressioner: direkte, én efemeridedag pr. 365,2422 forløbne levedage.
Målet omregnes til UTC før beregning. Akser: Naibod i rektascension, 0,98564733°
pr. leveår lagt til natal ARMC. Placidus beregnes med fødestedets breddegrad
og sand ekliptikahældning ved progressionens efemeridetid. Det er én eksplicit
valgt metode; andre programmer kan bruge andre nøgler/akser. Der udføres ingen
relokation af progressionen. Hastighed skaleres til grader pr. levedag.

Aspekter: fem hovedaspekter som i fødselshoroskopet. Ekstra himmellegemer og
knuden har højst 3° natal/afledt orbis og 2° til transit–natal-aspekter.

## Data og symboler

Ceres og Chiron bruger den originale `seas_18.se1`. Eris (136199), Haumea
(136108) og Makemake (136472) bruger Swiss Ephemeris-filer i `ast136` fra den
mirror, som projektets officielle fastlåste README henviser til. Alle filer
har SHA-256 og oprindelsesadresse i `data/upstream-manifest.json`.
Manglende filer afvises; der bruges ingen skjult tilnærmelse.

Solen, Månen, hovedplaneterne, knuden, Chiron og Ceres har originale SVG-symboler.
Chiron bruger nøgleformen og Ceres seglformen. Eris/Haumea/Makemake vises med
Er/Ha/Mk; de præsenteres ikke som standardiserede astrologiske glyffer.

## Verifikation

111 Python-tests og 7 JavaScript-tests bestået 13. oktober 2026.
De nye tests sammenligner fire epoker for hver dværgplanet og tre for Chiron
med `swetest`. Det kontrollerer binding og body-ID, men er samme motor/data,
ikke uafhængig astronomisk verifikation.
Solretur sammenlignes med Swiss' `swe_solcross`, restfejl og ±1-sekund-bracketing;
årsskifte, skuddag, 0°-passage og relokation er dækket.
Progression kontrollerer nulalder, 1/30/90 år, dagsnøgle, hastighedsskala og
AC/MC mod selvstændige sfærisk-geometriske formler.
API-validering dækker ugyldige felter, tidszonekonflikter og manglende indstillinger.

Metodereferencer: https://www.astro.com/swisseph/swephprg.htm og
https://www.astro.com/faq/fq_fh_owtype_e.htm .
