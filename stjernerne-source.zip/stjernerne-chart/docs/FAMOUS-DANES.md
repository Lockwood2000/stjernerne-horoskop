# Kendte danskere · 14. oktober 2026

Personvælgeren læser 189 poster fra hovedfanen i den gennemgåede oversigt.
De 10 uafklarede og den udeladte tyske astrolog medtages ikke. Originalarkiv:
https://www.astrologi-arkaden.dk/dataarkiv/ . Supplerende kilder og noter følger
de relevante poster. Navne og rating er bevaret, inklusive alternative tider.

Søgningen ignorerer store/små bogstaver og understøtter æ/ae, ø/o og å/a.
Valget alene ændrer ikke formularen; knappen Brug disse fødselsoplysninger
indsætter dato, tid, koordinater og arkivets UTC-forskel. Hjulet markeres som
forældet indtil en ny beregning. Eksisterende gemte horoskoper autoskrives ikke.

Manglende bynavne bliver ikke gættet. Koordinater og manuel UTC-forskel bruges
direkte; IANA-feltet er UTC som neutral basis, og den eksplicitte forskel
har forrang. Kildenoten indeholder navn, rating og arkivzone og følger med i
gemte horoskoper gennem det eksisterende offset_source-felt.

Begrænsninger: 36 poster er før 1900 og kan ses, men ikke indsættes i denne
generator. Nulkoordinater og breddegrader uden for Placidus-området blokerer
også indsættelse. Rating X efterlader tiden tom og kræver en særskilt tidskilde.
Ingen ukendt tid erstattes med middag eller midnat. De øvrige ratings er ikke
nyvalideret; kildenoter og usikkerheder er synlige før indsættelse.

Kontrol: 21 JavaScript-tests, herunder arkivudvalg, navnesøgning, alternative
tider, præcise sekunder, koordinater, UTC-forskel og blokering af ugyldige data.
Browserprøve: Birthe Kirk 2 indsætter 1942-10-22 06:12:17, 55°32′N 11°21′E,
UTC+02:00; beregningen viser 04:12:17 UTC og bevarer kilden i beregningsgrundlaget.

Offentlige biografiske arkivdata er medtaget i famous-danes.json. Der medtages
ingen private brugerhoroskoper. Datakildernes eventuelle rettigheder ændres ikke
af programmets AGPL-licens.
