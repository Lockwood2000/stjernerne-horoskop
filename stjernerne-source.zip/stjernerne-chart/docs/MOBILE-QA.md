# Mobilkontrol · 14. oktober 2026

Testet på den offentliggjorte https://www.stjernerne.io/dit-horoskop i Chrome
inkognito, med DevTools-profilen iPhone SE (375 × 667 CSS-pixels). Dette er
Chromium-emulering af mobilvisning og touch, ikke Safari eller en fysisk iPhone.
Alle data var appens fiktive eksempelhoroskoper eller tydeligt mærket Mobiltest.

## Verificeret via brugerfladen

- Mobilmenuen åbner og viser Dit horoskop uden login.
- Indlejret formular og fødselshoroskop kan vises og beregnes. Mobilens datovælger
  blev særskilt afprøvet med en livsbegivenhed.
- Det store hjul åbner og lukker. Zoomkontrollen kunne ændres fra 100 til 220 %.
- Planetoversigten indeholder Chiron, Ceres, Eris, Haumea og Makemake; aspektfanen
  viser beregnede forbindelser. Brede oversigter har egen vandret rulning.
- Transitdato flyttes én dag frem. Afspilning startede ved 15. oktober 2026 og
  blev pauset ved 23. oktober; hjulets ydre ring og dato blev opdateret.
  Transitoversigten viste 18 aspekter til eksempelhoroskopet.
- Solretur 2026 beregnes: København, 15. juni kl. 07:23:40.
- Sekundære progressioner for 14. oktober 2026 beregnes med Naibod-akser.
- Synastri mellem de to eksempelhoroskoper beregnes og viser 55 krydsaspekter.
- Fødselstidskorrektion +15 minutter ændrer 14:30 til 14:45, AC fra 9°03′ til
  11°33′ Vægten og MC fra 12°30′ til 16°00′ Krebsen. Kandidaten kan beholdes.
- Kalenderen accepterer begivenheden “Mobiltest – flytning”, 1. oktober 2026.
  Sammenligning af original og +15 minutter viser Saturn kvadrat MC (0°58′23″)
  henholdsvis Saturn opposition AC (0°01′21″).
- “Mobiltest 14. oktober” blev gemt med 2 tidskandidater og 1 begivenhed.
  Efter genindlæsning af hele Squarespace-siden kunne det genåbnes med korrekt
  kandidat, klokkeslæt og begivenhed. Dette dokumenterer samme sessions browserlager,
  ikke opbevaring efter lukning af inkognito eller synkronisering mellem enheder.
- SVG-download er gennemført i den efterfølgende kontrol. Filen er gyldig XML/SVG,
  viewBox 0 0 880 880, og titlen svarer til Aarhus, 1990-06-15 kl. 14:31.
- Backup-download er gennemført: JSON-format stjernerne-horoskoper, version 1,
  ét testhoroskop med korrekt by, klokkeslæt og kandidat. Ingen rigtige persondata.

Skærmbillede: ../../mobile-wheel-375.png (hjul-dialog ved 220 %).

## Automatiske kontroller

Genkørt samme dag: 123 Python-tests og 16 JavaScript-tests består.
En eksisterende Starlette/httpx-deprecation warning forekommer.
Testene omfatter beregninger, afspilning, symbolplacering og backup-validering;
de erstatter ikke browser- eller fysisk enhedstest.

## Udvidet kontrol efter Chrome blev frigivet

Chrome viewportkontrol på 320 × 640, 390 × 844 og 844 × 390 pixels.
Det er størrelsestest, ikke en komplet emulering af Safari eller Android.
På 320 pixels blev klokkeslættet ændret til 14:31:00, Aarhus søgt og valgt,
og horoskopet beregnet med korrekt by og tidspunkt. Iframe/body-bredde var begge
272 pixels, også med zoomdialog åben: ingen vandret udvidelse af selve dokumentet.
Dialogens bredde var 266,55 pixels. Zoomkontrollen og lukning fungerede.
På 390 pixels blev hele hjulet og kontrollerne visuelt kontrolleret.

Liggende visning afslørede en for høj minimumshøjde i Squarespace-indlejringen:
540 pixels på en skærm med 390 pixels i højden. Rettelsen er publiceret fra
squarespace-embed.html og work/publication/squarespace-code-block.html:
min-height: 0, fortsat height: 82svh og max-height: 900px.
Den lokale /embed-test bruger nu samme faste viewporthøjde og ingen automatisk
udvidelse til hele dokumentets højde. Ved lokal kontrol var iframehøjden 318 pixels
og dialogen 305,27 pixels; lukning og zoom er inden for rammen. Selve hjulet kan
rulles i zoomfeltet. Skærmbillede: ../../mobile-landscape-local.png.

Rettelsen er publiceret på Squarespace 14. oktober 2026 efter brugeren åbnede
editoren. Save afsluttede med Page · Published. Ingen ny Render-release eller betaling.

Linket “Åbn horoskopet i eget vindue” åbner appen med hele browserens bredde.
Den kortere tekst “Åbn i fuld størrelse ↗” er publiceret og kontrolleret på den
offentlige side. Adressen er bevaret og åbner i en ny fane.

Skærmbillede af livevisningen: ../../mobile-wheel-390.png.

## Resterende kontroller

- Filimport er efterfølgende gennemført i den direkte app, også ved 390 × 844.
  En faktisk Chrome-backup blev flyttet til et separat browserlager, genåbnet
  efter genindlæsning og kontrolleret med kandidater og begivenheder.
  Delvist ugyldig backup blev afvist uden ændringer. Se BACKUP-QA.md.
- Filvælgerforløbet inde i Squarespace-iframe er nu afsluttet i Chrome på macOS
  via den almindelige filvælger. Import, bevarelse af eksisterende post,
  genindlæsning, genåbning og begivenhedssammenligning bestod. Se BACKUP-QA.md.
- Fysisk iPhone/Safari og Android, herunder skærmtastatur, filvælger og pinch-zoom.

Ved et forsøg på at undersøge Chrome-vinduet afviste automatisk godkendelseskontrol
bred AX-læsning, fordi Gmail var forrest. Derefter anvendtes kun afgrænsede
browserfaner. Private maildata er ikke anvendt til denne opgave.

## Efterkontrol af publiceringen

Den offentlige iframe målte 321,8 pixels inklusive kant ved 844 × 390.
Chrome-fanens lazy iframe forblev about:blank i browserstyringen, så
funktionskontrollen blev gennemført i appens browser på den genindlæste
offentlige side. Her indlæstes beregningsappen; dialoghøjden var 307,2 pixels
i en iframe med 320 pixels indvendig højde. Åbn/luk blev verificeret i liggende
844 × 390 og stående 390 × 844. Den nye linktekst fremgik samtidigt.
Skærmbilleder: ../../mobile-landscape-live.png og ../../mobile-published.png.
Viewport blev nulstillet efter kontrollen.
