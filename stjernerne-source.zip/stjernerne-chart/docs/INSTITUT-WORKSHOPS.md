# Institut · fire personlige værksteder

Implementeret 16. oktober 2026 i den lokale skoleversion. Åbnes under
**Fordybelse** eller `/institut#fordybelse`. Designet viderefører Raleway,
Mulish, creme, guld og dæmpet salvie. De egne refleksionsspørgsmål er inspireret
af offentlige kursusbeskrivelser; de er ikke kopier af interne undervisningsark.

## Venus Star Point

Kursus: [Marie Malling · Dit Venus Star Point](https://www.astrologiskinstitut.dk/product-page/venus-star-point).
Metode: [Guttmans offentlige beskrivelse](https://sophiavenus.com/how-do-we-find-and-analysis-our-vsp/)
og [interviewet med Arielle Guttman](https://theastrologypodcast.com/2022/10/12/the-venus-star-point-cycle-with-arielle-guttman/).

- Personligt punkt: seneste Sol–Venus-konjunktion ved eller før det angivne
  fødselstidspunkt. Direkte og retrograde konjunktioner medtages.
- Fem punkter: dette punkt plus to tidligere og to efterfølgende konjunktioner.
  SVG placerer dem efter beregnet zodiaklængde med personligt punkt øverst;
  stjerneforbindelsen er en grafisk konstruktion mellem disse punkter.
- Swiss Ephemeris: geocentrisk, tilsyneladende, tropisk ekliptisk længde.
  To dages søgetrin, rødder forfinet til 0,25 sekunders numerisk tolerance.
  Tidsangivelserne er UTC. Numerisk tolerance er ikke historisk nøjagtighed.
- Retrograd/indre konjunktion starter morgenstjernecyklussen; direkte/ydre
  starter aftenstjernecyklussen. Venus' fase ved selve fødslen beregnes og
  vises særskilt ud fra fortegnet på dens længdeforskel til Solen. Nær 0,01°
  står der »nær konjunktion«. Faktisk synlighed ved horisonten beregnes ikke.
- Rytmer: søg faktiske konjunktioner inden for ±45 dage omkring 4, 8, 12 …
  tropiske år efter det personlige punkt. Brugeren vælger 40/80/120 år;
  rytmelisten stopper før 2100. Datoerne er ikke blot kalenderårsdage.
- Huse og aspekter vedrører placeringen i fødselshoroskopet; orbis følger
  lærerindstillingerne. Venus tilføjes i denne visning, hvis den var fravalgt.
- Ved ukendt tid bruges lokal middag, og fødselshuse udelades. Hvis intervallet
  for ukendt/cirka tid indeholder en konjunktion, vises de mulige personlige
  punkter og en tydelig besked om det foreløbige valg.
- SVG indeholder beregningsgrundlag og kilder som metadata. Noter og den
  valgte visning følger studiearbejdet; en cyklusdato kan tilføjes som en
  tydeligt navngivet Venus-begivenhed i livslinjen.

Ekstern numerisk kontrol:
[Guttmans tabel](https://sophiavenus.com/wp-content/uploads/2020/05/FindYourVenusStarPoint.pdf),
PDF-side 5, med eksplicit CDT-konvention (UTC−5) på sidste side:

| UTC, trykt minut | Trykt længde | Type |
|---|---|---|
| 3. juni 2020 17:43 | 13°35′ Tvillingerne | Retrograd |
| 22. oktober 2022 21:17 | 29°26′ Vægten | Direkte |
| 13. august 2023 11:15 | 20°28′ Løven | Retrograd |

Alle tre ligger inden for to minutter i tid og ét bueminut i længde.
Demofødslens punkt kontrolleres også mod 18. januar 1990, 28°35′ Stenbukken.
Testene dækker konjunktionsgrænsen, usikker fødselstid, de fem punkters
rækkefølge, skiftende cyklustype og grænseårene 1500/2099.

## Måneknudeværksted

Kursus: [Karsten Zeuthen · Måneknuderne](https://www.astrologiskinstitut.dk/product-page/m%C3%A5neknuderne-2026).

Begge knuder, deres herskere, herskernes dispositørkæder og aspekter vises.
Solen–Pluto og knuderne medtages i denne visning, så herskerne altid findes,
selv hvis de er skjult i hovedhjulet. Lærerindstillingerne afgør sand/middel
knude, huse, orbis og traditionelle/moderne herskere. Hjulet fremhæver aksens
punkter og herskere; hele hjulets aspektnet kan også vises. Tre felter til
personlige observationer gemmes med studiearbejdet. Der genereres ingen
personlighedstydning på elevens vegne.

## Livslinje

Kursus: [Louise Bunnage · Horoskopets tid](https://www.astrologiskinstitut.dk/product-page/horoskopets-tid).

- Op til 40 begivenheder med dato, navn og noter. Flere begivenheder på samme
  dato er tilladt; beregningen genbruger ét dagsbillede for den dato.
- Begivenheder kan redigeres eller fjernes med mulighed for at fortryde den
  seneste fjernelse, mens værkstedet er åbent. Gemning følger det almindelige
  studiearkiv; der er ingen automatisk cloud-lagring.
- Tidslinjens afstande er proportionale med tiden siden fødslen. Tætte datoer
  kan vælges i listen, også når markører overlapper.
- Transitter og sekundære progressioner beregnes kl. 12 UTC på hver dato.
  Dette er et dagsbillede, ikke en søgning efter en præcis transitpassage.
- Standardfokus: transitter fra Solen–Pluto og progressioner fra Solen–Mars
  samt AC/MC, til radix Solen–Pluto og AC/MC. Valget »Alle valgte punkter«
  medtager også knuder og småplaneter. Begge respekterer de valgte punkter,
  aspektvinkler og akseindstillinger. Livslinjens maksimale orbis begrænser
  den enkelte lærers aspektorbis yderligere.
- Én kandidat med ±180 minutters ændring kan sammenholdes med originalen.
  Whole-second præcision, og ingen rangering eller automatisk rettelse.
- Ved ukendt fødselstid udelades progressioner, akser og kandidat. Ved cirka
  tid er akser/progressioner foreløbige. Hvis en dato ligger på fødselsdagen,
  men kl. 12 UTC ligger før fødslen, udelades progressionen med forklaring.
- Dagens horoskop åbnes i den eksisterende visning med tre hjul, eller med
  transitter alene når progressionen ikke kan beregnes. Original fødselstid
  bruges ved åbning; kandidaten anvendes kun til sammenligningen.

## Louise Kirseboms sløjfemetode

Fjerde værksted under **Fordybelse**, direkte adresse `/institut#sloejfer`.
Bygger på hendes offentlige artikler
[om de ni trin](https://www.astrologiskinstitut.dk/post/retrograde-planeter),
[om rejsen gennem sløjfen](https://www.astrologiskinstitut.dk/post/retrograde-planeter-slojfen)
og [Merkur/Venus-eksemplet fra 2025](https://www.astrologiskinstitut.dk/post/det-sj%C3%A6ldne-sammenfald-mellem-merkur-og-venus-i-2025).

- Merkur til Pluto; fokus ved fødslen, på en valgt dato eller i sekundær
  progression. Forrige/næste sløjfe kan udforskes uden at flytte fokusdatoen.
- Ni beregnede trin. Kun trin 4 og 6 er astronomiske stationer. Trin 5 er
  retrograd Sol-konjunktion for Merkur/Venus og Sol-opposition for Mars–Pluto.
- Tre fællesgrader: 2/6, 3/5/7 og 4/8. Direkte passager findes på den korrekte
  side af stationerne; spring gennem 0° Vædder forveksles ikke med opposition.
- To døgns prøvegitter, numeriske rødder forfinet til 0,25 sekunder. Tropisk,
  geocentrisk, tilsyneladende længde med Swiss Ephemeris. Alle tider vises i UTC.
- Nærmeste centrale Sol-møde bestemmer den viste cyklus. Sløjfens kerne er
  trin 2–8. For nogle ydre planeter ligger en eller begge direkte
  Sol-konjunktioner 1/9 inde i skyggeperioden. Tabellen sorteres efter faktisk
  tidspunkt og advarer om den afvigende rækkefølge. Trinnumre ændres ikke.
- Den klikbare SVG er en original skematisk fremstilling. Fælles grader
  står lodret; afstande viser hverken tid eller himlens tilsyneladende bane.
  Alle ni trin kan vælges under figuren og i datooversigten. SVG indeholder
  beregnede trindata, metode og kildehenvisninger, men ingen skrevne elevnoter.
- Fokusplanetens nærhed til et trin testes på den aktuelle direkte/retrograde
  passage. Derfor bliver en grad ikke fejlagtigt mærket som alle tre passager.
  Konjunktioner til valgte fødselspunkter og trin-nærhed bruger højst 1½° orbis.
  Huse er fødselshuse og følger den valgte indstilling; ukendt tid udelader dem.
- Ukendt/cirka tid markeres. Krydser fødselsintervallet et trin, vises det.
  Progression kræver angivet tid. Dagsfokus er kl. 12 UTC; før fødselsøjeblikket
  afvises progressionen også på selve fødselsdagen.
- Progression følger motorens samme tropiske år: `YEAR_DAYS = 365.2422`.
  Efemeridetid = fødsel + (livsdato − fødsel) / YEAR_DAYS. Hvert trins livsdato
  beregnes med den inverse formel. Datoer før fødslen/efter 2099 kan ikke
  overføres. Ved cirka-tid beregnes intervallet i mulige livsdatoer fra begge
  ender af fødselstidsintervallet; selv en lille tidsusikkerhed kan flytte
  disse datoer mærkbart.
- Op til 120 noter à 4.000 tegn, adskilt efter planet, cyklus og trin.
  Noter fra de andre passager af samme grad kan åbnes ved siden af ens egen.
  Udvalgte trin føjes med dato, grad, tidspunkt og note til livslinjen.
  Progressive trin får et P i navnet og den omregnede livsdato. Livslinjens
  videre beregning er fortsat et dagsbillede kl. 12 UTC.
- Refleksionsspørgsmålene er originale. Den offentlige metode er implementeret;
  der er ingen kopiering af bogens fortolkninger eller interne lærerark.

**Referencekontrol:** 14 passager fra den offentlige 2025-tabel ligger inden
for 0,25° og ét døgn fra tabellens afrundede grader og kalenderdatoer.
Tabellen angiver ingen tidszone. Venus' trin 3 står 7. februar i tabellen;
præcis passage af den beregnede mødegrad findes 8. februar kl. 02:13 UTC.
Tabellens omtrentlige dato tvinges derfor ikke ind som beregningsresultat.
Nulhastighed, bevægelsesretning, Sol-geometri, fællesgrader, Vædder-overgangen,
cyklusnavigation, fødselstidsusikkerhed, progressionens inverse tid og
grænseårene 1500/2099 har særskilte tests.

## Lagring og kontrol

`workshops` er et valideret, valgfrit felt i det eksisterende studieformat.
Gamle filer får tomme værksteder. Refleksioner (4 × 8.000 tegn), begivenheder
(40 × 4.000 tegn noter), aktivt værksted, Venus-interval, valgt punkt og
livslinjeindstillinger og sløjfeindstillinger følger med gem/genåbn og JSON-eksport/import. De
beregnede resultater genberegnes og gemmes ikke som forældede facit.

Automatisk: 21 Python-tests og 4 JavaScript-tests for de tre første værksteder;
42 Python-tests og 3 JavaScript-tests for sløjfemetoden.
Samlet: 342 Python + 40 JavaScript = 382 beståede kontroller.
Den eneste advarsel er den eksisterende Starlette/httpx-deprecation.

Manuelt: desktop, mobil 390/320 px, gem/genåbn, import/eksport af syntetiske
data, kandidatændring, fjern/fortryd, refleksioner, sprogskift, overgang til
University og åbning af et dagsbillede med alle 51 planetmarkører.

Sløjfeværkstedet er desuden kontrolleret i browseren ved 1280, 390 og 320 px:
ni-trinsvalg, noter pr. passage, to forskellige overførsler til livslinjen
(én transit og én progression), gem/genåbn, JSON-eksport/import, SVG-download
og Plutos kronologiske oversigt. Ingen vandret side-overløb ved mobilbredderne.
