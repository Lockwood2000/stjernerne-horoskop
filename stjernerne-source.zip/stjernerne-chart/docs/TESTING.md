# Verifikation og testcases

Udført lokalt 13. oktober 2026 på macOS ARM64, Python 3.12 og Apple Clang. **57 Python-tests + 3 JavaScript-tests består.**

## Hvad er numerisk verificeret?

| Kontrol | Omfang | Tolerance / resultat |
|---|---|---|
| Uafhængig Astronomy Engine 2.1.19 | Sol, Måne og 8 planeter × 5 datoer = 50 længdegrader | Krav <60 buesekunder; største observerede forskel **11,5229 buesekunder** |
| Officielt `swetest`-referenceprogram | 11 objekter, hastigheder, retrogradfortegn, 12 Placidus-huse, AC og MC på 4 steder/tidspunkter | Længder <0,000001°; hastigheder <0,000001°/dag |
| Uafhængig sfærisk geometri | AC/MC på 3 tidspunkter, nordlig og sydlig halvkugle | <0,02°; tolerance inkluderer approksimeret obliquitet |
| Gemte referenceværdier | København, 15.06.1990 kl. 12.30 UTC | `tests/reference.json`, original CLI-output og kommando medfølger |

**Referenceprogrammet er samme beregningsmotor.** Det afprøver binding, parametre, tidskonvertering og udlæsning; det er ikke en uafhængig astronomisk validering. Den separate Astronomy Engine-kontrol omfatter ikke True Node eller alle Placidus-husspidser. Disse skal også fagligt krydstjekkes før lancering. De angivne tolerancer er testgrænser, ikke et løfte om fødselstidens eller alle historiske inputdatas nøjagtighed.

Datoer for de 50 uafhængige sammenligninger: 01.01.1900 12.00 UTC, 01.07.1950 00.00 UTC, 15.06.1990 12.30 UTC, 01.01.2000 12.00 UTC og 29.02.2024 23.59.59 UTC. Fulde tal i `verification.json`.

En fejl blev fundet under udviklingen: UTC-konverteringen brugte en anden standardværdi for tidal acceleration end de nye DE441-data på ældre datoer. Motoren og referencekørslen er nu begge eksplicit konfigureret med DE441-værdien −25,936. Den oprindelige tolerance blev bevaret; testen blev ikke blot gjort mindre streng.

## Centrale testcases

| Input / situation | Forventet adfærd |
|---|---|
| København, 15.06.1990 14.30 | UTC 12.30, +120 minutter |
| København, 15.01.1990 14.30 | UTC 13.30, +60 minutter |
| København, 31.03.2024 02.30 | Afvises: klokkeslættet eksisterer ikke |
| København, 27.10.2024 02.30 | Kræver valg; første = UTC 00.30, anden = UTC 01.30; forskellige ascendantpositioner |
| Kathmandu, juni 1985 / juni 1986 | Historisk forskel +05.30 / +05.45 |
| Kolkata, 29.02.2024 00.10 | Korrekt skuddag og UTC-datoskift til 28.02 |
| Lord Howe, januar / juli 2024 | +11.00 / +10.30; halvtimes sommertid |
| Lord Howe, 06.10.2024 02.15 | Afvises i halvtimes spring |
| Apia, 30.12.2011 | Afvises: hele den lokale dato blev sprunget over |
| Fødsel før 1970 | Historisk kontrolmarkering; ikke behandlet som universelt valideret |
| Manuel UTC-korrektion uden kilde | Afvises; dokumenteret korrektion returnerer kilde i resultatet |
| Ugyldig dato, 24.00, fremtid, ukendt zone/by, NaN eller ugyldige koordinater | Serveren afviser input uden at gentage fødselsdata i fejlrespons |
| 66° nord/syd eller længere mod polen | Tydelig Placidus-fejl, ingen skjult fallback |
| True Node, juni 1990 / januar 2000 | Direkte henholdsvis retrograd bevægelse; fortegnet må ikke hardcodes |
| Planeter ved 359° og 1° | Konjunktion med orb 2°; korrekt cirkulær afstand |
| Grænse for orbis og husskift | Inklusive præcis aspektgrænse; husspids tilhører det nye hus |
| 40 samtidige kald via tråde | Identiske resultater med serialiseret adgang til C-bibliotekets globale tilstand |
| Moshier-fallback / ændrede ephemerisfiler | Beregning henholdsvis opstart afvises |
| Fremmed origin, forkert content type, request >8 KB, forkert Host | Afvises med passende HTTP-status |
| Flere end 120 API-kald/minut fra samme peer i én proces | HTTP 429 |
| 11 tætliggende symboler omkring 0° | Labels adskilles mindst 11°, oprindelige longituder bevares til forbindelseslinjer |
| Afrunding ved 29,999999° / 359,999999° | Korrekt overgang til næste tegn / Vædderen |

Tidszonetests med kendte offsets er separate forventninger, men ikke et arkivstudie af lokale love for alle steder. IANA beskriver selv begrænsningerne ved tidlige data: [IANA theory](https://data.iana.org/time-zones/theory.html).

## Browserkontrol

Udført i Codex' indbyggede browser:

- Rigtigt eksempelhoroskop hentes fra den lokale server og tegnes.
- Planet- og aspektfaner viser de beregnede værdier.
- Den gentagne time 27.10.2024 kræver valg i formularen; anden forekomst vises som +01.00 og UTC 01.30.
- Aarhus-søgning viser et konkret sted, koordinater og tidszone.
- SVG-download blev gennemført; eksporten indeholder selve vektorhjulet.
- 390 px og 320 px: ingen horisontal side-overløb. Brede positionstabeller ruller i deres egen beholder.
- Lokal iframe indlæser appen og tilpasser højden efter faneskift. Afsenderkontrol findes på begge sider.
- Ingen observerede konsolfejl i indlejringsprøven.
- Desktop- og mobilskærmbilleder leveres separat i outputs.

Ikke udført: live Squarespace-integration, Safari/iOS/Android-matrix, ekstern penetrationstest, længerevarende produktion/loadtest og Docker-image-build. Disse er releaseopgaver, ikke beståede kontroller.

## Reproduktion

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.lock
.venv/bin/python scripts/build_native.py
.venv/bin/python -m pytest -q
node --test tests/wheel.test.mjs
```

Testkørslen giver én upstream-deprecation warning: Starlettes TestClient varsler overgang fra httpx til httpx2. Den påvirker ikke denne testkørsels resultater; testafhængigheden bør opdateres kontrolleret ved næste vedligeholdelse.

`benchmark.json` indeholder en lokal seriel måling af 200 komplette native beregninger. Den måler ikke HTTP, netværk, cold start eller kapacitet ved offentlig drift. Alle 35 originale upstream-filers hashes er kontrolleret mod manifestet.


## Udvidelse 13. oktober 2026

Seneste samlede resultat: **111 Python + 7 JavaScript-tests bestået**.
Se TECHNIQUES.md for de nye solretur-/progressions-/Chiron-/dværgplanet-tests.
Browserkontrol dækker de nye typevalg, solretur i andet sted, progressioner,
16 markører og transitring. Fuld Docker-/Render-test afventer deploymentadgang.

### Linux-arbejdstråde

Første Render-test afslørede Swiss Ephemeris' platformsforskel: TLS er slået til
på Linux, men fra på macOS. Processens import-initialisering var derfor ikke
synlig i Linux-API'ets arbejdstråde. Nativebiblioteket bygges nu med upstreams
`TLSOFF`, og alle kald er fortsat serialiseret af appens proceslås.
`scripts/verify_native_threads.py` kontrollerer fire epoker og 16 himmellegemer
fra worker-tråde under Docker-build; byggeprocessen stopper ved afvigelser.

### Offentlig livekontrol

Render/Linux-version `6e5fa73` er verificeret over HTTPS 13. oktober 2026.
16 himmellegemer i fødsel, transit, solretur og progression. Forskellen til
Mac-beregningen for testhoroskopets længder var højst 6,14e-10 buesekunder.
Kilde-downloadens SHA-256 matcher den publicerede pakke, fremmed Origin afvises,
og noindex-headeren er kontrolleret. Se live-verification.json.
Browserkontrol: solretur, progressioner, transitter og afspil/pause; responsive
visninger på 390 og 1280 px uden vandret overflow. Ingen Safari/iOS-test.

### Synastri 13. oktober 2026

Version 8582acc: 116 Python- og 7 JavaScript-tests bestået. Liveversionen
returnerer 55 krydsaspekter for de fiktive eksempelhoroskoper og korrekte
gensidige husplaceringer. Fødselspositioner matcher separate beregninger.
Alle fem horoskoptyper og kilde-download er verificeret; se live-verification.json.

### Fødselstidskorrektion 13. oktober 2026

Version 5b18ea9: 123 Python- og 7 JavaScript-tests bestået. Plus livekontrol
af +15 minutter, originale data bevaret, to kandidater ved én begivenhed
og fem langsomme transitplaneter. Eksisterende horoskoptyper, kildepakke
og Origin-afvisning kontrolleret igen. Se live-verification.json.

### Lokalt bibliotek 14. oktober 2026

Version 8a35c03: 123 Python- og 16 JavaScript-tests bestået.
Browserprøver for alle gemte horoskoptyper, genindlæsning, tidskandidater,
livsbegivenheder, backup/import, papirkurv og konflikt mellem faner.
Live bibliotek, kildepakke, beregninger og Origin-kontrol verificeret.
Se LIBRARY.md og live-verification.json.
