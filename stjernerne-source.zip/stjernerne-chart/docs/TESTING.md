# Verifikation og testcases

Udført lokalt 13. oktober 2026 på macOS ARM64, Python 3.12 og Apple Clang. **57 Python-tests + 3 JavaScript-tests består.**

## Hvad er numerisk verificeret?

| Kontrol | Omfang | Tolerance / resultat |
|---|---|---|
| Uafhængig Astronomy Engine 2.1.19 | Sol, Måne og 8 planeter × 5 datoer = 50 længdegrader | Krav <60 buesekunder; største observerede forskel **11,5229 buesekunder** |
| Officielt `swetest`-referenceprogram | 11 objekter, hastigheder, retrogradfortegn, 12 Placidus-huse, AC og MC på 4 steder/tidspunkter | Længder <0,000001°; hastigheder <0,000001°/dag |
| Uafhængig sfærisk geometri | AC/MC på 3 tidspunkter, nordlig og sydlig halvkugle | <0,02°; tolerance inkluderer approksimeret obliquitet |
| Gemte referenceværdier | København, 15.06.1990 kl. 12.30 UTC | `tests/reference.json`, original CLI-output og kommando medfølger |

**Referenceprogrammet er samme beregningsmotor.** Det afprøver binding, parametre, tidskonvertering og udlæsning; det er ikke en uafhængig astronomisk validering. Den separate Astronomy Engine-kontrol omfatter ikke True Node eller alle Placidus-husspidser. Disse skal også fagligt krydstjekkes før lancering. De angivne tolerancer er testgrænser, ikke et løfte om fødselstidens eller alle historiske inputdatas nøjagtighed.

Datoer for de 50 uafhængige sammenligninger: 01.01.1900 12.00 UTC, 01.07.1950 00.00 UTC, 15.06.1990 12.30 UTC, 01.01.2000 12.00 UTC og 29.02.2024 23.59.59 UTC. Fulde tal i `verification.json`.

En fejl blev fundet under udviklingen: UTC-konverteringen brugte en anden standardværdi for tidal acceleration end de nye DE441-data på ældre datoer. Motoren og referencekørslen er nu begge eksplicit konfigureret med DE441-værdien −25,936. Den oprindelige tolerance blev bevaret; testen blev ikke blot gjort mindre streng.

## Centrale testcases

| Input / situation | Forventet adfærd |
|---|---|
| København, 15.06.1990 14.30 | UTC 12.30, +120 minutter |
| København, 15.01.1990 14.30 | UTC 13.30, +60 minutter |
| København, 31.03.2024 02.30 | Afvises: klokkeslættet eksisterer ikke |
| København, 27.10.2024 02.30 | Kræver valg; første = UTC 00.30, anden = UTC 01.30; forskellige ascendantpositioner |
| Kathmandu, juni 1985 / juni 1986 | Historisk forskel +05.30 / +05.45 |
| Kolkata, 29.02.2024 00.10 | Korrekt skuddag og UTC-datoskift til 28.02 |
| Lord Howe, januar / juli 2024 | +11.00 / +10.30; halvtimes sommertid |
| Lord Howe, 06.10.2024 02.15 | Afvises i halvtimes spring |
| Apia, 30.12.2011 | Afvises: hele den lokale dato blev sprunget over |
| Fødsel før 1970 | Historisk kontrolmarkering; ikke behandlet som universelt valideret |
| Manuel UTC-korrektion uden kilde | Afvises; dokumenteret korrektion returnerer kilde i resultatet |
| Ugyldig dato, 24.00, fremtid, ukendt zone/by, NaN eller ugyldige koordinater | Serveren afviser input uden at gentage fødselsdata i fejlrespons |
| 66° nord/syd eller længere mod polen | Tydelig Placidus-fejl, ingen skjult fallback |
| True Node, juni 1990 / januar 2000 | Direkte henholdsvis retrograd bevægelse; fortegnet må ikke hardcodes |
| Planeter ved 359° og 1° | Konjunktion med orb 2°; korrekt cirkulær afstand |
| Grænse for orbis og husskift | Inklusive præcis aspektgrænse; husspids tilhører det nye hus |
| 40 samtidige kald via tråde | Identiske resultater med serialiseret adgang til C-bibliotekets globale tilstand |
| Moshier-fallback / ændrede ephemerisfiler | Beregning henholdsvis opstart afvises |
| Fremmed origin, forkert content type, request >8 KB, forkert Host | Afvises med passende HTTP-status |
| Flere end 120 API-kald/minut fra samme peer i én proces | HTTP 429 |
| 11 tætliggende symboler omkring 0° | Labels adskilles mindst 11°, oprindelige longituder bevares til forbindelseslinjer |
| Afrunding ved 29,999999° / 359,999999° | Korrekt overgang til næste tegn / Vædderen |

Tidszonetests med kendte offsets er separate forventninger, men ikke et arkivstudie af lokale love for alle steder. IANA beskriver selv begrænsningerne ved tidlige data: [IANA theory](https://data.iana.org/time-zones/theory.html).

## Browserkontrol

Udført i Codex' indbyggede browser:

- Rigtigt eksempelhoroskop hentes fra den lokale server og tegnes.
- Planet- og aspektfaner viser de beregnede værdier.
- Den gentagne time 27.10.2024 kræver valg i formularen; anden forekomst vises som +01.00 og UTC 01.30.
- Aarhus-søgning viser et konkret sted, koordinater og tidszone.
- SVG-download blev gennemført; eksporten indeholder selve vektorhjulet.
- 390 px og 320 px: ingen horisontal side-overløb. Brede positionstabeller ruller i deres egen beholder.
- Lokal iframe indlæser appen og tilpasser højden efter faneskift. Afsenderkontrol findes på begge sider.
- Ingen observerede konsolfejl i indlejringsprøven.
- Desktop- og mobilskærmbilleder leveres separat i outputs.

Ikke udført: live Squarespace-integration, Safari/iOS/Android-matrix, ekstern penetrationstest, længerevarende produktion/loadtest og Docker-image-build. Disse er releaseopgaver, ikke beståede kontroller.

## Reproduktion

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.lock
.venv/bin/python scripts/build_native.py
.venv/bin/python -m pytest -q
node --test tests/wheel.test.mjs
```

Testkørslen giver én upstream-deprecation warning: Starlettes TestClient varsler overgang fra httpx til httpx2. Den påvirker ikke denne testkørsels resultater; testafhængigheden bør opdateres kontrolleret ved næste vedligeholdelse.

`benchmark.json` indeholder en lokal seriel måling af 200 komplette native beregninger. Den måler ikke HTTP, netværk, cold start eller kapacitet ved offentlig drift. Alle 35 originale upstream-filers hashes er kontrolleret mod manifestet.


## Udvidelse 13. oktober 2026

Seneste samlede resultat: **111 Python + 7 JavaScript-tests bestået**.
Se TECHNIQUES.md for de nye solretur-/progressions-/Chiron-/dværgplanet-tests.
Browserkontrol dækker de nye typevalg, solretur i andet sted, progressioner,
16 markører og transitring. Fuld Docker-/Render-test afventer deploymentadgang.
