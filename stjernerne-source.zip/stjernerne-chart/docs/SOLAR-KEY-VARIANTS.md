# To individuelle solnøgler · 15. oktober 2026

## Brug

Vælg Progressioner og derefter Akser og huse:

- **Kündig · hel grad** bevarer den hidtidige metode.
- **ARGUS · centreret** bruger en grad centreret om den præcise fødselssol.
- Naibod er fortsat tilgængelig som et tredje valg.

Når en solnøgle er beregnet, vises begge varianters årlige nøgle, samlede
aksebue, progressive AC og MC på samme dato. Præcise decimalnøgler og forskelle
i buesekunder gør også små forskelle synlige. Vis i hjulet vælger den anden
metode og genberegner hele horoskopet, inklusive huse og planeternes husnumre.
Gamle resultater skjules, når inddata eller indstillinger ændres.

Under Fødselstid → Kandidater & begivenheder kan begge metoder vælges.
Aspekterne i tabellen følger den valgte metode. Åbn **Sammenlign solnøgler og
akser** i en celle for at se begge varianter for netop kandidaten og
begivenheden. Vælg til begivenheder genberegner tabellen med den anden metode.
Vis progression i hjulet viser den valgte metodes akser i den ydre ring.

Metodevalgene bevares i Mine horoskoper, genåbning og backup/import. Ingen
tidligere gemte valg får en ny betydning: `kundig` er stadig hel grad;
`kundig_argus` er det nye valg. Gamle progressioner uden metode beholder Naibod,
og gamle begivenhedssammenligninger uden metode beholder transitter.
Backupformatets version er fortsat 1; den nye validator accepterer det ekstra
metode-id. Ældre udgaver af appen kan ikke forventes at importere det nye id.

## Beregning og kilde

Med λ som fødselssolens tropiske længde og ε som sand natal obliquitet:

    RA(x) = atan2(sin(x) cos(ε), cos(x)) mod 360°
    hel grad: g = floor(λ mod 360°), nøgle = [RA(g + 1°) − RA(g)] mod 360°
    centreret: nøgle = [RA(λ + 0°30′) − RA(λ − 0°30′)] mod 360°
    progressiv ARMC = [natal ARMC + alder × nøgle] mod 360°

ARGUS-konventionen følger Christian Borups offentlige metodebeskrivelse i
[Artikler om korrektion og prognose](https://astrologi-arkaden.dk/ebooks/christian-korrektion.pdf),
PDF-side 76 (talt fra 1). Den oprindelige ARGUS-programkode er ikke brugt.
Helgradskonventionens kilde og de tidligere eksterne taleksempler er beskrevet
i SOLAR-KEY.md og CROSSCHECK.md.

Begge nøgler fryses ved fødslen. Sekundærplaneterne bruger samme efemeridetid
(én dag pr. leveår på 365,2422 dage), og Placidus-akser/huse bruger samme
progressive obliquitet og fødested. Kun nøglen, ARMC og deraf afledte
akser/huse ændres. Sammenligningen bruger uafrundede beregningsværdier.
AC/MC-forskelle vises som den korteste fortegnede zodiakbue, så et skift over
0° ikke bliver til en misvisende forskel på næsten 360°.

Testhoroskopet København 15. juni 1990 kl. 14:30 til 15. oktober 2026 kl. 12 UTC
giver cirka 1,08807782° RA/år med hel grad og 1,08783199° med centreret grad.
ARGUS minus hel grad bliver cirka −32,83″ i MC og −21,18″ i AC. Planeterne
har samme længdegrader og retrogradstatus. Disse konkrete tal er
regressionsværdier fra denne implementation, ikke et nyt facit fra ARGUS.

Dette er en implementation af den beskrevne centrerede konvention. Der er
fortsat ikke kørt en selvstændig ARGUS-installation med et publiceret,
præcist progressionsfacit. Den tidligere kontrol af fire ARGUS-snit vedrører
snitberegningen; den certificerer ikke automatisk begge solnøglevarianter.

## Kontrol

207 Python-tests og 33 JavaScript-tests bestod. Den nye beregning er
sammenholdt med Swiss Ephemeris' særskilte sfæriske koordinatrotation ved
otte sollængder, inklusive 360°/0° og tegnskift. Tests dækker kontinuitet,
tilfældet hvor varianterne er ens, og en sollængde hvor de er forskellige.
Ved 0, 1, 35 og 100 leveår stemmer sammenligningskortene med særskilt
beregnede horoskoper for hver metode. Sekundærplaneter og hastigheder er
identiske. Begivenheder kontrolleres særskilt for hver tidskandidat.

API-valideringen accepterer den nye variant til progressioner og afviser
den til solretur. Eksisterende standardvalg bevares. Backup/import testes
for begge metode-id'er. Visningen af den samlede aksebue testes over
30° og 360°, så en zodiakformatter ikke kan skjule hele grader.

Browserkontrol lokalt: begge varianter kan vælges og skiftes fra
sammenligningen, og hjulets metode og akser følger valget. En ARGUS-progression
er gemt, genindlæst og genåbnet med det samme metodevalg. Kandidaten 14:27:38
er sammenlignet med originalen ved en fiktiv begivenhed 1. juni 2020;
metodeskift fra resultatcellen genberegner begivenhedstabellen.
Ved 390 × 844 er dokumentbredde og scrollbredde begge 390 pixels, og
sammenligningsknapperne er over 44 pixels høje. Kun fiktive lokale testposter
er oprettet. En rigtig JSON-backup med ARGUS-progression og ARGUS-valgte
livsbegivenheder er efterfølgende importeret i Chromes tomme lokale bibliotek.
Begge metodevalg, kandidaten 14:27:38, sekundforskydningen og begivenheden
1. juni 2020 var bevaret. Begge horoskoper blev genberegnet, og kandidatens
progression kunne vises i hjulet. Udgivelsen dokumenteres i arbejdsområdets
work/argus-variants.

Ingen nye afhængigheder, betalte tjenester eller serverlagring. Tilføjelsen
indgår i den eksisterende AGPL-kildepakke. Squarespace-koden kræver ingen ændring.
