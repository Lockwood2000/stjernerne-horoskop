# Synastri · 13. oktober 2026

Vælg Synastri under Horoskoptype. Beregn først person A i den oprindelige formular,
og udfyld derefter person B. Begge kræver kendt klokkeslæt og fødested. B har sin
egen stedvælger, historiske IANA-tidszone, foldvalg og dokumenterede manuelle offset.
Ingen af personernes fødselsdata lagres af appen.

Hjulet viser to ringe. Vælgeren bestemmer, hvis horoskop og Placidus-huse der er
inderst. Den ydre persons AC og MC markeres særskilt. Synastrioversigten viser
aspekter mellem begge personers planeter, True Node, AC og MC samt hver planets
eget hus og placering i den andens huse. Klik fremhæver ét krydsaspekt i hjulet.
SVG-download inkluderer begge ringe og det valgte aspekt.

## Beregningsregler

POST /api/synastry tager {a: Birth, b: Birth}. Hvert fødselshoroskop beregnes med
den eksisterende Swiss-motor og alle eksisterende valideringsregler. Det er to
fødselsøjeblikke; der beregnes ikke anvendende/separerende transitfase.
Orbis er 8° konjunktion/opposition, 6° trigon/kvadrat, 4° sekstil. Ved AC, MC,
knude, Chiron eller dværgplanet begrænses den til 3°. Husplacering følger den
ekliptiske længde mellem husspidserne, uden 3D-husposition eller husspidsregel.
Ingen kompatibilitetsscore eller automatisk fortolkning af forholdet.

## Validering

tests/test_synastry.py dækker lighed med separate fødselshoroskoper, bytte af A/B,
identiske fødsler (18 præcise konjunktioner), gensidige huse, 0°-overgang,
inklusive/eksklusive orbisgrænser, ukendt sted, ukendte felter og DST-fold/gap.
Samlet 116 Python- og 7 JavaScript-tests. Browserkontrol omfatter to steder,
valgt AC–AC-aspekt, ringbytte, valg af anden forekomst af et gentaget klokkeslæt,
ugyldiggørelse ved inputændringer og responsiv visning.

## Fødselstidskorrektion: status

Tidskyder og begivenhedssammenligning er nu implementeret; se RECTIFICATION.md.
Nedenstående beskriver afgrænsningen mod automatisk rektifikation.

### Metodisk begrænsning

Ikke implementeret som automatisk rektifikation. En god første version vil være
at afprøve et oplyst tidsinterval med ±1/5/15 minutter, vise ændringer i AC, MC,
huse og aspekter samt sammenligne kandidater uden at overskrive originalen.
Daterede livsbegivenheder kan senere sammenholdes med eksplicit valgte astrologiske
metoder. Et match er ikke dokumentation for det faktiske fødselstidspunkt, og
systemet bør ikke vise en statistisk sikkerhed uden en valideret model.
Astrodienst beskriver selv fraværet af pålidelige rektifikationsmetoder:
https://www.astro.com/faq/fq_ua_method_s.htm
