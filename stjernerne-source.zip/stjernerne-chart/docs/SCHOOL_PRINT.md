# School print and PDF edition

Both `/institut` and `/university` offer **Print / PDF** above the workspace and in the chart toolbar. Calculate the chart, open the desired study room, then choose the content in the A4 preview. The final button opens the browser print dialog; choose Save as PDF or a printer. Use A4, 100% scale and no browser headers/footers.

The preview supports a personal title, the visible chart, the current study room, position/reference tables, the user's notes, writing lines and monochrome output. SVG charts remain vectors. Headers, school typography, colours and page numbers are repeated on each page. Long notes are paginated without truncation and tables repeat their headers. The current chart's hidden exercise information stays hidden. A study room follows its own visible selection and includes its course references.

The lifeline prints all saved event descriptions and notes plus the currently calculated event's contacts. The loop workshop prints all nine dates and notes for all stages of the selected cycle. University rooms print their current planet, date, lunation or relationship focus, including contacts that scroll onscreen. It does not combine all rooms or all historical journal dates into one document.

Printing takes an in-memory snapshot, including unsaved text. It does not save a study to browser storage or send notes to the server. Continue using Save for editable browser work and Export for a portable JSON backup.

The preview closes its modal before opening the browser print UI, then restores it after printing/cancelling. Native browser printing also builds a report; uncalculated or stale data produces a clear notice instead of stale chart output. PDF layout is checked using actual Chrome Save as PDF files, rendered with Poppler, alongside UI checks for all eight rooms, long notes, selected content, tables and monochrome output.
