# Squarespace-integration — klar til gennemgang, ikke installeret

Squarespaces officielle vejledning tillader JavaScript og iframe i Code Blocks på Advanced. Tilføj først til en godkendt testside. Ingen kode er indsat på Stjernerne.dk eller Stjernerne.io.

1. Godkend licens, hosting og HTTPS-adresse. Eksemplet `https://horoskop.stjernerne.io` er en **pladsholder**, ikke en eksisterende deployment.
2. På beregningsserveren: sæt `PUBLIC_ORIGIN` til appens præcise HTTPS-origin; `ALLOWED_HOSTS` til det konkrete hostname og `127.0.0.1` for healthcheck. `FRAME_ANCESTORS` skal kun indeholde godkendte HTTPS-origins, adskilt af mellemrum. Standardlisten omfatter Stjernerne.dk/io med og uden www. Opdater også frontendens liste i `static/app.js`, hvis en anden parent-origin vælges.
3. Brug en HTML Code Block på den godkendte Squarespace-testside. Indsæt det gennemgåede eksempel fra `squarespace-embed.html`. Erstat begge markerede origins med faktiske værdier. Visning af kildekode skal være slået fra.
4. Kontrollér siden som almindelig besøgende; editoren kan behandle indlejret kode anderledes. Test mobil, tastatur, højde efter faneskift/fejl og SVG-download.
5. Bed om brugerens godkendelse af den konkrete publicering, før den bliver offentlig.

## Hvorfor iframe og samme oprindelse for app/API?

Iframe isolerer appens skrifter, CSS og scripts fra Squarespace-temaet. API'et er på samme origin som appen, så fødselsdata ikke behøver sendes gennem Squarespace eller via browser-CORS til en tredje server. Der er ingen API-nøgle i HTML. Kodeblokken indeholder alene adressen og håndtering af højde.

Appen sender kun en type og en højde til parent-vinduet; ingen fødselsdata. Parent kontrollerer både `event.origin` og `event.source`, og barnets `targetOrigin` er konkret. `frame-ancestors` begrænser embedding. Dette er ikke autentifikation af et offentligt API; misbrug kræver særskilt rate limit ved netværkskanten.

Den lokale rute `/embed-test` er browserprøvet med automatisk højde og faneskift. Den er en test af mekanismen, **ikke** en live Squarespace-test. Hvis cross-origin staging ønskes, godkend først testhostname og adgang. Ved produktion bruges en separat origin til iframe; på det lokale testdomæne giver kombinationen `allow-scripts allow-same-origin` ikke fuld sandbox-isolation fra sin egen parent.

## Driftskrav før godkendelse

- HTTPS-terminering, ikke-root proces og skrivebeskyttet containerfilsystem, hvor muligt.
- Fastlåste buildinputs; vælg konkret container-image-digest ved release. Dockerfilen er forberedt, men er ikke kørt på denne Mac.
- Edge-rate-limit på alle relevante endpoints. Den medfølgende hukommelsesbaserede begrænsning gælder én proces og erstatter ikke DDoS-beskyttelse.
- Hvis en proxy bruges: trust kun dens kendte IP'er, før videresendt klient-IP anvendes. Standardstart ignorerer proxyheaders og kan derfor rate-limit'e alle brugere samlet bag en proxy.
- Ingen fødselsdata i adgangslogs, APM traces, analytics eller fejlrapporter. Applikationen logger ikke requestbody og lagrer ikke chartresultater. Hostingens øvrige logs skal konfigureres tilsvarende.
- Healthcheck, kontrollerede opdateringer af efemerider/tidszoner, genkørsel af referencetest og rollback til kendt image/data.
- Ved AGPL: gratis og tydelig adgang til den relevante komplette kildekode fra appen; ved Professional: dokumenteret gyldig kontrakt og fornyelsesansvar.

Kilde: [Squarespace — Add custom code](https://support.squarespace.com/hc/en-us/articles/205815928-Add-custom-code-to-your-site).
