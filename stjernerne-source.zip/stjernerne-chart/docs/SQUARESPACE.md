# Squarespace-integration · publiceret 14. oktober 2026

Offentlig side: https://www.stjernerne.io/dit-horoskop

Menupunktet **Dit horoskop** findes i Main Navigation. Det peger på den almindelige
side /dit-horoskop, som ligger i Not Linked. Et tilsvarende link findes i
Stjernerne medlem-menuen. Begge åbner samme offentlige side uden krav om medlemskab.
Brugerens nyere ønske om menupunkt erstatter det tidligere ønske om et skjult link.

## Indhold og indlejring

Introduktionen: “Udforsk dit fødselshoroskop og følg planeternes bevægelser gennem
tiden. Begynd med din fødselsdato, dit klokkeslæt og dit fødested.”
Formuleringen om gratis adgang og medlemskab blev fjernet efter brugerens rettelse.

Den indlejrede app kommer fra https://stjernerne-horoskop.onrender.com/?embed=1.
Den publicerede kode er gemt i squarespace-embed.html (min-height: 0). CSS gælder kun den sektion,
som indeholder #stjernerne-chart-embed. Sektionen bruger en responsiv kolonne med
maxbredde 1320px og 24px sidemargener. Iframe har egen rulning, højde 82svh,
uden fast minimum og med maksimum 900px. Det holder hjul-dialogen inden for en afgrænset
visning. Linket “Åbn i fuld størrelse ↗” åbner desuden appen i en ny fane.

Sandbox tillader scripts, same-origin, formularer og downloads. **allow-forms er
nødvendigt:** uden det viste eksempelberegningen sig, men nye form-submit-hændelser
blev blokeret. Det blev fundet ved browserprøven og rettet på den publicerede side
samt i den lokale /embed-test. Ingen topnavigation eller popup-tilladelse er tilføjet.
Backend-CSP tillader Stjernerne.dk/io med og uden www. Admin-preview på
stjernerne.squarespace.com kan derfor vise en afvist iframe; test den offentlige URL.

## Kontrol

- Chrome inkognito uden login: side, offentlig hovedmenu, iframe og beregning virker.
- Ændret eksempel: København, 15. juni 1990, kl. 14:30 → 14:31. Resultatets klokkeslæt
  opdateres, og ascendanten ændres fra Vægten 9°03′ til 9°13′.
- Stor hjulvisning åbner i iframe, og Escape lukker dialogen.
- Indlogget medlemsvisning: menulinket Dit horoskop peger på /dit-horoskop.
- Ingen betalte tjenester eller ændring af Render-instansen.
- Squarespace-siden er efterfølgende afprøvet i Chrome med iPhone SE-emulering
  (375 × 667): alle seks horoskoptyper, zoom, afspilning og lokal gem/genåbn.
  Resttest og begrænsninger er beskrevet i MOBILE-QA.md. Safari/fysiske telefoner
  er endnu ikke afprøvet.

## Drift og data

Render Free kan have cirka ét minuts koldstart. Lokal lagring er knyttet til
browser og origin; en indlejret app kan have separat lagringspartition fra appen
åbnet direkte. Brug backup/import ved flytning. Der er ingen serverlagring af
horoskoper. Rate limit bag Render-proxy og større kapacitetsbehov er fortsat
beskrevet i DEPLOYMENT.md. Der er ikke udført belastningstest.

Den publicerede beregningsapp og dens AGPL-kildepakke er uændret fra release.jsons
commit. Denne lokale dokumentation og rettelsen til /embed-test er efterfølgende
leveringsfiler og endnu ikke en ny Render-release.

## Mobilrettelse · publiceret 14. oktober 2026

Minimumshøjden er fjernet fra live-indlejringen, og linkteksten er ændret til
“Åbn i fuld størrelse ↗”. Squarespace viste Page · Published efter gemning.
Offentlig side kontrolleret ved 844 × 390 og 390 × 844: korrekt link, tilpasset
rammehøjde og fungerende åbning/lukning af hjul-dialogen. Se MOBILE-QA.md.
