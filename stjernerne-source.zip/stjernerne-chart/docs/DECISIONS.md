# Arkitektur- og licensbeslutning

Dato: **13. oktober 2026**. Status: lokal MVP bygget; produktion og betaling ikke godkendt eller udført.

## Anbefaling

En selvstændig webapp med beregningsserver, indlejret med iframe på Squarespace Advanced. Behold app og API på samme oprindelse, eksempelvis et fremtidigt `horoskop.stjernerne.io`. Domænenavnet er kun et forslag og er ikke registreret eller konfigureret.

Browser → Squarespace-side → iframe med app → POST til appens egen Python-server → Swiss Ephemeris C + lokale data → JSON → SVG-hjul.

Stjernerne.dk viderestillede ved kontrollen til **www.stjernerne.io**. Den endelige værtsadresse skal derfor bekræftes før indlejring. Intet Squarespace-abonnement eller administratorpanel er blevet ændret eller kontrolleret; Advanced er brugerens oplysning.

## Selvstændig app kontra Lovable

| Hensyn | Selvstændig app (valgt) | Lovable |
|---|---|---|
| Drift | Én lille server kan levere UI og beregninger; native C og lokale efemerider er ligetil. Stjernerne skal have en vedligeholdelsesansvarlig. | Administreret frontend/cloud mindsker dele af driften. Swiss Ephemeris kræver stadig en egnet beregningsløsning; jeg vil også her bruge en separat, kontrolleret server. |
| Ejerskab | Kilde, versionshistorik, data og hosting kan placeres under Stjernernes kontrol. | Lovable oplyser, at kunden ejer kode og indhold, med forbehold for tredjepartsrettigheder. Git-synk og ekstern hosting er mulige. Datamigrering er et særskilt arbejde. |
| Omkostning | Ingen licensbetaling ved opfyldt AGPL. Hosting og vedligeholdelse kommer ved lancering. Ingen pris pr. beregning hos en API-leverandør. | Gratis og betalte planer; Pro fra USD 25/måned for 100 credits i den aktuelle tabel. Forbrug og hosting skal regnes med, og en ekstern beregningsserver/licens kan komme oveni. |
| Squarespace | Lille iframe-kodeblok. CSS er isoleret fra sidens tema; appen kan opdateres separat. | Også indlejring af en separat app. Byggeværktøjet ændrer ikke Squarespace-integrationsprincippet. |
| Præcision | Fastlåste versioner, datachecksums, egne tests og kontrol over tidsmodellen. | Muligt, men kræver samme målrettede testarbejde og kontrol med beregningskode. |

Lovable er et fornuftigt design-/byggeværktøj, især hvis teamet selv vil arbejde visuelt videre. Det er min tekniske vurdering, at det her tilføjer et ekstra lag uden at fjerne projektets sværeste dele. Derfor er MVP'en bygget direkte.

Kilder: [Lovable ejerskab og hosting](https://docs.lovable.dev/tips-tricks/deployment-hosting-ownership), [Lovable FAQ](https://docs.lovable.dev/introduction/faq), [planer og priser](https://docs.lovable.dev/introduction/subscription-plans), [Squarespace custom code](https://support.squarespace.com/hc/en-us/articles/205815928-Add-custom-code-to-your-site).

Leverandørundersøgelsen begyndte med Stripe Directory-vejledningen. Directory-CLI var ikke tilgængelig i miljøet; sammenligningen bruger derfor de ovenstående officielle kilder. Ingen leverandørkonto er oprettet.

## Swiss Ephemeris: åben kildekode er ikke det samme som en fri proprietær licens

Swiss Ephemeris tilbydes på to licensspor: AGPL og Professional. Udgiveren kræver valget før distribution eller aktivering af offentlig service. AGPL-sporet er valgt til denne isolerede prototype, som leveres med projektkilde, byggeværktøjer, licenstekst og notices. Den er ikke publiceret.

**AGPL kan bruges til kommerciel drift.** Betaling fra slutbrugere er ikke i sig selv forbudt. Til gengæld skal licensens krav følges. Den praktiske åbne udgivelsesmodel skal omfatte den dækkede applikations tilsvarende kildekode, nødvendige bygge-/installationsfiler, ændringer og licensoplysninger. Netværksbrugere af det omfattede modificerede program skal have et tydeligt og gratis tilbud om kildekoden efter §13. Et privat repository alene er ikke tilstrækkeligt som dette tilbud.

Planlæg derfor AGPL-sporet som en åben generator, inklusive den tilhørende frontend og backend. En separat server eller iframe er ikke en automatisk undtagelse fra copyleft. Omfanget over for andre selvstændige systemer afhænger af den faktiske sammenkobling; det betyder ikke automatisk, at alt Squarespace-indhold bliver AGPL. Den endelige afgrænsning bør afklares skriftligt ved tvivl.

Kilder: [udgiverens licensforklaring](https://www.astro.com/swisseph/swephinfo_e.htm), [AGPL-3.0, især §§1, 5, 6 og 13](https://github.com/aloistr/swisseph/blob/master/agpl-3.0.txt). Fulde tekster ligger også i `COPYING` og `vendor/swisseph/`.

### Lukket kommerciel drift

Den aktuelle **2026-09-kontrakt** angiver **CHF 700**, ubegrænset antal projekter udviklet/vedligeholdt af licenstageren og **seks års gyldighed** med krav om fornyelse eller ophør. Pris, eventuelle skatter, betalingsvaluta og vilkår skal bekræftes ved bestilling. Dette er ikke en købt livstidslicens.

Kontrakten dækker både apps og serverdrift. Den indeholder særskilte krav ved API-ydelser til andre virksomheder: tredjeparten skal have egen Swiss Ephemeris-licens, og API-udbyderen har oplysningspligter. Derfor må en tredjeparts astrologi-API ikke antages automatisk at fjerne Stjernernes licensbehov.

Anbefaling, hvis generatoren skal være lukket: Lad Stjernernes rette juridiske enhed være licenstager, få den konkrete konstruktion bekræftet og underskriv/betal først efter brugerens godkendelse. Originale notices skal bevares. Dette notat er en teknisk licensgennemgang, ikke en bindende juridisk vurdering.

Kilder: [aktuel kontrakt, september 2026](https://www.astro.com/swisseph/secont_e_2609.pdf), [pris- og bestillingsside](https://www.astro.com/swisseph/swephprice_e.htm).

### Hvorfor direkte C-binding?

MVP'en bruger en lille egen `ctypes`-binding til den officielle C-kode. `pyswisseph` er selv AGPL-licenseret; køb af en Swiss Ephemeris Professional-licens kan ikke uden videre antages at licensere en uafhængig wrapper proprietært. Wrapperen er derfor ikke medtaget. [pyswisseph repository/licens](https://github.com/astrorigin/pyswisseph).

De fastlåste efemeridefiler bygger på DE441. Beregningen afvises ved manglende/ændrede data eller forsøg på automatisk Moshier-fallback. Tidal acceleration er eksplicit sat til DE441-værdien −25,936 for at undgå en forskel i ældre tidsberegninger. [Officiel kilde og filhistorik](https://github.com/aloistr/swisseph), [programmeringsmanual](https://www.astro.com/swisseph/swephprg.htm).

## Alternativer

**Astronomy Engine (MIT)** har en permissiv licens og er egnet til planetberegninger. Det er medtaget som uafhængig testmotor, ikke som produktionsafhængighed. Den undersøgte API er ikke en færdig erstatning for hele den ønskede astrologiske pakke med Placidus og True Node; den rute kræver egne moduler og yderligere validering. Ingen grund til at bygge dem fra bunden i denne MVP. [Officiel dokumentation](https://github.com/cosinekitty/astronomy), [MIT-licens](https://github.com/cosinekitty/astronomy/blob/master/LICENSE).

**Moshier i Swiss Ephemeris** undgår separate efemeridefiler, men ændrer ikke selve Swiss Ephemeris-kodens licens. Det er derfor ikke en licensgenvej og er ikke valgt her.

**Ekstern astrologi-API** kan reducere serverarbejde, men tilfører pris pr. forbrug, netværksafhængighed, dataoverførsel og kontrakt-/licenskontrol. Der er ikke købt eller tilsluttet en API.

## Økonomi

| Post | Nu | Mulig lancering |
|---|---:|---|
| Nye køb / betalte services oprettet i denne opgave | **0 kr.** | Ingen er bestilt |
| Lokal app, beregninger og bysøgning | 0 kr. i nye servicegebyrer | Ingen forbrugsbetaling til ekstern astrologi- eller geokodnings-API |
| Swiss Ephemeris | Lokal AGPL-prototype | Opfyldt AGPL: ingen licensbetaling. Lukket spor: aktuelt CHF 700 / 6 år, under de bekræftede kontraktvilkår |
| Hosting | Ikke oprettet | Foreløbig budgetramme **75–200 kr./måned** for en lille server/container; et skøn, ikke et leverandørtilbud, ekskl. vedligeholdelse og eventuel moms |
| Lovable | Ikke brugt | Valgfrit ekstra værktøj; aktuelt Pro fra USD 25/måned plus relevant forbrug |
| Squarespace | Eksisterende abonnement ifølge bruger | Ingen planopgradering planlagt |
| Drift og kvalitet | Lokal QA udført | Tid til sikkerheds-/tzdb-opdateringer, overvågning, backups af kode/configuration og faglig accepttest er ikke prissat |

Eksisterende ChatGPT/Codex-abonnement og arbejdsindsats er ikke medregnet som nye servicekøb.

## Resterende før offentlig lancering

1. Beslut åben AGPL-generator eller lukket generator med Professional-licens. Få afgrænsningen og den rette licenstager bekræftet.
2. Godkend design og få en astrolog til at kontrollere en fast referencepakke, især True Node og Placidus-huse. De hidtidige tests er dokumenteret i TESTING.md.
3. Beslut historisk dækningsløfte, kontrol af fødsler før 1970 og policy for polare fødesteder. Udvid atlas med historiske kilder efter behov.
4. Godkend konkret hostingpris og driftsejer. Vælg HTTPS-domæne, databehandlerforhold og logpolitik. Tilføj offentlig kildekodefunktion, hvis AGPL vælges. Brug ingen persondata i overvågningsværktøjer uden særskilt beslutning.
5. Test den færdige iframe på en godkendt, ikke-offentlig Squarespace-testside, inkl. Safari/iPhone, tastatur, højde, download og fejltilstande. En lokal iframe-test er ikke det samme som denne integrationstest.
6. Forelæg den konkrete publiceringsændring og udgifter til godkendelse. **Ingen publicering eller betaling før godkendelse.**
