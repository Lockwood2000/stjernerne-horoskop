# ARGUS-variant: offentlig numerisk krydskontrol

Kontrolleret 15. oktober 2026. Ingen beregningsformel er ændret.

## Konklusion

Den centrerede variant gengiver to uafhængigt trykte akseaspekter i Electric
Ephemeris' egen ARGUS-manual ved den trykte præcision på hele bueminutter.
Begge afvigelser er under et halvt bueminut. Helgradsvarianten falder uden for
præcisionen i begge sammenligninger, så eksemplet skelner faktisk mellem
varianterne. Den eksisterende liveberegner er prøvet med samme input og giver
samme resultat som den lokale kode inden for 0,001 buesekund.

**Solnøglen er dermed kontrolleret indirekte gennem aksernes bevægelse.**
Manualen udskriver ikke selve decimalnøglen eller præcise progressive
ARMC/AC/MC. Der er fortsat ikke foretaget en direkte sammenligning med disse
værdier fra en selvstændig ARGUS-installation. Det kræver et nyt programoutput;
et kort testark med to eksempler er forberedt til Eva Ganvig.

## Kilde og inddata

[Electric Ephemeris: ARGUS 4 user manual](https://www.electric-ephemeris.com/download/arg4manual.pdf),
side 12, 14 og 15, talt fra 1. Hele relevante sider er gengivet og visuelt
kontrolleret. Programvinduets titel viser PCA Argus 4.0-1.

Side 12 viser demonstrationshoroskopet mærket Jimmy Page: 9. januar 1944
kl. 04:17:21, zone 1:00 E, 50°05′ N, 5°16′ V, Placidus. Vi gengiver manualens
input, uden at hævde at det er personens autentiske biografiske fødselsdata.
UTC er 03:17:21. Zonens danske kode og de britiske koordinater er en usædvanlig
kombination, men de må ikke stiltiende erstattes med automatisk britisk tid.

Side 15 viser et Secondary/Radix-1-hjul dateret 27. januar 2005 med akseaspekter.
Den tilstødende graf angiver metoden Kündig Sunkey. Det enkelte hjul viser
ikke indstillingsdialogen. Side 14 instruerer i at ændre datoen og bevare øvrige
radixinddata; derfor bruges 04:17:21 og den samme faste zone, dvs. 03:17:21 UTC.
Måltidspunktets klokkeslæt er altså udledt af vejledningen og står ikke separat
i hjulets billedtekst.

Radix-Sol, Pluto, Neptun, MC og AC stemmer alle med de trykte positioner
inden for 30″. Der er ikke justeret et tidspunkt eller en konstant for at få
progressionen til at passe.

## Måling

| Progressiv akse til radixplanet | Trykt ARGUS-orbis | Centreret variant | Afvigelse fra trykt tal | Hel grad |
|---|---:|---:|---:|---:|
| MC kvadrat Pluto | 1°24′ | 1°23′46,82″ | −13,18″ | 1°25′36,07″ |
| AC kvadrat Neptun | 1°16′ | 1°15′31,69″ | −28,31″ | 1°17′16,73″ |

Begge aspekter er separerende i manualen og i vores beregning. De centrerede
resultater afrundes til 1°24′ og 1°16′. Helgradsværdierne afrundes til 1°26′
og 1°17′. Forskellen er derfor større end blot sidste decimal.

Manualens trykte Pluto 8°02′ Løven og Neptun 4°15′ Vægten samt aspekterne
indkredser også de absolutte akser: MC cirka 9°26′ Skorpionen og AC cirka
5°31′ Stenbukken, hver med ±1′ samlet afrundingsrum for planet og orbis.
Vores værdier er 9°25′38,50″ og 5°30′12,87″, begge inden for disse intervaller.
MC-intervallet indebærer med vores natal-ARMC/obliquitet en årlig nøgle mellem
cirka 1,07109662° og 1,07163169°. Vores centrerede nøgle 1,071268294861° ligger
indenfor; helgradsnøglen 1,071755407545° ligger udenfor. Dette er en afledt
intervalkontrol og må ikke omtales som en direkte trykt ARGUS-solnøgle.

Manualens knudeposition er middelknuden; appens valg er True Node. Knudeaspektet
bruges derfor ikke som godkendelsesreference. Efemeridemetode, årslængde og
obliquitetsvalg er heller ikke fuldt angivet i de gamle skærmbilleder. Resultatet
gælder den trykte præcision i dette eksempel, ikke alle ARGUS-versioners
uafrundede tal eller alle datoer/breddegrader.

## Gentagelig kontrol

- `tests/argus-progressions-published-reference.json` er manuelt aflæste eksterne
  værdier med kilde, præcision og begrænsninger. Filen må ikke regenereres fra
  vores beregner. `direct_argus_solar_key` er udtrykkeligt tom.
- `tests/test_argus_published_progressions.py` har 11 tests: radixinddata,
  akseaspekter, separerende retning, absolutte akseintervaller, indirekte
  nøgleinterval og hele eksemplet gennem appens API. Helgradsmetoden er en
  negativ kontrol, som ikke må bestå den centrerede references tolerance.
- `scripts/argus_reference_report.py` genberegner målinger uden at ændre den
  eksterne reference. Kør med projektets Python og gem eventuelt standardoutput.

Alle **218 Python-tests og 33 JavaScript-tests bestod**. De 11 nye eksterne
referencetests er inkluderet i de 218. De tidligere snit- og helgradsreferencer
består fortsat.

### Supplerende geometrisk kontrol før Evas test

Efter den offentlige referencekontrol er der tilføjet 16 tests i
`tests/test_argus_geometric_audit.py`. Begge solnøgler sammenholdes med en
numerisk integration af rektascensionens afledte gennem hele zodiakken ved
1.440 sollængder plus seks grænsetilfælde og fire ekliptikahældninger. Denne
kontrol bruger hverken appens RA-formel eller Swiss' koordinatrotation som
facit.

Begge progressionsvarianters AC og MC kontrolleres desuden ved at skære
ekliptikaplanet med horisont- og meridianplaner i tre dimensioner. Det dækker
fire fødselsdatoer/steder på nordlig og sydlig bredde samt ækvator, ved 0, 35 og
100 år. Den forventede ARMC bruger den særskilt integrerede nøgle. Alle valgte
breddegrader ligger uden for polarområdet, hvor Placidus kan være udefineret.

Alle 16 nye tests består; den samlede Python-testpakke har nu **234 tests**.
Dette er en særskilt kontrol af matematikken under vores dokumenterede
årslængde og obliquitetsvalg. Den giver ikke nye ARGUS-facitværdier og afgør
ikke, om ARGUS benytter præcis samme konventioner. Evas direkte kontrol er
fortsat udestående. Der er kun ændret lokale tests og denne dokumentation.

Arbejdsområdets `work/argus-reference/comparison.json` rummer de målte tal og to
testcases til direkte ARGUS-kontrol; `live-check.json` registrerer liveprøven.
Testarket ligger i `output/pdf/argus-kontrol-til-eva.pdf` fra arbejdsområdets rod.
ARGUS-felterne er tomme, indtil der foreligger programoutput. Ingen besked er
sendt til Eva. Ingen nye tjenester, udgifter, personlige horoskoper eller
ændringer på den offentlige side. Tilføjelsen omfatter kun lokale tests,
rapportværktøj og dokumentation; den allerede udgivne beregningskode er bevaret.
