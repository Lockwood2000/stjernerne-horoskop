# School timing and house-system verification

Both school entries share the same calculations. The editable starting profiles
remain Placidus for the Institute and Whole Sign for University. Placidus, Equal
House and Regiomontanus are available alongside the retained house systems.
Equal House means twelve 30-degree houses beginning at the Ascendant; MC remains
a separately calculated point. This is Swiss Ephemeris `E`, not the Aries-based
equal-house variant. See the [official house API](https://www.astro.com/swisseph/swephprg.htm)
and the pinned `vendor/swisseph/swehouse.c` source (`E`, `R`).

## Actual conventions

- Secondary progressions: elapsed UTC days divided by 365.2422 give ephemeris
  days after birth. Progressed ARMC advances by the selected Naibod, Kündig
  whole-degree or ARGUS centred key, at birth latitude and progressed obliquity.
  Naibod is 0.98564733 degrees per elapsed tropical year. The selected key and
  actual rate appear in the method guide and calculation data.
- Direct true solar arc: secondary progressed solar longitude minus natal
  solar longitude, modulo 360. The same arc advances every natal planet, angle
  and house cusp. The progression angle method does not change the solar arc.
  Directed declination and physical retrograde status are not inferred.
- Solar return: solve the tropical, apparent, geocentric Sun's return to its
  natal longitude, without precession correction. The year denotes the birthday
  in the recorded local birth calendar. For 29 February, 28 February is only
  the search anchor. The exact crossing determines the result. This also avoids
  selecting the adjacent annual return for births crossing a UTC year boundary.
- A selected return city determines return houses and local time. Leaving the
  field empty or choosing **Use birthplace** uses the birth location. Changing
  the return location does not change the geocentric crossing instant.

The form accepts a target date, clock time, time zone and repeated-clock-time
choice. Saved studies retain these choices. Loading another study clears stale
place selections before restoring that study's places. Notes are preserved.

The on-screen result and PDF cover share one metadata formatter: a return cover
shows the calculated return time, return city, time zone and selected houses.
The original birth basis remains in the method note. Progression/solar-arc
reports retain target time zones and include the time key and method guide.
Short method notes stay with their chart by modestly reducing the wheel when
needed, with a 125 mm minimum; longer content continues on numbered A4 pages.
The lifeline, loop room and University year room also state their progression
time key; annual profections intentionally retain their whole-sign convention.

## Verification

`tests/test_school_timing.py` independently checks P/E/R against the official
Swiss `swetest` CLI, north and south of the equator; Equal cusp spacing;
secondary planetary time and independent Ascendant/MC geometry; uniform true
solar arc including angles and cusps; return precision against native
`swe_solcross`; relocation; leap day; zodiac wrap; local/UTC year boundaries;
time-zone round trips; and profile defaults. `tests/calculation.test.mjs`
checks report metadata and saved choices.

Browser verification covers both school entries, changing house systems and
techniques, two distinct saved return locations, a repeated-clock target time,
notes, and print-preview pagination. The underlying engine and school defaults
are reused. No other generator's directory is edited.
