# Design tilpasset Stjernerne

Opdateret 13. oktober 2026 efter direkte visuel inspektion og aflæsning af beregnede styles på https://www.stjernerne.io/.

| Element | Reference og implementering |
|---|---|
| Overskrifter | Manrope, vægt 500, tæt bogstavafstand |
| Brødtekst og formular | Nunito Sans, primært vægt 400 og 600 |
| Grundflade | Varm creme `#f7f5ef` |
| Overskriftsfarve | Mørkegrøn `#142e2b` |
| Brødtekst | `#34483c` |
| Primær knap | Grøn `#435a48`, pill-form |
| Formularflade | Salvie `#e4e9dd` |
| Opsummering | Fersken `#f1dfd2`, salvie `#e4e9dd`, lavendel `#e9e1ee` |
| Kort | 24 px hjørner |
| Logo | Hjemmesidens eget originale PNG-logo |

Hjulets farver er afledt af paletten, med grønne, gyldne, terracotta- og lavendeltoner. Manrope/Nunito Sans-filer og deres SIL OFL-licenser ligger lokalt, så beregninger og almindelig brug stadig ikke kræver tredjepartsopslag. Kilder og hashes findes i `data/brand-assets.json`.

Den særskilte `static/brand.css` indeholder brandtilpasningen. `static/wheel.js` har tilsvarende SVG-farver, så farverne også følger med ved eksport. Fontfallbacks i SVG bevarer læsbarheden på systemer uden disse skrifter.

Browserkontrol: desktop 1280 px, mobil 390 og 320 px, fungerende horoskopberegning, planetoversigt og ingen observerede konsolfejl. Ingen vandret side-overløb ved de to mobilbredder. Brugerens indtastninger og valgte aspektfane blev gendannet ved opdateringen af den åbne prototype. Intet er ændret på den offentlige hjemmeside.
