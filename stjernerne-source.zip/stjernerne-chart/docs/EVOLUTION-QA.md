# Evolutionary model · verification

Latest timing and house-system update: [17 October timing QA](EVOLUTION-TIMING-QA.md)
records 389 passing automated checks, the three timing modes, five house
systems, the clockwise polar-house correction, browser round-trip/print
verification and local-only running status.

16 October 2026. Local working model on `127.0.0.1:8776`.

## Automated checks

- 294 Python tests passed, including 15 new evolutionary-overlay tests.
- 33 retained JavaScript tests passed.
- Total: **327 passing checks**. The 15 new tests also passed after the final
  per-body orbital-reference metadata refinement.
- JavaScript syntax checks passed for the new app and wheel modules and the
  modified workshop module.

Node cross-checks use the official retained `swetest` executable, matching
the TT epoch, coordinate reference and `-speed` flag. Seven planetary mean
node pairs and Pluto's heliocentric-osculating pair agree to 0.000001° in
the tested example. This checks binding, flags, epoch and result selection;
it is not an independent astronomical theory or a blanket error bound.

Other checks cover all three house systems, shared-engine compatibility,
true/mean lunar switching, actual ephemeris availability for nine additional
bodies, independently calculated geocentric south nodes, progression timing,
orb narrowing, missing/invalid settings, unknown times and polar house limits.

## Browser flows checked

- Standalone workspace calculates 21 bodies and 17 node pairs.
- Planetary-node table, all additional bodies and both lunar modes display.
- Whole Sign and Mean Node switch correctly; the progression ring calculates.
- Save, reset and open restore settings and reading notes.
- Downloaded JSON (97,418 bytes in the tested default export) contains both
  versioned contracts, inputs, settings and 17 node pairs.
- The downloaded JSON was imported through the real file chooser and
  recalculated successfully.
- Selecting an aspect draws a highlighted contact on the wheel.
- Unknown birth time removes houses/angles and disables the progression layer.
- The copied Astrology University workspace passes its London chart and
  Whole Sign setting into the overlay. Approximate birth-time confidence and
  its ±30-minute warning survive the bridge.
- The copied original workshop opens its natal chart with Placidus in the
  overlay. Both school profiles share the same bridge module.
- No browser console errors were observed in the final standalone session.

## Layout verification

- Desktop: 1280-pixel browser viewport, full-page screenshot retained at
  `screenshots/evolution-desktop.jpg`.
- Narrow layout: actual 390 × 844 same-origin iframe viewport; measured
  document width was 390 pixels, with no horizontal document overflow.
- The browser viewport-override capability did not change the standalone
  viewport, so narrow-layout QA used `static/evolution/responsive-test.html`.
  This verifies responsive CSS in a narrow browser frame, not a physical-phone
  or mobile Safari test.

## Delivery boundaries

The model is local and uses the retained Python/native Swiss Ephemeris stack.
It is not deployed to Sites, Render or the live Stjernerne/Squarespace site.
Overlay integration was tested in copied generators in this workspace.
The original workspaces in the other threads are left available independently.

The application offers SVG export; JSON was the export/import format exercised
through the actual browser download and upload flow in this QA pass.

## 17 October · observatory refinement

- **330 automated checks passed:** 294 Python tests and 36 JavaScript tests.
- The three new SVG regression checks cover separation between the node and
  progression bands, preservation of source longitudes during label spreading
  and focus selection, and unique accessible labels in the normal and large
  chart views. Numerical calculation code was unchanged in this pass.
- Browser-tested reading presets: Outer planets shows five node pairs; Lunar
  axis removes planetary nodes and compares True/Mean lunar nodes; Evolutionary
  restores the Pluto/Uranus starting view.
- The large chart opens, supports point selection, updates the planet panel,
  and closes correctly. Its accessible label IDs are distinct from the main
  chart's IDs.
- Secondary progressions display in a separate outer band; twelve core
  progressed markers were verified in the default view.
- Unknown birth time disables the progression switch, omits Rising from the
  summary, and displays the calculation warning above the chart.
- Notes display an unsaved indicator when edited. Local saved data were not
  overwritten during this visual refinement pass.
- The 390-pixel iframe layout still has no horizontal document overflow and
  now puts the chart before its settings. JSON export remains available on
  the narrow layout.
- No console errors were observed in the final standalone browser checks.
- Updated screenshots: `screenshots/evolution-refined-desktop.jpg` and
  `screenshots/evolution-refined-detail.jpg`.

The narrow layout was tested inside a real 390-pixel browser frame, with the
same physical-device limitations recorded above. This remains a local model.

## 17 October · all 17 node pairs

- 38 JavaScript checks passed, including two new dense-overlay regression
  tests. They cover 34 callouts at six Ascendant rotations, an extreme cluster
  crossing 0° Aries, progression clearance, unchanged source longitudes,
  exact-position dots and interactive/accessibility metadata.
- The live browser displayed all 34 node points and 68 text lines in two
  columns. Bounding rectangles showed no text overlaps or clipped node
  labels at 351 and 1280 pixels wide. The 351-pixel document had no horizontal
  page overflow; the large chart scrolls within its own container.
- The large chart also showed 34 labels without overlaps. Clicking a node
  selected its planet. The combined progression view retained 34 labels,
  twelve progressed planets and no node-text overlaps.
- The existing chart, notes and overlay choices were exported before the
  required reload, then restored through JSON import. The original 17-pair
  view was restored after progression testing; saved browser data were not
  overwritten.
- Numerical calculation code was unchanged. Python tests were not rerun for
  this SVG/CSS-only refinement.
- Updated overview: `screenshots/evolution-all-nodes-readable.jpg`.

## 17 October · full wheel without scrolling

- Replaced the large chart's fixed minimum widths with a flex layout bounded
  by the browser's dynamic viewport. The SVG scales uniformly within the
  remaining space below the header and above the footer.
- Narrow panels at least 580 pixels tall include a compact, 17-row table
  containing the north and south node positions. Each position is selectable;
  selecting Gonggong's south node displayed its full degree and house in the
  dialog footer and updated the selected planet. Pluto was selected again
  after the interaction check.
- Live browser measurements passed at **351 × 662, 320 × 580, 390 × 844,
  844 × 420 and 1280 × 900**. The dialog stayed within the viewport, neither
  the dialog nor the chart container required scrolling, and all 34 node
  labels remained inside the SVG without text overlap. All 17 compact-table
  rows fit inside the dialog wherever the table was displayed.
- 38 JavaScript regression checks passed. No browser console errors were
  recorded. This pass changes presentation only; no calculation code changed.
- Chart data and view choices were exported before reloading and restored
  through JSON import. The final dialog remains open with all 17 node pairs.
- Screenshots: `screenshots/evolution-large-fit-narrow.jpg` and
  `screenshots/evolution-large-fit-desktop.jpg`.

## 17 October · larger, clearer labels

- Large-chart node callouts now use 22/18 SVG-unit name/degree labels,
  heavier weights, darker green/brown text, wider margins and 54-unit row
  spacing. The normal chart retains its existing 16/13-unit sizing.
- At the current 351 × 662 viewport, the compact table increased from
  9-pixel text to 14-pixel bold body names and 13-pixel semibold positions.
  Alternating row backgrounds improve tracking across the two node columns.
  Shorter panels use 12-pixel text. The compact header and tighter footer
  keep space for the entire wheel.
- The 38 JavaScript checks passed, including dense-label geometry checks
  for both text sizes, six Ascendant rotations, extreme clusters and
  progression clearance. Numerical calculation code was unchanged.
- Browser checks passed at **351 × 662, 320 × 580, 320 × 662, 390 × 844,
  844 × 420 and 1280 × 900**: all 34 node labels fit, with no text overlap,
  clipped labels or scrolling in the dialog/chart. All 17 table rows and
  their cell contents fit wherever the compact table was displayed.
- The progression check retained all 34 nodes and twelve progressed
  markers without clipping or scrolling. Selecting Pluto's south node
  displayed its full degree and house. The original chart settings were
  restored after testing; the 17-pair dialog remains open.
- No browser console errors were recorded. Screenshots:
  `screenshots/evolution-large-readable-narrow.jpg` and
  `screenshots/evolution-large-readable-desktop.jpg`.

## 17 October · print layout

- Added Print buttons to the normal chart and large-chart toolbar. They open
  a separate, fitted preview of a **297 × 210 mm A4 landscape** page, with
  10 mm interior margins, a vector wheel and a selected-node table. The
  browser's native printing is invoked by Print / Save PDF; the standard
  browser print command prepares the same dedicated document.
- The actual browser preview showed all **34 node points and 17 table rows**.
  Measurements found no overlapping or clipped node labels, overflowing
  table cells, clipped heading or footer. Its physical CSS dimensions were
  1123 × 794 pixels at 96 CSS pixels per inch, matching landscape A4.
- Preview fitting was verified at 351 × 662, 1280 × 900 and 1280 × 720.
  The full paper preview remained inside the browser viewport. Both normal
  and large-chart Print buttons opened the preview.
- A long chart title fitted the alternate heading style without truncation.
  A combined progression print retained all node pairs and included the
  progression target in the footer. The original chart settings were restored
  through the previously exported JSON after testing.
- 38 JavaScript regression checks passed. No browser console errors were
  recorded in the final restored session. No calculation code changed.
- Verification covers the in-app paper preview and its measured contents;
  physical-printer output and the OS PDF-save flow were not executed.
- Screenshot: `screenshots/evolution-print-preview.jpg`.
