# Skolegeneratorer · status 16. oktober 2026

Fungerende demonstrationsudgaver for Astrologisk Institut og Astrology University.
Den engelske Chart Workshop-testversion er kopieret som grundlag. Den oprindelige mappe og offentlige generator er ikke ændret.

## Klar i begge profiler

- Fødselsdata med sekunder, stedsøgning, manuelle koordinater, tidszone,
  sommertidsvalg og dokumenteret UTC-forskel.
- Kendt, cirka eller ukendt fødselstid. Ukendt tid udelader fødselshuse og akser.
- Otte hussystemer, sand/middel måneknude, valgfri punkter og aspektorbis.
- Fødselshoroskop, solhoroskop, øjeblikshoroskop, transitter, sekundære
  progressioner og tre lag med fødsel, progression og transit.
- Solretur, solar arc, synastri, composite og to horoskoper side om side.
- Progressive månefaser, elementer, kvaliteter, polariteter, dispositørkæder,
  husherskere og grundlæggende traditionelle værdigheder.
- Deklination, paralleller, kontraparalleller og out of bounds.
- T-kvadrat, stortrigon, storkors, yod, drage og talenttrekant.
- Øvelser med skjulte oplysninger, planetfokus, gradsøgning og egne noter.
- Transitdagbog med præcise aspekter, orbisvinduer, stationer og tegnskift.
- Fødselstidskandidater, Kündig/Bonatti-snit og sammenligning med livsbegivenheder.
- Lokale lærerprofiler, gem/genåbn, JSON-eksport/import, SVG og CSV.
- Forstørret hjul og browserudskrift med noter og beregningsindstillinger.

## Skoleforskelle

| | Astrologisk Institut | Astrology University |
|---|---|---|
| Startside | `/institut` | `/university` |
| Sprog | Dansk | Engelsk |
| Skrifter | Raleway / Mulish | Libre Baskerville / Montserrat |
| Farver | Creme, guld og jordfarver | Blå, mintgrøn og lys blågrå |
| Redigerbart husforslag | Placidus | Whole Sign |
| Øvelseskilder | Institutets kursusbeskrivelser og gradøvelse | AU's offentlige chart-reading-øvelser |

Skrifter og farver bygger på skolernes offentlige hjemmesider. Hussystemer og
orbis er vores justerbare forslag. AU rummer flere traditioner; Whole Sign er
ikke angivet som skolens eneste metode. Profilerne er ikke godkendt af skolerne.

## Beregningskonventioner og afgrænsninger

- **Ukendt tid:** lokal middag som nominelt tidspunkt; 25 prøver over dagen.
  Intervallerne er ikke garanterede maksimum/minimum. Cirka-tid prøves inden for
  det angivne interval.
- **Solhoroskop:** Solen som første husspids, derefter lige 30°-huse.
  Syntetiske huse, ikke beregnede fødselshuse eller solretur.
- **Progression:** en dag pr. tropisk år med Naibod eller de videreførte
  Kündig/ARGUS-varianter til akserne. Månefasen bruger den progressive Sol.
- **Solar arc:** den progressive Sols ekliptiske forskydning roterer punkter og
  huse. Ingen opdigtet fysisk deklination/hastighed.
- **Composite:** korteste midtpunktsbue for planeter; midtpunkts-ARMC og
  gennemsnitlig bredde/ekliptikahældning til huse. Præcist modsatte punkter
  afvises som tvetydige. Ikke et Davison-horoskop.
- **Transitdagbog:** én planet til ét fødselspunkt pr. søgning, højst 366 dages
  forskel mellem start og slut. Seks timers prøvegitter deles ved stationer,
  og fund forfines til under et sekund. Afskårne orbisvinduer markeres i data.
  Kirseboms sløjfer beregnes særskilt i Institut-profilens fjerde værksted.
- **Fødselstid:** højst fem kandidater og fem begivenheder, ±180 minutter,
  hele sekunder. Originalen bevares. Datoer prøves kl. 12 UTC. Standardfokus
  er tidsfølsomme akser med højst 1° orbis. Ingen rangscore.
- **Lagring:** højst 100 studiearbejder pr. browser/origin og 30 lærerprofiler
  pr. skole. Revisionskontrol beskytter mod overskrivning fra en anden fane.
  Ingen konti, cloud-synkronisering eller import af det gamle backupformat.

## Kontrol

De 265 eksisterende automatiske kontroller er videreført. Der er tilføjet
42 Python-kontroller og fem JavaScript-kontroller til skoleudgaverne samt
21 Python-kontroller og fire JavaScript-kontroller til de tre nye værksteder:
samt 42 Python- og tre JavaScript-kontroller til sløjfemetoden:
og 30 Python- samt seks JavaScript-kontroller til University-værkstederne:
i alt 418 (372 Python og 46 JavaScript).

De nye kontroller dækker bl.a. alle horoskoptyper, hussystemer, knudevalg,
ukendt tid, progressiv månefase, solar arc, composite-symmetri, historiske
referencehoroskoper, stationssøgning, kandidater og datavalidering.

AU's offentlige undervisningsslides er eksterne referencer:

- David Bowie: 8. januar 1947 kl. 09 UT, **Brixworth** 52°20′ N, 0°54′ V,
  Whole Sign. Stedet følger det trykte eksempel. Sol, Måne, AC og MC matcher
  inden for det viste bueminut.
- George VI: 14. december 1895 kl. 03 UT, Sandringham 52°50′ N, 0°30′ Ø,
  Placidus. AC og MC matcher inden for det viste bueminut.
- Kilde: [AU's undervisningsslides om prognoser](https://www.astrologyuniversity.com/pdf/WebinarSurteesPredictive_Slides.pdf),
  PDF-side 12/55 og 59. Testene henviser til selve undervisningsfilen.

Institutets offentlige taske-horoskop mangler en entydig dokumentation af
tidszone og hussystem i det tilgængelige materiale og bruges derfor ikke som
numerisk facit. Interne elevopgaver og lærerfacit er ikke fremskaffet.

Browserkontrol omfatter begge profiler, tre lag, skjulte øvelsesoplysninger,
noter efter genåbning, lærerprofil, JSON-rundtur, SVG-download, zoom,
transitstationer og fødselstidskandidater. Mobilvisning er kontrolleret ved
390 px. Browserens endelige PDF-gemmedialog er ikke valideret som et
selvstændigt PDF-produkt.

## Resterende før en komplet skoleudgave

- Skolens ønskede undervisningsforløb og underviserens kontrol af sløjfevisningen.
- AU's særlige electional-visning og eventuelle ekstra helhedsfigurer/stellier.
- Skolernes lærerprofiler: husvalg, knudevalg, orbis, symboler og konkrete facit.
- Evas direkte ARGUS-kontrol; den eksisterende valideringsopgave fortsætter.
- Kontrol af udskrifter i de ønskede browsere og på konkrete undervisningsark.
- Eventuel overførsel af gamle gemte horoskoper.

Skolernes særskilte udgivelsesopsætning er beskrevet i [SCHOOL-DEPLOYMENT.md](SCHOOL-DEPLOYMENT.md).

## Kildespor

- [AU curriculum](https://www.astrologyuniversity.com/program-curriculum/)
- [AU chart-reading exercises](https://www.astrologyuniversity.com/top-chart-reading-exercises/)
- [AU enrollment questions](https://www.astrologyuniversity.com/enrollment-questions/)
- [Institutet: Horoskopets helhed](https://www.astrologiskinstitut.dk/product-page/horoskopets-helhed)
- [Institutet: gradøvelsen](https://www.astrologiskinstitut.dk/post/m%C3%A6rker-du-ogs%C3%A5-et-flashback-til-2017)
- [Institutet: Merkur/Venus-sløjfer](https://www.astrologiskinstitut.dk/post/det-sj%C3%A6ldne-sammenfald-mellem-merkur-og-venus-i-2025)
- [Institutet: En taske på skinner](https://www.astrologiskinstitut.dk/post/en-taske-p%C3%A5-skinner)

Kravdokumenterne i projektets `outputs/chart-skolekrav` er grundlaget.
Denne status beskriver den faktiske kode og erstatter ikke en skolegodkendelse.


## Visuel forfinelse · 16. oktober 2026

Institut-profilen har fået en særskilt visuel udgave i `static/school/institut.css`
og `institut-design.js`: let Raleway, Mulish, varm creme, dæmpet guld,
originale geometriske ornamenter, tydeligere hjulsymboler og en tættere
indramning af enkelthjulet. Farver og typografisk retning er genbesøgt på
[Institutets hjemmeside](https://www.astrologiskinstitut.dk/).

Det lokale arkiv kan foldes sammen og starter lukket på små skærme.
Mobilvisningen er kontrolleret ved 390 og 320 px uden vandret overløb.
Øvelser med skjulte oplysninger, genåbning af gemt arbejde, tre lag, zoom,
sprogskift og skoleskift er kontrolleret i browseren. SVG-eksporten indeholder
fortsat metadata og den nye indramning. 33 eksisterende JavaScript-kontroller
består. Beregningskoden er identisk med kopien før designændringen.

Et komplet kildearkiv fra før forfinelsen ligger uden for pakkemappen i
`../school-chart-backups/before-institut-polish-2026-10-16.zip`.


## Tre personlige værksteder · 16. oktober 2026

Under **Fordybelse** i Institut-versionen findes nu:

- **Venus Star Point:** personligt punkt, fem beregnede konjunktioner,
  klikbar stjerne, 4-/8-årsrytmer, morgen-/aftenstjerne, forbindelser til radix,
  egne refleksioner og SVG. En cyklusdato kan føjes til livslinjen.
- **Måneknuderne:** begge knuder, herskere, dispositørkæder og aspekter,
  fremhævet horoskophjul og tre refleksionsfelter. Følger lærerindstillingerne.
- **Min livslinje:** op til 40 daterede begivenheder med noter; redigering og
  fortryd ved fjernelse; dagsbilleder med transitter og progressioner; original
  sammenholdt med én fødselstidskandidat inden for ±180 minutter.

Felter og indstillinger følger med gem/genåbn og JSON-eksport/import.
Gamle studiearbejder kan stadig åbnes. Værkstederne bygger altid på person A's
fødselsoplysninger; alternative fødselstider ændrer ikke originalen.

Se [beregningsgrundlag og konkrete afgrænsninger](INSTITUT-WORKSHOPS.md).
Browserkontrollen omfatter alle tre moduler, gem/genåbn, JSON-import,
refleksioner, kandidatændring, redigering/fortryd, sprogskift og åbning af
livslinjens dato i tre hjul. Alle moduler er kontrolleret ved 390 og 320 px
uden vandret side-overløb. Der er ingen tilføjelse til den gamle generator.

## Fjerde værksted · Kirseboms sløjfemetode

**Sløjfemetoden** ligger under Fordybelse eller `/institut#sloejfer` og bruger
Kirseboms tre offentlige artikler. Merkur–Pluto, ni beregnede trin, forbindelser
mellem gentagne grader, fokus ved fødsel/valgt dato/progression, klikbar SVG,
egne trinnoter og overførsel til livslinjen. De to astronomiske stationer
adskilles fra metodens øvrige trin. For ydre planeter bevares konjunktionernes
faktiske placering i tidsforløbet. Progressive livsdatoer beregnes med samme
årsnøgle som horoskopmotoren; usikkert tidspunkt viser et datointerval.

14 passager er kontrolleret mod skolens afrundede 2025-tabel. Alle otte
planeters stationsretning, Sol-geometri og gentagne grader har automatiske
kontroller. Den offentlige metode er kodet; en direkte underviserkontrol og
skolens egne lærerprofiler er fortsat særskilte opgaver.

Kildearkivet før tilføjelsen ligger i
`../school-chart-backups/before-kirsebom-loops-2026-10-16.zip`.


## Astrology University · egen identitet og fire studieværksteder

Blå forside, mintgrønne accenter, Libre Baskerville/Montserrat og originale
himmelillustrationer. Fire kursusbaserede værksteder under **Study rooms**:

- **Chart Synthesis:** Tony Howard og Karen Hamaker-Zondag.
- **Your Year Ahead:** Kelly Surtees.
- **Prenatal Lunation:** Israel Ajose.
- **Relationship Dynamics:** Brian Clark.

Personlige beregninger, egne refleksioner og kildelinks i hvert værksted.
Daterede årsnoter og person B bevares med studiefilen. De præcise metoder,
herunder usikker fødselstid, er beskrevet i
[University-værkstedernes dokumentation](UNIVERSITY-WORKSHOPS.md).

Alle 418 automatiske kontroller består. Browserkontrollen omfatter alle fire
værksteder, planetvalg, fødselsdagsgrænsen, synastrifiltre, fremhævning,
gem/genåbn, JSON-rundtur og dansk/engelsk. Alle fire værksteder er kontrolleret
ved 390 og 320 px uden vandret overløb. Institutets sløjfemetode fungerer
fortsat efter skoleskift.
