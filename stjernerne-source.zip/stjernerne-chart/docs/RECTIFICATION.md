# Fødselstidskorrektion · 13. oktober 2026

## Brug

Beregn fødselshoroskopet, vælg Fødselstidskorrektion og flyt skyderen eller brug
±1/5/15 minutter. Hjulet, planeternes huse, aspekt- og positionstabellerne følger
kandidaten. AC/MC-ændringer og planeter, der skifter hus, opsummeres. Små knapper
ved selve hjulet gør det muligt at flytte tiden uden at forlade diagrammet.
Original-knappen vender tilbage til det oprindelige tidspunkt, der aldrig ændres.

Behold op til fem kandidater inklusive originalen. Under Kandidater & begivenheder
kan man tilføje op til fem datoer med korte labels og sammenligne dem med alle
kandidater. Et klik på en forbindelse viser begivenhedens langsomme transitter
som ydre ring og det valgte aspekt til kandidatens AC/MC.

Kandidater og begivenheder eksisterer kun i fanens hukommelse. Genindlæsning og
ændring af de oprindelige fødselsdata rydder dem. Skift mellem horoskoptyper
bevarer dem. Labels sendes ikke til serveren. Ingen localStorage, database,
AI-fortolkning eller automatisk kompatibilitets-/rektifikationsscore.
SVG-download viser det aktuelle hjul; der er ikke eksport af sessionsdata.

## Eksplicit metode

Tidsintervallet er ±180 **forløbne minutter på UTC-tidslinjen**, med originale
sekunder bevaret. Et sommertidsskift kan derfor springe eller gentage lokal tid;
visningen inkluderer UTC-offset. Originalens eventuelle foldvalg opløses først,
og kandidatens lokale tid/fold omregnes fra den nye UTC. En manuelt dokumenteret
UTC-forskel holdes fast, også ved forskydning. Datooverløb håndteres, men kandidater
før 1900 eller efter nu afvises. Beregninger bruger samme tropiske Swiss/Placidus-
motor og indstillinger som det oprindelige fødselshoroskop.

Begivenheder beregnes som **én prøve kl. 12 UTC på den oplyste dato**. Det er ikke
et registreret begivenhedstidspunkt. Jupiter, Saturn, Uranus, Neptun og Pluto
sammenholdes med AC og MC, med konjunktion, sekstil, kvadrat, trigon og opposition
inden for 2° orb. Ingen Måne, transithuse, progressioner, eksaktsøgning, fase eller
statistisk sandsynlighed er med i denne sammenligning. Husplaceringer er fortsat
baseret på ekliptisk længde mellem Placidus-spidser.

Tabellen bevarer kandidat-/begivenhedsrækkefølgen og viser også tomme celler.
Den enkelte celles aspekter sorteres efter orb alene; kandidater rangeres ikke.
En begivenhed før en kandidats lokale fødselsdato afvises. Samme kalenderdag
accepteres, da begivenhedens faktiske klokkeslæt er ukendt.

Astrologiske sammenfald kan ikke dokumentere et faktisk fødselstidspunkt.
Metoden er et transparent værktøj til udforskning, ikke en valideret estimator.
Astrodienst om metodens begrænsninger: https://www.astro.com/faq/fq_ua_method_s.htm

## API og test

- POST /api/rectify: {birth: Birth, shift_minutes: heltal -180..180}.
- POST /api/rectify/compare: {birth: Birth, shifts: op til 5 heltal, events: op til
  5 ISO-datoer fra 1900 til i dag}. Ingen labels modtages; ukendte felter afvises.
- Eksisterende origin-, host-, payload- og ratebegrænsning gælder begge endpoints.
- Debounce, afbrudte forespørgsler og generationskontrol forhindrer ældre svar i
  at overskrive den seneste forespørgsel. Hjulet angives som foregående resultat,
  og download/gem deaktiveres under en uberegnet forskydning.

Tests dækker identitet ved nul, separat Swiss-reference ved +15 minutter,
bevarede sekunder, originalens uforanderlighed, midnat/skuddag, begge DST-skift,
foldvalg, dokumenteret offset, dato-/antals-/typegrænser, begivenhed før fødsel,
planetudvalg, prøveklokkeslæt, aksegeometri over 0° og præcis 2°-orbisgrænse.
