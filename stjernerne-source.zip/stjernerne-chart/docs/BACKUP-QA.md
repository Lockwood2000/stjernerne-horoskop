# Backup og flytning · 14. oktober 2026

## Resultat

Den publicerede app er afprøvet med en faktisk downloadet JSON-backup fra Chrome,
importeret via filvælgeren i en separat browser (Codex-appens browser). Begge
brugte https://stjernerne-horoskop.onrender.com/ direkte. Ingen kodeændring,
ny deployment eller betalt tjeneste var nødvendig.

## Gennemført gennem brugerfladen

- Oprettet og gemt “Flyttetest fra Chrome – ÆØÅ” med fiktive eksempeldata:
  København, 15. juni 1990 kl. 14:30:00, ekstra himmellegemer tilvalgt.
- Beholdt originalen og +15 minutter som tidskandidater. Aktuel visning +15.
- Tilføjet “Test – flytning til Ærø”, 2020-08-15, og “Test – nyt arbejde”,
  2023-02-01. Gemte derefter horoskopet.
- Eksporteret en reel fil på 762 bytes, format stjernerne-horoskoper, version 1.
  Filens indhold blev læst og kontrolleret mod indtastningen.
- Importeret i Chrome som kopi: biblioteket gik fra 1 til 2 poster.
- Importeret samme fil i separat browser: biblioteket gik fra 1 til 2 poster,
  og den eksisterende post “Eksempel · tidskandidater og begivenheder” blev bevaret.
- Åbnet importeret post og genberegnet korrekt. Original 14:30, kandidat 14:45;
  AC 11°33′42″ Vægten og MC 16°00′06″ Krebsen for kandidaten.
- Genindlæst destinationssiden og genåbnet posten. Navn med danske tegn,
  fødselsdata, begge kandidater, valgt +15 og begge begivenhedsdatoer var bevaret.
- Genberegnet begivenhedssammenligningen: 2 kandidater × 2 begivenheder.
  Uranus sekstil MC, 1°49′13″, for original/2020-08-15; Uranus sekstil MC,
  1°01′16″, for +15/2023-02-01.
- Importeret en fil med én gyldig og én ugyldig post. Hele filen blev afvist med
  “Filen indeholder ugyldige eller ikke-understøttede horoskopdata.” Antallet
  forblev 2, begge poster og det åbne horoskop var bevaret.
- Gentaget gyldig filimport ved 390 × 844 pixels. Biblioteket gik fra 2 til 3
  poster, med besked om kopier og bevarede eksisterende horoskoper. Viewport nulstillet.

Ni målrettede automatiske tests i tests/library.test.mjs blev genkørt: alle bestået.
De dækker blandt andet formater, sekunder, manuelle tidszoner, alle horoskoptyper,
papirkurvsstatus, datovalidering og afvisning af delvist ugyldige filer.

## Afgrænsning

Dette er overførsel mellem to browserlagre på samme computer, ikke mellem to
fysiske enheder. 390 pixels er størrelsestest, ikke iOS/Safari eller Android.
Squarespace-iframe er efterfølgende verificeret med Chromes native filvælger,
se nedenfor. Browserstyringens filechooser-hændelse havde tidligere timeout;
det var ikke en påvist fejl i appens import.
Indlejret visning og fuld størrelse kan have separate browserlagre. Eksport skal
derfor foretages dér, hvor horoskoperne er gemt. Der er ingen automatisk synkronisering.

## Dokumentation

- ../../backup-import-verified.png: gendannede tidskandidater.
- ../../backup-import-events.png: genberegnet sammenligning efter import og genindlæsning.
- ../../backup-import-mobile.png: vellykket import ved 390 pixels.
- backup-transfer-fixture.json: den faktiske eksporterede backup, kun fiktive testdata.

Flytning: Gem ændringer → Mine horoskoper → Backup og flytning til en anden enhed
→ Eksportér backup. Overfør JSON-filen til den nye enhed, vælg Importér backup,
og åbn det importerede horoskop. Internet er nødvendigt for genberegningen.

## Afsluttet importtest direkte på Squarespace

På https://www.stjernerne.io/dit-horoskop blev Importér backup aktiveret inde
i den publicerede iframe. Chromes almindelige macOS-filvælger åbnede, og den
faktiske 762-byte eksportfil blev valgt og åbnet. Appen meddelte, at én kopi
var importeret, og biblioteket gik fra 1 til 2 poster. Den eksisterende
“Mobiltest 320 – Aarhus” blev bevaret sammen med “Flyttetest fra Chrome – ÆØÅ”.

Hele Squarespace-siden blev genindlæst. Den importerede post blev genåbnet
inde i iframe, med original 14:30 og kandidat +15 minutter/14:45, korrekte
AC/MC-værdier og begge begivenheder med danske tegn og datoer. Sammenligning
blev genberegnet på siden med samme 2 × 2-resultat som i den direkte app.
Ingen ny fane, kodeændring eller publicering var nødvendig for importforløbet.

Skærmbillede efter genindlæsning/genåbning: ../../squarespace-import-verified.png.
Testmiljø: Chrome på macOS, almindelig desktopvisning. Fysiske telefoners
filvælgere og Safari er fortsat ikke afprøvet.
