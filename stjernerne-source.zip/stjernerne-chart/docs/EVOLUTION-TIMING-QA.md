# Evolutionary timing update - 17 October 2026

## Delivered behavior

- Five selectable house systems: Porphyry (retained default), Placidus,
  Equal House from ASC, Regiomontanus and Whole Sign. The same-origin bridge
  preserves all five codes.
- Secondary progressions, true solar arc and exact solar return use the
  existing local Swiss Ephemeris school-engine calculations. No new service.
- Secondary/solar arc accept a target date, clock time and IANA zone. Solar
  return accepts a year and explicitly uses the birthplace, a searched city,
  or confirmed manual coordinates and zone.
- Timing planets, house ticks and ASC/MC appear in the purple outer ring.
  Tables expose the active layer, its own houses, separate natal-house
  assignments, and all twelve cusps. Solar arc motion is labelled symbolic.
- All 17 independently calculated planetary-node pairs remain natal and
  selectable. The evolutionary focus, lunar comparison and Pluto polarity
  retain their natal meaning.
- The active method/date/place and position-layer selection travel with JSON
  save/export/import. SVG contains the input and calculation metadata. The
  A4 print/PDF layout includes the timing ring, label and date/location.
- Method help records the 365.2422-day key, Naibod RA axes, true solar arc
  derivation and actual tropical apparent geocentric solar return convention.

## Automated verification

**389 passing checks: 344 Python + 45 JavaScript**, including the subsequent
clockwise polar-house correction below. The preceding timing release passed
368 checks before the 21 polar regression checks were added.
App JavaScript syntax check also passed. One retained Starlette/httpx
deprecation warning; no test failures.

The new timing suite contributes 32 Python cases; the SVG/print suite adds
four JavaScript cases. Checks include:

- All five natal house systems agree with the retained official `swetest`
  executable within 0.000001 degree. Equal cusps are 30 degrees apart from
  ASC; MC is verified as an independent angle.
- All fifteen timing/house combinations retain 17 natal node pairs, 21
  calculated bodies, the selected house method and distinct natal-house data.
- Secondary epoch follows actual elapsed UTC time / 365.2422 and axes follow
  Naibod RA. Solar longitude agrees with `swetest` at the ephemeris epoch.
- Solar arc applies the secondary Sun's arc to every planet, angle and cusp,
  including all nine extra bodies. Physical motion, declination, latitude and
  distance claims are omitted for this symbolic direction.
- Solar-return cases include a leap-day birth and a year-end birth. Calculated
  solar residuals are below 0.0001 arcsecond. A separate `swetest` comparison
  at the solved TT epoch agrees with natal longitude within 0.000001 degree
  (the CLI comparison has its own printed precision).
- Moving a return location changes houses/angles, while keeping the solved
  epoch, planetary longitudes and natal node pairs identical.
- Required dates/years, unknown birth time, pre-birth targets, invalid/mixed
  places, target DST folds and explicit polar-house failure are checked.
- All three timing layers retain 34 node markers, house ticks, angles,
  correct aspect highlighting and 17 table rows in static print rendering.

These are numerical integration checks against the same retained Swiss
Ephemeris source, not an independent astronomical theory or a universal error
bound. House codes and conventions were checked against the
[official Swiss Ephemeris programmer documentation](https://www.astro.com/swisseph/swephprg.htm).

### Clockwise polar houses - subsequent correction

`app/engine.py` now determines whether the twelve cusp intervals make one
complete circle forwards or backwards. `house_for` applies that direction to
both planet distance and cusp span. Invalid, incomplete or non-finite cusp
cycles are rejected. No replacement house system is introduced.

`static/wheel.js` exports the same validated direction/midpoint rule. All local
wheels use it: the retained workshop, retained school copy, evolutionary natal
wheel and its timing-house ring. The enlarged wheel and print document reuse
the evolutionary renderer, so their house-number labels follow the same rule.

The retained real reference is `tests/polar-houses-reference.json`:
21 June 2026, 00:00 UTC, latitude 69.6492 N, longitude 18.9553 E, Regiomontanus.
Its forward interval sum is 3960 degrees and its reverse sum is 360 degrees.
The Sun at 89.6656064506634 degrees belongs to house 11; the previous forward-only
loop incorrectly assigned it to house 1.

18 added Python cases verify real clockwise and counterclockwise cusps at both
northern and southern polar latitudes, all 21 natal bodies and all 34 node
points against the separate native `swe_house_pos` spherical calculation at
zero ecliptic latitude, cusp boundaries, all three timing methods, malformed
cycles and explicit unavailable-Placidus failure. Native Regiomontanus returns
success (status 0), agrees with official `swetest` cusp output within 0.000001
degree, and differs from Porphyry; no hidden fallback occurs.

Three added JavaScript checks cover actual reference midpoints, invalid/empty
cycles, and the coordinates of all twelve house-number labels in every local
wheel and in print, including the timing-house ring. These use the real cusp
fixture and preserve the input data.

Actual browser verification used the form's manual coordinates to calculate
the reference case. Regiomontanus remained selected, the position table showed
Sun in house 11, and all twelve natal house labels matched the clockwise
reference coordinates both on the wheel and in the A4 preview. All 34 nodes
and 17 print-table rows remained visible, with no overlapping/clipped node
labels or heading/table/footer overflow. Choosing Placidus showed the explicit
latitude restriction and retained the previous result as stale; recalculating
Regiomontanus cleared the error. The pre-test chart and notes were restored.

Screenshots: `screenshots/evolution-polar-regiomontanus-large.jpg` and
`screenshots/evolution-polar-regiomontanus-print.jpg`. No new PDF was authored
in this correction; the print renderer itself is covered.

## Actual browser verification

- Equal House and Regiomontanus calculate and update chart badges/tables.
  Retained Placidus and Whole Sign also calculate with solar return.
- A secondary target of 17 October 2026 at 18:45:30 Europe/Copenhagen resolves
  to 16:45:30 UTC and renders 12 core timing markers, 12 house ticks and 2 axes.
- Solar arc renders its own position table, ASC/MC, natal-house column and
  Symbolic motion labels.
- London was selected through real atlas search; the 2026 return solved to
  15 June 2026 at 05:23:40.184695 UTC, 06:23:40.184695 Europe/London.
- Switching to birthplace and back preserves the chosen London city. Manual
  London coordinates were confirmed and calculated successfully.
- Real JSON download, reset, file-chooser import and recalculation restored
  Whole Sign, solar return, year, manual London location, all 17 visible pairs,
  the timing position-layer selection and test reading notes. Existing browser
  localStorage was not overwritten during QA; Save uses the same file payload.
- All three actual A4 previews contained 34 node points and 17 table rows,
  with no overlapping/clipped node labels or overflowing heading, table or
  footer. The footer sizes to its timing text instead of clipping a third line.
- At the current 351 x 662 browser viewport, both the whole A4 preview and
  the large chart fit. Large view retains all 17 compact-table rows without
  dialog/chart scrolling and labels the active solar return method.
- Unknown birth time omits houses/angles, disables the timing overlay and
  retains 34 natal node markers. The original user's Porphyry chart, notes and
  all-17 view were restored through the pre-update JSON backup after QA.
- Browser console: no errors. Screenshots:
  `screenshots/evolution-solar-return-large.jpg` and
  `screenshots/evolution-solar-return-print.jpg`.

The print checks cover the actual HTML/SVG document and fitted preview.
Physical-printer output and native OS PDF-save were not repeated in this update.
The previous standalone PDF remains available unchanged under `output/pdf/`.

## Changed files

All paths below are relative to this standalone `evolution-chart` folder:

- `app/evolution.py`, `app/evolution_api.py`, `app/engine.py`
- `static/wheel.js`, `static/school/wheel.js`
- `static/evolution/app.js`, `index.html`, `wheel.js`, `timing.js`, `bridge.js`
- `static/evolution/print.js`, `print.css`, `observatory.css`
- `tests/test_evolution_timing.py`, `tests/evolution-wheel.test.mjs`
- `tests/test_evolution_polar_houses.py`, `tests/polar-houses-reference.json`,
  `tests/wheel.test.mjs`
- `README.md`, `docs/EVOLUTION-INTEGRATION.md`, `docs/EVOLUTION-QA.md`, this file
- The timing and polar screenshots listed above and `source/stjernerne-source.zip`

No original generator checkout in another conversation was modified. The
local copy of the common engine was corrected for cusp direction; the retained
timing calculations were reused.

## Running status and remaining boundaries

The updated local server is running at
<http://127.0.0.1:8776/evolution>, bound to loopback only. The corresponding
source archive was regenerated and its changed members verified.

There are no outstanding local implementation blockers. This update has not
been published to the live Stjernerne/Squarespace site, Render or Sites; it
adds no new public endpoint or service. Live deployment remains a separate
deployment/integration step under the existing publishing approvals.
The repository and prior delivery records contain no existing published test
or site URL for this standalone generator. The existing approved local address
has been updated; no remote site was created or published.
