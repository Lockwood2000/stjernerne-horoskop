# Kündigs individuelle solnøgle · 15. oktober 2026

## Brug og beregningskonvention

Vælg Progressioner → Akser og huse → Kündigs individuelle solnøgle.
Resultatet viser den årlige nøgle og den samlede aksebue. Under Fødselstid →
Kandidater & begivenheder kan samme metode vælges til hver tidskandidat.
Valgene følger bibliotek, genåbning og backup/import. Ældre gemte progressioner
bevarer Naibod, og ældre begivenhedssammenligninger bevarer transitter.

Electric Ephemeris' ARGUS-manual, trykt side 105, beskriver en fast årlig
bevægelse af RAMC svarende til en ekliptisk solgrad omregnet til rektascension:
https://www.electric-ephemeris.dk/download/argus421.pdf

Denne implementation vælger den **hele zodiakgrad, fødselssolen står i**.
Med λ som fødselssolens tropiske længde og ε som sand natal obliquitet:

    g = floor(λ mod 360)
    RA(x) = atan2(sin(x) cos(ε), cos(x)) mod 360
    nøgle = (RA(g + 1°) − RA(g)) mod 360
    alder = forløbne UTC-dage / 365,2422
    progressiv ARMC = natal ARMC + alder × nøgle

Nøglen beregnes særskilt for hver fødselstidskandidat og fryses til natal-epoken.
AC, MC og Placidus-huse beregnes derefter med den progressive obliquitet.
Planeterne følger fortsat direkte sekundærprogression (én dag = ét leveår),
uanset aksemetoden. Nøglen bruges altså ikke som en bue til alle planeter.

Den hele grads konvention gengives som en henvisning til Kündigs
Astrologische Prognose, side 213, i Anthony Louis' offentliggjorte metodegennemgang
og hans svar på Bernd Muellers rettelse:
https://tonylouis.wordpress.com/2016/07/30/the-kundig-sun-key-for-directing-a-chart/
Louis beskriver selv også en variant fra eksakt natal længde til længde +1°.
Den variant er ikke valgt her. Den trykte originalbog er ikke kontrolleret, og
der hævdes ikke numerisk identitet med en konkret ARGUS-installation.
Det er heller ikke en nøgle baseret på faktisk solbevægelse over 24 timer.
De eksplicitte gradgrænser, obliquitet og decimalnøgle returneres i resultatet,
så beregningsvarianten kan efterprøves uden at gætte ud fra navnet.

## Livsbegivenheder og hjul

En begivenhed prøves kl. 12 UTC på den valgte dato. Viser de fem hovedaspekter
med højst 1° orb: progressive AC/MC til fødselsplaneter og progressive planeter,
og progressive planeter til natal AC/MC. Planetgruppen er Solen til Pluto.
Tabellen bruger P for progressiv og R for radix. Vis progression i hjulet viser
fødselskandidaten inderst og sekundærplaneter og progressive AC/MC yderst.
De progressive husspidser findes i beregningen; biwheelets huslinjer er radix.

Der er ingen søgning efter eksakte passager i månederne omkring begivenheden,
ingen mindre aspekter, automatiske fortolkninger, rangering eller sikkerhedsscore.
Dette er ikke hele CORREX-udskriften. Transitter er fortsat et separat valg.
Astrologiske sammenfald dokumenterer ikke en faktisk fødselstid.

## Verifikation og drift

161 Python-tests og 29 JavaScript-tests bestod før udgivelse. Browserprøven
omfattede progression med synlig nøgle, tre snit med en testbegivenhed, biwheel
med AC P/MC P, gemning, genindlæsning, eksport og import af en rigtig JSON-backup.
Metodevalg, begivenhed og tidspunktet 15:19:09 blev bevaret. Ved 390 × 844 var
sidebredden 390 uden vandret sideudvidelse; hjulet var 364 px bredt. Testdataene
var opdigtede og blev kun gemt på den lokale testadresse.

Den geometriske nøgle sammenholdes med Swiss Ephemeris' selvstændige
koordinatrotation, også hen over 360°/0°. Tests dækker gradgrænser, fast nøgle
ved forskellige aldre, nulalder, uændrede sekundærplaneter, analytisk MC,
API-validering, akseaspekternes orbgrænse, kandidatsammenligning og backupvalg.
Den gengivne 7° Tvillingerne-nøgle på cirka 1°03′39″ bruges kun som en grov
ekstern kontrol; den erstatter ikke sammenligning med originalprogrammet.

Ingen nye dependencies, tjenester, licenser eller serverlagring.
Hele tilføjelsen følger den eksisterende AGPL-kildepakke. Ingen proprietær
ARGUS/CORREX-kode er brugt. Squarespace-indlejringen kræver ingen ændringer.
