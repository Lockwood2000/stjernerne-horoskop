# Gennemgang af Kündig-forløbet · 15. oktober 2026

## Resultat og ændringer

Kündig-snit og den individuelle solnøgle var allerede implementeret. Den tidligere
brugerflade krævede, at brugeren selv fandt sammenhængen mellem snit, kandidater,
metodevalg og livsbegivenheder. Denne ændring gør sammenhængen synlig:

1. Find snit med en tydelig startknap, som vælger kun Kündig.
2. Behold to eller tre mulige tidspunkter og se dem i hjulet.
3. Gå videre til daterede livsbegivenheder og sammenlign med Kündigs solnøgle.

En kort ordliste forklarer snit, kandidat, solnøgle, AC/MC og orb. Hjælpen viser
næste trin ud fra det aktuelle arbejde. Manuel tidsflytning er valgfri og
sammenfoldet. Tabellen forklarer rækker, kolonner og begrænsninger; progression
og fødsel skrives helt ud i stedet for P/R. Tekniske metodeoplysninger kan
foldes ud. På mobil lander valget Fødselstid ved guiden; tidligere flyttede
automatisk fokus på hjulfanen siden forbi vejledningen. Den rettelse bevarer
fanernes normale tastaturfokus, når en fane vælges direkte.

## Kontrol

175 Python-tests og 31 JavaScript-tests bestod. Efter de sidste ændringer i
navigation, fokus og statustekst bestod alle 31 JavaScript-tests igen.
JavaScript-syntaks og entydige HTML-id'er er kontrolleret.

Det lokale forløb blev afprøvet med det fiktive standardhoroskop: København,
15. juni 1990 kl. 14:30. Startknappen gav de samme tre Kündig-snit som før:
13:35:08, 14:27:38 og 15:19:09 inden for ±1 time. De sidste to blev beholdt
sammen med originalen. En fiktiv flytning 1. juni 2020 blev tilføjet, og
progressionssammenligningen blev beregnet med den individuelle solnøgle.
Tallene var uændrede; de nye, fuldt udskrevne betegnelser var synlige.
Tilbageknappen bevarede arbejdet. Valgfri tidsflytning ændrede preview med
præcis ét sekund. Startknappen fungerede også via Enter, og fokus blev flyttet
til snitmetodefeltet, mens søgningen kørte.

Ved 390 × 844 pixels var dokumentets bredde og scrollbredde begge 390.
Fødselstid landede ved guiden, og Videre til livsbegivenheder landede ved
de valgte tidspunkter. Den lange indstillingsdel blev foldet sammen, så den
ikke stod i vejen. Kandidaterne og sammenligningstabellen kunne betjenes.
Ingen personlige horoskoper blev ændret eller gemt under denne kontrol.

Den konkrete udgivelse og efterfølgende kontrol på Squarespace dokumenteres
uden for den offentlige kildepakke i arbejdsområdets work/clarity/release.json.

## Hvad kontrollen ikke beviser

Der er ikke gennemført en brugertest med en uøvet person. Vurderingen af
forståeligheden er en faglig gennemgang og en praktisk afprøvning af forløbet.
Fortolkning af aspekter kræver stadig astrologisk viden.

Beregningskoden, fødselsdata, biblioteksformat og backup/import er uændrede i
denne udgave. Testværdierne er regressionsværdier, ikke en uafhængig reference.
Ved denne brugerfladegennemgang var der endnu ikke udført ekstern numerisk
kontrol. Den efterfølgende sammenligning med en publiceret ARGUS-snitliste og
offentliggjorte solnøgler er nu dokumenteret i CROSSCHECK.md. Der er fortsat
ikke kørt en ARGUS-installation. Se KUNDIG.md og SOLAR-KEY.md for den
valgte metodekonvention. Begivenhedssammenligningen tager ét udsnit pr. dato
(kl. 12 UTC), bruger fem hovedaspekter og søger ikke efter præcise passager
i månederne omkring begivenheden. Dette er ikke hele CORREX-systemet, og
snit eller lille orb fastslår ikke et faktisk fødselstidspunkt.
