# Evolutionary overlay integration

## Shared foundation

Copied from the latest local school-chart workspace on 16 October 2026. The
retained workshop at `/`, and school endpoints at `/api/school/*`, remain
available. New code is isolated in `app/evolution.py`, `app/evolution_api.py`
and `static/evolution/`. `app/main.py` only registers the new routes and their
validation messages. The copied school UI imports and mounts `bridge.js`.

No changes have been written to the source checkouts in other threads.

## Mount over a school or another chart generator

```js
import {openEvolutionOverlay} from '/static/evolution/bridge.js';

openEvolutionOverlay({
  name: 'My practice chart',
  place_label: 'Copenhagen, Denmark',
  birth: {
    date: '1990-06-15',
    time: '14:30:00',
    confidence: 'exact',
    place_id: '2618425'
  },
  settings: {house_system: 'O', lunar_node: 'true', ruler_mode: 'modern'}
});
```

The helper mounts `/evolution?embed=1` in a modal iframe, waits for the ready
message and passes birth data using `postMessage`. The child checks both
the exact origin and that the sender is the parent window. Birth data are
not included in the URL. The original chart remains underneath the overlay.
Closing the dialog removes the iframe and its message listener.

For a host house system outside O/P/W/E/R the helper explicitly labels its
Porphyry starting setting in the dialog heading. Host fold choices, documented
UTC offsets, approximate-time confidence and uncertainty are preserved.
The progression module uses Naibod axes, regardless of a host's other axis
methods, and labels this convention in the interface and result.

This bridge is same-origin. A cross-origin Squarespace deployment needs an
explicit allowed-parent origin and CSP/frame-ancestor configuration; it has
not been deployed or tested on the live Squarespace site.

## Calculation API

`POST /api/evolution/chart`, JSON:

```json
{
  "birth": {"date":"1990-06-15", "time":"14:30:00", "place_id":"2618425"},
  "house_system":"O",
  "lunar_node":"true",
  "node_reference":"geocentric",
  "node_method":"mean_barycentric",
  "node_orb":3,
  "quincunx":true,
  "extras":["chiron","ceres","eris","haumea","makemake","sedna","quaoar","orcus","gonggong"],
  "include_extra_nodes":true,
  "include_progressions":true,
  "target":{"date":"2026-10-16","time":"12:00:00","timezone":"UTC"},
  "ruler_mode":"modern"
}
```

Manual birth input replaces `place_id` with latitude, longitude and an IANA
timezone. The shared `BirthInput` also accepts fold, documented UTC offset,
uncertainty and confidence. Unknown time uses `time: null, confidence: "unknown"`.

The result contract is `stjernerne-evolution-1`:

- `natal`: compatible school-engine natal data, plus selected extra bodies.
- `planetary_nodes`: one pair per body, with north/south longitudes, latitude,
  speed, house, actual method and reference.
- `lunar_nodes`: true/mean comparison.
- `node_aspects`, `node_to_node_aspects`: separate contact groups.
- `timing`, `timing_aspects`: the optional selected timing layer and contacts.
- `progressed`, `progression_aspects`: retained secondary-only aliases, so old
  consumers are not given a solar arc or solar return labelled as a progression.
- `focus`: natal Pluto, polarity point, lunar nodes and their sign rulers.
- `input`, `calculation`, `warnings`: complete reproducibility information.

Planetary nodes are calculated at the natal epoch, including when progression
is enabled. All three timing methods can form aspects to those natal nodes.

### Timing options added on 17 October 2026

`house_system` accepts `O`, `P`, `W`, `E` and `R`; `O` remains the default.
`E` uses twelve 30° houses from ASC. MC remains an independent angle.
`R` is Regiomontanus. These codes pass through the same-origin bridge unchanged.

The retained `include_progressions` boolean activates the timing overlay for
backward compatibility. `timing_mode` defaults to `secondary`; it also accepts
`solar_arc` and `solar_return`. Secondary and solar arc require `target`, with
its date, local time, IANA zone and optional fold. Target DST choices are
identified by `error.context: "target"`; birth choices remain `"birth"`.

Solar return requires `return_year` (1500–2099, from birth onwards). Set
`return_place: null` to explicitly use the birthplace, or provide
`{"place_id":"2643743"}` for a selected atlas place. Manual input uses
`{"place_name":"London","latitude":51.50853,"longitude":-0.12574,"timezone":"Europe/London"}`.
An atlas ID cannot be mixed with manual coordinates. The solved epoch is the
same at all locations; houses, angles and the displayed local time use the
selected location. No fixed birthday/noon surrogate is used.

Numerical conventions:

- Direct secondary: ephemeris UTC = birth UTC + elapsed days / 365.2422.
  ARMC advances 0.98564733° per year in right ascension (Naibod), using
  progressed obliquity, the selected house system and the birthplace.
- Direct true solar arc: secondary progressed Sun minus natal Sun in tropical
  longitude. Apply the same arc to every natal planet, angle and cusp.
  Motion/declination claims are omitted for this symbolic direction.
- Solar return: Newton solution of apparent geocentric tropical solar longitude
  near the birthday in the requested year, with no precession correction.
  Results include `solar_error_arcsec`, local and UTC time, and place provenance.

`timing.planets[].house` is placement in that timing layer's own houses;
`house_in_natal` is separately assigned against natal cusps. `input` records all
active method/date/place choices. JSON save/export/import, SVG metadata, the
enlarged wheel and the dedicated A4 print/PDF document use that same result.
Planetary nodes, lunar comparisons, Pluto polarity and the evolutionary focus
remain natal in all three modes. All 17 node pairs remain independently selectable.

## Boundaries of this model

- There is no automatic evolutionary interpretation, stage assignment, or
  generated report.
- A single sign ruler is used; co-ruler chains are not inferred.
- Progressive node pairs, transit node pairs and planet-to-planet orbital-plane
  intersections are not added by this release.
- Natal background aspect lines are from the retained core chart; additional
  bodies participate in the new node-contact tables.
- The model does not offer an account, cloud chart library or synchronization.
- The server accepts calculation requests from its configured origin and applies
  the retained request-size/rate limits. Keep a single native worker locally.
- Deploy using the retained Python/Docker stack. A static frontend alone cannot
  run the native Swiss library. The app was not deployed to Sites.

## Sources for the mathematical contract

- [Swiss Ephemeris programmer documentation](https://www.astro.com/swisseph/swephprg.htm)
- [Swiss Ephemeris planetary-node definitions](https://www.astro.com/swisseph/swisseph.htm)
- [Official file download locations](https://www.astro.com/ftp/swisseph/ephe/)

Implementation details are in Method and exported metadata; primary controls
use practitioner-facing terminology.
