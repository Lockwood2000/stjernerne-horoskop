import {houseLabel} from './chart-options.js';
import {chartReady} from './navigation.js';
import {fillBirthForm} from './birth-form.js';
import {renderWheel,dms} from './wheel.js';
const $=id=>document.getElementById(id);
const el=(tag,text)=>{const x=document.createElement(tag);if(text!==undefined)x.textContent=text;return x;};
export function createSynastry(context,renderNatal,setTab){
  const form=$('birth-form').cloneNode(true);
  for(const node of [form,...form.querySelectorAll('*')]){
    for(const attribute of ['id','for','aria-controls','aria-describedby'])if(node.hasAttribute(attribute))node.setAttribute(attribute,node.getAttribute(attribute).split(' ').map(x=>'syn-'+x).join(' '));
  }
  $('synastry-form-slot').append(form);
  const s=id=>$('syn-'+id);
  s('date').value='1992-03-21';s('time').value='10:15:00';s('calculate').textContent='Beregn synastri';
  let selected={id:'2618425',name:'København',country:'Denmark',latitude:55.67594,longitude:12.56553,timezone:'Europe/Copenhagen'};
  let data=null,chosen=null,serial=0,controller=null,searchController=null,timer=null;
  const points=c=>[...c.planets,{id:'ascendant',name:'AC',...c.ascendant},{id:'midheaven',name:'MC',...c.midheaven}];
  function clear(){s('calculate').disabled=false;serial++;controller?.abort();data=null;chosen=null;$('synastry-details').replaceChildren();$('synastry-order-label').hidden=true;$('synastry-status').textContent='';s('error').hidden=true;}
  function changed(resetFold=true){clear();renderNatal();$('download').disabled=true;$('synastry-status').textContent='Beregn igen med de nye oplysninger. Hjulet viser person A.';if(resetFold){s('fold-panel').hidden=true;s('fold').value='';}}
  form.addEventListener('input',e=>changed(e.target.id!=='syn-fold'));
  s('manual-place').addEventListener('change',()=>{s('manual-fields').disabled=!s('manual-place').checked;s('place-search').disabled=s('manual-place').checked;for(const id of ['latitude','longitude','timezone'])s(id).required=s('manual-place').checked;});
  s('manual-offset').addEventListener('change',()=>{s('offset-fields').disabled=!s('manual-offset').checked;for(const id of ['offset-minutes','offset-source'])s(id).required=s('manual-offset').checked;});
  s('place-search').addEventListener('input',()=>{
    selected=null;clearTimeout(timer);searchController?.abort();s('place-results').hidden=true;s('place-hint').textContent='Vælg et sted fra søgeresultaterne.';
    const q=s('place-search').value.trim();if(q.length<2)return;
    timer=setTimeout(async()=>{
      const abort=new AbortController();searchController=abort;
      try{const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:abort.signal});if(!response.ok)throw Error('Bysøgningen kunne ikke gennemføres.');const places=await response.json();if(s('place-search').value.trim()!==q)return;s('place-results').replaceChildren();
        for(const p of places){const li=el('li'),button=el('button',`${p.name} · ${p.country} · ${p.timezone}`);button.type='button';button.addEventListener('click',()=>{changed();selected=p;s('place-search').value=`${p.name}, ${p.country}`;s('place-hint').textContent=`${p.latitude}°, ${p.longitude}° · ${p.timezone}`;s('place-results').hidden=true;});li.append(button);s('place-results').append(li);}if(!places.length)s('place-results').append(el('li','Ingen resultater. Prøv et andet navn eller manuel placering.'));s('place-results').hidden=false;
      }catch(e){if(e.name!=='AbortError')s('place-hint').textContent=e.message;}
    },230);
  });
  s('place-search').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){s('place-results').querySelector('button')?.focus();e.preventDefault();}if(e.key==='Escape')s('place-results').hidden=true;});
  s('place-results').addEventListener('keydown',e=>{const buttons=[...s('place-results').querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}if(e.key==='Escape'){s('place-results').hidden=true;s('place-search').focus();}});
  function payload(){
    const b={date:s('date').value,time:s('time').value,include_dwarfs:s('include-dwarfs').checked,house_system:s('house-system').value};
    if(s('manual-place').checked){if(s('latitude').value===''||s('longitude').value==='')throw Error('Udfyld begge koordinater for person B.');Object.assign(b,{place_name:s('manual-name').value,latitude:Number(s('latitude').value),longitude:Number(s('longitude').value),timezone:s('timezone').value.trim()});}
    else{if(!selected)throw Error('Vælg fødested for person B.');b.place_id=selected.id;}
    if(!s('fold-panel').hidden&&s('fold').value!=='')b.fold=Number(s('fold').value);
    if(s('manual-offset').checked){if(s('offset-minutes').value==='')throw Error('Angiv UTC-forskellen.');b.offset_minutes=Number(s('offset-minutes').value);b.offset_source=s('offset-source').value.trim();}return b;
  }
  function draw(){
    if(!data)return;
    const inner=$('synastry-order').value,outer=inner==='a'?'b':'a',a=data[inner],b=data[outer];
    $('wheel').replaceChildren(renderWheel({...a,person:inner.toUpperCase(),display_title:'Synastri · Person '+inner.toUpperCase()}, {...b,kind:'synastry',person:outer.toUpperCase(),timing:b.birth,points:points(b)},chosen?{...chosen,natal:chosen[inner],transit:chosen[outer]}:null));
    $('chart-title').textContent='Synastri · to horoskoper';$('chart-label').textContent='PERSON A & PERSON B';
    $('chart-meta').textContent=`A: ${data.a.birth.local.slice(0,19).replace('T',' kl. ')} · ${data.a.place.name} / B: ${data.b.birth.local.slice(0,19).replace('T',' kl. ')} · ${data.b.place.name}`;
    $('chart-meta').textContent+=' · A: '+houseLabel(data.a)+' · B: '+houseLabel(data.b);$('house-label').textContent=houseLabel(data.a);
    const names=k=>Object.fromEntries(points(data[k]).map(p=>[p.id,p.name]));
    $('transit-caption').hidden=false;$('transit-caption').textContent=`Indre ring og huse: person ${inner.toUpperCase()} · Ydre ring: person ${outer.toUpperCase()}`+(chosen?` — A: ${names('a')[chosen.a]} · ${chosen.label.toLowerCase()} · B: ${names('b')[chosen.b]} · orb ${dms(chosen.orb).full}`:'');
    $('big-three').replaceChildren(...['a','b'].map(k=>{const card=el('div');const degree=el('span','AC: '+dms(data[k].ascendant.longitude).short+' '+dms(data[k].ascendant.longitude).sign);degree.className='degree';card.append(el('small','PERSON '+k.toUpperCase()),el('strong',data[k].place.name),degree);return card;}));
  }
  function table(caption,heads,rows){const wrap=el('div');wrap.className='table-wrap';const t=el('table');t.append(el('caption',caption));const head=el('thead'),tr=el('tr');for(const name of heads){const th=el('th',name);th.scope='col';tr.append(th);}head.append(tr);t.append(head);const body=el('tbody');for(const cells of rows){const row=el('tr');for(const cell of cells){const td=el('td');td.append(typeof cell==='string'?document.createTextNode(cell):cell);row.append(td);}body.append(row);}t.append(body);wrap.append(t);return wrap;}
  function details(){
    const names=k=>Object.fromEntries(points(data[k]).map(p=>[p.id,p.name]));
    const rows=data.aspects.map(aspect=>{const button=el('button',`A: ${names('a')[aspect.a]} ↔ B: ${names('b')[aspect.b]}`);button.type='button';button.className='transit-link';button.addEventListener('click',()=>{chosen=aspect;draw();setTab($('tab-wheel'));});return [button,aspect.label,dms(aspect.orb).full];});
    $('synastry-details').replaceChildren(table(`${data.aspects.length} aspekter mellem A og B`,['Forbindelse','Aspekt','Orb'],rows));
    for(const k of ['a','b'])$('synastry-details').append(table(`Person ${k.toUpperCase()} · positioner og huse`,['Planet','Placering','Eget hus','Hos '+(k==='a'?'B':'A')],data[k].planets.map(p=>[p.name+(p.retrograde?' ℞':''),`${dms(p.longitude).full} ${dms(p.longitude).sign}`,String(p.house),String(p.house_in_other)])));
    const warnings=['a','b'].flatMap(k=>data[k].birth.warnings.map(w=>'Person '+k.toUpperCase()+': '+w));$('warnings').replaceChildren(...warnings.map(w=>el('p',w)));$('warnings').hidden=!warnings.length;
    const details=el('dl');for(const k of ['a','b'])for(const [label,value] of Object.entries({UTC:data[k].birth.utc,Tidszone:data[k].birth.timezone,Tidsforskel:data[k].birth.offset_minutes+' minutter',Sted:`${data[k].place.name} · ${data[k].place.latitude}°, ${data[k].place.longitude}°`,Tidskilde:data[k].birth.source==='manual'?data[k].birth.source_note:'IANA '+data[k].birth.iana_version})){details.append(el('dt','Person '+k.toUpperCase()+' · '+label),el('dd',String(value)));}$('calculation-details').replaceChildren(details,el('p','Swiss Ephemeris '+data.a.calculation.version+' · tropisk · geocentrisk · A: '+houseLabel(data.a)+' · B: '+houseLabel(data.b)+' · True Node.'));
  }
  form.addEventListener('submit',async e=>{
    e.preventDefault();clear();renderNatal();$('download').disabled=true;
    const ctx=context();if(!ctx.valid){s('error').textContent='Beregn først person A med de aktuelle fødselsoplysninger.';s('error').hidden=false;return;}
    let b;try{b=payload();}catch(error){s('error').textContent=error.message;s('error').hidden=false;return;}
    const generation=serial;controller=new AbortController();const abort=controller,deadline=setTimeout(()=>abort.abort(),15000);s('calculate').disabled=true;$('synastry-status').textContent='Beregner de to horoskoper …';
    try{
      const response=await fetch('/api/synastry',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({a:ctx.payload,b}),signal:abort.signal});const received=await response.json();if(generation!==serial||$('chart-mode').value!=='synastry')return;
      if(!response.ok){if(received.error?.code==='ambiguous_time'&&received.error.person==='B'){s('fold-panel').hidden=false;s('fold').replaceChildren(new Option('Vælg forekomst …',''));for(const c of received.error.choices)s('fold').add(new Option(`${c.fold===0?'Første':'Anden'} · UTC${c.offset_minutes>=0?'+':''}${c.offset_minutes/60} · ${c.abbreviation}`,String(c.fold)));}throw Error(received.error?.message||'Synastrien kunne ikke beregnes.');}
      data=received;chosen=data.aspects[0]||null;draw();details();$('synastry-order-label').hidden=false;$('download').disabled=false;$('synastry-status').textContent='Synastrien er klar. Se forbindelser og husplaceringer under Synastrioversigt.';setTab($('tab-wheel'));chartReady({navigate:true});
    }catch(error){if(generation===serial){s('error').textContent=error.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':error.message;s('error').hidden=false;$('synastry-status').textContent='Hjulet viser person A.';}}
    finally{clearTimeout(deadline);if(generation===serial)s('calculate').disabled=false;}
  });
  $('synastry-order').addEventListener('change',draw);
  function snapshot(){if(!data)throw Error('Beregn synastrien før du gemmer den.');return {birth:payload(),order:$('synastry-order').value};}
  function pause(){serial++;controller?.abort();searchController?.abort();clearTimeout(timer);s('calculate').disabled=false;}
  function restore(saved,received){clear();pause();fillBirthForm('syn-',saved.birth,received.b);selected=received.b.place;data=received;chosen=data.aspects[0]||null;$('synastry-order').value=saved.order;draw();details();$('synastry-order-label').hidden=false;$('synastry-status').textContent='Synastrien er genberegnet fra biblioteket.';}
  return {snapshot,restore,pause,clear,draw,get data(){return data;}};
}
