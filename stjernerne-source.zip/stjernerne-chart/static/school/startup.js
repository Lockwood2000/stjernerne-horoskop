const screen = document.getElementById('startup');
const english = location.pathname.startsWith('/university');
const copy = english ? {
  brand: 'Astrology University · Study workspace', title: 'Your study space is opening',
  status: 'Preparing your workspace. It will open as soon as it is ready.',
  slow: 'Loading is taking longer than expected. Check your connection or try again.',
  failed: 'The workspace could not be opened. Check your connection and try again.', retry: 'Try again'
} : {
  brand: 'Astrologisk Institut · Studieværksted', title: 'Dit studierum åbner',
  status: 'Vi gør værkstedet klar. Du kommer ind, så snart det er parat.',
  slow: 'Det tager længere tid end forventet. Kontrollér forbindelsen, eller prøv igen.',
  failed: 'Studierummet kunne ikke åbnes. Kontrollér forbindelsen, og prøv igen.', retry: 'Prøv igen'
};
screen.dataset.school = english ? 'university' : 'institut';
screen.lang = english ? 'en' : 'da';
for (const key of ['brand', 'title', 'status', 'retry']) document.getElementById('startup-' + key).textContent = copy[key];
const retry = document.getElementById('startup-retry');
retry.onclick = () => location.reload();
function problem(message) {
  screen.dataset.failed = 'true';
  document.getElementById('startup-status').textContent = message;
  retry.hidden = false;
}
const timer = setTimeout(() => problem(copy.slow), 12000);
try {
  await import('./app.js');
  clearTimeout(timer);
  screen.remove();
} catch {
  clearTimeout(timer);
  problem(copy.failed);
}
