import {noteParagraphs,printFilename,printableLink} from './print-model.js';
import {chartMetadata,methodGuide} from './calculation-model.js';

const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!=null)e.textContent=String(text);if(cls)e.className=cls;return e;};
export const words=e=>[...e.childNodes].map(n=>n.nodeType===3?n.textContent:words(n)).join(' ').replace(/\s+/g,' ').trim();
const paragraph=(text,cls='report-copy')=>({kind:'text',text:String(text||''),cls});
const heading=(text,level=3)=>({kind:'heading',text,level});
const line=(a,b='')=>({kind:'line',a,b});
const figure=svg=>({kind:'figure',svg:svg.cloneNode(true)});
let vectorSequence=0;
function vector(svg){
 const copy=svg.cloneNode(true),prefix='report-vector-'+(++vectorSequence)+'-',ids=new Map();
 for(const n of [copy,...copy.querySelectorAll('[id]')])if(n.id){ids.set(n.id,prefix+n.id);n.id=prefix+n.id;}
 for(const n of [copy,...copy.querySelectorAll('*')])for(const a of [...n.attributes]){
  let value=a.value.replace(/url\(#([^)]*)\)/g,(all,id)=>ids.has(id)?'url(#'+ids.get(id)+')':all);
  if(['href','xlink:href'].includes(a.name)&&value.startsWith('#')&&ids.has(value.slice(1)))value='#'+ids.get(value.slice(1));
  if(value!==a.value)n.setAttribute(a.name,value);
 }

 copy.removeAttribute('style');copy.removeAttribute('width');copy.removeAttribute('height');
 copy.querySelectorAll('script,foreignObject').forEach(e=>e.remove());
 for(const n of [copy,...copy.querySelectorAll('*')]){for(const a of [...n.attributes])if(/^on/i.test(a.name)||['tabindex','role','aria-pressed'].includes(a.name))n.removeAttribute(a.name);}
 return copy;
}

// Capture current form values rather than textarea default contents. This never
// modifies the live workshop, changes its selection or sends notes to a server.
export function cloneForPrint(root){
 const copy=root.cloneNode(true),original=[...root.querySelectorAll('input,select,textarea')];
 copy.querySelectorAll('input,select,textarea').forEach((e,i)=>{e.value=original[i].value;if(e.type==='checkbox')e.checked=original[i].checked;});
 return copy;
}

function workshopBlocks(context,opt,L){
 const blocks=[],root=context.element;
 const skip='script,style,nav,[hidden],.au-room-heading,.atelier-card-head,.loop-title,.au-save-row,.au-journal-index,.au-planet-picker,.au-planet-nav,.au-choice-row,.loop-controls,.loop-reading-actions,.loop-cycle-nav,.loop-stage-buttons,.life-map,.life-empty,.life-undo,.life-entry,.life-controls,.life-edit-actions,.life-workspace,.life-events,.au-relationship-tools,.au-date-bar';
 const dataButtons='.au-contact,[data-loop-table],.loop-family,[data-venus-point],[data-rhythm],.venus-point,.venus-small-point,.rhythm-point,.au-year-cycle button';
 function walk(n){
  if(n.nodeType===3){const s=n.textContent.trim();if(s&&s!=='↗')blocks.push(paragraph(s,'report-caption'));return;}
  if(n.nodeType!==1||n.matches(skip))return;
  if(n.matches('[aria-hidden="true"]')&&n.tagName.toLowerCase()!=='svg')return;
  if(context.active==='loops'&&n.matches('.atelier-writing,.loop-related'))return;
  if(n.matches('label')&&n.querySelector('textarea')){
   if(!opt.notes)return;const input=n.querySelector('textarea'),label=n.querySelector('span')?.textContent||L('Mine noter','My notes');
   if(input.value.trim()||opt.lines){blocks.push(heading(label));const prompt=n.querySelector('small')?.textContent;if(prompt)blocks.push(paragraph(prompt,'report-caption'));for(const p of noteParagraphs(input.value))blocks.push(paragraph(p,'report-note'));if(!input.value.trim()&&opt.lines)blocks.push({kind:'writing'});}return;
  }
  if(n.matches('.venus-points,.rhythm-track,.au-year-cycle,.loop-table')){
   const buttons=[...n.querySelectorAll('button')],isLoop=n.matches('.loop-table'),isYear=n.matches('.au-year-cycle');
   const headers=isLoop?[L('Trin','Stage'),L('Tidspunkt','Time'),L('Position','Position')]:isYear?[L('Alder','Age'),L('Hus','House'),L('Tegn og hersker','Sign and ruler')]:[L('Punkt / rytme','Point / rhythm'),n.matches('.rhythm-track')?L('År','Year'):L('Position','Position'),n.matches('.rhythm-track')?L('Position','Position'):L('Dato','Date')];
   blocks.push({kind:'table',headers,rows:buttons.map(b=>[...b.children].map(words))});return;
  }
  if(n.matches('.atelier-contacts,.au-contact-list')){
   blocks.push({kind:'table',headers:[L('Forbindelse','Contact'),L('Orbis','Orb')],rows:[...n.children].map(r=>[...r.children].map(words))});return;
  }
  if(n.matches('.atelier-more>summary'))return;
  if(n.matches('.au-section-label,.atelier-section-title>div')){blocks.push(heading(words(n)));return;}
  if(n.matches('input,select,textarea'))return;
  if(n.matches('button')){if(n.matches(dataButtons))blocks.push(paragraph(words(n),'report-callout'));return;}
  if(n.tagName.toLowerCase()==='svg'){blocks.push(figure(n));return;}
  if(n.matches('h1,h2,h3,h4,h5,h6,summary')){if(words(n))blocks.push(heading(words(n)));return;}
  if(n.matches('table')){
   const rows=[...n.querySelectorAll('tr')].map(r=>[...r.children].map(words));
   if(rows.length)blocks.push({kind:'table',headers:rows.shift(),rows});return;
  }
  if(n.matches('a')){const href=printableLink(n.getAttribute('href'),location.href);if(href)blocks.push({kind:'source',title:words(n).replace(/\s*↗$/,''),href});return;}
  if(n.matches('p,li')&&!n.querySelector('svg,textarea,a')){if(words(n))blocks.push(paragraph(words(n),n.closest('.au-sources,.atelier-method,.life-scope')?'report-caption':n.matches('li')?'report-callout':'report-copy'));return;}
  if(n.matches('.eyebrow,.au-kicker,.atelier-kicker,.au-paper-label')){blocks.push(paragraph(words(n),'report-kicker'));return;}
  if(n.matches('.au-fact,.au-lord-position,.node-ruler,.au-person-point,.au-overlay,.au-contact')){blocks.push(paragraph(words(n),'report-callout'));return;}
  if(n.matches('label')){
   const control=n.querySelector('select,input');if(control){const label=words(n.cloneNode(false))||n.firstChild?.textContent||'';const value=control.tagName==='SELECT'?control.selectedOptions[0]?.textContent:control.value;if(value&&control.type!=='checkbox')blocks.push(line(label.trim(),value));return;}
  }
  // Group inline values into one readable paragraph, avoiding one-line-per-span.
  if(!n.querySelector('div,section,article,p,a,ul,ol,li,table,svg,label,textarea,button,h1,h2,h3,h4,h5,details')){
   const text=words(n);if(text&&text!=='↗')blocks.push(paragraph(text,n.matches('small,time')?'report-caption':'report-copy'));return;
  }
  for(const child of n.childNodes)walk(child);
 }
 for(const child of root.childNodes)walk(child);
 if(context.active==='life'){
  const selected=context.state.events.find(e=>e.id===context.state.selectedEvent);
  if(context.lifeResult&&selected){blocks.push(heading(L('Horoskopets bevægelser · ','Chart movements · ')+selected.date+' · '+selected.label));const contacts=root.querySelector('#life-contacts');if(contacts)walk(contacts);}
  blocks.push(heading(L('Min livslinje','My lifeline')));
  const events=[...(context.state?.events||[])].sort((a,b)=>a.date.localeCompare(b.date));
  if(!events.length)blocks.push(paragraph(L('Der er endnu ingen begivenheder på livslinjen.','There are no events on the lifeline yet.')));
  for(const e of events){blocks.push(heading(e.date+' · '+e.label));if(opt.notes)for(const p of noteParagraphs(e.note))blocks.push(paragraph(p,'report-note'));if(opt.lines&&!e.note)blocks.push({kind:'writing'});}
 }
 if(context.active==='loops'&&opt.notes&&context.data){
  const d=context.data,key=d.planet+'|'+d.stages[4].utc.slice(0,10)+'|';
  for(const s of d.stages){const text=context.state.loops.notes[key+s.number];if(!text)continue;
   const title=root.querySelector(`[data-loop-table="${s.number}"] span`)?.textContent||L('Trin ','Stage ')+s.number;
   blocks.push(heading(L('Mine noter · ','My notes · ')+title));for(const p of noteParagraphs(text))blocks.push(paragraph(p,'report-note'));
  }
 }
 if(context.source)blocks.push({kind:'source',title:L('Værkstedets kursusgrundlag','Workshop course source'),href:context.source});
 return blocks;
}

function contentBlocks(s,opt){
 const L=(a,b)=>s.lang==='da'?a:b,blocks=[];
 const metadata=(layer,index,natal=false)=>chartMetadata(s.result,index,s.lang,{natal});
 if(opt.chart){
  for(const [i,svg] of s.wheels.entries()){
   blocks.push({kind:'section',title:opt.title,kicker:s.mode,subtitle:s.result.mode==='compare'?L('Person ','Person ')+(i?'B':'A'):''});
   blocks.push({kind:'meta',values:metadata(s.result.layers[i]||s.result.layers[0],i)});
   if(i===0&&s.result.input.other&&s.result.mode!=='compare'){
    const other=s.result.input.other,place=s.result.layers[1]?.place;
    blocks.push(paragraph(L('Person B: ','Person B: ')+other.date+' · '+(other.confidence==='unknown'?L('ukendt tid','unknown time'):other.time)+(place?' · '+place.name+' · '+place.timezone:''),'report-caption'));
   }
   blocks.push({kind:'chart',svg});
   if(s.facts)blocks.push(paragraph(s.facts,'report-facts'));
   if(!s.visibility.signs||!s.visibility.houses||!s.visibility.aspects)blocks.push(paragraph(L('Øvelsesvisning: skjulte oplysninger forbliver skjult i horoskophjulet og oversigterne.','Exercise view: information hidden in the chart and tables remains hidden here.'),'report-caption'));
   for(const warning of s.warnings)blocks.push(paragraph(warning,'report-caption'));
  }
 }
 if(opt.tables){
  blocks.push({kind:'section',title:L('Horoskopets oversigter','Chart reference'),kicker:s.mode,subtitle:opt.title});
  for(const [i,c] of s.result.layers.entries()){
   const heads=[L('Punkt','Point'),...(s.visibility.signs?[L('Position','Position'),L('Bevægelse','Motion')]:[]),...(s.visibility.houses?[L('Hus','House')]:[])];
   const rows=c.planets.filter(p=>!s.focus||p.id===s.focus).map(p=>[s.bodyName(p.id),...(s.visibility.signs?[s.positionText(p.longitude),p.retrograde===null?'—':p.retrograde?L('Retrograd','Retrograde'):L('Direkte','Direct')]:[]),...(s.visibility.houses?[p.house??'—']:[])]);
   if(s.visibility.houses)for(const k of ['ascendant','midheaven'])if(c[k])rows.push([s.bodyName(k),...(s.visibility.signs?[s.positionText(c[k].longitude),'—']:[]),'—']);
   blocks.push({kind:'table',title:s.layerLabels[i],headers:heads,rows});
  }
  if(s.tableTab!=='positions'&&s.tableTab!=='notes'){
   blocks.push(heading(s.tableTitle));blocks.push(...workshopBlocks({element:s.table,active:'table'},opt,L));
  }
 }
 if(opt.context&&s.context){
  blocks.push({kind:'section',title:s.context.title,kicker:L('PERSONLIGT VÆRKSTED','PERSONAL STUDY ROOM'),subtitle:opt.title});
  blocks.push(paragraph(s.context.subtitle||'','report-lead'));
  if(!opt.chart)blocks.push({kind:'meta',values:metadata(s.result.layers[0],0,true)});
  blocks.push(...workshopBlocks(s.context,opt,L));
 }
 if(opt.notes){
  const titles={observation:L('Observationer','Observations'),synthesis:L('Samlet tolkning','Synthesis'),questions:L('Spørgsmål til underviseren','Questions for the teacher')};
  const entries=Object.entries(s.notes).filter(([,text])=>text.trim()||opt.lines);
  if(entries.length){blocks.push({kind:'section',title:L('Mine refleksioner','My reflections'),kicker:L('I EGNE ORD','IN MY OWN WORDS'),subtitle:opt.title});
   for(const [key,text] of entries){blocks.push(heading(titles[key]));for(const p of noteParagraphs(text))blocks.push(paragraph(p,'report-note'));if(!text.trim()&&opt.lines)blocks.push({kind:'writing'});}
  }
 }
 if(!blocks.length)blocks.push({kind:'section',title:L('Vælg indhold til dit studieark','Choose content for your study pages'),kicker:'A4',subtitle:L('Vælg mindst ét indholdsfelt ovenfor.','Select at least one content option above.')});
 if(blocks.length>1){
  if(opt.chart||opt.tables)for(const item of methodGuide(s.result,s.lang).filter(item=>item.key!=='houses'))blocks.push(paragraph(item.title+' · '+item.text,'report-caption'));
  const set=s.result.settings;
  let method=L('Herskerskaber: ','Rulerships: ')+(set.ruler_mode==='traditional'?L('traditionelle','traditional'):L('moderne','modern'))+' · '+L('Progressive akser: ','Progressed angles: ')+({naibod:'Naibod',kundig:'Kündig · '+L('hel grad','whole degree'),kundig_argus:'ARGUS · '+L('centreret','centred')})[set.progression_method]+'. ';
  method+=L('Aspektorbis: ','Aspect orbs: ')+Object.entries(set.orbs).map(([a,o])=>a+'° / '+o+'°').join(' · ')+'. ';
  method+=L('Udviklet af Stjernerne. Studieprofiler og øvelser er forslag, endnu ikke godkendt af skolerne. Noter er brugerens egne.','Developed by Stjernerne. Study profiles and exercises are proposals, not yet approved by the schools. Notes are the user’s own.');
  blocks.push(paragraph(method,'report-method'));
 }
 return blocks;
}

export function buildPrintPages(s,opt){
 const L=(a,b)=>s.lang==='da'?a:b,host=el('div',null,'report-measure');document.body.append(host);
 const pages=[],school=s.school==='institut'?'Astrologisk Institut':'Astrology University';let page,body;
 const fits=()=>body.scrollHeight<=body.clientHeight+1;
 function next(){
  page=el('article',null,'report-page '+(s.school==='university'?'university-paper ':'')+(opt.mono?'mono-paper':''));
  const head=el('header',null,'report-head'),brand=el('div',null,'report-brand');
  if(s.mark)brand.append(vector(s.mark));brand.append(el('span',school));head.append(brand,el('small',L('STUDIEARK\nSTJERNERNE','STUDY PAGES\nSTJERNERNE')));
  body=el('div',null,'report-body');const foot=el('footer',null,'report-foot');foot.append(el('span',opt.title),el('span',''));
  page.append(head,body,foot);host.append(page);pages.push(page);
 }
 next();
 function put(e){
  body.append(e);if(fits())return;
  // Keep a short method note with its chart instead of creating a nearly
  // empty page. Retain a readable 125 mm minimum; longer text still paginates.
  const chart=body.querySelector('.report-chart');
  if(e.dataset.text&&chart){
   const previousHeight=chart.style.height;
   const compactHeight=chart.getBoundingClientRect().height-(body.scrollHeight-body.clientHeight)-2;
   if(compactHeight>=125*96/25.4){
    chart.style.height=compactHeight+'px';if(fits())return;
    chart.style.height=previousHeight;
   }
  }
  e.remove();const last=body.lastElementChild;
  if(last?.dataset.keep){last.remove();if(body.children.length)next();body.append(last);}
  else if(body.children.length)next();
  body.append(e);
  if(!fits()&&e.dataset.text){
   e.remove();splitText(e.dataset.text,e.className);return;
  }
  if(!fits())throw Error(L('En del af indholdet er for stor til A4. Prøv at fravælge oversigter.','A content block is too large for A4. Try excluding reference tables.'));
 }
 function splitText(text,cls){
  let remaining=text;
  while(remaining){
   const p=el('p','',cls);body.append(p);let low=0,high=remaining.length;
   while(low<high){const mid=Math.ceil((low+high)/2);p.textContent=remaining.slice(0,mid);if(fits())low=mid;else high=mid-1;}
   if(!low){p.remove();if(!body.children.length)throw Error('Unable to fit a text line on A4.');next();continue;}
   let count=low;if(count<remaining.length){const last=Math.max(remaining.lastIndexOf(' ',count),remaining.lastIndexOf('\n',count));if(last>count*.65)count=last+1;}
   p.textContent=remaining.slice(0,count);remaining=remaining.slice(count);if(remaining)next();
  }
 }
 function tableBlock(block){
  let table,tbody;
  const start=()=>{table=el('table',null,'report-table report-block');const head=el('thead');if(block.title){const tr=el('tr'),th=el('th',block.title,'report-table-title');th.colSpan=block.headers.length;tr.append(th);head.append(tr);}const tr=el('tr');block.headers.forEach(h=>tr.append(el('th',h)));head.append(tr);tbody=el('tbody');table.append(head,tbody);body.append(table);};
  start();
  for(const row of block.rows){const tr=el('tr');row.forEach(c=>tr.append(el('td',c??'—')));tbody.append(tr);
   if(!fits()){tr.remove();let title;
    if(!tbody.children.length){table.remove();if(body.lastElementChild?.dataset.keep){title=body.lastElementChild;title.remove();}}
    if(body.children.length)next();if(title)body.append(title);start();tbody.append(tr);
    if(!fits()){tr.remove();if(!tbody.children.length)table.remove();for(const [i,value] of row.entries()){put(el('h3',block.headers[i]||''));const p=el('p',value,'report-copy report-block');p.dataset.text=String(value||'');put(p);}start();}
   }
  }
  if(!tbody.children.length)table.remove();
 }
 try{
  for(const block of contentBlocks(s,opt)){
   if(block.kind==='section'){
    if(body.children.length)next();const wrap=el('div',null,'report-block');wrap.append(el('div',block.kicker,'report-kicker'),el('h1',block.title));if(block.subtitle)wrap.append(el('p',block.subtitle,'report-lead'));put(wrap);continue;
   }
   if(block.kind==='table'){tableBlock(block);continue;}
   let e;
   if(block.kind==='text'){if(!block.text.trim())continue;e=el('p',block.text,block.cls);e.dataset.text=block.text;}
   if(block.kind==='heading'){e=el('h'+block.level,block.text);e.dataset.keep='true';}
   if(block.kind==='line'){e=el('div',null,'report-line');e.append(el('span',block.a),el('span',block.b));}
   if(block.kind==='chart'||block.kind==='figure'){e=el('div',null,block.kind==='chart'?'report-chart':'report-figure');e.append(vector(block.svg));}
   if(block.kind==='writing')e=el('div',null,'report-writing');
   if(block.kind==='meta'){e=el('div',null,'report-meta');for(const [label,value] of block.values){const item=el('div');item.append(el('b',label),el('span',value));e.append(item);}}
   if(block.kind==='source'){e=el('p',null,'report-source');const a=el('a',block.title+'\n'+block.href);a.href=block.href;e.append(a);}
   e.classList.add('report-block');put(e);
  }
  pages.forEach((p,i)=>{p.querySelector('.report-foot span:last-child').textContent=L('Side ','Page ')+(i+1)+' / '+pages.length;});
  return pages;
 }finally{host.remove();}
}

export function createPrintPreview({snapshot,onError}){
 let dialog=null,current=null,options=null,previousTitle=null,restoreFocus=null,observer=null,timer=null,reopen=false;
 const cleanOutput=()=>{document.getElementById('print-output')?.remove();if(previousTitle!==null){document.title=previousTitle;previousTitle=null;}};
 const defaultOptions=s=>({title:s.title,chart:true,tables:false,context:!!s.context,notes:true,lines:false,mono:false});
 function prepareOutput(s,opt,pages){
  cleanOutput();previousTitle=document.title;document.title=printFilename(opt.title,s.school);
  const output=el('section');output.id='print-output';output.setAttribute('aria-label','Print');output.append(...(pages||buildPrintPages(s,opt)).map(p=>p.cloneNode(true)));document.body.append(output);
 }
 function close(){reopen=false;clearTimeout(timer);dialog?.close();observer?.disconnect();observer=null;dialog?.remove();dialog=null;current=null;options=null;cleanOutput();restoreFocus?.focus?.();}
 async function open(){
  try{
   current=snapshot();options=defaultOptions(current);restoreFocus=document.activeElement;
   const L=(a,b)=>current.lang==='da'?a:b;
   dialog?.remove();dialog=el('dialog');dialog.id='print-dialog';dialog.setAttribute('aria-labelledby','print-preview-title');
   const bar=el('div',null,'print-toolbar'),intro=el('div');intro.append(el('h2',L('Dit studiearbejde, på papir','Your study, on paper')));intro.firstChild.id='print-preview-title';intro.append(el('p',L('En rolig udgave med plads til horoskopet og dine egne ord.','A considered edition, with room for the chart and your own words.')));
   const actions=el('div',null,'print-actions'),count=el('span','…'),print=el('button',L('Print / Gem som PDF','Print / Save as PDF'),'primary'),exit=el('button',L('Tilbage','Back')+' ×');print.id='print-confirm';count.id='print-page-count';actions.append(count,print,exit);bar.append(intro,actions);
   const controls=el('div',null,'print-options'),title=el('label',L('Titel på studiearket','Study title'),'print-title'),input=el('input');input.value=options.title;input.maxLength=120;input.id='print-document-title';title.append(input);controls.append(title);
   const checks={chart:L('Horoskop','Chart'),context:current.context?.title||L('Åbent værksted','Current study room'),tables:L('Oversigter','Reference tables'),notes:L('Egne noter','My notes'),lines:L('Skrivelinjer','Writing lines')};
   for(const [key,label] of Object.entries(checks)){const l=el('label'),box=el('input');box.type='checkbox';box.id='print-include-'+key;box.checked=options[key];box.disabled=key==='context'&&!current.context;l.append(box,document.createTextNode(label));controls.append(l);box.onchange=()=>{options[key]=box.checked;if(key==='lines'&&box.checked){options.notes=true;controls.querySelector('#print-include-notes').checked=true;}if(key==='notes'&&!box.checked){options.lines=false;controls.querySelector('#print-include-lines').checked=false;}render();};}
   const colour=el('label',L('Farver','Colour')),select=el('select');select.id='print-colour';select.append(new Option(L('Skolens farver','School colours'),'colour'),new Option(L('Sort / hvid','Black / white'),'mono'));colour.append(select);controls.append(colour);select.onchange=()=>{options.mono=select.value==='mono';render();};
   const help=el('p',L('A4 · Vælg “Gem som PDF” i udskriftsdialogen. Brug 100 % skala og slå browserens sidehoveder og sidefødder fra. Værkstedet følger de valg, du har åbne nu.','A4 · Choose “Save as PDF” in the print dialog. Use 100% scale and turn off browser headers and footers. The study room follows your current selections.'),'print-help');
   const stage=el('div',null,'print-preview-stage'),pages=el('div',null,'print-preview-pages');pages.id='print-preview-pages';stage.append(pages);dialog.append(bar,controls,help,stage);document.body.append(dialog);
   function scale(){pages.style.setProperty('--paper-scale',Math.min(1,(stage.clientWidth-32)/(210*96/25.4)));}
   function render(){try{options.title=input.value.trim()||current.title;const next=buildPrintPages(current,options);pages.replaceChildren(...next);count.textContent=next.length+' '+L(next.length===1?'side':'sider',next.length===1?'page':'pages');print.disabled=!['chart','context','tables','notes'].some(k=>options[k]);scale();}catch(e){count.textContent=e.message;print.disabled=true;}}
   input.oninput=()=>{clearTimeout(timer);timer=setTimeout(render,200);};
   print.onclick=async()=>{clearTimeout(timer);render();if(print.disabled)return;await document.fonts.ready;prepareOutput(current,options,[...pages.children]);if(dialog?.open){reopen=true;dialog.close();}window.print();};
   exit.onclick=close;dialog.addEventListener('cancel',e=>{e.preventDefault();close();});dialog.showModal();await document.fonts.ready;if(!dialog?.open)return;render();observer=new ResizeObserver(scale);observer.observe(stage);
  }catch(e){close();onError(e.message);}
 }
 window.addEventListener('beforeprint',()=>{if(dialog?.open){reopen=true;dialog.close();}if(document.getElementById('print-output'))return;try{const s=current||snapshot();prepareOutput(s,options||defaultOptions(s));}catch(e){cleanOutput();const output=el('section');output.id='print-output';const page=el('article',null,'report-page');page.append(el('h1','Print / PDF'),el('p',e.message));output.append(page);document.body.append(output);onError(e.message);}});
 window.addEventListener('afterprint',()=>{cleanOutput();if(reopen&&dialog?.isConnected){dialog.showModal();reopen=false;}});
 return {open};
}
