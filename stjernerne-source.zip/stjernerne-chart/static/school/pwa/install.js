const standalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
let installPrompt;
const bar = document.createElement('section');
bar.id = 'student-app-tools';
bar.setAttribute('aria-label', 'Studieapp');
bar.innerHTML = '<p id="app-offline-notice" role="status" hidden>Du er offline. Beregninger kræver internet.</p><span id="app-installed-label" hidden>Studieværksted · app</span><button type="button" id="student-install-open">Installér app</button>';
document.body.prepend(bar);
const dialog = document.createElement('dialog');
dialog.id = 'student-install-dialog';
dialog.setAttribute('aria-labelledby', 'student-install-title');
dialog.innerHTML = `<button type="button" class="install-close" aria-label="Luk installationsvejledningen">Luk</button>
<h2 id="student-install-title">Dit studieværksted som app</h2>
<p>Åbn horoskoper og værksteder fra et ikon på din mobil, tablet eller computer. Du behøver ingen konto.</p>
<button type="button" id="student-install-now" hidden>Installér på denne enhed</button>
<p id="student-install-status" role="status"></p>
<h3>iPhone og iPad</h3><ol><li>Åbn denne side i Safari.</li><li>Tryk på <strong>Del</strong>, og vælg <strong>Føj til hjemmeskærm</strong>.</li><li>Slå <strong>Åbn som webapp</strong> til, hvis valget vises, og tryk <strong>Tilføj</strong>.</li></ol>
<h3>Android</h3><p>Åbn siden i Chrome. Brug installationsknappen her eller browserens menu → <strong>Installér app</strong> / <strong>Føj til startskærm</strong>.</p>
<h3>Computer</h3><p>I Chrome eller Edge: vælg installationsikonet i adresselinjen eller appinstallationen i browserens menu. På nyere Mac-computere kan Safari bruge <strong>Arkiv → Føj til Dock</strong>.</p>
<p class="install-note"><strong>Internet og dine opgaver</strong><br>Beregninger og åbning af værkstedet kræver internet. Gemte opgaver og noter ligger på denne enhed; de synkroniseres ikke. Brug <strong>Eksportér</strong> til sikkerhedskopiering og <strong>Importér</strong>, hvis du skal flytte opgaver til en anden browser eller appinstallation.</p>
<p>Opdateringer hentes, når du åbner appen igen med internet. Gem dit arbejde, før du lukker eller genindlæser.</p>`;
document.body.append(dialog);
const open = bar.querySelector('button'), install = dialog.querySelector('#student-install-now'), status = dialog.querySelector('#student-install-status');
function refresh() {
  const installed = standalone();
  open.textContent = installed ? 'Om appen' : 'Installér app';
  bar.querySelector('#app-installed-label').hidden = !installed;
  bar.querySelector('#app-offline-notice').hidden = navigator.onLine;
  install.hidden = installed || !installPrompt;
}
open.addEventListener('click', () => { refresh(); dialog.showModal(); });
dialog.querySelector('.install-close').addEventListener('click', () => dialog.close());
window.addEventListener('beforeinstallprompt', event => { event.preventDefault(); installPrompt = event; refresh(); });
window.addEventListener('appinstalled', () => { installPrompt = null; install.hidden = true; status.textContent = 'Appen er installeret. Du kan nu åbne den fra dens ikon.'; });
install.addEventListener('click', async () => {
  if (!installPrompt) return;
  const prompt = installPrompt; installPrompt = null; refresh();
  try { await prompt.prompt(); const choice = await prompt.userChoice; status.textContent = choice.outcome === 'accepted' ? 'Installationen er godkendt. Find Studieværksted på din enhed.' : 'Du kan installere appen senere fra browserens menu.'; }
  catch { status.textContent = 'Brug browserens menu eller vejledningen nedenfor til at installere.'; }
});
window.addEventListener('online', refresh);
window.addEventListener('offline', refresh);
matchMedia('(display-mode: standalone)').addEventListener('change', refresh);
refresh();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/institut-sw.js', {scope:'/institut', updateViaCache:'none'}).catch(() => {
  status.textContent = 'Installationshjælpen kunne ikke indlæses. Kontrollér forbindelsen og åbn siden igen. Du kan fortsat bruge værkstedet i browseren.';
});
