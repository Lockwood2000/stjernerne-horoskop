// Presentation-only mobile shell. Existing controls own calculations and storage.
let view = 'home', cleanup = () => {}, controller;
const paths = {
 home:'M3 10 12 3l9 7v11H3z M9 21v-8h6v8',
 chart:'M12 3a9 9 0 1 0 0 18 9 9 0 1 0 0-18 M12 3v18 M3 12h18 M6 6l12 12 M18 6 6 18',
 workshops:'m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z',
 library:'M4 4h6l2 2 2-2h6v16h-6l-2 2-2-2H4z M12 6v16',
 data:'M5 4h14v17H5z M8 8h8 M8 12h8 M8 16h4'
};
const icon = key => `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[key]}"/></svg>`;
export function mobileCalculated(){if(view==='data')controller?.('chart');}
export function mobileOpenChart(){controller?.('chart');}
export function mountMobileApp({school,lang,showWork,listRecords,openRecord}) {
 cleanup(); controller=null;
 delete document.body.dataset.mobileView;
 if(school!=='institut')return;
 const da=lang==='da', L=(a,b)=>da?a:b, app=document.getElementById('app');
 const compact=matchMedia('(max-width:720px)');
 const folds=[];
 for(const [selector,title] of [['.exercise',L('Øvelser og inspiration','Exercises and inspiration')],['.visibility',L('Tilpas horoskophjulet','Adjust the chart wheel')]]){
  const content=app.querySelector(selector),fold=document.createElement('details'),summary=document.createElement('summary');fold.className='mobile-fold';summary.textContent=title;content.before(fold);fold.append(summary,content);fold.open=!compact.matches;folds.push(fold);
 }
 const chartActions=app.querySelector('.result-top .actions'),chartTop=app.querySelector('.result-top'),chartArea=app.querySelector('.chart-area');
 const resize=()=>{for(const fold of folds)fold.open=!compact.matches;if(compact.matches)chartArea.after(chartActions);else chartTop.append(chartActions);};compact.addEventListener('change',resize);resize();
 const home=document.createElement('section');home.className='mobile-home';home.setAttribute('aria-label',L('Startside','Home'));
 home.innerHTML=`<div class="mobile-hero"><span class="mobile-kicker">${L('DIT PERSONLIGE STUDIERUM','YOUR PERSONAL STUDY SPACE')}</span><h1>${L('Et øjeblik.<br>Et helt univers.','A moment.<br>A whole universe.')}</h1><p>${L('Giv nysgerrigheden plads. Udforsk horoskopet, og saml dine egne indsigter.','Make room for curiosity. Explore the chart and collect your own insights.')}</p><div class="mobile-orbit" aria-hidden="true">${icon('chart')}<span>✧</span></div><button class="mobile-primary" data-go="data">${L('Beregn et horoskop','Calculate a chart')} <span aria-hidden="true">↗</span></button><button class="mobile-continue" data-go="chart">${L('Se det åbne horoskop','View the open chart')} <span aria-hidden="true">→</span></button></div><div class="mobile-section-heading"><h2>${L('Find din fordybelse','Find your focus')}</h2><span>01 — 04</span></div><div class="mobile-discover"><button data-go="workshops">${icon('workshops')}<strong>${L('Værksteder','Study rooms')}</strong><span>${L('Cyklusser, knuder og livets mønstre','Cycles, nodes and patterns of life')}</span><b aria-hidden="true">↗</b></button><button data-go="notes">${icon('library')}<strong>${L('Mine noter','My notes')}</strong><span>${L('Dine iagttagelser. Dine egne ord.','Your observations. Your own words.')}</span><b aria-hidden="true">↗</b></button></div><div class="mobile-section-heading"><h2>${L('Seneste studiearbejde','Recent studies')}</h2><button data-go="library">${L('Se alle','View all')} →</button></div><div id="mobile-recent" class="mobile-recent"></div><p class="mobile-home-foot">${L('Et rum til at undersøge, forstå og vende tilbage.','A space to explore, understand and return to.')}</p>`;
 app.querySelector('.topbar').after(home);
 const nav=document.createElement('nav');nav.className='mobile-bottom-nav';nav.setAttribute('aria-label',L('Appens hovedmenu','App navigation'));
 nav.innerHTML=[['home',L('Hjem','Home')],['chart',L('Horoskop','Chart')],['workshops',L('Værksteder','Study')],['library',L('Mine opgaver','My studies')]].map(([key,label])=>`<button data-go="${key}" type="button">${icon(key)}<span>${label}</span></button>`).join('');app.append(nav);
 const heading=document.createElement('div');heading.className='mobile-view-heading';heading.innerHTML=`<div><span class="mobile-kicker">${L('DIT STUDIEVÆRKSTED','YOUR STUDY WORKSPACE')}</span><h1 id="mobile-view-title"></h1></div><button data-go="data" aria-label="${L('Redigér fødselsdata og indstillinger','Edit birth data and settings')}">${icon('data')}<span>${L('Data','Data')}</span></button>`;app.querySelector('.layout').before(heading);
 const tools=document.createElement('div');tools.className='mobile-extra-tools';tools.innerHTML=`<button data-go="diary">${L('Transitdagbog','Transit diary')} ↗</button><button data-go="rectify">${L('Undersøg fødselstid','Explore birth time')} ↗</button>`;app.querySelector('#workshops-work').before(tools);
 const notice=document.createElement('p');notice.className='mobile-status';notice.setAttribute('role','status');notice.hidden=true;heading.after(notice);
 const status=document.getElementById('status');let noticeTimer;const observer=new MutationObserver(()=>{clearTimeout(noticeTimer);notice.textContent=status.textContent;notice.hidden=!status.textContent;notice.classList.toggle('error',status.classList.contains('error'));if(!status.classList.contains('error'))noticeTimer=setTimeout(()=>notice.hidden=true,5000);});observer.observe(status,{childList:true,subtree:true,characterData:true,attributes:true});
 let active=true;
 async function recent(){
  const root=home.querySelector('#mobile-recent');
  try{const rows=(await listRecords()).filter(r=>r.request.school==='institut').sort((a,b)=>b.updated.localeCompare(a.updated)).slice(0,3);if(!active)return;root.replaceChildren();
   if(!rows.length){const p=document.createElement('p');p.className='mobile-empty';p.textContent=L('Dit første studie begynder med et horoskop. Gem det under Mine opgaver, og find det her næste gang.','Your first study begins with a chart. Save it under My studies to find it here next time.');root.append(p);}
   for(const record of rows){const button=document.createElement('button');button.className='mobile-study-card';const mark=document.createElement('span');mark.className='mobile-study-mark';mark.textContent='✧';const text=document.createElement('span');const title=document.createElement('strong');title.textContent=record.name;const date=document.createElement('small');date.textContent=L('Gemt ','Saved ')+new Date(record.updated).toLocaleDateString(da?'da-DK':'en-GB',{day:'numeric',month:'short'});text.append(title,date);const arrow=document.createElement('span');arrow.textContent='↗';arrow.setAttribute('aria-hidden','true');button.append(mark,text,arrow);button.onclick=async()=>{button.disabled=true;try{await openRecord(record);controller?.('chart');}catch(e){notice.hidden=false;notice.textContent=e.message;}finally{button.disabled=false;}};root.append(button);}
  }catch{if(active)root.textContent=L('Biblioteket kunne ikke åbnes. Brug Importér til en gemt sikkerhedskopi.','The library could not be opened. Import a saved backup.');}
 }
 function go(next,scroll=true){
  view=next==='notes'?'chart':next;document.body.dataset.mobileView=view;
  if(['chart','workshops','diary','rectify'].includes(view))showWork(view);
  if(next==='notes')document.getElementById('tab-notes').click();
  if(view==='data')document.getElementById('birth-details').open=true;
  if(view==='library'){document.querySelector('.study-library').open=true;recent();}
  if(view==='home'){recent();if(compact.matches)history.replaceState(null,'','/institut');}
  const titles={chart:L('Mit horoskop','My chart'),workshops:L('Fordybelse','Study rooms'),library:L('Mine opgaver','My studies'),data:L('Fødselsdata','Birth data'),diary:L('Transitdagbog','Transit diary'),rectify:L('Fødselstid','Birth time')};heading.querySelector('h1').textContent=titles[view]||'';
  nav.querySelectorAll('button').forEach(b=>{const selected=b.dataset.go===(['diary','rectify'].includes(view)?'workshops':view);if(selected)b.setAttribute('aria-current','page');else b.removeAttribute('aria-current');});
  if(scroll&&matchMedia('(max-width:720px)').matches)window.scrollTo({top:0,behavior:'instant'});
 }
 const click=e=>{const b=e.target.closest('[data-go]');if(b)go(b.dataset.go);};app.addEventListener('click',click);
 const skip=document.querySelector('.skip');const skipClick=e=>{if(compact.matches){e.preventDefault();go('chart');const target=document.getElementById('mobile-view-title');target.tabIndex=-1;target.focus({preventScroll:true});}};skip.addEventListener('click',skipClick);
 controller=go;
 cleanup=()=>{active=false;skip.removeEventListener('click',skipClick);clearTimeout(noticeTimer);observer.disconnect();app.removeEventListener('click',click);compact.removeEventListener('change',resize);};
 if(location.hash&&view==='home')view='workshops';
 go(view,false);
}
