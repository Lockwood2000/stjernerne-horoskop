// Text-only helpers shared by the print preview and its regression checks.
export function printFilename(title,school){
 const name=String(title||'').normalize('NFKC').replace(/[\x00-\x1f<>:"/\\|?*]/g,' ').replace(/\s+/g,' ').trim().slice(0,100);
 return (name||'Studieark')+' · '+(school==='university'?'Astrology University':'Astrologisk Institut');
}
export function noteParagraphs(text){
 return String(text||'').replace(/\r\n?/g,'\n').split(/\n\s*\n/).filter(s=>s.trim());
}
export function printableLink(href,base){
 try{const u=new URL(href,base);return ['http:','https:'].includes(u.protocol)?u.href:null;}catch{return null;}
}
export {HOUSE_NAMES} from './calculation-model.js';
