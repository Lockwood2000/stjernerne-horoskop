import {validDay} from './workshop-model.js';

export const UNIVERSITY_ROOMS=['synthesis','year','lunation','relationships'];
export const UNIVERSITY_HASHES={synthesis:'#study-rooms',year:'#year-ahead',lunation:'#prenatal-lunation',relationships:'#relationships'};
export const MAJOR_BODIES=['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'];
export function emptyUniversity(){return {version:1,active:'synthesis',planet:'sun',date:'',relationshipFocus:'all',other:null,notes:{}};}

function otherBirth(raw){
 if(raw==null)return null;
 const fail=()=>{throw Error('Invalid second birth chart');};
 if(typeof raw!=='object'||Array.isArray(raw)||!validDay(raw.date)||!['exact','approximate','unknown'].includes(raw.confidence))fail();
 if(raw.confidence==='unknown'){if(raw.time!=null)fail();}
 else if(typeof raw.time!=='string'||!/^([01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d{1,6})?)?$/.test(raw.time))fail();
 const allowed=['date','time','confidence','uncertainty_minutes','place_id','place_name','latitude','longitude','timezone','fold','offset_minutes','offset_source'];
 if(Object.keys(raw).some(k=>!allowed.includes(k)))fail();
 for(const [key,max] of [['place_id',20],['place_name',120],['timezone',80],['offset_source',250]])if(raw[key]!=null&&(typeof raw[key]!=='string'||raw[key].length>max))fail();
 if(raw.place_id){if(['latitude','longitude','timezone'].some(k=>raw[k]!=null))fail();}
 else if(!Number.isFinite(raw.latitude)||Math.abs(raw.latitude)>89.9||!Number.isFinite(raw.longitude)||Math.abs(raw.longitude)>180||!raw.timezone)fail();
 if(raw.uncertainty_minutes!=null&&(!Number.isInteger(raw.uncertainty_minutes)||raw.uncertainty_minutes<1||raw.uncertainty_minutes>720))fail();
 if(raw.fold!=null&&![0,1].includes(raw.fold))fail();
 if(raw.offset_minutes!=null&&(!Number.isInteger(raw.offset_minutes)||Math.abs(raw.offset_minutes)>840))fail();
 return structuredClone(raw);
}

export function validateUniversity(raw){
 if(raw==null)return emptyUniversity();
 const fail=()=>{throw Error('Invalid University study-room data');};
 if(typeof raw!=='object'||Array.isArray(raw)||raw.version!==1||!UNIVERSITY_ROOMS.includes(raw.active)||!MAJOR_BODIES.includes(raw.planet)||!(raw.date===''||validDay(raw.date))||!['all','luminaries','affection','communication'].includes(raw.relationshipFocus)||!raw.notes||typeof raw.notes!=='object'||Array.isArray(raw.notes)||Object.keys(raw.notes).length>60)fail();
 const pattern=/^(synthesis\.(sun|moon|mercury|venus|mars|jupiter|saturn|uranus|neptune|pluto)\.(keywords|integration)|synthesis\.summary|year\.\d{4}-\d{2}-\d{2}\.(theme|observation)|lunation\.(pattern|integration)|relationship\.(a|b|bridge))$/;
 for(const [k,v] of Object.entries(raw.notes))if(!pattern.test(k)||typeof v!=='string'||v.length>3000||(k.startsWith('year.')&&!validDay(k.split('.')[1])))fail();
 return {version:1,active:raw.active,planet:raw.planet,date:raw.date,relationshipFocus:raw.relationshipFocus,other:otherBirth(raw.other),notes:{...raw.notes}};
}

export function relationshipContacts(contacts,focus){
 const group={luminaries:['sun','moon'],affection:['venus','mars'],communication:['mercury']}[focus];
 return group?contacts.filter(c=>group.includes(c.a)||group.includes(c.b)):contacts;
}
