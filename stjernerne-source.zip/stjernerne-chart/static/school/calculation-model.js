// Shared, plain-language provenance for the chart view and printed study pages.
export const HOUSE_NAMES={P:'Placidus',W:'Whole Sign',E:'Equal House',K:'Koch',O:'Porphyry',C:'Campanus',T:'Topocentric',R:'Regiomontanus'};
export const axisName=(method,lang='en')=>({naibod:'Naibod',kundig:lang==='da'?'Kündig · hel grad':'Kündig · whole degree',kundig_argus:lang==='da'?'ARGUS · centreret':'ARGUS · centred'})[method]||method;
export const stampText=iso=>String(iso||'').replace('T',' ').replace(/\.\d+/, '').replace(/\+00:00$/,' UTC').replace(/Z$/,' UTC');
const placeText=p=>[p?.name,p?.timezone].filter(Boolean).join(' · ');

export function chartMetadata(result,index=0,lang='en',{natal=false}={}){
 const L=(a,b)=>lang==='da'?a:b,layer=result.layers[index]||result.layers[0],input=result.input;
 const second=index>0&&result.mode==='compare',birth=second?input.other:input.birth;
 const birthplace=result.birth_places?.[second?1:0]||layer.place;
 const isReturn=result.mode==='solar_return'&&!natal;
 const certainty=birth.confidence==='unknown'?L('Ukendt tid','Unknown time'):birth.confidence==='approximate'?L('Cirka ','Approx. ')+(birth.time||'')+' ±'+birth.uncertainty_minutes+' min':birth.time;
 const houses=layer.synthetic_houses?L('Solbaserede huse','Solar houses'):!layer.houses.length?L('Huse udeladt','Houses omitted'):HOUSE_NAMES[result.settings.house_system];
 const node=result.settings.node==='true'?L('Sand knude','True Node'):L('Middelknude','Mean Node');
 if(isReturn)return [
  [L('Solretur · lokal tid','Solar return · local time'),stampText(layer.birth.local)],
  [L('Opholdssted og tidszone','Return place and time zone'),placeText(layer.place)],
  [L('Huse og måneknuder','Houses and lunar nodes'),houses+' · '+node],
  [L('Præcist tidspunkt · UTC','Exact time · UTC'),stampText(layer.birth.utc)]
 ];
 const target=input.target;
 const event=result.mode==='event',view=({event:L('Øjeblikshoroskop','Event chart'),solar_chart:L('Solhoroskop','Solar chart'),composite:'Composite'})[result.mode]||L('Fødselshoroskop','Birth chart');
 return [[event?L('Dato og tid','Date and time'):L('Fødselsdato og tid','Birth date and time'),birth.date+' · '+certainty],
  [event?L('Sted og tidszone','Place and time zone'):L('Fødested og tidszone','Birthplace and time zone'),placeText(birthplace)],
  [L('Huse og måneknuder','Houses and lunar nodes'),houses+' · '+node],
  [target&&!natal?L('Måldato','Target date'):L('Visning','View'),target&&!natal?target.date+' · '+target.time+' · '+target.timezone+(target.fold==null?'':L(' · forekomst ',' · occurrence ')+(target.fold+1)):second?'Person B':natal?L('Fødselsgrundlag','Birth basis'):result.mode==='compare'?'Person A':view]];
}

export function methodGuide(result,lang='en'){
 const L=(a,b)=>lang==='da'?a:b,rows=[],system=result.settings.house_system;
 const houseText={
  E:L('12 huse på hver 30°, med første husspids på Ascendanten. MC vises som et selvstændigt punkt.','Twelve houses of 30°, with the first cusp at the Ascendant. MC is shown as a separate point.'),
  W:L('Ascendantens tegn er hele første hus. MC vises som et selvstændigt punkt.','The Ascendant’s whole sign is the first house. MC is shown as a separate point.'),
  P:L('Placidus beregnes for tid og sted. Ved breddegrader fra 66° kræves et andet hussystem; der skiftes ikke automatisk.','Placidus is calculated for the time and place. At latitudes of 66° or more another system is required; there is no automatic substitution.'),
  R:L('Regiomontanus beregnes for tid og sted med 12 huse og særskilte akser.','Regiomontanus is calculated for the time and place, with twelve houses and separate angles.')
 };
 if(result.layers[0].synthetic_houses)rows.push({key:'houses',title:L('Solbaserede huse','Solar houses'),text:L('Solen danner første husspids; de tolv huse er hver 30°.','The Sun forms the first cusp; all twelve houses span 30°.')});
 else if(result.layers[0].houses.length)rows.push({key:'houses',title:HOUSE_NAMES[system],text:houseText[system]||L('Det valgte hussystem følger beregningens tid og sted.','The selected house system follows the calculation’s time and place.')});
 const p=result.layers.find(c=>c.kind==='progressed');
 if(p){const t=p.technique;
  rows.push({key:'progressed',title:L('Sekundære progressioner','Secondary progressions'),text:L('Én efemeridedag svarer til 365,2422 levede døgn. Måltidspunkt: ','One ephemeris day represents 365.2422 elapsed days. Target: ')+stampText(t.target_utc)+L('. Planeternes efemeridetid: ','. Planetary ephemeris time: ')+stampText(t.ephemeris_utc)+'.'});
  rows.push({key:'axes',title:L('Progressive akser','Progressed angles'),text:axisName(t.axis_method,lang)+' · '+t.degrees_per_year.toFixed(8)+L('° pr. år. Nøglen lægges til fødslens ARMC (MC i rektascension). Huse og akser beregnes med fødestedets breddegrad og den progredierede ekliptikahældning.','° per year. The key advances natal ARMC (MC in right ascension). Houses and angles use the birth latitude and progressed obliquity.')});
 }
 const arc=result.layers.find(c=>c.kind==='solar_arc');
 if(arc){const t=arc.technique;
  rows.push({key:'solar_arc',title:'Solar arc',text:L('Den sekundært progredierede Sols længde minus fødselssolens længde, fremad gennem zodiakken. Samme bue lægges til alle fødselsplaneter, akser og husspidser. Tidsnøgle: én dag pr. 365,2422 levede døgn. Måltidspunkt: ','Secondary progressed solar longitude minus natal solar longitude, forward through the zodiac. The same arc advances all natal planets, angles and cusps. Time key: one day per 365.2422 elapsed days. Target: ')+stampText(t.target_utc)+L('. Det valgte progressive aksevalg ændrer ikke denne bue.','. The selected progressed-angle method does not change this arc.')});
 }
 const ret=result.layers.find(c=>c.kind==='solar_return');
 if(ret){const t=ret.technique,b=result.input.birth;
  rows.push({key:'solar_return',title:L('Solretur ','Solar return ')+result.input.return_year,text:L('Det beregnede tidspunkt, hvor Solen vender tilbage til fødselssolens tropiske, geocentriske apparente længde. Der korrigeres ikke for præcession. Året følger fødselsdagen i fødselsoplysningernes kalender.','The calculated instant when the Sun returns to its natal tropical, geocentric apparent longitude. No precession correction is applied. The selected year follows the birthday in the recorded birth calendar.')});
  rows.push({key:'return_place',title:L('Solreturens sted','Return location'),text:placeText(ret.place)+(t.location_basis==='birthplace'?L(' · fødestedet',' · birthplace'):L(' · valgt opholdssted',' · selected return location'))+L('. Stedet bestemmer huse og akser; det ændrer ikke returens tidspunkt. Fødselsgrundlag: ','. Location determines houses and angles; it does not change the return instant. Birth basis: ')+b.date+' · '+b.time+' · '+placeText(result.birth_places?.[0])+'.'});
 }
 return rows;
}
