// Original vector artwork; the circles are decorative, not calculated positions.
export function universityOrbit(kind='synthesis',cls=''){
 const stars=Array.from({length:12},(_,i)=>{const a=i*Math.PI/6,x=160+111*Math.cos(a),y=160+111*Math.sin(a);return `<circle cx="${x}" cy="${y}" r="${i%3?1.5:3}"/>`;}).join('');
 const inner=kind==='lunation'?'<circle cx="160" cy="160" r="48" fill="currentColor" opacity=".16"/><path d="M160 112a48 48 0 0 1 0 96 37 48 0 0 0 0-96" fill="currentColor"/>'
 :kind==='relationships'?'<circle cx="126" cy="160" r="56"/><circle cx="194" cy="160" r="56"/><path d="M105 115 215 205M105 205 215 115" opacity=".35"/>'
 :kind==='year'?Array.from({length:12},(_,i)=>{const a=i*Math.PI/6;return `<path d="M${160+64*Math.cos(a)} ${160+64*Math.sin(a)}L${160+87*Math.cos(a)} ${160+87*Math.sin(a)}"/>`;}).join('')+'<path d="M160 160 160 79M160 160 205 186"/><circle cx="160" cy="160" r="7" fill="currentColor"/>'
 :'<ellipse cx="160" cy="160" rx="87" ry="37" transform="rotate(-36 160 160)"/><ellipse cx="160" cy="160" rx="87" ry="37" transform="rotate(36 160 160)"/><circle cx="160" cy="160" r="25"/><path d="M160 120v80m-40-40h80" opacity=".5"/>';
 return `<svg class="${cls}" viewBox="0 0 320 320" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width="1"><circle cx="160" cy="160" r="139" opacity=".25"/><circle cx="160" cy="160" r="111" opacity=".55"/>${inner}<path d="M160 9v20m-10-10h20M301 160h-20m10-10v20M160 291v20m-10-10h20M9 160h20m-10-10v20" opacity=".7"/></g><g fill="currentColor">${stars}</g></svg>`;
}

export function universityHeading(lang){
 const da=lang==='da';
 return `<div class="topbar au-masthead"><div class="au-brand">${universityOrbit('synthesis','au-seal')}<div><span>Astrology University</span><small>${da?'STUDIEVÆRKSTED':'STUDY WORKSPACE'} <i>·</i> STJERNERNE</small></div></div><div class="au-masthead-tools"><nav aria-label="${da?'Skoleprofil':'School profile'}"><a href="/institut">${da?'Instituttet':'The Institute'}</a><a href="/university" aria-current="page">University</a></nav><button id="language" class="quiet" aria-label="${da?'Skift til engelsk':'Switch to Danish'}">${da?'EN':'DA'} ↗</button></div></div>
 <header class="header au-intro"><div class="au-intro-copy"><div class="eyebrow">${da?'LÆR · UNDERSØG · FORBIND':'LEARN · OBSERVE · INTEGRATE'}</div><h1>${da?'Giv dit horoskop<br><em>liv og sammenhæng.</em>':'Bring your chart<br><em>to life.</em>'}</h1><p>${da?'Et personligt studieværksted. Mange astrologiske perspektiver.<br> Plads til din egen forståelse.':'A personal place to study. A world of astrological perspectives.<br> Room for your own understanding.'}</p><button id="au-enter" class="au-enter">${da?'Åbn de fire værksteder':'Explore the four study rooms'} <span>↗</span></button></div><div class="au-intro-sky">${universityOrbit('synthesis','au-hero-orbit')}<div class="au-orbit-caption">☉ <span>${da?'FRA ENKELTDEL TIL HELHED':'FROM PATTERN TO PERSPECTIVE'}</span> ☽</div></div><div class="au-intro-index"><span>01 <i>${da?'Syntese':'Synthesis'}</i></span><span>02 <i>${da?'Årets tema':'Your year'}</i></span><span>03 <i>${da?'Månens aftryk':'Lunation'}</i></span><span>04 <i>${da?'Relationer':'Relationships'}</i></span></div></header>`;
}

export function decorateUniversity(lang){
 const library=document.querySelector('.saved'),heading=library.querySelector('h3'),details=document.createElement('details'),summary=document.createElement('summary');
 details.className='au-library';details.open=window.matchMedia('(min-width:721px)').matches;summary.textContent=heading.textContent;heading.remove();details.append(summary,...library.childNodes);library.append(details);
 document.querySelectorAll('.workspace-nav button').forEach((button,i)=>{const n=document.createElement('span');n.className='au-nav-number';n.textContent=String(i+1).padStart(2,'0');n.setAttribute('aria-hidden','true');button.prepend(n);});
}
