// Visual identity for the proposed Institut workspace. All marks are original
// decorative line drawings, not the school's official logo or chart data.
function celestialMark(className='') {
  const p=(r,a)=>[48+r*Math.cos(a*Math.PI/180),48+r*Math.sin(a*Math.PI/180)];
  const rays=Array.from({length:24},(_,i)=>{const a=p(i%2?38:36,i*15),b=p(42,i*15);return `<path d="M${a}L${b}"/>`;}).join('');
  const star=[0,2,4,1,3,0].map(i=>p(27,-90+i*72).join(',')).join(' ');
  return `<svg class="${className}" viewBox="0 0 96 96" aria-hidden="true" focusable="false"><g fill="none" stroke="currentColor" stroke-width=".7"><circle cx="48" cy="48" r="45"/><circle cx="48" cy="48" r="34"/>${rays}<polygon points="${star}"/><circle cx="48" cy="48" r="12"/><circle cx="48" cy="48" r="3"/></g><g fill="currentColor"><circle cx="48" cy="3" r="1.3"/><circle cx="93" cy="48" r="1.3"/><circle cx="48" cy="93" r="1.3"/><circle cx="3" cy="48" r="1.3"/></g></svg>`;
}

export function instituteHeading(lang) {
  const da=lang==='da';
  return `<div class="topbar institute-masthead">
    <div class="institute-brand">${celestialMark('institute-seal')}<div><span class="institute-name">Astrologisk Institut</span><span class="institute-byline">${da?'Studieværksted':'Study workspace'} <i>·</i> Stjernerne</span></div></div>
    <div class="masthead-tools"><nav aria-label="${da?'Skoleprofil':'School profile'}"><a href="/institut" aria-current="page">${da?'Instituttet':'The Institute'}</a><a href="/university">Astrology University</a></nav><button id="language" class="quiet" aria-label="${da?'Skift til engelsk':'Switch to Danish'}">${da?'EN':'DA'} <span aria-hidden="true">↗</span></button></div>
  </div>
  <header class="header institute-intro"><div><div class="eyebrow">${da?'ASTROLOGI · FORDYBELSE · PRAKSIS':'ASTROLOGY · STUDY · PRACTICE'}</div><h1>${da?'Horoskopets sammenhænge':'The patterns of the chart'}<span class="title-stop">.</span></h1><p>${da?'Fra de enkelte placeringer til det samlede billede.':'From individual placements to the whole picture.'}</p></div><div class="institute-intro-art" aria-hidden="true">${celestialMark()}<span>☉ <i></i> ☽</span></div></header>`;
}

export function decorateInstitute(lang) {
  const da=lang==='da';
  const library=document.querySelector('.saved'),heading=library.querySelector('h3'),details=document.createElement('details'),summary=document.createElement('summary');
  details.className='study-library';details.open=window.matchMedia('(min-width:721px)').matches;summary.textContent=heading.textContent;heading.remove();details.append(summary,...library.childNodes);library.append(details);
  document.querySelectorAll('.workspace-nav button').forEach((button,i)=>{
    const number=document.createElement('span');number.className='nav-number';number.setAttribute('aria-hidden','true');number.textContent=String(i+1).padStart(2,'0');button.prepend(number);
  });
  const labels={
    'zoom-chart':[da?'Stort hjul':'Enlarge','M4 9V4h5M15 4h5v5M20 15v5h-5M9 20H4v-5'],
    'download-svg':['SVG','M12 3v12m-4-4 4 4 4-4M4 16v4h16v-4'],
    'download-csv':['CSV','M4 4h16v16H4zM4 10h16M10 4v16'],
    'print':[da?'Arbejdsark':'Worksheet','M6 8V3h12v5M6 17H3V9h18v8h-3M6 14h12v7H6z']
  };
  for(const [id,[label,path]] of Object.entries(labels)){
    const button=document.getElementById(id);
    button.innerHTML=`<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="${path}" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg><span>${label}</span>`;
    button.title=id==='download-svg'?(da?'Hent horoskophjulet som SVG':'Download the chart as SVG'):id==='download-csv'?(da?'Hent positioner som CSV':'Download positions as CSV'):label;
  }
}
