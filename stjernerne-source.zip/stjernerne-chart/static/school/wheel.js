import {planetSymbol} from '../symbols.js';
import {spreadLabels,houseMidpoints} from '../wheel.js';
const NS='http://www.w3.org/2000/svg',glyphs=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
export function wheel(layers,{visibility,bodyName,positionText,title,pair=null,selected=null,school='institut',focus=''}){
 const el=(tag,attrs={},text)=>{const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));if(text!==undefined)n.textContent=text;return n;};
 const svg=el('svg',{viewBox:'0 0 980 980',xmlns:NS,role:'img','aria-label':title});svg.append(el('title',{},title),el('rect',{width:980,height:980,fill:'#fff'}));
 const center=490,asc=layers[0].ascendant?.longitude??(layers[0].synthetic_houses?layers[0].houses[0].longitude:0);
 const point=(lon,r)=>{const rad=(180-lon+asc)*Math.PI/180;return [center+r*Math.cos(rad),center+r*Math.sin(rad)];};
 const add=(tag,attrs,text)=>{const n=el(tag,attrs,text);svg.append(n);return n;};
 const line=(a,b,color,width=1,extra={})=>add('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:color,'stroke-width':width,...extra});
 const text=(lon,r,value,attrs={})=>{const [x,y]=point(lon,r);return add('text',{x,y,'text-anchor':'middle','dominant-baseline':'middle','font-family':'Arial,sans-serif','font-size':13,fill:'#484a50',...attrs},value);};
 const circle=(r,fill,stroke)=>add('circle',{cx:center,cy:center,r,fill,stroke,'stroke-width':1});
 const colors=school==='institut'?['#856b1d','#526987','#b66b52']:['#2a3c75','#368f79','#a44c76'];
 circle(478,'#fff','#ece9e1');circle(412,'#fff','#b8b4ab');circle(371,'#fff','#d5d2c9');circle(352,'none','#e5e2da');circle(188,'#fbfaf7','#e5e2da');
 if(visibility.signs){
  const fills=['#fbefe8','#f0f3e9','#f4eef7','#eaf1f6'];
  for(let i=0;i<12;i++){const a=point(i*30,411),b=point((i+1)*30,411),c=point((i+1)*30,372),d=point(i*30,372);add('path',{d:`M${a}A411 411 0 0 0 ${b}L${c}A372 372 0 0 1 ${d}Z`,fill:fills[i%4],stroke:'#fff','stroke-width':1});text(i*30+15,392,glyphs[i]+'\uFE0E',{'font-size':27,fill:['#ad674b','#7b8455','#86658c','#547d96'][i%4]});}
  for(let d=0;d<360;d++)line(point(d,d%5?365:359),point(d,370),'#a9aaa3',d%5?.6:1);
 }
 const base=layers[0];
 if(visibility.houses){
  const houseCenters=houseMidpoints(base.houses);
  for(let i=0;i<base.houses.length;i++){const h=base.houses[i];line(point(h.longitude,189),point(h.longitude,352),'#dad5c8',1);text(houseCenters[i],207,String(i+1),{'font-size':16,fill:'#8d8778','data-house-label':i+1});}
  for(const [k,label] of [['ascendant','AC'],['midheaven','MC']])if(base[k]){const lon=base[k].longitude;line(point(lon,190),point(lon,353),colors[0],1.5,base.birth.confidence==='approximate'?{'stroke-dasharray':'5 4'}:{});text(lon,343,label,{'font-size':13,'font-weight':700,fill:colors[0]});}
 }
 if(visibility.aspects){
  const from=pair?.from??0,to=pair?.to??0,rows=selected?[selected]:(pair?.aspects??base.aspects);
  const map=i=>Object.fromEntries([...layers[i].planets,...['ascendant','midheaven'].filter(k=>layers[i][k]).map(k=>({id:k,...layers[i][k]}))].map(p=>[p.id,p]));
  const a=map(from),b=map(to);
  for(const row of rows){if(focus&&![row.a,row.b].includes(focus))continue;if(!visibility.houses&&[row.a,row.b].some(k=>['ascendant','midheaven'].includes(k)))continue;if(row.angle===0||!a[row.a]||!b[row.b])continue;const color=[60,120].includes(row.angle)?'#64877a':[150,30].includes(row.angle)?'#997ba7':'#bb7965';line(point(a[row.a].longitude,185),point(b[row.b].longitude,185),color,selected?2.2:1,{'stroke-opacity':selected?1:.55});}
 }
 const radii=layers.length===3?[251,321,447]:layers.length===2?[286,447]:[289];
 layers.forEach((layer,index)=>{
  const r=radii[index];if(index)circle(r+23,'none','#e8e5dd');
  for(const p of spreadLabels(layer.planets,index===0?10:8)){
   const [x,y]=point(p.display,r);line(point(p.longitude,index===0?220:r-27),point(p.display,r-16),colors[index],.8,{'stroke-opacity':.6});
   const group=add('g',{'data-body':p.id,'data-layer':index,opacity:focus&&p.id!==focus?.45:1});
   group.append(el('title',{},bodyName(p.id)+(visibility.signs?' · '+positionText(p.longitude):'')+(visibility.houses&&p.house?' · '+p.house:'')));
   group.append(el('circle',{cx:x,cy:y,r:15,fill:'white'}));
   const id=p.id.endsWith('_node')?'true_node':p.id;
   const symbol=planetSymbol(id,x,y,22,colors[index],{eris:'Er',haumea:'Ha',makemake:'Mk',pallas:'Pa',juno:'Ju',vesta:'Ve'}[p.id]);
   if(p.id==='south_node')symbol.setAttribute('transform',symbol.getAttribute('transform')+' rotate(180 12 12)');group.append(symbol);
   if(visibility.signs)text(p.display,r+22,Math.floor(p.degree)+'°'+(p.retrograde?' ℞':''),{'font-size':12,fill:colors[index]});
  }
 });
 return svg;
}
