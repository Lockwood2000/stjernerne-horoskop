import {planetSymbol} from '../symbols.js';
import {spreadLabels} from '../wheel.js';
import {houseSectors} from '../house-geometry.js';
const NS='http://www.w3.org/2000/svg',glyphs=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
export function wheel(layers,{visibility,bodyName,positionText,title,pair=null,selected=null,school='institut',focus=''}){
 const el=(tag,attrs={},text)=>{const n=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));if(text!==undefined)n.textContent=text;return n;};
 const focused=Array.isArray(focus)?focus:focus?[focus]:[];
 const institut=school==='institut',paper=institut?'#fffdf9':'#fff',single=layers.length===1;
 const svg=el('svg',{viewBox:institut&&single?'48 48 884 884':'0 0 980 980',xmlns:NS,role:'img','aria-label':title});svg.append(el('title',{},title),el('rect',{width:980,height:980,fill:paper}));
 const center=490,asc=layers[0].ascendant?.longitude??(layers[0].synthetic_houses?layers[0].houses[0].longitude:0);
 const point=(lon,r)=>{const rad=(180-lon+asc)*Math.PI/180;return [center+r*Math.cos(rad),center+r*Math.sin(rad)];};
 const add=(tag,attrs,text)=>{const n=el(tag,attrs,text);svg.append(n);return n;};
 const line=(a,b,color,width=1,extra={})=>add('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:color,'stroke-width':width,...extra});
 const text=(lon,r,value,attrs={})=>{const [x,y]=point(lon,r);return add('text',{x,y,'text-anchor':'middle','dominant-baseline':'middle','font-family':'Arial,sans-serif','font-size':13,fill:'#484a50',...attrs},value);};
 const circle=(r,fill,stroke)=>add('circle',{cx:center,cy:center,r,fill,stroke,'stroke-width':1});
 const colors=school==='institut'?['#756035','#577575','#a56954']:['#2a3c75','#368f79','#a44c76'];
 if(institut){const outer=single?428:478;circle(outer,paper,'#c5b37d');circle(outer-5,'none','#e3d8bc');for(let i=0;i<12;i++){const [x,y]=point(i*30,outer-2.5);add('circle',{cx:x,cy:y,r:i%3===0?1.7:.8,fill:'#b19a57'});}circle(412,paper,'#bba66b');circle(371,paper,'#cfc2a2');circle(352,'none','#e3dac7');circle(188,'#f8f3e9','#d9cbaa');}else{circle(478,'#fff','#e0e8f2');circle(473,'none','#eef3f9');circle(412,'#fff','#9daec8');circle(371,'#fff','#c1cedf');circle(352,'none','#e0e8f2');circle(188,'#f7f9fd','#d4e0ec');}
 if(visibility.signs){
  const fills=institut?['#f2e5d8','#e8ebdf','#eee7ed','#e4edf0']:['#fbefe8','#f0f3e9','#f4eef7','#eaf1f6'];
  for(let i=0;i<12;i++){const a=point(i*30,411),b=point((i+1)*30,411),c=point((i+1)*30,372),d=point(i*30,372);add('path',{d:`M${a}A411 411 0 0 0 ${b}L${c}A372 372 0 0 1 ${d}Z`,fill:fills[i%4],stroke:paper,'stroke-width':1});text(i*30+15,392,glyphs[i]+'\uFE0E',{'font-size':institut?29:27,fill:(institut?['#9b6b4b','#717e54','#806486','#527b89']:['#ad674b','#7b8455','#86658c','#547d96'])[i%4]});}
  for(let d=0;d<360;d++)line(point(d,d%5?365:359),point(d,370),'#a9aaa3',d%5?.6:1);
 }
 const base=layers[0];
 if(visibility.houses){
  for(const h of houseSectors(base.houses)){line(point(h.cusp,189),point(h.cusp,352),institut?'#cfc1a0':'#cedae9',1);text(h.midpoint,207,String(h.number),{'font-size':institut?18:16,fill:institut?'#a18c59':'#7289a8','data-house':h.number});}
  for(const [k,label] of [['ascendant','AC'],['midheaven','MC']])if(base[k]){const lon=base[k].longitude;line(point(lon,190),point(lon,353),colors[0],1.5,base.birth.confidence==='approximate'?{'stroke-dasharray':'5 4'}:{});text(lon,343,label,{'font-size':13,'font-weight':700,fill:colors[0]});}
 }
 if(visibility.aspects){
  const from=pair?.from??0,to=pair?.to??0,rows=selected?[selected]:(pair?.aspects??base.aspects);
  const map=i=>Object.fromEntries([...layers[i].planets,...['ascendant','midheaven'].filter(k=>layers[i][k]).map(k=>({id:k,...layers[i][k]}))].map(p=>[p.id,p]));
  const a=map(from),b=map(to);
  for(const row of rows){if(focused.length&&![row.a,row.b].some(id=>focused.includes(id)))continue;if(!visibility.houses&&[row.a,row.b].some(k=>['ascendant','midheaven'].includes(k)))continue;if(!a[row.a]||!b[row.b])continue;if(row.angle===0){if(selected&&!institut){for(const p of [a[row.a],b[row.b]]){const [x,y]=point(p.longitude,185);add('circle',{cx:x,cy:y,r:5,fill:'#fff',stroke:'#3d8b78','stroke-width':2});}line(point(a[row.a].longitude,185),point(b[row.b].longitude,185),'#3d8b78',2.2);}continue;}const color=[60,120].includes(row.angle)?'#64877a':[150,30].includes(row.angle)?'#997ba7':'#bb7965';line(point(a[row.a].longitude,185),point(b[row.b].longitude,185),color,selected?2.2:(institut?1.15:1),{'stroke-opacity':selected?1:(institut?.62:.55)});}
 }
 const radii=layers.length===3?[251,321,447]:layers.length===2?[286,447]:[289];
 layers.forEach((layer,index)=>{
  const r=radii[index];if(index)circle(r+23,'none',institut?'#ddd0af':'#dce7ee');
  for(const p of spreadLabels(layer.planets,index===0?10:8)){
   const [x,y]=point(p.display,r);line(point(p.longitude,index===0?220:r-27),point(p.display,r-16),colors[index],.8,{'stroke-opacity':.6});
   const group=add('g',{'data-body':p.id,'data-layer':index,opacity:focused.length&&!focused.includes(p.id)?.3:1});
   group.append(el('title',{},bodyName(p.id)+(visibility.signs?' · '+positionText(p.longitude):'')+(visibility.houses&&p.house?' · '+p.house:'')));
   group.append(el('circle',{cx:x,cy:y,r:15,fill:paper}));
   const id=p.id.endsWith('_node')?'true_node':p.id;
   const symbol=planetSymbol(id,x,y,institut?24:22,colors[index],{eris:'Er',haumea:'Ha',makemake:'Mk',pallas:'Pa',juno:'Ju',vesta:'Ve'}[p.id]);
   if(p.id==='south_node')symbol.setAttribute('transform',symbol.getAttribute('transform')+' rotate(180 12 12)');group.append(symbol);
   if(visibility.signs)text(p.display,r+22,Math.floor(p.degree)+'°'+(p.retrograde?' ℞':''),{'font-size':institut?13:12,fill:colors[index]});
  }
 });
 return svg;
}
