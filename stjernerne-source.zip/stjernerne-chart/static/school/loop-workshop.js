const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const PLANETS=['mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'];
const GLYPHS=['☿','♀','♂','♃','♄','♅','♆','♇'];
const DA=['Ledsagende konjunktion','Indgang i sløjfen','Advarselslampen','Vendegraden','Mødegraden','Rodpunktet','Reaktiveringsgraden','Udgangen','En ny cyklus'];
const EN=['Direct conjunction','Entering the loop','First signal','Retrograde turn','Solar encounter','Direct turn','Reactivation','Leaving the loop','A new cycle'];
const EXPLAIN_DA=[
 'Planeten passerer Solens længdegrad under direkte bevægelse.',
 'Den første direkte passage af den grad, hvor planeten senere vender fremad.',
 'Første passage af den grad, der bliver cyklens møde med Solen.',
 'Hastigheden når nul. Her begynder den retrograde del af forløbet.',
 'Planeten er retrograd. Merkur og Venus møder Solen i konjunktion; de ydre planeter står i opposition.',
 'Hastigheden når igen nul. Planeten skifter fra retrograd til direkte bevægelse.',
 'Efter vendingen passerer planeten mødegraden for tredje gang.',
 'Planeten når igen den grad, hvor den vendte retrograd. Sløjfen er gennemløbet.',
 'Den næste direkte konjunktion med Solen markerer en ny cyklus.'
];
const EXPLAIN_EN=[
 'The planet passes the Sun’s longitude while moving direct.',
 'The first direct passage of the longitude where the planet later turns direct.',
 'The first passage of the longitude of the later solar encounter.',
 'Longitudinal speed reaches zero. Retrograde motion begins.',
 'The planet is retrograde: Mercury and Venus conjoin the Sun; outer planets oppose it.',
 'Longitudinal speed reaches zero again. The planet turns direct.',
 'After turning direct, the planet crosses the encounter longitude for the third time.',
 'The planet returns to the longitude where it turned retrograde. The loop is complete.',
 'The next direct conjunction with the Sun marks a new cycle.'
];

export function renderLoopWorkshop(panel,data,ctx){
 const {L,state,bodyName,positionText,angularText,dateText,day,notice,onApply,onLife,download}=ctx;
 const q=id=>panel.querySelector('#'+id),label=n=>L(DA[n-1],EN[n-1]);
 const setting=state.loops,selected=data?.stages[setting.selected-1];
 const noteKey=data?`${data.planet}|${data.stages[4].utc.slice(0,10)}|${setting.selected}`:'';
 const full=noteKey&&!(noteKey in setting.notes)&&Object.keys(setting.notes).length>=120;
 const option=(value,text,current)=>`<option value="${value}" ${value===current?'selected':''}>${text}</option>`;
 const utc=iso=>dateText(iso);
 function flush(){
  if(q('loop-note')){const value=q('loop-note').value;if(value)setting.notes[noteKey]=value;else delete setting.notes[noteKey];}
  if(q('loop-planet')){setting.planet=q('loop-planet').value;setting.mode=q('loop-mode').value;setting.orb=Number(q('loop-orb').value);setting.date=q('loop-date').value;}
 }
 function apply(){flush();setting.cycleDate='';onApply();}
 function choose(n){flush();setting.selected=n;ctx.redraw(data);panel.querySelector(`[data-loop-stage="${n}"]`)?.focus();}
 panel.innerHTML=`<div class="atelier-card loop-card"><div class="atelier-card-head"><div><span class="eyebrow">${L('LOUISE KIRSEBOM · SLØJFEMETODEN','LOUISE KIRSEBOM · THE LOOP METHOD')}</span><h3>${L('Kunsten at vende tilbage','The art of returning')}</h3></div><span class="loop-seal" aria-hidden="true">℞</span></div>
  <div class="loop-controls"><label>${L('Planet','Planet')}<select id="loop-planet">${PLANETS.map((p,i)=>option(p,GLYPHS[i]+' '+bodyName(p),setting.planet)).join('')}</select></label><label>${L('Undersøg','Explore')}<select id="loop-mode">${option('natal',L('Ved min fødsel','At my birth'),setting.mode)}${option('transits',L('På en valgt dato','On a chosen date'),setting.mode)}${option('progressed',L('I progression','In progression'),setting.mode)}</select></label><label ${setting.mode==='natal'?'hidden':''}>${L('Dato','Date')}<input id="loop-date" type="date" min="1500-01-01" max="2099-12-31" value="${setting.date||new Date().toISOString().slice(0,10)}"></label><label class="loop-orb-label">${L('Orbis','Orb')}<input id="loop-orb" type="number" min="0.1" max="1.5" step="0.1" value="${setting.orb}"></label><button type="button" id="loop-apply" class="primary">${L('Vis sløjfen','Show loop')} ↗</button></div>
  <div class="loop-example"><span>${L('Et forløb. Tre passager. Nye iagttagelser.','One cycle. Three passages. New observations.')}</span><button type="button" id="loop-example" class="quiet">${L('Prøv Kirseboms eksempel fra 2025','Try Kirsebom’s 2025 example')} ↗</button></div>
  ${data?`<div id="loop-result"><div class="loop-cycle-nav"><button type="button" id="loop-prev" ${data.previous?'':'disabled'} aria-label="${L('Forrige sløjfe','Previous loop')}">←</button><div><span>${esc(bodyName(data.planet))} · ${L('SLØJFEN','THE LOOP')}${data.mode==='progressed'?' · '+L('EFEMERIDE','EPHEMERIS'):''}</span><strong>${day(data.stages[1].utc)} — ${day(data.stages[7].utc)}</strong></div><button type="button" id="loop-next" ${data.next?'':'disabled'} aria-label="${L('Næste sløjfe','Next loop')}">→</button></div>
  ${data.uncertainty?`<div class="atelier-caution">${L('Fødselstiden er usikker. Huse og personlige grader er foreløbige; ved ukendt tid vises ingen huse eller akser.','The birth time is uncertain. Houses and personal degrees are provisional; unknown time excludes houses and angles.')}${data.boundary_stages.length?' '+L('Tidsintervallet krydser trin ','The interval crosses stage ')+data.boundary_stages.join(', ')+'.':''}${data.mode==='progressed'?' '+L('De mulige livsdatoer vises ved hvert trin.','The possible life dates are shown for each stage.'):''}</div>`:''}
  <div class="loop-main"><div class="loop-figure"><div id="loop-drawing"></div><p class="atelier-caption">${L('Skematisk sløjfe · de lodrette forbindelser samler samme grad. Datoer og grader er beregnede.','Schematic loop · vertical links connect the same longitude. Dates and degrees are calculated.')}</p><div class="loop-step-nav" aria-label="${L('Sløjfens ni trin','The nine stages')}">${data.stages.map(s=>`<button type="button" data-loop-stage="${s.number}" class="${setting.selected===s.number?'active':''}" aria-pressed="${setting.selected===s.number}" aria-label="${s.number}. ${label(s.number)}" title="${label(s.number)}">${s.number}</button>`).join('')}</div></div>
  <article class="loop-reading"><span class="atelier-kicker">${L('TRIN','STAGE')} ${selected.number} ${selected.stationary?'· '+L('STATIONÆR','STATIONARY'):''}</span><h4>${label(selected.number)}</h4><div class="loop-degree">${positionText(selected.longitude)}</div><time datetime="${selected.utc}">${data.mode==='progressed'?L('Efemeridetid: ','Ephemeris time: '):''}${utc(selected.utc)}</time><p class="atelier-muted">${L(EXPLAIN_DA[selected.number-1],EXPLAIN_EN[selected.number-1])}</p>
   ${data.mode==='progressed'?`<div class="loop-life-date"><span>${L('PÅ DIN LIVSLINJE','ON YOUR LIFELINE')}</span><strong>${selected.life_utc?day(selected.life_utc):L('Uden for fødsel–2099','Outside birth–2099')}</strong>${selected.life_uncertainty?`<small>${L('Muligt interval','Possible interval')}: ${day(selected.life_uncertainty[0])} — ${day(selected.life_uncertainty[1])}</small>`:''}</div>`:''}
   ${selected.house?`<p class="atelier-fine">${L('I fødselshoroskopets hus ','In natal house ')}${selected.house}</p>`:''}
   <div class="loop-reading-actions"><button type="button" id="loop-to-life" ${selected.life_utc?'':'disabled'}>${L('Føj til livslinjen','Add to lifeline')} ↗</button><button type="button" id="loop-svg" class="quiet" aria-label="${L('Hent sløjfen som SVG','Download loop as SVG')}">SVG ↓</button></div>
   <div class="atelier-rule"></div><h5>${L('Fødselspunkter på graden','Natal points at this degree')}</h5>${selected.contacts.length?`<ul class="atelier-contacts">${selected.contacts.map(p=>`<li><span>${esc(bodyName(p.id))}</span><b>${angularText(p.orb)}</b></li>`).join('')}</ul>`:`<p class="atelier-fine">${L('Ingen valgte fødselspunkter inden for','No selected natal points within')} ${setting.orb}°.</p>`}<p class="atelier-fine">${L('Gradkontakt · højst 1½° orbis','Longitude contact · maximum 1½° orb')}</p>
  </article></div>
  <div class="loop-focus"><span class="loop-focus-symbol">${GLYPHS[PLANETS.indexOf(data.planet)]}</span><div><h5>${L('På fokusdatoen','At the focus instant')}: ${data.mode==='natal'?L('din fødsel','your birth'):day(data.focus_date)}</h5><p>${positionText(data.focus_point.longitude)} · ${data.focus_point.retrograde?L('retrograd','retrograde'):L('direkte','direct')} · ${data.phase?L('i sløjfen, fra trin ','in the loop, from stage ')+data.phase:L('uden for den valgte sløjfe','outside the selected loop')}${data.near.length?'<br>'+L('Nær trin ','Near stage ')+data.near.map(p=>p.stage+' ('+angularText(p.orb)+')').join(' · '):''}</p></div><button type="button" id="loop-return" class="quiet">${L('Find nærmeste sløjfe','Find nearest loop')} ↗</button></div>
  <section class="loop-families"><div class="atelier-section-title"><div><span class="eyebrow">${L('GRADER DER FORBINDER','LONGITUDES THAT CONNECT')}</span><h4>${L('Det samme sted. Et nyt møde.','The same place. A new encounter.')}</h4></div></div><div class="loop-family-grid">${[[2,6],[3,5,7],[4,8]].map((family,i)=>`<button type="button" data-loop-family="${family[0]}" class="loop-family ${family.includes(selected.number)?'active':''}"><span>${family.join(' ↔ ')}</span><strong>${positionText(data.stages[family[0]-1].longitude)}</strong><small>${L(['Indgang & rodpunkt','Signal, møde & genbesøg','Vending & udgang'][i],['Entry & direct turn','Signal, encounter & return','Retrograde turn & exit'][i])}</small></button>`).join('')}</div><p class="atelier-caption">${L('Vælg en forbindelse, og undersøg de tilsvarende trin i rækken ovenfor. Hvad har dine egne iagttagelser til fælles?','Choose a connection, then explore its stages above. What do your own observations have in common?')}</p></section>
  <div class="atelier-writing"><label class="atelier-reflection" for="loop-note"><span>${L('Mine iagttagelser','My observations')} · ${selected.number}. ${label(selected.number)}</span><small>${L('Hvad lægger du mærke til her? Sammenhold dine noter fra de andre passager af samme grad.','What do you notice here? Compare your notes from the other passages of this longitude.')}</small><textarea id="loop-note" maxlength="4000" rows="3" ${full?'disabled':''} placeholder="${L('Dine egne ord, erfaringer og spørgsmål …','Your own words, experiences and questions …')}">${esc(setting.notes[noteKey]||'')}</textarea>${full?`<small>${L('Studiet har 120 trinnoter. Du kan stadig redigere eksisterende noter.','This study has 120 stage notes. Existing notes remain editable.')}</small>`:''}</label>${selected.family.filter(n=>n!==selected.number).map(n=>{const text=setting.notes[`${data.planet}|${data.stages[4].utc.slice(0,10)}|${n}`];return text?`<details class="loop-related"><summary>${L('Din note fra trin ','Your note from stage ')}${n} · ${label(n)}</summary><p>${esc(text)}</p></details>`:'';}).join('')}</div>
  <details class="atelier-method"><summary>${L('Alle ni trin · datoer og grader','All nine stages · dates and longitudes')}</summary>${!data.conjunctions_frame_shadow?`<p>${L('For denne ydre planet ligger en eller begge Sol-konjunktioner (1 og 9) inde i skyggeperioden. Rækken nedenfor er derfor sorteret efter dato; trin 2–8 beskriver selve sløjfen.','For this outer planet, one or both solar conjunctions (1 and 9) occur inside the shadow. The list is therefore sorted by date; stages 2–8 describe the loop itself.')}</p>`:''}<div class="loop-table">${[...data.stages].sort((a,b)=>a.utc.localeCompare(b.utc)).map(s=>`<button type="button" data-loop-table="${s.number}"><span>${s.number}. ${label(s.number)}</span><time>${utc(s.utc)}${data.mode==='progressed'?'<small>'+L('Livslinje: ','Lifeline: ')+(s.life_utc?day(s.life_utc):'—')+'</small>':''}</time><strong>${positionText(s.longitude)}</strong></button>`).join('')}</div></details>
  <details class="atelier-method"><summary>${L('Beregningsmetode & kilder','Calculation method & sources')}</summary><p>${L('Vi bruger Kirseboms offentlige beskrivelse af sløjfens ni trin. Trin 4 og 6 er astronomiske stationer; de øvrige er definerede passager. Merkur og Venus har konjunktion med Solen i trin 5, de ydre planeter opposition. Sløjfen vælges efter det midterste Sol-møde nærmest fokusdatoen.','We use Kirsebom’s public description of the nine stages. Only stages 4 and 6 are astronomical stations. Mercury and Venus conjoin the Sun at stage 5; outer planets oppose it. Selection uses the central solar encounter nearest the focus date.')}</p><p>${L('Graderne er geocentriske og tropiske. Tidspunkter vises i UTC. Progression bruger ét efemeridedøgn pr. tropisk år; der vises kun livsdatoer fra fødslen til 2099. En ukendt fødselstid giver ingen progression. Orbis på højst 1½° bruges til nærhed på den aktuelle passage og til konjunktioner med fødselspunkter.','Coordinates are geocentric and tropical; times are UTC. Progressions use one ephemeris day per tropical year. Life dates are restricted to birth–2099; unknown birth time excludes progressions. The maximum 1½° orb applies to branch-aware phase proximity and conjunctions with natal points.')}</p><p>${L('Refleksionsspørgsmålene er skrevet til dette værksted. Personlig tolkning og sammenhænge undersøger du selv.','Reflection prompts were written for this workspace. Personal interpretation and connections are yours to explore.')}</p>${data.sources.map((url,i)=>`<a href="${url}" target="_blank" rel="noopener">${L(['Kirsebom: de ni trin','Kirsebom: rejsen gennem sløjfen','Kirsebom: Merkur & Venus i 2025'][i],['Kirsebom: the nine stages','Kirsebom: the journey through the loop','Kirsebom: Mercury & Venus in 2025'][i])} ↗</a>`).join(' · ')}</details>
  </div>`:`<div class="atelier-empty"><span>℞</span><p>${esc(ctx.error||L('Vælg en planet og et udgangspunkt.','Choose a planet and a starting point.'))}</p></div>`}</div>`;
 q('loop-apply').onclick=apply;
 q('loop-planet').onchange=apply;q('loop-mode').onchange=apply;
 for(const id of ['loop-date','loop-orb'])q(id).oninput=()=>{flush();if(q('loop-result'))q('loop-result').hidden=true;notice(L('Tryk “Vis sløjfen” for at bruge de nye valg.','Choose “Show loop” to apply the new settings.'));};
 q('loop-example').onclick=()=>{flush();Object.assign(setting,{planet:'mercury',mode:'transits',date:'2025-03-23',cycleDate:'',selected:5});onApply();};
 if(!data)return {flush};
 q('loop-note').oninput=flush;
 for(const direction of ['prev','next'])q('loop-'+direction).onclick=()=>{flush();setting.cycleDate=data[direction==='prev'?'previous':'next'];onApply();};
 q('loop-return').onclick=()=>{flush();setting.cycleDate='';onApply();};
 panel.querySelectorAll('[data-loop-stage],[data-loop-table],[data-loop-family]').forEach(b=>b.onclick=()=>choose(Number(b.dataset.loopStage||b.dataset.loopTable||b.dataset.loopFamily)));
 q('loop-to-life').onclick=()=>{flush();if(selected.life_utc)onLife({date:selected.life_utc.slice(0,10),label:`${data.mode==='progressed'?'P · ':''}${bodyName(data.planet)} · ${label(selected.number)}`,note:`${label(selected.number)} · ${positionText(selected.longitude)}\n${L('Beregnet tidspunkt','Calculated instant')}: ${utc(selected.life_utc)}\n${data.mode==='progressed'?L('Efemeridetid','Ephemeris instant')+': '+utc(selected.utc)+'\n':''}${setting.notes[noteKey]||''}`});};
 const svg=loopSvg(data,setting.selected,{L,label,positionText,choose});q('loop-drawing').append(svg);
 q('loop-svg').onclick=()=>{const exported=svg.cloneNode(true),meta=document.createElementNS('http://www.w3.org/2000/svg','metadata');meta.textContent=JSON.stringify({planet:data.planet,stages:data.stages,method:data.method,sources:data.sources});exported.prepend(meta);download(new XMLSerializer().serializeToString(exported),'kirsebom-sloejfe.svg','image/svg+xml');};
 return {flush};
}

function loopSvg(data,selected,{L,label,positionText,choose}){
 const NS='http://www.w3.org/2000/svg',el=(tag,attrs={},text)=>{const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(text!=null)e.textContent=text;return e;};
 const svg=el('svg',{xmlns:NS,viewBox:'0 0 520 420',role:'group','aria-label':L('Sløjfens tre passager. Vælg et nummer.','Three passages through the loop. Select a number.')});
 const add=(tag,attrs,text)=>{const e=el(tag,attrs,text);svg.append(e);return e;};
 add('title',{},L('Sløjfen · trin 2–8','The loop · stages 2–8'));add('rect',{width:520,height:420,rx:8,fill:'#fffdf8'});
 const colors={gold:'#a18b50',sage:'#88967b',ink:'#74603d',faint:'#e5dac2'};
 add('circle',{cx:260,cy:210,r:187,fill:'#faf6eb',stroke:'#ede4d0','stroke-width':.7});
 add('circle',{cx:260,cy:210,r:174,fill:'none',stroke:'#e6dac2','stroke-dasharray':'1 7'});
 const low=80,high=440,middle=low+(high-low)*(((data.stages[4].longitude-data.stages[5].longitude+540)%360-180)/data.span_degrees);
 const curves=[[[low,100],[240,100],[high,100],[high,170]],[[high,170],[high,205],[low,215],[low,250]],[[low,250],[low,320],[260,320],[high,320]]];
 const bezier=(c,t)=>[0,1].map(k=>(1-t)**3*c[0][k]+3*(1-t)**2*t*c[1][k]+3*(1-t)*t*t*c[2][k]+t**3*c[3][k]);
 const atX=(c,x)=>{let a=0,b=1;for(let i=0;i<45;i++){const t=(a+b)/2,p=bezier(c,t);if((p[0]<x)===(c[3][0]>c[0][0]))a=t;else b=t;}return bezier(c,(a+b)/2);};
 const locations={2:[low,100],3:atX(curves[0],middle),4:[high,170],5:atX(curves[1],middle),6:[low,250],7:atX(curves[2],middle),8:[high,320]};
 const family=data.stages[selected-1].family;
 for(const [a,b] of [[2,6],[3,7],[4,8]]){const p=locations[a],q=locations[b];add('line',{x1:p[0],y1:p[1],x2:q[0],y2:q[1],stroke:family.includes(a)?'#bca56f':colors.faint,'stroke-dasharray':'3 6','stroke-width':1});}
 curves.forEach((c,i)=>{const path=`M${c[0].join(' ')} C${c.slice(1).map(p=>p.join(' ')).join(' ')}`;add('path',{d:path,fill:'none',stroke:i===1?colors.sage:colors.gold,'stroke-width':2.1,'stroke-linecap':'round'});});
 add('text',{x:260,y:47,'text-anchor':'middle',fill:colors.ink,'font-family':'sans-serif','font-size':9,'letter-spacing':3},L('PLANETENS TRE PASSAGER','THREE PLANETARY PASSAGES'));
 [[195,83,L('DIREKTE →','DIRECT →'),colors.gold],[265,239,L('← RETROGRAD','← RETROGRADE'),colors.sage],[240,350,L('DIREKTE →','DIRECT →'),colors.gold]].forEach(([x,y,text,color])=>add('text',{x,y,'text-anchor':'middle','font-size':8,'font-family':'sans-serif','letter-spacing':2,fill:color},text));
 for(const s of data.stages.slice(1,8)){
  const [x,y]=locations[s.number],active=s.number===selected,related=family.includes(s.number);
  const g=add('g',{role:'button',tabindex:0,'aria-label':`${s.number}. ${label(s.number)} · ${positionText(s.longitude)}`,'aria-pressed':String(active)});
  if(active)g.append(el('circle',{cx:x,cy:y,r:23,fill:'none',stroke:'#c5ae79','stroke-width':.8,'stroke-dasharray':'1 3'}));
  g.append(el('circle',{cx:x,cy:y,r:active?17:13,fill:active?colors.ink:related?'#f1e5c8':'#fffdf8',stroke:related?colors.gold:colors.faint,'stroke-width':1.4}),el('text',{x,y:y+4,'text-anchor':'middle','font-family':'sans-serif','font-size':12,fill:active?'#fffdf8':colors.ink},String(s.number)));
  g.onclick=()=>choose(s.number);g.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();choose(s.number);}};
 }
 add('text',{x:260,y:389,'text-anchor':'middle','font-size':10,fill:colors.ink},'2 ↔ 6       ·       3 ↔ 5 ↔ 7       ·       4 ↔ 8');
 return svg;
}
