import {wheel} from './wheel.js';
import {axisName} from './calculation-model.js';
import {validDay,timelinePositions} from './workshop-model.js';
import {renderLoopWorkshop} from './loop-workshop.js';

const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const glyphs=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
const SOURCES={venus:'https://www.astrologiskinstitut.dk/product-page/venus-star-point',nodes:'https://www.astrologiskinstitut.dk/product-page/m%C3%A5neknuderne-2026',life:'https://www.astrologiskinstitut.dk/product-page/horoskopets-tid',loops:'https://www.astrologiskinstitut.dk/post/retrograde-planeter'};

export function mountWorkshops(root,ctx){
 const {L,state,bodyName,positionText,angularText,aspectName,dateText}=ctx;
 const q=id=>root.querySelector('#'+id);
 const day=iso=>new Date(iso.slice(0,10)+'T12:00:00Z').toLocaleDateString(L('da-DK','en-GB'),{day:'numeric',month:'short',year:'numeric',timeZone:'UTC'});
 const option=(key,text,current)=>`<option value="${key}" ${key===current?'selected':''}>${text}</option>`;
 const starName=star=>star==='morning'?L('Morgenstjerne','Morning star'):star==='evening'?L('Aftenstjerne','Evening star'):L('Nær konjunktion','Near conjunction');
 let serial=0,cache={},signature='',loaded=null,lifeResult=null,selectedRhythm=0,showAllNodes=false,editing=null,removed=null,loopView=null;
 const note=(key,title,prompt)=>`<label class="atelier-reflection" for="reflection-${key}"><span>${title}</span><small>${prompt}</small><textarea id="reflection-${key}" data-reflection="${key}" maxlength="8000" rows="3" placeholder="${L('Skriv dine egne iagttagelser …','Write your own observations …')}">${esc(state.reflections[key])}</textarea></label>`;
 const contacts=(rows,limit=6)=>{
  if(!rows.length)return `<p class="atelier-muted">${L('Ingen forbindelser inden for den valgte orbis.','No contacts within the chosen orb.')}</p>`;
  const row=a=>`<li><span>${a.method?`<small class="method-tag">${a.method==='progressed'?'P':'T'}</small>`:''}${esc(a.a==='venus_star'?'✧':bodyName(a.a))} <i>${aspectName(a.angle)}</i> ${esc(bodyName(a.b))}</span><b>${angularText(a.orb)}</b></li>`;
  return `<ul class="atelier-contacts">${rows.slice(0,limit).map(row).join('')}</ul>${rows.length>limit?`<details class="atelier-more"><summary>${L('Se alle','See all')} ${rows.length} ${L('forbindelser','contacts')}</summary><ul class="atelier-contacts">${rows.slice(limit).map(row).join('')}</ul></details>`:''}`;
 };
 function notice(text,error=false){q('atelier-message').textContent=text;q('atelier-message').classList.toggle('error',error);}
 function flush(){
  loopView?.flush();
  root.querySelectorAll('[data-reflection]').forEach(el=>state.reflections[el.dataset.reflection]=el.value);
  const event=state.events.find(e=>e.id===state.selectedEvent);if(event&&q('life-note'))event.note=q('life-note').value;
  if(q('life-method')){state.method=q('life-method').value;state.focus=q('life-focus').value;state.orb=Number(q('life-orb').value);state.shift=Math.round(Number(q('life-shift').value)*60)/60;}
 }
 function bindNotes(){root.querySelectorAll('[data-reflection]').forEach(el=>el.oninput=()=>{state.reflections[el.dataset.reflection]=el.value;});}
 function header(){
  root.innerHTML=`<div class="atelier-intro"><div><div class="eyebrow">${L('FIRE VEJE IND I HOROSKOPET','FOUR WAYS INTO THE CHART')}</div><h2>${L('Et personligt studierum','A personal study room')}<span>.</span></h2><p>${L('Følg en cyklus. Udforsk en akse. Se dit liv i sammenhæng.','Follow a cycle. Explore an axis. See your life in context.')}</p></div><button type="button" id="atelier-save" class="atelier-save">${L('Gem arbejdet','Save study')} ↗</button></div>
   <div class="atelier-switch" role="tablist" aria-label="${L('Vælg værksted','Choose a workshop')}">${[
    ['venus','♀','Venus Star Point',L('MARIE MALLINGS KURSUS','MARIE MALLING’S COURSE')],
    ['nodes','☊',L('Måneknuderne','Lunar nodes'),L('KARSTEN ZEUTHENS KURSUS','KARSTEN ZEUTHEN’S COURSE')],
    ['life','◷',L('Min livslinje','My lifeline'),L('LOUISE BUNNAGES KURSUS','LOUISE BUNNAGE’S COURSE')],
    ['loops','℞',L('Sløjfemetoden','Planetary loops'),L('LOUISE KIRSEBOMS METODE','LOUISE KIRSEBOM’S METHOD')]
   ].map(([id,glyph,title,teacher])=>`<button type="button" role="tab" id="atelier-tab-${id}" aria-controls="atelier-panel" aria-selected="${state.active===id}" tabindex="${state.active===id?0:-1}" data-atelier="${id}" class="atelier-choice ${state.active===id?'active':''}"><span class="atelier-icon" aria-hidden="true">${glyph}</span><span><strong>${title}</strong><small>${teacher}</small></span></button>`).join('')}</div>
   <div id="atelier-message" role="status" aria-live="polite"></div><div id="atelier-panel" class="atelier-panel" role="tabpanel" aria-labelledby="atelier-tab-${state.active}"></div>
   <p class="atelier-footnote">${L('Værksteder bygget på Instituttets offentlige kursusbeskrivelser og artikler. Dine noter og livsbegivenheder gemmes sammen med studiearbejdet.','Workshops based on the Institute’s public course descriptions and articles. Your notes and life events are saved with your study work.')} <a id="atelier-source" href="${SOURCES[state.active]}" target="_blank" rel="noopener">${L('Læs kilden','Read the source')} ↗</a></p>`;
  root.querySelectorAll('[data-atelier]').forEach(b=>{
   b.onclick=()=>{flush();state.active=b.dataset.atelier;open();};
   b.onkeydown=e=>{if(!['ArrowLeft','ArrowRight','Home','End'].includes(e.key))return;e.preventDefault();const tabs=[...root.querySelectorAll('[data-atelier]')],i=tabs.indexOf(b),j=e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:tabs.length-1))%tabs.length;tabs[j].click();tabs[j].focus();};
  });
  q('atelier-save').onclick=async()=>{const b=q('atelier-save');b.disabled=true;try{await ctx.save();notice(L('Dit studiearbejde er gemt i denne browser.','Your study work is saved in this browser.'));}catch(e){notice(e.message,true);}finally{if(b.isConnected)b.disabled=false;}};
 }
 function activate(){history.replaceState(null,'','/institut'+(state.active==='loops'?'#sloejfer':'#fordybelse'));root.querySelectorAll('[data-atelier]').forEach(b=>{const active=b.dataset.atelier===state.active;b.classList.toggle('active',active);b.setAttribute('aria-selected',String(active));b.tabIndex=active?0:-1;});q('atelier-panel').setAttribute('aria-labelledby','atelier-tab-'+state.active);q('atelier-source').href=SOURCES[state.active];}
 function current(){const input=ctx.input();const key=JSON.stringify(input);if(key!==signature){cache={};lifeResult=null;signature=key;}return input;}
 function invalidate(){serial++;cache={};loaded=null;lifeResult=null;signature='';if(q('atelier-panel')){q('atelier-panel').innerHTML=`<div class="atelier-empty"><span>✧</span><h3>${L('Et nyt udgangspunkt','A new starting point')}</h3><p>${L('Beregn horoskopet igen for at opdatere værkstederne. Dine noter er bevaret.','Calculate the chart again to update the workshops. Your notes are retained.')}</p></div>`;notice('');}}
 async function open(){
  activate();const token=++serial;notice('');let input;
  try{input=current();}catch(e){q('atelier-panel').innerHTML=`<div class="atelier-empty"><span>✧</span><p>${esc(e.message)}</p></div>`;return;}
  const active=state.active;loopView=null;loaded=null;
  if(active==='life'){loaded=null;renderLife();return;}
  const loopPayload=active==='loops'?{planet:state.loops.planet,mode:state.loops.mode,date:state.loops.mode==='natal'?null:state.loops.date||null,cycle_date:state.loops.cycleDate||null,orb:state.loops.orb}:{};
  const key=active+(active==='venus'?state.venusHorizon:active==='loops'?JSON.stringify(loopPayload):'');
  q('atelier-panel').innerHTML=`<div class="atelier-empty" aria-busy="true"><span class="atelier-loading">✧</span><p>${L('Finder horoskopets forbindelser …','Finding the chart’s connections …')}</p></div>`;
  try{
   if(active==='loops'&&state.loops.mode==='progressed'&&input.birth.confidence==='unknown')throw Error(L('Progression kræver et angivet fødselstidspunkt. Vælg i stedet en dato eller fødselsvisningen.','Progression needs a stated birth time. Choose a date or the birth view instead.'));
   const data=cache[key]||await ctx.api('/api/school/'+(active==='venus'?'venus':active==='loops'?'loops':'nodes'),{...input,...(active==='venus'?{horizon_years:state.venusHorizon}:loopPayload)});
   if(token!==serial||!root.isConnected||JSON.stringify(ctx.input())!==signature)return;
   cache[key]=data;loaded=data;if(active==='venus')renderVenus(data);else if(active==='loops')renderLoops(data);else renderNodes(data);
  }catch(e){if(token!==serial||!root.isConnected)return;if(active==='loops'){renderLoops(null,e.message);return;}q('atelier-panel').innerHTML=`<div class="atelier-empty"><p>${esc(e.message)}</p><button type="button" id="atelier-retry">${L('Prøv igen','Try again')}</button></div>`;q('atelier-retry').onclick=open;}
 }
 function renderLoops(data,error){
  loopView=renderLoopWorkshop(q('atelier-panel'),data,{L,state,bodyName,positionText,angularText,dateText,day,notice,error,download:ctx.download,onApply:open,redraw:renderLoops,onLife:entry=>{
   if(state.events.length>=40){notice(L('Der er plads til 40 begivenheder.','Up to 40 events are supported.'),true);return;}
   if(!validDay(entry.date)||entry.date<ctx.input().birth.date){notice(L('Datoen ligger uden for livslinjen.','This date is outside the lifeline.'),true);return;}
   const existing=state.events.find(e=>e.date===entry.date&&e.label===entry.label);
   const event=existing||{id:crypto.randomUUID(),...entry,note:entry.note.slice(0,4000)};
   if(!existing)state.events.push(event);state.selectedEvent=event.id;state.active='life';lifeResult=null;open();
  }});
 }
 function starSvg(data){
  const NS='http://www.w3.org/2000/svg';
  const el=(tag,attrs={},text)=>{const e=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))e.setAttribute(k,v);if(text!=null)e.textContent=text;return e;};
  const svg=el('svg',{viewBox:'0 0 540 540',xmlns:NS,role:'group','aria-label':L('Dine fem Venus Star Points. Vælg et punkt.','Your five Venus Star Points. Select a point.')});
  const add=(tag,attrs,text)=>{const e=el(tag,attrs,text);svg.append(e);return e;};
  const main=data.points[2];const xy=(lon,r)=>{const a=(-90-lon+main.longitude)*Math.PI/180;return [270+r*Math.cos(a),270+r*Math.sin(a)];};
  add('title',{},L('Venusstjernen — fem beregnede konjunktioner','The Venus star — five calculated conjunctions'));
  add('rect',{width:540,height:540,fill:'#fffdf8'});
  for(const [r,color] of [[253,'#d7c69c'],[247,'#e9dfc9'],[211,'#ddd0b4'],[178,'#e6dcc7']])add('circle',{cx:270,cy:270,r,fill:'none',stroke:color,'stroke-width':1});
  for(let i=0;i<120;i++){const [x1,y1]=xy(i*3,i%10===0?239:244),[x2,y2]=xy(i*3,247);add('line',{x1,y1,x2,y2,stroke:'#b7a16b','stroke-width':i%10===0?1:.5});}
  for(let i=0;i<12;i++){const [x,y]=xy(i*30+15,229);add('text',{x,y,'text-anchor':'middle','dominant-baseline':'middle','font-size':21,fill:['#9e7053','#788366','#8c718d','#67838b'][i%4]},glyphs[i]+'\uFE0E');}
  const sorted=[...data.points].sort((a,b)=>a.longitude-b.longitude);
  add('polygon',{points:[0,2,4,1,3].map(i=>xy(sorted[i].longitude,178).join(',')).join(' '),fill:'#b59a5010',stroke:'#b1954b','stroke-width':1.6,'stroke-linejoin':'round'});
  add('circle',{cx:270,cy:270,r:43,fill:'#fffdf8',stroke:'#ddcea9','stroke-width':.8});
  add('text',{x:270,y:275,'text-anchor':'middle','font-size':38,fill:'#a28a45'},'♀');
  add('text',{x:270,y:335,'text-anchor':'middle','font-size':9,'letter-spacing':3,fill:'#8f7b4c'},'V E N U S');
  data.points.forEach((p,i)=>{
   const selected=i===state.selectedStar,[x,y]=xy(p.longitude,178),[tx,ty]=xy(p.longitude,197);
   const g=add('g',{role:'button',tabindex:0,'data-star-point':i,'aria-pressed':String(selected),'aria-label':`${i===2?L('Dit Venus Star Point','Your Venus Star Point'):L('Støttepunkt','Supporting point')+' '+(i+1)} · ${positionText(p.longitude)} · ${day(p.utc)}`});
   g.append(el('circle',{cx:x,cy:y,r:selected?17:12,fill:selected?'#8b7331':'#fffdf8',stroke:'#ac914e','stroke-width':1.4}),el('text',{x,y:y+4,'text-anchor':'middle','font-size':12,fill:selected?'#fffdf8':'#8b7331'},i===2?'✧':String(i+1)));
   if(p.personal)g.append(el('circle',{cx:x,cy:y,r:22,fill:'none',stroke:'#b8a069','stroke-dasharray':'1 4'}));
   add('text',{x:tx,y:ty+4,'text-anchor':'middle','font-size':11,fill:'#7d6845'},positionText(p.longitude).split(' ')[0]);
   g.onclick=()=>{flush();state.selectedStar=i;renderVenus(data);q('venus-drawing').querySelector(`[data-star-point="${i}"]`)?.focus();};
   g.onkeydown=e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();g.onclick();}};
  });
  return svg;
 }
 function renderVenus(data){
  const p=data.points[state.selectedStar],personal=p.personal,echo=data.rhythm[Math.min(selectedRhythm,data.rhythm.length-1)];
  const cycle=p.retrograde?L('Retrograd konjunktion · indre passage','Retrograde conjunction · inferior'):L('Direkte konjunktion · ydre passage','Direct conjunction · superior');
  q('atelier-panel').innerHTML=`<div class="atelier-card venus-card"><div class="atelier-card-head"><div><span class="eyebrow">${L('VENUS · VÆRDIER · RELATIONER','VENUS · VALUES · RELATIONSHIPS')}</span><h3>${L('Din stjerne, dine rytmer','Your star, your rhythms')}</h3></div><button type="button" id="venus-svg" class="quiet">${L('Hent stjernen','Download star')} ↓</button></div>
   ${data.ambiguity.length?`<div class="atelier-caution">${L('Dit usikre fødselsinterval rummer en Sol–Venus-konjunktion. Punktet nedenfor bygger på det foreløbige tidspunkt. De mulige personlige punkter er:','Your uncertain birth interval contains a Sun–Venus conjunction. The display uses the nominal time. Possible personal points are:')} ${data.ambiguity.map(p=>positionText(p.longitude)+' ('+day(p.utc)+')').join(' / ')}.</div>`:''}
   <div class="venus-main"><div id="venus-drawing" class="venus-drawing"></div><div class="venus-reading"><span class="atelier-kicker">${personal?L('DIT PERSONLIGE PUNKT','YOUR PERSONAL POINT'):L('DET VALGTE STØTTEPUNKT','SELECTED SUPPORTING POINT')}</span><h4>${positionText(p.longitude)}</h4><span class="atelier-cycle">${p.retrograde?'☀':'☽'} ${starName(p.star)}</span><p class="atelier-muted">${cycle}<br>${dateText(p.utc)}${p.house?'<br>'+L('I fødselshoroskopets hus ','In natal house ')+p.house:''}</p><div class="atelier-rule"></div><h5>${L('Forbindelser til dit horoskop','Contacts with your chart')}</h5>${contacts(p.aspects,4)}<p class="atelier-fine">${L('Venus ved fødslen','Venus at birth')}: ${starName(data.natal_star)} · ${positionText(data.natal_venus.longitude)}.<br>${L('Cyklustypen ovenfor hører til konjunktionen; fødselsfasen vises særskilt.','The cycle type above belongs to the conjunction; the birth phase is shown separately.')}</p></div></div>
   <div class="venus-points">${data.points.map((p,i)=>`<button type="button" class="venus-point ${state.selectedStar===i?'active':''}" data-select-star="${i}" aria-pressed="${state.selectedStar===i}"><span>${i===2?'✧ '+L('DIT PUNKT','YOUR POINT'):String(i+1).padStart(2,'0')+' · '+(i<2?L('FØR','BEFORE'):L('EFTER','AFTER'))}</span><strong>${positionText(p.longitude)}</strong><small>${day(p.utc)}</small></button>`).join('')}</div>
   <p class="atelier-caption">${L('Tre konjunktioner før fødslen og to efter. Punkternes placeringer er beregnede; linjerne forbinder dem som en stjernefigur.','Three conjunctions before birth and two after. Point positions are calculated; the lines connect them into a star figure.')}</p>
   <section class="venus-rhythm"><div class="atelier-section-title"><div><span class="eyebrow">${L('4 & 8 ÅRS RYTMER','4 & 8 YEAR RHYTHMS')}</span><h4>${L('Genbesøg en periode','Revisit a period')}</h4></div><label>${L('Vis frem til','Show up to')}<select id="venus-horizon">${[40,80,120].map(n=>option(n,n+' '+L('år','years'),state.venusHorizon)).join('')}</select></label></div><p class="atelier-muted">${L('Vælg en beregnet konjunktion og sammenhold den med dine egne oplevelser. Årstallet angiver cyklens afstand fra dit Venus Star Point.','Choose a calculated conjunction and compare it with your own experiences. Years indicate the cycle’s distance from your Venus Star Point.')}</p>
   <div class="rhythm-track">${data.rhythm.map((p,i)=>`<button type="button" data-rhythm="${i}" class="rhythm-point ${i===selectedRhythm?'active':''}" aria-pressed="${i===selectedRhythm}"><span>${p.cycle_years===0?L('UDGANGSPUNKT','ORIGIN'):'+'+p.cycle_years+' '+L('ÅR','YEARS')}</span><b>${new Date(p.utc).getUTCFullYear()}</b><small>${positionText(p.longitude)}</small></button>`).join('')}</div>
   <div class="rhythm-detail"><div><strong>${dateText(echo.utc)}</strong><p>${starName(echo.star)} · ${positionText(echo.longitude)}${echo.cycle_years?' · '+L('Alder ca. ','Age approx. ')+echo.age_years.toFixed(1):''}</p></div>${echo.cycle_years?`<button type="button" id="rhythm-to-life">${L('Føj til livslinjen','Add to lifeline')} ↗</button>`:''}</div></section>
   <div class="atelier-writing">${note('venus',L('Hvad vender tilbage i dit liv?','What returns in your life?'),L('Se efter temaer i relationer, værdier eller kreativitet. Hvad genkender du — og hvad passer ikke?','Consider themes in relationships, values or creativity. What resonates — and what does not?'))}</div>
   <details class="atelier-method"><summary>${L('Om beregningen og kilderne','Calculation and sources')}</summary><p>${L('Dit punkt er den seneste Sol–Venus-konjunktion ved eller før fødslen. Både direkte og retrograde konjunktioner indgår. Rytmerne er præcist beregnede konjunktioner nær intervaller på fire år, ikke kalenderårsdage. Der vises datoer frem til 2099.','Your point is the last Sun–Venus conjunction at or before birth. Direct and retrograde conjunctions are included. Rhythms are calculated conjunctions near four-year intervals, not calendar anniversaries. Dates stop before 2100.')}</p><p>${L('Tropisk, geocentrisk længde · Swiss Ephemeris · tidspunkter i UTC. Ved ukendt tid bruges lokal middag som foreløbigt referencepunkt; huse udelades.','Tropical, geocentric longitude · Swiss Ephemeris · times in UTC. Unknown birth time uses local noon provisionally; houses are omitted.')}</p><a href="https://sophiavenus.com/how-do-we-find-and-analysis-our-vsp/" target="_blank" rel="noopener">${L('Guttmans offentlige metodebeskrivelse','Guttman’s public method description')} ↗</a></details></div>`;
  q('venus-drawing').append(starSvg(data));
  root.querySelectorAll('[data-select-star]').forEach(b=>b.onclick=()=>{flush();state.selectedStar=Number(b.dataset.selectStar);renderVenus(data);q('atelier-panel').querySelector(`[data-select-star="${state.selectedStar}"]`).focus();});
  root.querySelectorAll('[data-rhythm]').forEach(b=>b.onclick=()=>{flush();selectedRhythm=Number(b.dataset.rhythm);renderVenus(data);root.querySelector(`[data-rhythm="${selectedRhythm}"]`).focus();});
  q('venus-horizon').onchange=()=>{flush();state.venusHorizon=Number(q('venus-horizon').value);selectedRhythm=0;open();};
  q('rhythm-to-life')?.addEventListener('click',()=>{
   if(state.events.length>=40){notice(L('Der er plads til 40 begivenheder.','Up to 40 events are supported.'),true);return;}
   const label='Venus · '+echo.cycle_years+'-'+L('årsrytme','year rhythm'),date=echo.utc.slice(0,10);
   const existing=state.events.find(e=>e.date===date&&e.label===label);
   const event=existing||{id:crypto.randomUUID(),date,label,note:''};
   if(!existing)state.events.push(event);flush();state.selectedEvent=event.id;state.active='life';lifeResult=null;open();
  });
  q('venus-svg').onclick=()=>{const svg=starSvg(data);const meta=document.createElementNS('http://www.w3.org/2000/svg','metadata');meta.textContent=JSON.stringify({birth:data.birth,settings:data.settings,points:data.points,method:data.method,sources:data.sources});svg.prepend(meta);ctx.download(new XMLSerializer().serializeToString(svg),'venus-star-point.svg','image/svg+xml');};
  bindNotes();
 }
 function renderNodes(data){
  const focus=data.axis.flatMap(a=>[a.point.id,a.ruler.id]);
  q('atelier-panel').innerHTML=`<div class="atelier-card nodes-card"><div class="atelier-card-head"><div><span class="eyebrow">${L('MÅNEKNUDER · HERSKERE · FORBINDELSER','LUNAR NODES · RULERS · CONNECTIONS')}</span><h3>${L('Fra det velkendte til det mulige','From the familiar to the possible')}</h3></div></div>
   <p class="atelier-lead">${L('Se knudeaksen som en indgang til din egen tydning. Følg først knuderne, derefter deres herskere.','Use the nodal axis as a starting point for your own reading. Follow the nodes, then their rulers.')}</p>
   <div class="node-axis">${data.axis.map((a,i)=>`<article class="node-card ${i?'north':'south'}"><span class="node-symbol" aria-hidden="true">${i?'☊':'☋'}</span><div class="atelier-kicker">${i?L('NORDKNUDEN · DET MULIGE','NORTH NODE · POSSIBILITY'):L('SYDKNUDEN · DET VELKENDTE','SOUTH NODE · FAMILIARITY')}</div><h4>${positionText(a.point.longitude)}</h4><p>${a.point.house?L('Hus ','House ')+a.point.house:L('Hus udeladt ved ukendt tid','House omitted for unknown time')}</p><div class="node-ruler"><span>${L('Hersker','Ruler')}</span><strong>${bodyName(a.ruler.id)}</strong><small>${positionText(a.ruler.longitude)}${a.ruler.house?' · '+L('hus ','house ')+a.ruler.house:''}</small></div></article>`).join('<span class="node-bridge" aria-hidden="true">⟷</span>')}</div>
   <div class="node-study"><div><div id="node-wheel" class="node-wheel"></div><button type="button" id="node-whole" class="quiet">${showAllNodes?L('Fremhæv knuder og herskere','Highlight nodes and rulers'):L('Vis alle forbindelser','Show all connections')}</button><p class="atelier-caption">${data.settings.node==='true'?L('Sand knude','True node'):L('Middelknude','Mean node')} · ${data.settings.ruler_mode==='traditional'?L('Traditionelle herskere','Traditional rulers'):L('Moderne herskere','Modern rulers')} · ${data.chart.calculation.houses}</p></div><div class="node-links">${data.axis.map(a=>`<section><h5>${bodyName(a.point.id)} · ${L('forbindelser','contacts')}</h5>${contacts(a.aspects,4)}<details class="atelier-more"><summary>${L('Følg herskeren','Follow the ruler')}: ${bodyName(a.ruler.id)}</summary><p class="dispositor-chain">${a.ruler.dispositor_chain.map(bodyName).join(' → ')}</p>${contacts(a.ruler_aspects,5)}</details></section>`).join('')}</div></div>
   ${data.chart.birth.confidence!=='exact'?`<p class="atelier-caution">${L('Positioner og husplaceringer følger fødselstidens angivne usikkerhed.','Positions and house placements follow the stated birth-time uncertainty.')}</p>`:''}
   <div class="atelier-writing node-reflections">${note('south',L('Det jeg allerede kender','What I already know'),L('Hvilke erfaringer, ressourcer og gentagelser lægger du mærke til?','Which experiences, resources and repetitions do you notice?'))}${note('north',L('Det jeg vil udforske','What I want to explore'),L('Hvilke muligheder giver mening for dig at afprøve?','Which possibilities make sense for you to explore?'))}${note('bridge',L('Min samlede læsning af aksen','My reading of the whole axis'),L('Hvordan spiller knuderne, husene og deres herskere sammen?','How do the nodes, houses and their rulers interact?'))}</div>
   <details class="atelier-method"><summary>${L('Om visningen','About this view')}</summary><p>${L('Værkstedet medtager begge knuder og Solen–Pluto, så herskerne altid kan undersøges. Det følger dine valgte huse, knudetype, orbis og herskerskaber. Refleksionsspørgsmålene er lavet til dette værksted med inspiration fra kursusbeskrivelsen.','The workshop includes both nodes and Sun–Pluto so that rulers can always be explored. It follows your selected houses, node type, orbs and rulerships. Reflection prompts were created for this workspace from the course description.')}</p></details></div>`;
  q('node-wheel').append(wheel([data.chart],{visibility:{signs:true,houses:true,aspects:true},bodyName,positionText,title:L('Måneknuder og deres herskere','Lunar nodes and their rulers'),school:'institut',focus:showAllNodes?'':focus}));
  q('node-whole').onclick=()=>{flush();showAllNodes=!showAllNodes;renderNodes(data);};bindNotes();
 }
 function renderLife(){
  const input=current(),birth=input.birth;if(birth.confidence==='unknown')state.shift=0;
  const sorted=[...state.events].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id));
  if(!sorted.some(e=>e.id===state.selectedEvent))state.selectedEvent=sorted[0]?.id||'';
  const selected=sorted.find(e=>e.id===state.selectedEvent),edit=state.events.find(e=>e.id===editing);
  q('atelier-panel').innerHTML=`<div class="atelier-card life-card"><div class="atelier-card-head"><div><span class="eyebrow">${L('LIVSBEGIVENHEDER · TRANSITTER · PROGRESSIONER','LIFE EVENTS · TRANSITS · PROGRESSIONS')}</span><h3>${L('Dit liv, set i sammenhæng','Your life, seen in context')}</h3></div><span class="atelier-count">${state.events.length} / 40</span></div>
   <p class="atelier-lead">${L('Saml betydningsfulde datoer. Undersøg horoskopets bevægelser på dagen, og lad dine egne erfaringer være udgangspunktet.','Collect meaningful dates. Explore the chart’s movements on each day, starting with your own experience.')}</p>
   <form id="life-form" class="life-entry"><label>${L('Dato','Date')}<input id="life-date" type="date" min="${esc(birth.date)}" max="2099-12-31" value="${esc(edit?.date||'')}" required></label><label class="life-name">${L('Begivenhed','Event')}<input id="life-label" maxlength="120" value="${esc(edit?.label||'')}" placeholder="${L('Fx flytning, møde eller nyt arbejde','e.g. a move, meeting or new work')}" required></label><button type="submit" class="primary">${edit?L('Gem ændring','Save change'):L('Tilføj dato','Add date')} +</button>${edit?`<button type="button" id="life-cancel">${L('Annullér','Cancel')}</button>`:''}</form>
   ${removed?`<div class="life-undo">${L('Begivenheden er fjernet.','Event removed.')} <button type="button" id="life-undo">${L('Fortryd','Undo')}</button></div>`:''}
   ${sorted.length?`<div class="life-map" aria-label="${L('Livslinjens tidsoversigt','Lifeline overview')}"><div class="life-map-track"><span class="life-origin" style="left:8%">${birth.date.slice(0,4)}</span>${timelinePositions(sorted,birth.date).map(e=>`<button type="button" data-life-dot="${e.id}" style="left:${e.percent}%" class="life-dot ${e.id===state.selectedEvent?'active':''}" aria-label="${esc(day(e.date)+' · '+e.label)}" title="${esc(day(e.date)+' · '+e.label)}"></button>`).join('')}<span class="life-end">${sorted.at(-1).date.slice(0,4)}</span></div><span class="atelier-caption">${L('Afstandene følger tiden fra fødslen. Vælg en dato på linjen eller i listen.','Spacing follows time since birth. Choose a date on the line or in the list.')}</span></div>
   <div class="life-workspace"><div class="life-events">${sorted.map(e=>`<button type="button" data-life-event="${e.id}" class="life-event ${e.id===state.selectedEvent?'active':''}" aria-pressed="${e.id===state.selectedEvent}"><time datetime="${e.date}">${day(e.date)}</time><strong>${esc(e.label)}</strong></button>`).join('')}</div><article class="life-detail"><div class="life-selected-head"><div class="eyebrow">${day(selected.date)}</div><h4>${esc(selected.label)}</h4><div class="life-edit-actions"><button type="button" id="life-edit" class="quiet">${L('Redigér','Edit')}</button><button type="button" id="life-remove" class="quiet">${L('Fjern','Remove')}</button></div></div><label class="atelier-reflection">${L('Mine iagttagelser','My observations')}<textarea id="life-note" maxlength="4000" rows="3" placeholder="${L('Hvad skete der, og hvad betød det for dig?','What happened, and what did it mean to you?')}">${esc(selected.note)}</textarea></label><div id="life-contacts"></div></article></div>`:`<div class="atelier-empty life-empty"><span>◷</span><h4>${L('En livslinje begynder med én dato','A lifeline starts with one date')}</h4><p>${L('Tilføj din første begivenhed ovenfor — eller hent en Venus-rytme fra stjerneværkstedet.','Add your first event above — or bring in a Venus rhythm from the star workshop.')}</p></div>`}
   <div class="life-calculations"><div class="atelier-section-title"><div><span class="eyebrow">${L('SAMMENHOLD MED HOROSKOPET','COMPARE WITH THE CHART')}</span><h4>${L('Undersøg bevægelserne','Explore the movements')}</h4></div></div><div class="life-controls"><label>${L('Vis','Show')}<select id="life-method">${option('both',L('Transitter + progressioner','Transits + progressions'),state.method)}${option('transits',L('Transitter','Transits'),state.method)}${option('progressed',L('Progressioner','Progressions'),state.method)}</select></label><label>${L('Maks. orbis','Max. orb')}<input id="life-orb" type="number" min="0.1" max="5" step="0.1" value="${state.orb}"></label><label class="life-focus-label">${L('Fokus','Focus')}<select id="life-focus">${option('personal',L('Planeter & akser','Planets & angles'),state.focus)}${option('all',L('Alle valgte punkter','All selected points'),state.focus)}</select></label><button type="button" class="primary" id="life-calculate" ${!sorted.length?'disabled':''}>${L('Beregn livslinjen','Calculate lifeline')} ↗</button></div><details class="life-compare"><summary>${L('Afprøv en anden fødselstid','Try another birth time')}</summary><p>${L('Originalen bevares. Sammenlign den med én kandidat, højst tre timer tidligere eller senere.','The original is preserved. Compare it with one candidate, up to three hours earlier or later.')}</p><label>${L('Forskydning i minutter','Shift in minutes')}<input id="life-shift" type="number" min="-180" max="180" step="0.0166666667" value="${state.shift}" ${birth.confidence==='unknown'?'disabled':''}></label>${birth.confidence==='unknown'?`<small>${L('En tidskandidat kræver et angivet fødselstidspunkt.','A time candidate needs a stated birth time.')}</small>`:''}</details><details class="life-scope"><summary>${L('Hvilke forbindelser vises?','Which contacts are shown?')}</summary><p>${L('Planeter & akser: transitter fra Solen–Pluto og progressioner fra Solen–Mars samt AC/MC, til fødselshoroskopets Sol–Pluto og AC/MC. Alle valgte punkter medtager også knuder og småplaneter. Dine valg af planeter og akser i lærerindstillingerne gælder fortsat.','Planets & angles: transits from Sun–Pluto and progressions from Sun–Mars plus AC/MC, to natal Sun–Pluto and AC/MC. All selected points also includes nodes and minor bodies. Your teacher settings for included bodies and angles still apply.')}</p><p>${L('Sekundære progressioner: ét efemeridedøgn pr. 365,2422 levede døgn. Aksemetoden er ','Secondary progressions: one ephemeris day per 365.2422 elapsed days. The angle method is ')}${esc(axisName(input.settings.progression_method,L('da','en')))}${L(' i rektascension, med fødestedets breddegrad.',' in right ascension, at the birth latitude.')}</p></details><p class="atelier-fine">${L('Dagsbilleder beregnes kl. 12 UTC. De viser aspekter på tidspunktet; præcise passager findes i transitdagbogen.','Daily snapshots are calculated at noon UTC. They show aspects at that instant; use the transit diary for exact passages.')} ${birth.confidence==='unknown'?L('Ved ukendt fødselstid vises transitter uden fødselsakser; progressioner udelades.','Unknown birth time shows transits without natal angles; progressions are omitted.'):birth.confidence==='approximate'?L('Akser og progressioner bygger på dit foreløbige fødselstidspunkt.','Angles and progressions use your provisional birth time.'):''}</p></div></div>`;
  q('life-form').onsubmit=e=>{e.preventDefault();flush();const date=q('life-date').value,label=q('life-label').value.trim();if(!validDay(date)||date<birth.date||!label){notice(L('Vælg en gyldig dato efter fødslen og giv begivenheden et navn.','Choose a valid date after birth and name the event.'),true);return;}if(!edit&&state.events.length>=40){notice(L('Der er plads til 40 begivenheder.','Up to 40 events are supported.'),true);return;}const event=edit||{id:crypto.randomUUID(),note:''};Object.assign(event,{date,label});if(!edit)state.events.push(event);flush();state.selectedEvent=event.id;editing=null;lifeResult=null;notice('');renderLife();};
  q('life-cancel')?.addEventListener('click',()=>{editing=null;renderLife();});
  const select=id=>{flush();state.selectedEvent=id;editing=null;renderLife();};
  root.querySelectorAll('[data-life-event]').forEach(b=>b.onclick=()=>select(b.dataset.lifeEvent));root.querySelectorAll('[data-life-dot]').forEach(b=>b.onclick=()=>select(b.dataset.lifeDot));
  if(selected){q('life-note').oninput=()=>selected.note=q('life-note').value;q('life-edit').onclick=()=>{editing=selected.id;renderLife();q('life-label').focus();};q('life-remove').onclick=()=>{removed={...selected};state.events=state.events.filter(e=>e.id!==selected.id);editing=null;lifeResult=null;renderLife();};}
  q('life-undo')?.addEventListener('click',()=>{if(state.events.length>=40){notice(L('Fjern en anden begivenhed før du gendanner.','Remove another event before restoring.'),true);return;}state.events.push(removed);state.selectedEvent=removed.id;removed=null;lifeResult=null;renderLife();});
  for(const [id,key] of [['life-method','method'],['life-focus','focus'],['life-orb','orb'],['life-shift','shift']])q(id).oninput=q(id).onchange=()=>{state[key]=['method','focus'].includes(key)?q(id).value:Number(q(id).value);lifeResult=null;renderLifeContacts();};
  q('life-calculate').onclick=calculateLife;renderLifeContacts();
 }
 function renderLifeContacts(){
  const box=q('life-contacts');if(!box)return;
  const event=state.events.find(e=>e.id===state.selectedEvent),row=lifeResult?.events.find(e=>e.date===event.date);
  if(!row){box.innerHTML=`<div class="life-await"><span>✧</span><p>${L('Beregn livslinjen for at se forbindelserne på denne dato.','Calculate the lifeline to see contacts for this date.')}</p></div>`;return;}
  const phase=L(['Nymåne','Tiltagende segl','Første kvarter','Tiltagende måne','Fuldmåne','Aftagende måne','Sidste kvarter','Balsamisk måne'],['New Moon','Crescent','First Quarter','Gibbous','Full Moon','Disseminating','Last Quarter','Balsamic']);
  box.innerHTML=`<div class="life-contact-intro"><span>${L('Alder ca. ','Age approx. ')+Math.max(0,row.age_years).toFixed(1)} · 12:00 UTC</span><button type="button" id="life-open-chart" class="quiet">${L('Åbn dagens horoskop','Open this day’s chart')} ↗</button></div><p class="atelier-fine">T = ${L('transit','transit')} · P = ${L('progression','progression')} → ${L('fødselspunkt','natal point')}. ${L('Sorteret efter orbis.','Sorted by orb.')}</p><div class="life-candidate-grid ${row.candidates.length>1?'comparing':''}">${row.candidates.map(c=>`<section><h5>${c.shift_minutes===0?L('Original fødselstid','Original birth time'):(c.shift_minutes>0?'+':'')+c.shift_minutes+' min'}</h5><p class="atelier-fine">${esc(c.birth.local.replace('T',' '))}</p>${c.ascendant?`<p class="life-angles">AC ${positionText(c.ascendant.longitude)}<br>MC ${positionText(c.midheaven.longitude)}</p>`:''}${c.progression_before_birth?`<p class="atelier-fine">${L('Progression udeladt: kl. 12 UTC ligger før fødslen.','Progression omitted: noon UTC precedes birth.')}</p>`:''}${c.progressed_phase?`<p class="life-phase">☽ ${L('Progressiv månefase','Progressed lunar phase')}: <strong>${phase[c.progressed_phase.index]}</strong></p>`:''}${contacts(c.contacts,6)}</section>`).join('')}</div>`;
  q('life-open-chart').onclick=()=>ctx.openDay(event.date);
 }
 async function calculateLife(){
  const button=q('life-calculate'),token=++serial;
  try{
   flush();const input=current();if(!Number.isFinite(state.orb)||state.orb<=0||state.orb>5||!Number.isFinite(state.shift)||Math.abs(state.shift)>180)throw Error(L('Orbis skal være over 0 og højst 5°. Forskydningen skal være inden for ±180 minutter.','Orb must be above 0 and at most 5°. Shift must be within ±180 minutes.'));
   state.shift=Math.round(state.shift*60)/60;q('life-shift').value=state.shift;button.disabled=true;notice(L('Sammenholder dine datoer med horoskopet …','Comparing your dates with the chart …'));
   const payload={...input,events:[...new Set(state.events.map(e=>e.date))],shift_minutes:state.shift,orb:state.orb,method:state.method,focus:state.focus};
   const data=await ctx.api('/api/school/lifeline',payload);
   if(token!==serial||!root.isConnected||JSON.stringify(ctx.input())!==signature)return;
   // Ignore a response if events or controls were edited while it was running.
   if(JSON.stringify(payload.events)!==JSON.stringify([...new Set(state.events.map(e=>e.date))])||payload.shift_minutes!==state.shift||payload.orb!==state.orb||payload.method!==state.method||payload.focus!==state.focus)return;
   lifeResult=data;notice(L('Livslinjen er beregnet. Vælg en begivenhed for at undersøge dagen.','Lifeline calculated. Choose an event to explore that day.'));renderLifeContacts();
  }catch(e){if(token===serial&&root.isConnected)notice(e.message,true);}finally{if(button.isConnected)button.disabled=false;}
 }
 function printable(){
  const tab=q('atelier-tab-'+state.active);
  return {ready:state.active==='life'||!!loaded,active:state.active,title:tab.querySelector('strong').textContent,
   subtitle:tab.querySelector('small').textContent+(state.active==='loops'&&loaded?' · '+bodyName(loaded.planet)+' · '+({natal:L('Ved fødslen','At birth'),transits:L('Transit','Transit'),progressed:L('Progression','Progression')})[loaded.mode]:''),element:q('atelier-panel'),source:SOURCES[state.active],
   state:structuredClone(state),data:loaded,lifeResult:structuredClone(lifeResult)};
 }
 header();return {open,invalidate,flush,printable};
}
