export function emptyLoops(){return {planet:'mercury',mode:'natal',date:'',cycleDate:'',orb:1.5,selected:5,notes:{}};}
export function emptyWorkshops(){return {version:1,active:'venus',venusHorizon:80,selectedStar:2,reflections:{venus:'',south:'',north:'',bridge:''},events:[],selectedEvent:'',focus:'personal',method:'both',orb:1.5,shift:0,loops:emptyLoops()};}
export function validDay(value){return typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&value>='1500-01-01'&&value<='2099-12-31'&&!Number.isNaN(Date.parse(value+'T12:00:00Z'))&&new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;}
export function validateWorkshops(raw){
 if(raw==null)return emptyWorkshops();
 const fail=()=>{throw Error('Invalid workshop data');};
 if(typeof raw!=='object'||Array.isArray(raw)||raw.version!==1||!['venus','nodes','life','loops'].includes(raw.active)||![40,80,120].includes(raw.venusHorizon)||!Number.isInteger(raw.selectedStar)||raw.selectedStar<0||raw.selectedStar>4||!['both','transits','progressed'].includes(raw.method)||(raw.focus!=null&&!['personal','all'].includes(raw.focus))||!Number.isFinite(raw.orb)||raw.orb<=0||raw.orb>5||!Number.isFinite(raw.shift)||Math.abs(raw.shift)>180||Math.abs(raw.shift*60-Math.round(raw.shift*60))>1e-7)fail();
 if(!raw.reflections||['venus','south','north','bridge'].some(k=>typeof raw.reflections[k]!=='string'||raw.reflections[k].length>8000))fail();
 if(!Array.isArray(raw.events)||raw.events.length>40||raw.events.some(e=>!e||typeof e.id!=='string'||!/^[a-zA-Z0-9-]{1,80}$/.test(e.id)||!validDay(e.date)||typeof e.label!=='string'||!e.label.trim()||e.label.length>120||typeof e.note!=='string'||e.note.length>4000)||new Set(raw.events.map(e=>e.id)).size!==raw.events.length)fail();
 return {version:1,active:raw.active,venusHorizon:raw.venusHorizon,selectedStar:raw.selectedStar,
  reflections:Object.fromEntries(['venus','south','north','bridge'].map(k=>[k,raw.reflections[k]])),
  events:raw.events.map(({id,date,label,note})=>({id,date,label,note})),selectedEvent:raw.events.some(e=>e.id===raw.selectedEvent)?raw.selectedEvent:'',focus:raw.focus||'personal',method:raw.method,orb:raw.orb,shift:raw.shift,loops:validateLoops(raw.loops)};
}
export function validateLoops(raw){
 if(raw==null)return emptyLoops();
 const fail=()=>{throw Error('Invalid loop workshop data');};
 if(typeof raw!=='object'||Array.isArray(raw)||!['mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'].includes(raw.planet)||!['natal','transits','progressed'].includes(raw.mode)||!(raw.date===''||validDay(raw.date))||!(raw.cycleDate===''||validDay(raw.cycleDate))||!Number.isFinite(raw.orb)||raw.orb<=0||raw.orb>1.5||!Number.isInteger(raw.selected)||raw.selected<1||raw.selected>9||!raw.notes||typeof raw.notes!=='object'||Array.isArray(raw.notes)||Object.keys(raw.notes).length>120)fail();
 for(const [k,v] of Object.entries(raw.notes)){const parts=k.split('|');if(parts.length!==3||!['mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'].includes(parts[0])||!/^\d{4}-\d{2}-\d{2}$/.test(parts[1])||!/[1-9]/.test(parts[2])||parts[2].length!==1||typeof v!=='string'||v.length>4000)fail();}
 return {planet:raw.planet,mode:raw.mode,date:raw.date,cycleDate:raw.cycleDate,orb:raw.orb,selected:raw.selected,notes:{...raw.notes}};
}
export function timelinePositions(events,birthDate){
 const dates=[birthDate,...events.map(e=>e.date)].filter(validDay).map(d=>Date.parse(d+'T12:00:00Z'));
 const start=Math.min(...dates),end=Math.max(start+86400000,...dates);
 return events.map(e=>({...e,percent:8+84*(Date.parse(e.date+'T12:00:00Z')-start)/(end-start)}));
}
