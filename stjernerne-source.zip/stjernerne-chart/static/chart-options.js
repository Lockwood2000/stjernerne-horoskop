export const houseLabel=value=>({P:'Placidus',E:'Equal House',R:'Regiomontanus'}[typeof value==='string'?value:value?.calculation?.house_system]||value?.calculation?.houses||'Placidus');
export function techniqueHelp(mode,system){
  if(mode==='solar')return "Solretur beregnes ved Solens faktiske tilbagevenden til fødselssolens tropiske længde. Vælg året og dit opholdssted ved returen; afkrydsningen vælger udtrykkeligt fødestedet. Stedet og det valgte hussystem bestemmer akser og huse.";
  if(mode==='solar_arc')return "Direkte solar arc: 1 efemeridedag efter fødslen = 1 leveår på 365,2422 dage. Buen er den sekundært progredierede Sols tropiske længde minus fødselssolens længde. Alle fødselsplaneter, husspidser og AC/MC flyttes med samme ekliptiske bue. Dette er symbolske direktioner, ikke himlen på måldatoen; der bruges ikke en fast 1°/år-nøgle eller Naibod/Kündig til akserne. Fødestedets oprindelige huse bruges som grundlag.";
  return "Direkte sekundær progression: 1 dag efter fødslen = 1 leveår på 365,2422 dage. Akser og "+houseLabel(system)+"-huse beregnes med den valgte aksenøgle i rektascension. Mål-tidspunkt angives i UTC; fødestedets koordinater bevares.";
}
export function arcStatus(data){return 'Solar arc · '+data.technique.target.local.slice(0,10)+' · '+data.technique.arc_degrees.toFixed(6)+'° · '+houseLabel(data);}
