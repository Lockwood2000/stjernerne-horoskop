import {renderWheel,dms} from './wheel.js';
const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
const offset=n=>(n>0?'+':'')+n+' min.';
const stamp=c=>c.birth.local.slice(0,19).replace('T',' kl. ')+' · UTC'+c.birth.local.slice(19);
const names={jupiter:'Jupiter',saturn:'Saturn',uranus:'Uranus',neptune:'Neptun',pluto:'Pluto',ascendant:'AC',midheaven:'MC'};
const delta=(a,b)=>(a-b+540)%360-180;
export function createRectification(context,render,setTab){
  let active=false,current=null,shift=0,cache=new Map(),candidates=[],events=[],comparison=null,overlay=null,serial=0,controller=null,timer=null;
  const err=message=>{$('rect-error').textContent=message;$('rect-error').hidden=!message;};
  function stop(){if($('rect-compare').disabled)$('rect-comparison-status').textContent='Sammenligningen blev afbrudt. Tryk Sammenlign for at prøve igen.';shift=current?.rectification?.shift_minutes||0;active=false;serial++;controller?.abort();clearTimeout(timer);$('rect-compare').disabled=false;}
  function reset(){stop();current=null;shift=0;cache.clear();candidates=[];events=[];comparison=null;overlay=null;$('rect-shift').value='0';$('rect-shift-label').textContent='0 min.';$('rect-event-form').reset();$('rect-comparison').replaceChildren();$('rect-comparison-status').textContent='';err('');}
  function invalidateComparison(){comparison=null;$('rect-comparison').replaceChildren();$('rect-comparison-status').textContent='Kandidater eller begivenheder er ændret. Sammenlign igen.';overlay=null;}
  function draw(){
    if(!current||!active||!cache.has(shift))return;
    render({...current,display_title:'Fødselstidskorrektion · '+offset(shift)});
    $('rect-quick-time').textContent=current.birth.local.slice(0,19).replace('T',' kl. ')+' · '+offset(shift);
    $('chart-label').textContent='TIDSKANDIDAT · ORIGINALEN ER BEVARET';
    if(overlay){$('wheel').replaceChildren(renderWheel(current,overlay.event,overlay.aspect));$('transit-caption').hidden=false;$('transit-caption').textContent=`${overlay.label} · ${overlay.event.date} kl. 12 UTC · langsomme transitter til kandidatens AC/MC`+(overlay.aspect?` — ${names[overlay.aspect.transit]} ${overlay.aspect.label.toLowerCase()} ${names[overlay.aspect.natal]} · orb ${dms(overlay.aspect.orb).full}`:' · ingen aspekter inden for 2°');}
    else $('transit-caption').hidden=true;
    const base=context().chart;
    $('rect-changes').replaceChildren(...['ascendant','midheaven'].map(k=>{const p=el('p');p.append(el('strong',names[k]+' · '+dms(current[k].longitude).full+' '+dms(current[k].longitude).sign),el('span','Ændring fra original: '+delta(current[k].longitude,base[k].longitude).toFixed(2)+'°'));return p;}));
    const changed=current.planets.filter(p=>p.house!==base.planets.find(b=>b.id===p.id)?.house);
    $('rect-status').textContent=`Viser ${stamp(current)} · ${offset(shift)} fra originalen.`+(changed.length?' Nye huse: '+changed.map(p=>p.name+' → '+p.house).join(', ')+'.':' Ingen planeter har skiftet hus.');
    $('rect-save').disabled=candidates.includes(shift)||candidates.length>=5;$('download').disabled=false;
  }
  function candidateList(){
    $('rect-candidates').replaceChildren(...candidates.map(n=>{const c=cache.get(n),row=el('div',undefined,'rect-candidate'),text=el('span',(n===0?'Original':offset(n))+' · '+stamp(c));text.append(el('small','AC '+dms(c.ascendant.longitude).short+' '+dms(c.ascendant.longitude).sign+' · MC '+dms(c.midheaven.longitude).short+' '+dms(c.midheaven.longitude).sign));const show=el('button','Vis');show.type='button';show.setAttribute('aria-label','Vis kandidat '+offset(n));show.addEventListener('click',()=>{select(n);setTab($('tab-wheel'));});row.append(text,show);if(n!==0){const remove=el('button','Fjern');remove.type='button';remove.setAttribute('aria-label','Fjern kandidat '+offset(n));remove.addEventListener('click',()=>{candidates=candidates.filter(x=>x!==n);cancelComparison();invalidateComparison();candidateList();draw();});row.append(remove);}return row;}));
  }
  function eventList(){
    $('rect-events').replaceChildren(...events.map((e,i)=>{const li=el('li',e.label+' · '+e.date),remove=el('button','Fjern');remove.type='button';remove.setAttribute('aria-label','Fjern begivenhed '+e.label);remove.addEventListener('click',()=>{events.splice(i,1);cancelComparison();invalidateComparison();eventList();draw();});li.append(remove);return li;}));
  }
  function cancelComparison(){if($('rect-compare').disabled)$('rect-comparison-status').textContent='Sammenligningen blev afbrudt. Tryk Sammenlign for at prøve igen.';serial++;controller?.abort();clearTimeout(timer);$('rect-compare').disabled=false;}
  function activate(){
    const ctx=context();active=true;err('');$('rect-event-date').max=$('date').max;
    if(!ctx.valid){err('Beregn først dit fødselshoroskop med de aktuelle oplysninger.');$('rect-save').disabled=true;return;}
    if(!current){current=ctx.chart;cache.set(0,current);candidates=[0];shift=0;}
    $('rect-original').textContent='Original: '+stamp(ctx.chart);$('rect-shift').value=String(shift);$('rect-shift-label').textContent=offset(shift);candidateList();eventList();draw();
  }
  async function select(value,debounce=false){
    const ctx=context();if(!ctx.valid){err('Beregn først fødselshoroskopet.');return;}
    if(!current)activate();
    cancelComparison();const generation=serial;
    shift=Math.max(-180,Math.min(180,Math.round(value)));overlay=null;
    $('rect-shift').value=String(shift);$('rect-shift-label').textContent=offset(shift);err('');
    if(cache.has(shift)){current=cache.get(shift);draw();return;}
    $('rect-quick-time').textContent='Beregner '+offset(shift)+' …';$('rect-save').disabled=true;$('download').disabled=true;$('rect-status').textContent='Beregner '+offset(shift)+' … Hjulet viser stadig det senest beregnede tidspunkt.';
    const run=async()=>{
      const abort=new AbortController();controller=abort;const timeout=setTimeout(()=>abort.abort(),15000);
      try{
        const response=await fetch('/api/rectify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:ctx.payload,shift_minutes:shift}),signal:abort.signal});const data=await response.json();if(generation!==serial||!active)return;
        if(!response.ok)throw Error(data.error?.message||'Kandidaten kunne ikke beregnes.');
        current=data;cache.set(shift,data);draw();
      }catch(error){if(generation===serial&&active){$('rect-quick-time').textContent='Senest vist: '+stamp(current);err(error.name==='AbortError'?'Serveren svarede ikke i tide. Flyt skyderen for at prøve igen.':error.message);$('rect-status').textContent='Kandidaten kunne ikke beregnes. Hjulet viser fortsat det foregående tidspunkt.';}}
      finally{clearTimeout(timeout);}
    };
    if(debounce)timer=setTimeout(run,300);else await run();
  }
  $('rect-shift').addEventListener('input',()=>select(Number($('rect-shift').value),true));
  for(const b of document.querySelectorAll('[data-shift]'))b.addEventListener('click',()=>select(shift+Number(b.dataset.shift),true));
  $('rect-zero').addEventListener('click',()=>select(0));
  $('rect-save').addEventListener('click',()=>{if(!active||!cache.has(shift)||candidates.includes(shift)||candidates.length>=5)return;cancelComparison();candidates.push(shift);invalidateComparison();candidateList();draw();$('rect-status').textContent+=' Kandidaten er beholdt under Kandidater & begivenheder.';});
  $('rect-event-form').addEventListener('submit',e=>{
    e.preventDefault();const label=$('rect-event-label').value.trim(),date=$('rect-event-date').value;
    if(!label||!date)return;
    if(events.length>=5){$('rect-comparison-status').textContent='Der er plads til fem begivenheder. Fjern én for at tilføje en anden.';return;}
    cancelComparison();events.push({label,date});invalidateComparison();eventList();$('rect-event-form').reset();draw();
  });
  function showComparison(){
    const table=el('table'),caption=el('caption','Kandidater × begivenheder · datoens transitter til AC/MC');table.append(caption);
    const thead=el('thead'),head=el('tr');for(const title of ['Begivenhed',...comparison.charts.map(c=>offset(c.rectification.shift_minutes)+' · '+c.birth.local.slice(11,19))]){const th=el('th',title);th.scope='col';head.append(th);}thead.append(head);table.append(thead);
    const body=el('tbody');comparison.events.forEach((event,i)=>{const tr=el('tr'),th=el('th',events[i].label);th.scope='row';th.append(el('small',event.date));tr.append(th);
      for(const c of event.candidates){const td=el('td');const contacts=c.aspects.length?c.aspects:[null];for(const a of contacts){const b=el('button',a?`${names[a.transit]} ${a.label.toLowerCase()} ${names[a.natal]} · ${dms(a.orb).full}`:'Ingen aspekter ≤ 2° · Vis hjul','transit-link');b.type='button';b.addEventListener('click',()=>{cancelComparison();shift=c.shift_minutes;current=cache.get(shift);$('rect-shift').value=String(shift);$('rect-shift-label').textContent=offset(shift);overlay={event,aspect:a,label:events[i].label};draw();setTab($('tab-wheel'));});td.append(b);}tr.append(td);}body.append(tr);});table.append(body);const wrap=el('div',undefined,'table-wrap');wrap.append(table);$('rect-comparison').replaceChildren(el('p','På smalle skærme kan tabellen rulles vandret.','hint'),wrap);
  }
  $('rect-compare').addEventListener('click',async()=>{
    const ctx=context();if(!ctx.valid||!events.length||!candidates.length){$('rect-comparison-status').textContent='Beregn fødselshoroskopet og tilføj mindst én begivenhed.';return;}
    cancelComparison();const generation=serial,abort=new AbortController();controller=abort;const timeout=setTimeout(()=>abort.abort(),20000);$('rect-compare').disabled=true;$('rect-comparison-status').textContent='Sammenligner …';
    try{
      const response=await fetch('/api/rectify/compare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:ctx.payload,shifts:candidates,events:events.map(e=>e.date)}),signal:abort.signal});const data=await response.json();if(generation!==serial||!active)return;
      if(!response.ok)throw Error(data.error?.message||'Sammenligningen kunne ikke beregnes.');
      comparison=data;for(const c of data.charts)cache.set(c.rectification.shift_minutes,c);showComparison();$('rect-comparison-status').textContent=`${candidates.length} kandidater og ${events.length} begivenheder. Klik på et aspekt for at se det i hjulet. Færre eller tættere aspekter er ikke i sig selv tegn på en mere korrekt fødselstid.`;
    }catch(error){if(generation===serial&&active)$('rect-comparison-status').textContent=error.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':error.message;}
    finally{clearTimeout(timeout);if(generation===serial)$('rect-compare').disabled=false;}
  });
  function snapshot(){return {shifts:candidates.length?[...candidates]:[0],current:current?.rectification?.shift_minutes||0,events:events.map(e=>({...e}))};}
  function restore(saved,charts){reset();for(const c of charts)cache.set(c.rectification?.shift_minutes||0,c);candidates=[...saved.shifts];events=saved.events.map(e=>({...e}));shift=saved.current;current=cache.get(shift)||cache.get(0);candidateList();eventList();$('rect-comparison-status').textContent='Gendannet fra biblioteket. Tryk Sammenlign for at beregne begivenhederne igen.';}
  return {snapshot,restore,activate,stop,reset,draw,get active(){return active;}};
}
