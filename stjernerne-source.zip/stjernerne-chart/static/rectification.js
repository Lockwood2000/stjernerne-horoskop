import {renderWheel,dms} from './wheel.js';
import {formatShift,normalizeShift} from './rectification-time.js';
const $=id=>document.getElementById(id);
const el=(tag,text,cls)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;};
const offset=formatShift;
const stamp=c=>c.birth.local.slice(0,19).replace('T',' kl. ')+' · UTC'+c.birth.local.slice(19);
const names={jupiter:'Jupiter',saturn:'Saturn',uranus:'Uranus',neptune:'Neptun',pluto:'Pluto',ascendant:'AC',midheaven:'MC'};
const delta=(a,b)=>(a-b+540)%360-180;
export function createRectification(context,render,setTab){
  let active=false,current=null,shift=0,cache=new Map(),candidates=[],events=[],comparison=null,overlay=null,serial=0,controller=null,timer=null;
  let kundigSerial=0,kundigAbort=null,kundigData=null,cutTypes=new Map();
  const cutLabel=methods=>(methods||[]).map(m=>m==='kundig'?'Kündig':'Bonatti').join(' + ');
  const rememberCut=item=>{const n=normalizeShift(item.shift_minutes);cutTypes.set(n,[...new Set([...(cutTypes.get(n)||[]),...(item.methods||['kundig'])])].sort((a,b)=>['kundig','bonatti'].indexOf(a)-['kundig','bonatti'].indexOf(b)));};
  function stopKundig(){if($('kundig-find').disabled)$('kundig-status').textContent='Beregningen blev afbrudt. Tryk Find snit for at prøve igen.';kundigSerial++;kundigAbort?.abort();$('kundig-find').disabled=false;}
  const err=message=>{$('rect-error').textContent=message;$('rect-error').hidden=!message;};
  function stop(){stopKundig();if($('rect-compare').disabled)$('rect-comparison-status').textContent='Sammenligningen blev afbrudt. Tryk Sammenlign for at prøve igen.';shift=current?.rectification?.shift_minutes||0;active=false;serial++;controller?.abort();clearTimeout(timer);$('rect-compare').disabled=false;}
  function reset(){stop();kundigData=null;cutTypes.clear();$('cut-mode').value='both';$('kundig-results').replaceChildren();$('kundig-status').textContent='';current=null;shift=0;cache.clear();candidates=[];events=[];comparison=null;overlay=null;$('rect-shift').value='0';$('rect-shift').setAttribute('aria-valuetext','0 min.');$('rect-shift-label').textContent='0 min.';$('rect-event-form').reset();$('rect-method').value='transits';methodHelp();$('rect-comparison').replaceChildren();$('rect-comparison-status').textContent='';err('');}
  function invalidateComparison(){comparison=null;$('rect-comparison').replaceChildren();$('rect-comparison-status').textContent='Kandidater eller begivenheder er ændret. Sammenlign igen.';overlay=null;}
  function draw(){
    if(!current||!active||!cache.has(shift))return;
    render({...current,display_title:'Fødselstidskorrektion · '+offset(shift)});
    $('rect-quick-time').textContent=current.birth.local.slice(0,19).replace('T',' kl. ')+' · '+offset(shift);
    $('chart-label').textContent='TIDSKANDIDAT · ORIGINALEN ER BEVARET';
    if(overlay?.progressed){const p=overlay.progressed;$('wheel').replaceChildren(renderWheel(current,{...p,kind:'progressed',timing:{local:overlay.event.date+' kl. 12 UTC'}}));$('transit-caption').hidden=false;$('transit-caption').textContent=`${overlay.label} · ${overlay.event.date} kl. 12 UTC · Ydre ring: sekundære progressioner med Kündig-akser (P). Indre ring: tidskandidatens fødselshoroskop. Solnøgle ${dms(p.technique.solar_key.degrees_per_year).full} RA pr. år.`;}
    else if(overlay){$('wheel').replaceChildren(renderWheel(current,overlay.event,overlay.aspect));$('transit-caption').hidden=false;$('transit-caption').textContent=`${overlay.label} · ${overlay.event.date} kl. 12 UTC · langsomme transitter til kandidatens AC/MC`+(overlay.aspect?` — ${names[overlay.aspect.transit]} ${overlay.aspect.label.toLowerCase()} ${names[overlay.aspect.natal]} · orb ${dms(overlay.aspect.orb).full}`:' · ingen aspekter inden for 2°');}
    else $('transit-caption').hidden=true;
    const base=context().chart;
    $('rect-changes').replaceChildren(...['ascendant','midheaven'].map(k=>{const p=el('p');p.append(el('strong',names[k]+' · '+dms(current[k].longitude).full+' '+dms(current[k].longitude).sign),el('span','Ændring fra original: '+delta(current[k].longitude,base[k].longitude).toFixed(2)+'°'));return p;}));
    const changed=current.planets.filter(p=>p.house!==base.planets.find(b=>b.id===p.id)?.house);
    $('rect-status').textContent=`Viser ${stamp(current)} · ${offset(shift)} fra originalen.`+(changed.length?' Nye huse: '+changed.map(p=>p.name+' → '+p.house).join(', ')+'.':' Ingen planeter har skiftet hus.');
    $('rect-save').disabled=candidates.includes(shift)||candidates.length>=5;$('download').disabled=false;
  }
  function candidateList(){
    $('rect-candidates').replaceChildren(...candidates.map(n=>{const c=cache.get(n),row=el('div',undefined,'rect-candidate'),text=el('span',(n===0?'Original':offset(n))+' · '+stamp(c));if(cutTypes.has(n))text.append(el('small','Snit: '+cutLabel(cutTypes.get(n))));text.append(el('small','AC '+dms(c.ascendant.longitude).short+' '+dms(c.ascendant.longitude).sign+' · MC '+dms(c.midheaven.longitude).short+' '+dms(c.midheaven.longitude).sign));const show=el('button','Vis');show.type='button';show.setAttribute('aria-label','Vis kandidat '+offset(n));show.addEventListener('click',()=>{select(n);setTab($('tab-wheel'));});row.append(text,show);if(n!==0){const remove=el('button','Fjern');remove.type='button';remove.setAttribute('aria-label','Fjern kandidat '+offset(n));remove.addEventListener('click',()=>{candidates=candidates.filter(x=>x!==n);cutTypes.delete(n);cancelComparison();invalidateComparison();candidateList();draw();});row.append(remove);}return row;}));
    showKundig();
  }
  function eventList(){
    $('rect-events').replaceChildren(...events.map((e,i)=>{const li=el('li',e.label+' · '+e.date),remove=el('button','Fjern');remove.type='button';remove.setAttribute('aria-label','Fjern begivenhed '+e.label);remove.addEventListener('click',()=>{events.splice(i,1);cancelComparison();invalidateComparison();eventList();draw();});li.append(remove);return li;}));
  }
  function cancelComparison(){if($('rect-compare').disabled)$('rect-comparison-status').textContent='Sammenligningen blev afbrudt. Tryk Sammenlign for at prøve igen.';serial++;controller?.abort();clearTimeout(timer);$('rect-compare').disabled=false;}
  function activate(){
    const ctx=context();active=true;err('');$('rect-event-date').max=$('date').max;
    if(!ctx.valid){err('Beregn først dit fødselshoroskop med de aktuelle oplysninger.');$('rect-save').disabled=true;return;}
    if(!current){current=ctx.chart;cache.set(0,current);candidates=[0];shift=0;}
    $('rect-original').textContent='Original: '+stamp(ctx.chart);$('rect-shift').value=String(Math.round(shift*60));$('rect-shift').setAttribute('aria-valuetext',offset(shift));$('rect-shift-label').textContent=offset(shift);candidateList();eventList();draw();
  }
  async function select(value,debounce=false){
    const ctx=context();if(!ctx.valid){err('Beregn først fødselshoroskopet.');return;}
    if(!current)activate();
    cancelComparison();const generation=serial;
    shift=normalizeShift(value);overlay=null;
    $('rect-shift').value=String(Math.round(shift*60));$('rect-shift').setAttribute('aria-valuetext',offset(shift));$('rect-shift-label').textContent=offset(shift);err('');
    if(cache.has(shift)){current=cache.get(shift);draw();return;}
    $('rect-quick-time').textContent='Beregner '+offset(shift)+' …';$('rect-save').disabled=true;$('download').disabled=true;$('rect-status').textContent='Beregner '+offset(shift)+' … Hjulet viser stadig det senest beregnede tidspunkt.';
    const run=async()=>{
      const abort=new AbortController();controller=abort;const timeout=setTimeout(()=>abort.abort(),15000);
      try{
        const response=await fetch('/api/rectify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:ctx.payload,shift_minutes:shift}),signal:abort.signal});const data=await response.json();if(generation!==serial||!active)return;
        if(!response.ok)throw Error(data.error?.message||'Kandidaten kunne ikke beregnes.');
        current=data;cache.set(shift,data);draw();
      }catch(error){if(generation===serial&&active){$('rect-quick-time').textContent='Senest vist: '+stamp(current);err(error.name==='AbortError'?'Serveren svarede ikke i tide. Flyt skyderen for at prøve igen.':error.message);$('rect-status').textContent='Kandidaten kunne ikke beregnes. Hjulet viser fortsat det foregående tidspunkt.';}}
      finally{clearTimeout(timeout);}
    };
    if(debounce)timer=setTimeout(run,300);else await run();
  }
  $('rect-shift').addEventListener('input',()=>select(Number($('rect-shift').value)/60,true));
  for(const b of document.querySelectorAll('[data-shift]'))b.addEventListener('click',()=>select(shift+Number(b.dataset.shift),true));
  $('rect-zero').addEventListener('click',()=>select(0));
  $('rect-save').addEventListener('click',()=>{if(!active||!cache.has(shift)||candidates.includes(shift)||candidates.length>=5)return;cancelComparison();candidates.push(shift);const cut=kundigData?.candidates.find(c=>c.shift_minutes===shift);if(cut)rememberCut(cut);invalidateComparison();candidateList();draw();$('rect-status').textContent+=' Kandidaten er beholdt under Kandidater & begivenheder.';});
  async function useCut(item,keep){
    const ctx=context();
    const value=normalizeShift(item.shift_minutes);
    if(keep&&!candidates.includes(value)&&candidates.length>=5){$('kundig-status').textContent='Der er allerede fem kandidater. Fjern en under Kandidater & begivenheder for at beholde et nyt snit.';return;}
    await select(value);
    if(!active||context().payload!==ctx.payload||!cache.has(value)||shift!==value||(current?.rectification?.shift_minutes||0)!==value)return;
    if(keep&&!candidates.includes(value)){candidates.push(value);rememberCut(item);invalidateComparison();candidateList();draw();}
    $('kundig-status').textContent=keep?'Snittet er beholdt under Kandidater & begivenheder. Gem i Mine horoskoper for at bevare det.':'Hjulet viser nu snittet '+item.local.slice(11,19)+'.';
    if(!keep)setTab($('tab-wheel'));
    showKundig();
  }
  function showKundig(){
    if(!kundigData)return;
    $('kundig-results').replaceChildren(...kundigData.candidates.map(item=>{
      const row=el('article',undefined,'kundig-cut'),text=el('div');
      text.append(el('strong',item.local.slice(11,19)+' · '+offset(item.shift_minutes)),el('span',cutLabel(item.methods||['kundig']),'kundig-nearest cut-'+(item.methods?.length===2?'both':item.methods?.[0]||'kundig')));
      text.append(el('small',item.local.slice(0,10)+' · UTC'+item.local.slice(19)));
      if(item.partners.length)text.append(el('small','Kündig-partnere: '+item.partners.map(p=>p.name).join(' / ')));
      for(const contact of item.bonatti_contacts||[])text.append(el('small','Bonatti: '+contact.name+' på '+contact.axis));
      text.append(el('small','MC '+dms(item.mc.longitude).short+' '+item.mc.sign+' · IC '+dms(item.ic.longitude).short+' '+item.ic.sign));
      if(item.nearest)text.append(el('span','Blandt de tre nærmeste','kundig-nearest'));
      const actions=el('div',undefined,'rect-actions'),show=el('button','Vis i hjulet'),keep=el('button',candidates.includes(item.shift_minutes)?'Beholdt':'Behold kandidat');
      show.type=keep.type='button';show.setAttribute('aria-label','Vis '+cutLabel(item.methods||['kundig'])+'-snit '+item.local.slice(11,19));
      keep.setAttribute('aria-label','Behold '+cutLabel(item.methods||['kundig'])+'-snit '+item.local.slice(11,19));keep.disabled=candidates.includes(item.shift_minutes);
      show.addEventListener('click',()=>useCut(item,false));keep.addEventListener('click',()=>useCut(item,true));
      actions.append(show,keep);row.append(text,actions);return row;
    }));
  }
  $('cut-mode').addEventListener('change',()=>{stopKundig();kundigData=null;$('kundig-results').replaceChildren();$('kundig-status').textContent='Tryk Find snit for at søge med det nye metodevalg. Beholdte kandidater er bevaret.';});
  $('kundig-radius').addEventListener('change',()=>{stopKundig();kundigData=null;$('kundig-results').replaceChildren();$('kundig-status').textContent='Tryk Find snit for at søge i det nye interval.';});
  $('kundig-find').addEventListener('click',async()=>{
    const ctx=context();if(!ctx.valid){$('kundig-status').textContent='Beregn først dit fødselshoroskop med de aktuelle oplysninger.';return;}
    stopKundig();const generation=kundigSerial,abort=new AbortController();kundigAbort=abort;
    const timeout=setTimeout(()=>abort.abort(),20000);$('kundig-find').disabled=true;$('kundig-status').textContent='Beregner snit …';kundigData=null;$('kundig-results').replaceChildren();
    try{
      const response=await fetch('/api/rectify/kundig',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:ctx.payload,radius_minutes:Number($('kundig-radius').value),cut_mode:$('cut-mode').value}),signal:abort.signal});
      const data=await response.json();if(generation!==kundigSerial||!active)return;
      if(!response.ok)throw Error(data.error?.message||'Snittene kunne ikke beregnes.');
      kundigData=data;for(const item of data.candidates)if(candidates.includes(item.shift_minutes))rememberCut(item);candidateList();if(comparison)showComparison();showKundig();$('kundig-status').textContent=data.candidates.length?`${data.candidates.length} tidspunkter · ${data.method.counts.kundig} Kündig-snit · ${data.method.counts.bonatti} Bonatti-snit.${data.method.cut_mode==='both'?' Sammenfald tælles i begge metoder.':''} De tre nærmeste er markeret efter tidsafstand, ikke sandsynlighed.`:'Ingen snit i intervallet. Prøv et større tidsinterval.';
    }catch(error){if(generation===kundigSerial)$('kundig-status').textContent=error.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':error.message;}
    finally{clearTimeout(timeout);if(generation===kundigSerial)$('kundig-find').disabled=false;}
  });
  $('rect-event-form').addEventListener('submit',e=>{
    e.preventDefault();const label=$('rect-event-label').value.trim(),date=$('rect-event-date').value;
    if(!label||!date)return;
    if(events.length>=5){$('rect-comparison-status').textContent='Der er plads til fem begivenheder. Fjern én for at tilføje en anden.';return;}
    cancelComparison();events.push({label,date});invalidateComparison();eventList();$('rect-event-form').reset();draw();
  });
  function methodHelp(){
    $('rect-method-help').textContent=$('rect-method').value==='kundig'
      ?'Sekundære planeter (én dag = ét år) og akser med Kündigs faste individuelle solnøgle i rektascension. Solnøglen bruger den hele zodiakgrad, fødselssolen står i. Viser progressive AC/MC til fødselsplaneter og progressive planeter samt progressive planeter til fødslens AC/MC. Solen–Pluto, de fem hovedaspekter, højst 1° orb. Én prøve kl. 12 UTC; ingen søgning efter eksakte datoer. Dette er ikke en fuld CORREX-analyse.'
      :'Jupiter, Saturn, Uranus, Neptun og Pluto til AC/MC. De fem hovedaspekter, højst 2° orb. Én prøve kl. 12 UTC på hver dato; dette er ikke begivenhedens præcise tidspunkt.';
    $('rect-method-help').textContent+=' Ingen automatisk rangering. Astrologiske sammenfald fastslår ikke din faktiske fødselstid.';
  }
  $('rect-method').addEventListener('change',()=>{cancelComparison();invalidateComparison();methodHelp();draw();});
  $('kundig-use-key').addEventListener('click',()=>{$('rect-method').value='kundig';cancelComparison();invalidateComparison();methodHelp();draw();setTab($('tab-rectify'));});
  methodHelp();
  function showProgressComparison(){
    const table=el('table'),caption=el('caption','Kandidater × begivenheder · Kündigs individuelle solnøgle');table.append(caption);
    const thead=el('thead'),head=el('tr'),first=el('th','Begivenhed');first.scope='col';head.append(first);
    comparison.charts.forEach((c,i)=>{const th=el('th',offset(c.rectification.shift_minutes)+' · '+c.birth.local.slice(11,19));th.scope='col';const k=comparison.events[0].candidates[i].progressed.technique.solar_key;th.append(el('small','Solnøgle '+dms(k.degrees_per_year).full+' RA/år'));if(cutTypes.has(c.rectification.shift_minutes))th.append(el('small',cutLabel(cutTypes.get(c.rectification.shift_minutes))));head.append(th);});thead.append(head);table.append(thead);
    const body=el('tbody');comparison.events.forEach((event,i)=>{const tr=el('tr'),th=el('th',events[i].label);th.scope='row';th.append(el('small',event.date+' · kl. 12 UTC'));tr.append(th);
      for(const c of event.candidates){const td=el('td'),p=c.progressed;
        td.append(el('p','Progressiv AC '+dms(p.ascendant.longitude).full+' '+dms(p.ascendant.longitude).sign),el('p','Progressiv MC '+dms(p.midheaven.longitude).full+' '+dms(p.midheaven.longitude).sign));
        if(!c.aspects.length)td.append(el('p','Ingen akseaspekter inden for 1° orb.'));
        for(const a of c.aspects)td.append(el('p',`P ${a.a_name} ${a.label.toLowerCase()} ${a.target==='natal'?'R':'P'} ${a.b_name} · ${dms(a.orb).full}`));
        const show=el('button','Vis progression i hjulet');show.type='button';show.setAttribute('aria-label','Vis Kündig-progression '+event.date+' '+offset(c.shift_minutes));
        show.addEventListener('click',()=>{cancelComparison();shift=c.shift_minutes;current=cache.get(shift);$('rect-shift').value=String(Math.round(shift*60));$('rect-shift').setAttribute('aria-valuetext',offset(shift));$('rect-shift-label').textContent=offset(shift);overlay={event,progressed:p,label:events[i].label};draw();setTab($('tab-wheel'));});td.append(show);tr.append(td);
      }body.append(tr);
    });table.append(body);const wrap=el('div',undefined,'table-wrap');wrap.append(table);$('rect-comparison').replaceChildren(el('p','P = progression · R = fødselshoroskop. På smalle skærme kan tabellen rulles vandret.','hint'),wrap);
  }
  function showComparison(){
    if(comparison.method.id==='kundig'){showProgressComparison();return;}
    const table=el('table'),caption=el('caption','Kandidater × begivenheder · datoens transitter til AC/MC');table.append(caption);
    const thead=el('thead'),head=el('tr');for(const [i,title] of ['Begivenhed',...comparison.charts.map(c=>offset(c.rectification.shift_minutes)+' · '+c.birth.local.slice(11,19))].entries()){const th=el('th',title);th.scope='col';const n=comparison.charts[i-1]?.rectification.shift_minutes;if(cutTypes.has(n))th.append(el('small',cutLabel(cutTypes.get(n))));head.append(th);}thead.append(head);table.append(thead);
    const body=el('tbody');comparison.events.forEach((event,i)=>{const tr=el('tr'),th=el('th',events[i].label);th.scope='row';th.append(el('small',event.date));tr.append(th);
      for(const c of event.candidates){const td=el('td');const contacts=c.aspects.length?c.aspects:[null];for(const a of contacts){const b=el('button',a?`${names[a.transit]} ${a.label.toLowerCase()} ${names[a.natal]} · ${dms(a.orb).full}`:'Ingen aspekter ≤ 2° · Vis hjul','transit-link');b.type='button';b.addEventListener('click',()=>{cancelComparison();shift=c.shift_minutes;current=cache.get(shift);$('rect-shift').value=String(Math.round(shift*60));$('rect-shift').setAttribute('aria-valuetext',offset(shift));$('rect-shift-label').textContent=offset(shift);overlay={event,aspect:a,label:events[i].label};draw();setTab($('tab-wheel'));});td.append(b);}tr.append(td);}body.append(tr);});table.append(body);const wrap=el('div',undefined,'table-wrap');wrap.append(table);$('rect-comparison').replaceChildren(el('p','På smalle skærme kan tabellen rulles vandret.','hint'),wrap);
  }
  $('rect-compare').addEventListener('click',async()=>{
    const ctx=context();if(!ctx.valid||!events.length||!candidates.length){$('rect-comparison-status').textContent='Beregn fødselshoroskopet og tilføj mindst én begivenhed.';return;}
    cancelComparison();const generation=serial,abort=new AbortController();controller=abort;const timeout=setTimeout(()=>abort.abort(),20000);$('rect-compare').disabled=true;$('rect-comparison-status').textContent='Sammenligner …';
    try{
      const response=await fetch('/api/rectify/compare',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:ctx.payload,shifts:candidates,events:events.map(e=>e.date),method:$('rect-method').value}),signal:abort.signal});const data=await response.json();if(generation!==serial||!active)return;
      if(!response.ok)throw Error(data.error?.message||'Sammenligningen kunne ikke beregnes.');
      comparison=data;for(const c of data.charts)cache.set(c.rectification.shift_minutes,c);showComparison();$('rect-comparison-status').textContent=`${candidates.length} kandidater og ${events.length} ${events.length===1?'begivenhed':'begivenheder'}. ${data.method.id==='kundig'?'Solnøgler og progressive akser er beregnet særskilt for hver kandidat. Vælg Vis progression i hjulet.':'Klik på et aspekt for at se det i hjulet.'} Færre eller tættere aspekter er ikke i sig selv tegn på en mere korrekt fødselstid.`;
    }catch(error){if(generation===serial&&active)$('rect-comparison-status').textContent=error.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':error.message;}
    finally{clearTimeout(timeout);if(generation===serial)$('rect-compare').disabled=false;}
  });
  function snapshot(){return {shifts:candidates.length?[...candidates]:[0],current:current?.rectification?.shift_minutes||0,method:$('rect-method').value,cut_mode:$('cut-mode').value,cut_types:[...cutTypes].filter(([n])=>candidates.includes(n)).map(([n,methods])=>({shift_minutes:n,methods:[...methods]})),events:events.map(e=>({...e}))};}
  function restore(saved,charts){reset();$('cut-mode').value=saved.cut_mode||'kundig';cutTypes=new Map((saved.cut_types||[]).map(c=>[c.shift_minutes,[...c.methods]]));$('rect-method').value=saved.method||'transits';methodHelp();for(const c of charts)cache.set(c.rectification?.shift_minutes||0,c);candidates=[...saved.shifts];events=saved.events.map(e=>({...e}));shift=saved.current;current=cache.get(shift)||cache.get(0);candidateList();eventList();$('rect-comparison-status').textContent='Gendannet fra biblioteket. Tryk Sammenlign for at beregne begivenhederne igen.';}
  return {snapshot,restore,activate,stop,reset,draw,get active(){return active;}};
}
