import {session,MAX_RECORDS} from './library-model.js';
const DB="stjernerne-en-test-library",STORE='charts';
let opening;
function db(){if(!opening)opening=new Promise((resolve,reject)=>{
  const request=indexedDB.open(DB,1);
  request.onupgradeneeded=()=>request.result.createObjectStore(STORE,{keyPath:'id'});
  request.onsuccess=()=>{request.result.onversionchange=()=>{request.result.close();opening=null;};resolve(request.result);};
  request.onerror=()=>{opening=null;reject(Error("The local browser library could not be opened. Export a backup if storage is blocked."));};
  request.onblocked=()=>{opening=null;reject(Error("Close other tabs with this app and try again."));};
});return opening;}
export async function listRecords(){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction(STORE,'readonly'),q=t.objectStore(STORE).getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(Error("The library could not be read."));});}
// All checks and writes share one readwrite transaction: concurrent tabs cannot lose updates.
export async function changeRecord(action){const d=await db();return new Promise((resolve,reject)=>{
  const tx=d.transaction(STORE,'readwrite'),store=tx.objectStore(STORE),q=store.getAll();let result,reason;
  tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(reason||Error("Could not save locally. Check browser storage and permissions."));
  q.onsuccess=()=>{try{
    const rows=q.result,now=new Date().toISOString();
    if(action.type==='create'||action.type==='import'){
      const entries=action.type==='import'?action.records:[action];
      if(rows.length+entries.length>MAX_RECORDS)throw Error("The library can hold 100 charts including the bin. Export a backup to keep more.");
      result=entries.map(entry=>{const row={id:crypto.randomUUID(),revision:1,name:entry.name.trim(),session:session(entry.session),created:now,updated:now,trashed:entry.trashed===true};if(!row.name||row.name.length>80)throw Error("Give the chart a name of up to 80 characters.");store.add(row);return row;});
    }else{
      const row=rows.find(r=>r.id===action.id);if(!row||row.revision!==action.revision)throw Error("The chart was changed in another tab. Open the latest version or save your changes as a new chart.");
      if(action.type==='update'){if(row.trashed)throw Error("Restore the chart from the bin first.");row.name=action.name.trim();if(!row.name||row.name.length>80)throw Error("Enter a name of up to 80 characters.");row.session=session(action.session);}
      else if(action.type==='trash')row.trashed=true;
      else if(action.type==='restore')row.trashed=false;
      else throw Error("Unknown library change.");
      row.revision++;row.updated=now;store.put(row);result=row;
    }
  }catch(e){reason=e;tx.abort();}};
});}
