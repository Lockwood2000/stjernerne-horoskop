import {session,MAX_RECORDS} from './library-model.js';
const DB='stjernerne-library',STORE='charts';
let opening;
function db(){if(!opening)opening=new Promise((resolve,reject)=>{
  const request=indexedDB.open(DB,1);
  request.onupgradeneeded=()=>request.result.createObjectStore(STORE,{keyPath:'id'});
  request.onsuccess=()=>{request.result.onversionchange=()=>{request.result.close();opening=null;};resolve(request.result);};
  request.onerror=()=>{opening=null;reject(Error('Browserens lokale bibliotek kunne ikke åbnes. Eksportér en backup, hvis lagring er blokeret.'));};
  request.onblocked=()=>{opening=null;reject(Error('Luk andre åbne faner med generatoren, og prøv igen.'));};
});return opening;}
export async function listRecords(){const d=await db();return new Promise((resolve,reject)=>{const t=d.transaction(STORE,'readonly'),q=t.objectStore(STORE).getAll();q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(Error('Biblioteket kunne ikke læses.'));});}
// All checks and writes share one readwrite transaction: concurrent tabs cannot lose updates.
export async function changeRecord(action){const d=await db();return new Promise((resolve,reject)=>{
  const tx=d.transaction(STORE,'readwrite'),store=tx.objectStore(STORE),q=store.getAll();let result,reason;
  tx.oncomplete=()=>resolve(result);tx.onabort=()=>reject(reason||Error('Kunne ikke gemme lokalt. Kontrollér browserens lagerplads og tilladelser.'));
  q.onsuccess=()=>{try{
    const rows=q.result,now=new Date().toISOString();
    if(action.type==='create'||action.type==='import'){
      const entries=action.type==='import'?action.records:[action];
      if(rows.length+entries.length>MAX_RECORDS)throw Error('Biblioteket har plads til 100 horoskoper inklusive papirkurven. Eksportér en backup for at bevare flere.');
      result=entries.map(entry=>{const row={id:crypto.randomUUID(),revision:1,name:entry.name.trim(),session:session(entry.session),created:now,updated:now,trashed:entry.trashed===true};if(!row.name||row.name.length>80)throw Error('Giv horoskopet et navn på højst 80 tegn.');store.add(row);return row;});
    }else{
      const row=rows.find(r=>r.id===action.id);if(!row||row.revision!==action.revision)throw Error('Horoskopet er ændret i en anden fane. Åbn den nyeste version, eller gem dine ændringer som et nyt horoskop.');
      if(action.type==='update'){if(row.trashed)throw Error('Gendan horoskopet fra papirkurven først.');row.name=action.name.trim();if(!row.name||row.name.length>80)throw Error('Angiv et navn på højst 80 tegn.');row.session=session(action.session);}
      else if(action.type==='trash')row.trashed=true;
      else if(action.type==='restore')row.trashed=false;
      else throw Error('Ukendt biblioteksændring.');
      row.revision++;row.updated=now;store.put(row);result=row;
    }
  }catch(e){reason=e;tx.abort();}};
});}
