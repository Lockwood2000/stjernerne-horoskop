const $=id=>document.getElementById(id);
const guidance={
  natal:['Dit fødselshoroskop','Se dit horoskophjul, dine planetpositioner og aspekterne mellem dem.'],
  transit:['Dato og afspilning','Sammenlign himlen på en valgt dato med dit fødselshoroskop. Brug Afspil for at følge bevægelsen.'],
  solar:['År og opholdssted','Vælg et år og det sted, hvor du opholder dig ved solreturen. Tryk derefter Beregn horoskop.'],
  progressed:['Progressionsdato','Vælg den dato, du vil undersøge. Tryk derefter Beregn horoskop.'],
  solar_arc:["Solar arc-dato","Vælg måldatoen for de symbolske direktioner og tryk Beregn horoskop."],
  synastry:['Person B og ringe','Indtast den anden persons fødselsoplysninger. Dit første horoskop er person A.'],
  rectify:['Undersøg fødselstiden','Find snit → vælg tidspunkter → sammenlign med livsbegivenheder. En kort guide hjælper dig i gang.']
};
let previousMode=null;
export function syncNavigation(){
  const mode=$('chart-mode').value==='natal'&&$('show-transits').checked?'transit':$('chart-mode').value;
  for(const button of document.querySelectorAll('[data-mode]'))button.setAttribute('aria-pressed',String(button.dataset.mode===mode));
  $('mode-title').textContent=document.querySelector(`[data-mode="${mode}"]`).firstChild.textContent;
  $('mode-help').textContent=guidance[mode][1];$('settings-title').textContent=guidance[mode][0];
  $('chart-settings').hidden=mode==='natal';
  if(mode!==previousMode)$('chart-settings').open=true;
  previousMode=mode;
  $('tab-transits').hidden=mode!=='transit';
}
export function chartReady({navigate=false}={}){
  $('birth-summary').textContent=`${$('date').value} · ${$('time').value} · ${$('manual-place').checked?$('manual-name').value:$('place-search').value}`;
  if(navigate&&matchMedia('(max-width:760px)').matches){
    $('birth-editor').open=false;$('chart-settings').open=false;$('mode-picker').open=false;
    $('chart-card').focus({preventScroll:true});$('chart-card').scrollIntoView({block:'start'});
  }
}
export function initNavigation(){
  function jump(target){
    if(target==='birth'){$('birth-editor').open=true;$('date').focus({preventScroll:true});$('birth-card').scrollIntoView({block:'start'});}
    else if(target==='chart'){$('chart-card').focus({preventScroll:true});$('chart-card').scrollIntoView({block:'start'});}
    else{$('library').open=true;const focus=target==='save'?$('library-name'):$('library').querySelector('summary');focus.focus({preventScroll:true});(target==='save'?$('library-name'):$('library')).scrollIntoView({block:target==='save'?'center':'start'});}
  }
  for(const button of document.querySelectorAll('[data-jump]'))button.addEventListener('click',()=>jump(button.dataset.jump));
  for(const button of document.querySelectorAll('[data-mode]'))button.addEventListener('click',()=>{
    if(button.getAttribute('aria-pressed')==='true'){if(button.dataset.mode!=='natal')$('chart-settings').open=true;if(button.dataset.mode==='rectify')$('rectify-controls').scrollIntoView({block:'start'});return;}
    const mode=button.dataset.mode;
    $('show-transits').checked=mode==='transit';$('transit-tools').hidden=mode!=='transit';
    $('chart-mode').value=mode==='transit'?'natal':mode;
    $('chart-mode').dispatchEvent(new Event('change',{bubbles:true}));
    // Mode changes focus the wheel tab in the calculation controller. Keep the
    // user's place in the chooser so the next keyboard action reaches settings.
    button.focus({preventScroll:true});syncNavigation();if(mode==='rectify')$('rectify-controls').scrollIntoView({block:'start'});
  });
  $('settings-done').addEventListener('click',()=>{$('chart-settings').open=false;$('mode-picker').open=false;$('tab-wheel').click();$('tab-wheel').scrollIntoView({block:'start'});});
  $('show-transits').addEventListener('change',syncNavigation);
  const dialog=$('wheel-dialog'),wheel=$('wheel'),stage=$('wheel-stage');
  let placeholder=null;
  function zoom(){const value=Number($('wheel-zoom').value);wheel.style.width=value+'%';$('wheel-zoom-value').textContent=value+' %';}
  $('wheel-expand').disabled=!wheel.querySelector('svg');
  new MutationObserver(()=>{$('wheel-expand').disabled=!wheel.querySelector('svg');}).observe(wheel,{childList:true});
  $('wheel-expand').addEventListener('click',()=>{
    if(!wheel.querySelector('svg'))return;
    $('wheel-dialog-title').textContent=$('chart-title').textContent;$('wheel-dialog-meta').textContent=$('chart-meta').textContent;
    placeholder=document.createComment('wheel-home');wheel.before(placeholder);stage.append(wheel);
    $('wheel-zoom').value='100';zoom();dialog.showModal();stage.scrollTop=0;stage.scrollLeft=0;
  });
  $('wheel-zoom').addEventListener('input',zoom);
  $('wheel-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{if(placeholder){placeholder.replaceWith(wheel);placeholder=null;}wheel.style.removeProperty('width');$('wheel-expand').focus({preventScroll:true});});
  syncNavigation();
}
