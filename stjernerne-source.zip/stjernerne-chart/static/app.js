import {houseLabel,techniqueHelp,arcStatus} from './chart-options.js';
import {initNavigation,syncNavigation,chartReady} from './navigation.js';
import {createLibrary} from './library.js';
import {session as validateSession} from './library-model.js';
import {fillBirthForm} from './birth-form.js';
import {createFamousPicker} from './famous-danes.js';
import {archiveBirth} from './famous-model.js';
import {createRectification} from './rectification.js';
import {createSynastry} from './synastry.js';
import {renderWheel,dms} from './wheel.js';
import {createPlayer,nextTransitTime} from './playback.js';
import {solarKeyLabel,renderSolarKeyComparison} from './solar-key.js';
const $=id=>document.getElementById(id);
const create=(tag,text,className)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(className)e.className=className;return e;};
let selected={id:'2618425',name:'København',country:'Denmark',latitude:55.67594,longitude:12.56553,timezone:'Europe/Copenhagen'};
let synastry=null,rectification=null;
let famousPicker=null;
let result=null,revision=0,searchAbort=null,searchTimer=null;
let derivedResult=null,techniqueSerial=0,techniqueAbort=null,returnPlace=null,returnSearchTimer=null,returnSearchAbort=null;
let natalPayload=null,transitResult=null,transitAspect=null,transitSerial=0,transitAbort=null,transitTimer=null;
const player=createPlayer(playbackFrame,active=>{
  $('transit-play').textContent=active?'Ⅱ Pause':'▶ Afspil';
  $('transit-play').setAttribute('aria-pressed',String(active));
  $('playback-status').textContent=active?'Afspiller · ét skridt ca. hvert 1,2 sekund.':'Afspilningen er sat på pause.';
  if(!active){transitSerial++;transitAbort?.abort();}
});
const phaseNames={applying:'Nærmer sig',separating:'Aftager',exact:'Eksakt',stationary:'Næsten stationær'};
const today=new Date();$('date').max=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
function markChanged(resetFold=true){famousPicker?.clear();revision++;resetTechnique();clearTransit();$('stale').hidden=!result;$('download').disabled=true;$('error').hidden=true;if(resetFold){$('fold-panel').hidden=true;$('fold').value='';}}
function placeHint(p){$('place-hint').textContent=`${p.name} · ${p.latitude.toFixed(5)}°, ${p.longitude.toFixed(5)}° · ${p.timezone}`;}
function pick(p){selected=p;$('place-search').value=`${p.name}, ${p.country}`;$('place-results').hidden=true;placeHint(p);markChanged();$('place-search').focus();}
$('place-search').addEventListener('input',()=>{
  selected=null;markChanged();$('place-hint').textContent='Vælg et præcist sted fra søgeresultaterne.';
  clearTimeout(searchTimer);searchAbort?.abort();$('place-results').hidden=true;
  const q=$('place-search').value.trim();if(q.length<2)return;
  searchTimer=setTimeout(async()=>{
    const controller=new AbortController();searchAbort=controller;
    try{
      const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});
      if(!response.ok)throw Error('Bysøgningen kunne ikke gennemføres. Prøv igen.');
      const places=await response.json();if($('place-search').value.trim()!==q)return;
      const list=$('place-results');list.replaceChildren();
      if(!places.length)list.append(create('li','Ingen resultater. Prøv et andet navn, eller angiv stedet manuelt.','empty'));
      for(const p of places){const li=create('li'),button=create('button',p.name);button.type='button';button.append(create('small',`${p.country} · region ${p.region} · ${p.latitude.toFixed(2)}°, ${p.longitude.toFixed(2)}° · ${p.timezone}`));button.addEventListener('click',()=>pick(p));li.append(button);list.append(li);}list.hidden=false;
    }catch(e){if(e.name!=='AbortError'){$('place-hint').textContent=e.message;}}
  },230);
});
$('place-search').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('place-results').querySelector('button')?.focus();}if(e.key==='Escape')$('place-results').hidden=true;});
$('place-results').addEventListener('keydown',e=>{const buttons=[...$('place-results').querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}if(e.key==='Escape'){$('place-results').hidden=true;$('place-search').focus();}});
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))$('place-results').hidden=true;});
$('manual-place').addEventListener('change',()=>{$('manual-fields').disabled=!$('manual-place').checked;$('place-search').disabled=$('manual-place').checked;for(const id of ['latitude','longitude','timezone'])$(id).required=$('manual-place').checked;});
$('manual-offset').addEventListener('change',()=>{$('offset-fields').disabled=!$('manual-offset').checked;for(const id of ['offset-minutes','offset-source'])$(id).required=$('manual-offset').checked;});
$('birth-form').addEventListener('input',e=>{if(!['place-search','house-system'].includes(e.target.id))markChanged(e.target.id!=='fold');});
function showError(message){$('error').textContent=message;$('error').hidden=false;}
function requestData(){
  const payload={date:$('date').value,time:$('time').value,include_dwarfs:$('include-dwarfs').checked,house_system:$('house-system').value};
  if($('manual-place').checked){
    if($('latitude').value===''||$('longitude').value==='')throw Error('Udfyld begge koordinater.');
    Object.assign(payload,{place_name:$('manual-name').value,latitude:Number($('latitude').value),longitude:Number($('longitude').value),timezone:$('timezone').value.trim()});
  }else{if(!selected)throw Error('Vælg dit fødested fra søgeresultaterne.');payload.place_id=selected.id;}
  if(!$('fold-panel').hidden&&$('fold').value!=='')payload.fold=Number($('fold').value);
  if($('manual-offset').checked){if($('offset-minutes').value==='')throw Error('Angiv UTC-forskellen.');payload.offset_minutes=Number($('offset-minutes').value);payload.offset_source=$('offset-source').value.trim();}
  return payload;
}
async function submit(example=false){
  $('error').hidden=true;let payload;try{payload=requestData();}catch(e){showError(e.message);return;}
  const generation=revision;resetTechnique();clearTransit();$('calculate').disabled=true;$('calculate').textContent='Beregner dit stjernekort …';$('result-status').textContent='Beregner horoskop.';
  try{
    const response=await fetch('/api/chart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
    const data=await response.json();if(generation!==revision)return;
    if(!response.ok){
      if(data.error?.code==='ambiguous_time'){
        $('fold-panel').hidden=false;$('fold').replaceChildren(new Option('Vælg forekomst …',''));
        data.error.choices.forEach((c,i)=>$('fold').add(new Option(`${i===0?'Første':'Anden'} · UTC${c.offset_minutes>=0?'+':''}${c.offset_minutes/60} · ${c.abbreviation}`,String(c.fold))));
        $('fold').focus();
      }
      throw Error(data.error?.message||'Beregningen kunne ikke gennemføres.');
    }
    clearTransit();natalPayload=payload;result=data;render(data,example);chartReady({navigate:!example});$('stale').hidden=true;$('download').disabled=false;$('result-status').textContent='Dit horoskop er beregnet. Hjul, positioner og aspekter er klar.';if($('chart-mode').value==='rectify')rectification.activate();else if($('chart-mode').value==='natal'&&$('show-transits').checked)updateTransits();
  }catch(e){if(generation===revision){showError(e.name==='TimeoutError'?'Beregningen tog for lang tid. Prøv igen.':e.message==='Failed to fetch'?'Serveren svarer ikke. Kontrollér, at den lokale app kører.':e.message);$('result-status').textContent='Beregningen kunne ikke gennemføres.';if(!result)$('wheel').replaceChildren(create('p','Indtast fødselsoplysninger og beregn dit horoskop.','loading'));}}
  finally{$('calculate').disabled=false;$('calculate').replaceChildren(document.createTextNode('Se mit fødselshoroskop '),create('span','↗'));}
}
$('birth-form').addEventListener('submit',e=>{e.preventDefault();submit();});
const axisLabel=data=>solarKeyLabel(data.technique?.house_method_id||'naibod');
function render(data,example){
  $('chart-title').textContent=data.display_title||'Dit fødselshoroskop';
  $('chart-label').textContent=`${data.chart_type?'DIT '+(data.chart_type==='solar'?'SOLRETURHOROSKOP':'PROGRESSIONSHOROSKOP'):example?'EKSEMPEL':'DIT STJERNEKORT'} · ${data.place.name.toLocaleUpperCase('da')}`;
  const local=data.birth.local.slice(0,19),date=new Date(local+'Z');
  $('chart-meta').textContent=`${new Intl.DateTimeFormat('da-DK',{dateStyle:'long',timeZone:'UTC'}).format(date)} · kl. ${local.slice(11)} · ${data.place.name}`;
  if(data.chart_type==='progressed')$('chart-meta').textContent=`For ${data.technique.target.local.slice(0,10)} · ${data.place.name} · ${axisLabel(data)}-akser`;
  if(data.chart_type==='solar_arc'){$('chart-label').textContent='SOLAR ARC · '+data.place.name;$('chart-meta').textContent=arcStatus(data);}
  $('house-label').textContent=houseLabel(data);$('house-caption').textContent="Husspidser · "+houseLabel(data);
  if(data.chart_type!=='solar_arc')$('chart-meta').textContent+=' · '+houseLabel(data);
  $('wheel').replaceChildren(renderWheel(data));
  const sun=data.planets.find(p=>p.id==='sun'),moon=data.planets.find(p=>p.id==='moon');
  $('big-three').replaceChildren(...[['SOL',sun],['MÅNE',moon],['ASCENDANT',data.ascendant]].map(([name,p])=>{const card=create('div'),v=dms(p.longitude);card.append(create('small',name),create('strong',v.sign),create('span',v.short,'degree'));return card;}));
  $('planet-rows').replaceChildren(...data.planets.map(p=>{const row=create('tr'),name=create('td');name.append(create('span',p.glyph,'planet-glyph'),document.createTextNode(p.name));row.append(name,create('td',`${dms(p.longitude).full} ${dms(p.longitude).sign}`),create('td',String(p.house)),create('td',p.retrograde?'℞ Retrograd':'Direkte'));return row;}));
  $('house-rows').replaceChildren(...data.houses.map(h=>{const row=create('tr');row.append(create('td',String(h.number)),create('td',`${dms(h.longitude).full} ${dms(h.longitude).sign}`));return row;}));
  const names=Object.fromEntries(data.planets.map(p=>[p.id,p.name]));
  $('aspect-rows').replaceChildren(...data.aspects.map(a=>{const row=create('tr');row.append(create('td',`${names[a.a]} · ${names[a.b]}`),create('td',`${a.label} ${a.angle}°`),create('td',dms(a.orb).full));return row;}));
  $('warnings').replaceChildren(...data.birth.warnings.map(w=>create('p',w)));$('warnings').hidden=!data.birth.warnings.length;
  const dl=create('dl');for(const [key,value] of Object.entries({'Fødested':`${data.place.name} · ${data.place.latitude}°, ${data.place.longitude}°`,'Horoskopets lokale efemeridetid':data.birth.local,'UTC':data.birth.utc,'Tidszone':data.birth.timezone,'Tidsforskel':`${data.birth.offset_minutes} minutter`,'Tidskilde':data.birth.source==='manual'?data.birth.source_note:`IANA ${data.birth.iana_version}`,'Beregning':`Swiss Ephemeris ${data.calculation.version} · DE441`,'Indstillinger':"Tropisk · geocentrisk · "+houseLabel(data)+" · True Node"+(data.chart_type==='progressed'?' · '+axisLabel(data)+' i rektascension':''),'Juliansk dag (TT)':data.calculation.jd_tt.toFixed(8),'Juliansk dag (UT1)':data.calculation.jd_ut1.toFixed(8)})){dl.append(create('dt',key),create('dd',String(value)));}$('calculation-details').replaceChildren(dl);
}
function setTab(button,focus=true){for(const t of document.querySelectorAll('[role=tab]')){const on=t===button;t.setAttribute('aria-selected',String(on));t.tabIndex=on?0:-1;$('panel-'+t.dataset.tab).hidden=!on;}if(focus)button.focus();}
for(const button of document.querySelectorAll('[role=tab]')){button.addEventListener('click',()=>setTab(button));button.addEventListener('keydown',e=>{const tabs=[...document.querySelectorAll('[role=tab]')].filter(t=>!t.hidden),i=tabs.indexOf(button);if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();setTab(tabs[e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length]);}});}
$('download').addEventListener('click',()=>{if(!result)return;const svg=$('wheel svg')||$('wheel').querySelector('svg');const markup=new XMLSerializer().serializeToString(svg);const url=URL.createObjectURL(new Blob([markup],{type:'image/svg+xml'})),a=create('a');a.href=url;a.download=`stjernerne-${$('chart-mode').value==='rectify'?'tidskandidat':$('chart-mode').value==='synastry'?'synastri':derivedResult?.chart_type||'foedselshoroskop'}.svg`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);});

function drawTransit(){
  if(rectification?.active&&$('chart-mode').value==='rectify'){rectification.draw();return;}
  if(synastry?.data&&$('chart-mode').value==='synastry'){synastry.draw();return;}
  if(result)$('wheel').replaceChildren(renderWheel(derivedResult||result,derivedResult?null:transitResult,derivedResult?null:transitAspect));
  $('transit-caption').hidden=!transitResult;
  if(transitResult){
    const names=Object.fromEntries(result.planets.map(p=>[p.id,p.name]));
    $('transit-caption').textContent='Ydre ring: transitter · Indre ring: dit fødselshoroskop'+(transitAspect?` — ${names[transitAspect.transit]} i transit: ${transitAspect.label.toLowerCase()} til ${names[transitAspect.natal]} i fødselshoroskopet · orb ${dms(transitAspect.orb).full}`:'');
  }
}
function clearTransit(){
  player.stop();
  transitSerial++;transitAbort?.abort();clearTimeout(transitTimer);transitResult=null;transitAspect=null;
  $('transit-rows').replaceChildren();$('transit-table').hidden=true;$('transit-caption').hidden=true;
  $('transit-error').hidden=true;$('transit-status').textContent='';
  $('transit-intro').textContent=$('show-transits').checked?'Beregn fødselshoroskopet, og vælg et transittidspunkt.':'Slå “Vis transitter” til for at sammenligne himlen med dit fødselshoroskop.';
  drawTransit();
}
function transitNow(){
  const parts=Object.fromEntries(new Intl.DateTimeFormat('sv-SE',{timeZone:$('transit-zone').value,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).map(p=>[p.type,p.value]));
  $('transit-date').value=`${parts.year}-${parts.month}-${parts.day}`;$('transit-time').value=`${parts.hour}:${parts.minute}:${parts.second}`;
}
function scheduleTransits(resetFold=true){
  clearTransit();
  if(resetFold){$('transit-fold-panel').hidden=true;$('transit-fold').value='';}
  transitTimer=setTimeout(()=>updateTransits(),220);
}
async function updateTransits(playbackTime=null){
  const animated=playbackTime!==null;
  if(animated){transitSerial++;transitAbort?.abort();clearTimeout(transitTimer);$('transit-error').hidden=true;}
  else clearTransit();
  if(!$('show-transits').checked)return;
  if(!result||!natalPayload||!$('stale').hidden){$('transit-status').textContent='Beregn først fødselshoroskopet med dine aktuelle oplysninger.';return;}
  if(!$('transit-form').reportValidity())return;
  const generation=transitSerial, birthRevision=revision;
  transitAbort=new AbortController();const controller=transitAbort;
  const deadline=setTimeout(()=>controller.abort(),15000);
  const transit={...(playbackTime||{date:$('transit-date').value,time:$('transit-time').value}),timezone:$('transit-zone').value};
  if(!animated&&!$('transit-fold-panel').hidden&&$('transit-fold').value!=='')transit.fold=Number($('transit-fold').value);
  if(!animated){$('transit-status').textContent='Beregner transitter …';$('transit-intro').textContent='Beregner transitter …';}
  try{
    const response=await fetch('/api/transits',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:natalPayload,transit}),signal:controller.signal});
    const data=await response.json();if(generation!==transitSerial||birthRevision!==revision)return;
    if(!response.ok){
      if(animated){$('transit-date').value=transit.date;$('transit-time').value=transit.time;transitResult=null;transitAspect=null;drawTransit();$('transit-rows').replaceChildren();$('transit-table').hidden=true;}
      if(data.error?.code==='ambiguous_time'){
        $('transit-fold-panel').hidden=false;$('transit-fold').replaceChildren(new Option('Vælg forekomst …',''));
        data.error.choices.forEach((c,i)=>$('transit-fold').add(new Option(`${i===0?'Første':'Anden'} · UTC${c.offset_minutes>=0?'+':''}${c.offset_minutes/60} · ${c.abbreviation}`,String(c.fold))));
      }
      throw Error(data.error?.code==='nonexistent_time'?'Transittidspunktet findes ikke på grund af skift til sommertid. Vælg et andet klokkeslæt, og tryk Opdatér.':data.error?.message||'Transitterne kunne ikke beregnes.');
    }
    return acceptTransits(data,animated,transit);
  }catch(e){if(generation===transitSerial&&birthRevision===revision){$('transit-status').textContent='';$('transit-intro').textContent='Transitterne kunne ikke beregnes.';$('transit-error').hidden=false;$('transit-error').textContent=e.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':e.message;}}
  finally{clearTimeout(deadline);}
}
function acceptTransits(data,animated=false,transit=null){
    const previousAspect=transitAspect;
    transitResult=data;transitAspect=data.aspects.find(a=>a.transit===previousAspect?.transit&&a.natal===previousAspect?.natal&&a.type===previousAspect?.type)||data.aspects[0]||null;
    if(animated){$('transit-date').value=transit.date;$('transit-time').value=transit.time;$('transit-fold-panel').hidden=true;$('transit-fold').value='';}
    const local=data.timing.local;
    const stamp=`${new Intl.DateTimeFormat('da-DK',{dateStyle:'long',timeZone:'UTC'}).format(new Date(local.slice(0,10)+'T12:00:00Z'))} · kl. ${local.slice(11,19)} · ${data.timing.timezone} (UTC${local.slice(-6)})`;
    $('transit-status').textContent=stamp+(data.timing.warnings.length?' · '+data.timing.warnings.join(' '):'');
    $('transit-intro').textContent=data.aspects.length?`${data.aspects.length} aspekter til dit fødselshoroskop · ${stamp}`:'Ingen hovedaspekter inden for den valgte orb på dette tidspunkt.';
    $('transit-table').hidden=!data.aspects.length;
    const names=Object.fromEntries(result.planets.map(p=>[p.id,p.name]));
    $('transit-rows').replaceChildren(...data.aspects.map(a=>{
      const row=create('tr'),pair=create('td'),button=create('button',`${names[a.transit]} → ${names[a.natal]}`,'transit-link');button.type='button';
      button.setAttribute('aria-label',`Vis ${names[a.transit]} i transit ${a.label.toLowerCase()} til fødslens ${names[a.natal]} i hjulet`);
      button.addEventListener('click',()=>{transitAspect=a;drawTransit();setTab($('tab-wheel'));});pair.append(button);
      const aspect=create('td',a.label);aspect.append(create('small',dms(a.orb).full));
      row.append(pair,aspect,create('td',phaseNames[a.phase]));return row;
    }));drawTransit();return true;
}
async function playbackFrame(){
  if(document.hidden||!$('show-transits').checked||!$('stale').hidden||!transitResult)return false;
  const next=nextTransitTime($('transit-date').value,$('transit-time').value,Number($('playback-step').value)*Number($('playback-direction').value));
  if(!next){player.stop();$('playback-status').textContent='Afspilningen er stoppet ved datogrænsen (1500–2099).';return false;}
  return await updateTransits(next);
}
$('transit-play').addEventListener('click',()=>{
  if(player.active){player.stop();return;}
  if(!transitResult||!$('stale').hidden){$('playback-status').textContent='Beregn først et gyldigt fødselshoroskop og transittidspunkt.';return;}
  setTab($('tab-wheel'));$('transit-play').focus();player.start();
});
for(const id of ['transit-date','transit-time','transit-zone','transit-fold','playback-step','playback-direction'])$(id).addEventListener('input',()=>player.stop());
document.addEventListener('visibilitychange',()=>{if(document.hidden)player.stop();});
$('show-transits').addEventListener('change',()=>{$('transit-tools').hidden=!$('show-transits').checked;if($('show-transits').checked)updateTransits();else clearTransit();});
$('transit-form').addEventListener('submit',e=>{e.preventDefault();updateTransits();});
for(const id of ['transit-date','transit-time','transit-zone'])$(id).addEventListener('change',()=>scheduleTransits());
$('transit-fold').addEventListener('change',()=>scheduleTransits(false));
$('transit-now').addEventListener('click',()=>{transitNow();scheduleTransits();});
for(const button of document.querySelectorAll('[data-days]'))button.addEventListener('click',()=>{
  const date=new Date($('transit-date').value+'T12:00:00Z');if(Number.isNaN(date.getTime()))return;
  date.setUTCDate(date.getUTCDate()+Number(button.dataset.days));const value=date.toISOString().slice(0,10);
  if(value<'1500-01-01'||value>'2099-12-31')return;
  $('transit-date').value=value;scheduleTransits();
});

function setTechniqueVisibility(){
  const mode=$('chart-mode').value;
  $('rect-quick').hidden=mode!=='rectify';$('rectify-controls').hidden=mode!=='rectify';$('tab-rectify').hidden=mode!=='rectify';
  $('technique-form').hidden=!['solar','progressed','solar_arc'].includes(mode);
  $('synastry-controls').hidden=mode!=='synastry';$('tab-synastry').hidden=mode!=='synastry';
  $('tab-positions').hidden=mode==='synastry';$('tab-aspects').hidden=mode==='synastry';$('solar-fields').hidden=mode!=='solar';$('progress-fields').hidden=!['progressed','solar_arc'].includes(mode);$('progress-axis-fields').hidden=mode!=='progressed';$('progress-method').disabled=mode!=='progressed';
  $('return-year').required=mode==='solar';$('return-year').disabled=mode!=='solar';
  for(const id of ['progress-date','progress-time']){$(id).required=['progressed','solar_arc'].includes(mode);$(id).disabled=!['progressed','solar_arc'].includes(mode);}
  document.querySelector('.transit-controls').hidden=mode!=='natal';$('tab-transits').hidden=mode!=='natal';
  $('technique-method').textContent=techniqueHelp(mode,$('house-system').value)+(mode==='progressed'?' · '+solarKeyLabel($('progress-method').value):'');
  syncNavigation();
}
function clearTechnique(){
  rectification?.stop();
  synastry?.clear();
  techniqueSerial++;techniqueAbort?.abort();derivedResult=null;$('technique-error').hidden=true;$('technique-status').textContent='';$('solar-key-comparison').replaceChildren();$('solar-key-comparison').hidden=true;
  if(result)render(result,false);
}
function resetTechnique(){
  rectification?.reset();
  clearTechnique();$('progress-method').value='naibod';$('chart-mode').value='natal';setTechniqueVisibility();
}
$('chart-mode').addEventListener('change',()=>{
  clearTechnique();clearTransit();setTechniqueVisibility();setTab($('tab-wheel'),false);
  if($('chart-mode').value==='natal'){$('download').disabled=!result||!$('stale').hidden;if($('show-transits').checked)updateTransits();}
  else if($('chart-mode').value==='rectify'){rectification.activate();}
  else $('technique-status').textContent=$('chart-mode').value==='synastry'?'':'Vælg indstillinger, og tryk Beregn horoskop. Hjulet viser indtil da fødselshoroskopet.';
});
$('technique-form').addEventListener('input',()=>{setTechniqueVisibility();clearTechnique();$('download').disabled=true;$('technique-status').textContent='Indstillinger ændret. Beregn igen; hjulet viser fødselshoroskopet.';});
$('return-birthplace').addEventListener('change',()=>{$('return-place-fields').hidden=$('return-birthplace').checked;});
$('return-place').addEventListener('input',()=>{
  returnPlace=null;clearTimeout(returnSearchTimer);returnSearchAbort?.abort();$('return-results').hidden=true;$('return-place-hint').textContent='Vælg et sted fra søgeresultaterne.';
  const q=$('return-place').value.trim();if(q.length<2)return;
  returnSearchTimer=setTimeout(async()=>{
    const controller=new AbortController();returnSearchAbort=controller;
    try{
      const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});
      if(!response.ok)throw Error('Bysøgningen kunne ikke gennemføres.');
      const places=await response.json();if($('return-place').value.trim()!==q)return;
      $('return-results').replaceChildren();
      for(const p of places){const li=create('li'),b=create('button',`${p.name} · ${p.country} · ${p.timezone}`);b.type='button';
        b.addEventListener('click',()=>{clearTechnique();returnPlace=p;$('return-place').value=`${p.name}, ${p.country}`;$('return-results').hidden=true;$('return-place-hint').textContent=`${p.latitude}°, ${p.longitude}° · ${p.timezone}`;});li.append(b);$('return-results').append(li);}
      if(!places.length)$('return-results').append(create('li','Ingen resultater. Prøv et andet bynavn.','empty'));
      $('return-results').hidden=false;
    }catch(e){if(e.name!=='AbortError')$('return-place-hint').textContent=e.message;}
  },230);
});
$('return-place').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){$('return-results').querySelector('button')?.focus();e.preventDefault();}if(e.key==='Escape')$('return-results').hidden=true;});
$('technique-form').addEventListener('submit',async e=>{
  e.preventDefault();clearTechnique();clearTransit();
  if(!result||!natalPayload||!$('stale').hidden){$('technique-error').textContent='Beregn først fødselshoroskopet med dine aktuelle oplysninger.';$('technique-error').hidden=false;return;}
  const mode=$('chart-mode').value,payload={birth:natalPayload,mode};
  if(mode==='solar'){
    payload.year=Number($('return-year').value);
    if(!$('return-birthplace').checked){if(!returnPlace){$('technique-error').textContent='Vælg solretursted fra søgeresultaterne.';$('technique-error').hidden=false;return;}payload.location={place_id:returnPlace.id};}
  }else {payload.target={date:$('progress-date').value,time:$('progress-time').value,timezone:'UTC'};if(mode==='progressed')payload.house_method=$('progress-method').value;}
  const generation=techniqueSerial,birthRevision=revision;
  const controller=new AbortController();techniqueAbort=controller;const timer=setTimeout(()=>controller.abort(),15000);
  $('calculate-technique').disabled=true;$('download').disabled=true;$('technique-status').textContent='Beregner …';
  try{
    const response=await fetch('/api/technique',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
    const data=await response.json();if(generation!==techniqueSerial||birthRevision!==revision)return;
    if(!response.ok)throw Error(data.error?.message||'Horoskopet kunne ikke beregnes.');
    derivedResult=data;render(data,false);$('download').disabled=false;setTab($('tab-wheel'));chartReady({navigate:true});
    $('technique-status').textContent=mode==='solar'?`Solretur: ${data.birth.local.slice(0,19).replace('T',' kl. ')} · ${data.birth.timezone} · ${data.place.name}.`:`Progression til ${payload.target.date} kl. ${payload.target.time} UTC. Efemeridetid: ${data.technique.progressed_utc.slice(0,19).replace('T',' kl. ')} UTC · ${data.technique.age_years.toFixed(4)} år · ${axisLabel(data)}-akser.`;
    if(mode==='solar_arc')$('technique-status').textContent=arcStatus(data);
    if(data.technique.solar_key){const k=data.technique.solar_key;$('technique-status').textContent+=` Din solnøgle: ${dms(k.degrees_per_year).full} RA pr. år (${k.degrees_per_year.toFixed(8)}°). Samlet aksebue: ${data.technique.arc_degrees.toFixed(6)}° RA. Solgradens grænser: ${dms(k.degree_start).full} ${dms(k.degree_start).sign} – ${dms(k.degree_end).full} ${dms(k.degree_end).sign}.`;}
    showSolarKeyComparison(data);
  }catch(error){if(generation===techniqueSerial&&birthRevision===revision){$('technique-status').textContent='Hjulet viser fødselshoroskopet.';$('technique-error').hidden=false;$('technique-error').textContent=error.name==='AbortError'?'Beregningen tog for lang tid. Prøv igen.':error.message;}}
  finally{clearTimeout(timer);$('calculate-technique').disabled=false;}
});
function showSolarKeyComparison(data){
  renderSolarKeyComparison($('solar-key-comparison'),data,method=>{
    $('progress-method').value=method;$('progress-method').dispatchEvent(new Event('input',{bubbles:true}));$('technique-form').requestSubmit();
  });
}
function librarySnapshot(){
  if(!result||!natalPayload||!$('stale').hidden)throw Error('Beregn først fødselshoroskopet med de aktuelle oplysninger.');
  const mode=$('chart-mode').value,entry={birth:structuredClone(natalPayload),mode,rectification:rectification.snapshot()};
  if(mode==='synastry')entry.synastry=synastry.snapshot();
  if(['solar','progressed','solar_arc'].includes(mode)){
    if(!derivedResult||derivedResult.chart_type!==mode)throw Error('Beregn det valgte horoskop før du gemmer det.');
    entry.technique={mode};
    if(mode==='solar'){entry.technique.year=Number($('return-year').value);if(!$('return-birthplace').checked){if(!returnPlace)throw Error('Vælg solretursted.');entry.technique.location={place_id:String(returnPlace.id)};}}
    else {entry.technique.target={date:$('progress-date').value,time:$('progress-time').value,timezone:'UTC'};if(mode==='progressed')entry.technique.house_method=$('progress-method').value;}
  }
  if(mode==='natal'&&$('show-transits').checked){
    if(!transitResult)throw Error('Beregn transitterne før du gemmer dem.');
    entry.transit={date:$('transit-date').value,time:$('transit-time').value,timezone:$('transit-zone').value};
    if(!$('transit-fold-panel').hidden&&$('transit-fold').value!=='')entry.transit.fold=Number($('transit-fold').value);
  }
  return validateSession(entry);
}
async function openLibrarySession(raw){
  const saved=validateSession(raw);
  // Stage recomputation before replacing inputs; failures keep the current session and saved record.
  revision++;player.stop();techniqueSerial++;techniqueAbort?.abort();transitSerial++;transitAbort?.abort();clearTimeout(transitTimer);synastry.pause();rectification.stop();
  const abort=new AbortController(),timeout=setTimeout(()=>abort.abort(),25000);
  const request=async(path,payload)=>{const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:abort.signal});const data=await r.json();if(!r.ok)throw Error(data.error?.message||'Horoskopet kunne ikke genberegnes.');return data;};
  try{
    const base=await request('/api/chart',saved.birth);
    const shifts=[...new Set([...saved.rectification.shifts,saved.rectification.current])];
    const charts=await Promise.all(shifts.map(n=>n===0?Promise.resolve(base):request('/api/rectify',{birth:saved.birth,shift_minutes:n})));
    let extra=null;
    if(saved.mode==='synastry')extra=await request('/api/synastry',{a:saved.birth,b:saved.synastry.birth});
    if(saved.technique)extra=await request('/api/technique',{birth:saved.birth,...saved.technique});
    if(saved.transit)extra=await request('/api/transits',{birth:saved.birth,transit:saved.transit});
    resetTechnique();clearTransit();searchAbort?.abort();clearTimeout(searchTimer);returnSearchAbort?.abort();clearTimeout(returnSearchTimer);
    famousPicker?.clear();selected=base.place;natalPayload=structuredClone(saved.birth);result=base;fillBirthForm('',saved.birth,base);$('stale').hidden=true;render(base,false);
    rectification.restore(saved.rectification,charts);$('show-transits').checked=!!saved.transit;$('transit-tools').hidden=!saved.transit;
    $('chart-mode').value=saved.mode;setTechniqueVisibility();
    if(saved.mode==='rectify')rectification.activate();
    if(saved.mode==='synastry')synastry.restore(saved.synastry,extra);
    if(saved.technique){
      derivedResult=extra;render(extra,false);
      if(saved.mode==='solar'){$('return-year').value=String(saved.technique.year);$('return-birthplace').checked=!saved.technique.location;$('return-place-fields').hidden=!saved.technique.location;returnPlace=saved.technique.location?extra.place:null;$('return-place').value=returnPlace?.name||'';$('return-place-hint').textContent=returnPlace?`${returnPlace.name} · ${returnPlace.timezone}`:'';}
      else{$('progress-date').value=saved.technique.target.date;$('progress-time').value=saved.technique.target.time;$('progress-method').value=saved.technique.house_method||'naibod';setTechniqueVisibility();}
      $('technique-status').textContent='Horoskopet er genberegnet fra biblioteket.'+(extra.technique.solar_key?' Din solnøgle: '+dms(extra.technique.solar_key.degrees_per_year).full+' RA pr. år.':'');
      showSolarKeyComparison(extra);
    }
    if(saved.transit){$('transit-date').value=saved.transit.date;$('transit-time').value=saved.transit.time;$('transit-zone').value=saved.transit.timezone;$('transit-fold-panel').hidden=saved.transit.fold===undefined;$('transit-fold').replaceChildren(new Option('Vælg forekomst …',''),new Option('Første forekomst','0'),new Option('Anden forekomst','1'));$('transit-fold').value=saved.transit.fold===undefined?'':String(saved.transit.fold);acceptTransits(extra);}
    $('download').disabled=false;$('result-status').textContent='Horoskopet er åbnet og genberegnet fra biblioteket.';setTab($('tab-wheel'));chartReady();
  }catch(e){if($('chart-mode').value==='rectify')rectification.activate();throw Error(e.name==='AbortError'?'Serveren svarede ikke i tide. Dit gemte horoskop er bevaret; prøv igen.':e.message);}
  finally{clearTimeout(timeout);abort.abort();}
}

$('return-year').value=String(today.getFullYear());$('progress-date').value=$('date').max;
synastry=createSynastry(()=>({valid:!!result&&!!natalPayload&&$('stale').hidden,payload:natalPayload}),()=>{if(result)render(result,false);$('transit-caption').hidden=true;},setTab);
rectification=createRectification(()=>({valid:!!result&&!!natalPayload&&$('stale').hidden,payload:natalPayload,chart:result}),data=>render(data,false),setTab);
createLibrary(librarySnapshot,openLibrarySession);

$('house-system').addEventListener('change',async()=>{
  const value=$('house-system').value;
  if(!result||!natalPayload||!$('stale').hidden){$('stale').hidden=!result;return;}
  const old=natalPayload.house_system||'P',workspace=document.querySelector('.workspace');
  const draft=Object.fromEntries(['rect-event-label','rect-event-date'].map(id=>[id,$(id).value]));
  const activeTab=document.querySelector('[role=tab][aria-selected=true]')?.id;
  const panels=Object.fromEntries(['birth-editor','mode-picker','chart-settings','rect-manual','kundig-tools'].map(id=>[id,$(id).open]));
  const hadComparison=$('rect-comparison').childElementCount>0,scrollPosition=[scrollX,scrollY];
  try{
    const current=librarySnapshot();current.birth.house_system=value;workspace.inert=true;
    await openLibrarySession(current);
    for(const [id,value] of Object.entries(draft))$(id).value=value;
    for(const [id,open] of Object.entries(panels))$(id).open=open;
    if(activeTab&&!$(activeTab).hidden)setTab($(activeTab),false);
    if(hadComparison&&current.mode==='rectify')$('rect-compare').click();
    scrollTo(...scrollPosition);
  }catch(error){$('house-system').value=old;showError(error.message);}
  finally{workspace.inert=false;}
});

function applyFamousRecord(record){
  const birth={...archiveBirth(record,$('include-dwarfs').checked),house_system:$('house-system').value};
  clearTimeout(searchTimer);searchAbort?.abort();selected=null;markChanged();
  fillBirthForm('',birth,{place:{name:birth.place_name,latitude:birth.latitude,longitude:birth.longitude,timezone:'UTC'}});
  $('place-hint').textContent=`${record.place==='Ikke angivet'?'Bynavn mangler i arkivet':record.place} · ${record.latitude.toFixed(5)}°, ${record.longitude.toFixed(5)}° · arkivzone ${record.zone}`;
  $('birth-summary').textContent=`${record.name} · ${record.date} · ${birth.time||'tid ukendt'}`;
  $('birth-editor').open=true;
}
famousPicker=createFamousPicker(applyFamousRecord);
initNavigation();
setTechniqueVisibility();
transitNow();
const params=new URLSearchParams(location.search);
if(params.get('embed')==='1')document.body.classList.add('embedded');
const parents=new Set(['https://stjernerne.dk','https://www.stjernerne.dk','https://stjernerne.io','https://www.stjernerne.io',location.origin]);
const parentOrigin=params.get('parent');
if(window.parent!==window&&parents.has(parentOrigin)){
  const shell=document.querySelector('.shell');
  const notifyParent=type=>{
    const height=Math.ceil(shell.getBoundingClientRect().height)+8;
    if(Number.isFinite(height)&&height>0)window.parent.postMessage({type,height},parentOrigin);
  };
  window.addEventListener('message',event=>{
    if(event.origin===parentOrigin&&event.source===window.parent&&event.data?.type==='stjernerne:hello')notifyParent('stjernerne:ready');
  });
  // Readiness is explicit; ResizeObserver may wait while an iframe is concealed.
  notifyParent('stjernerne:ready');
  let previous=0;
  new ResizeObserver(()=>{const height=Math.ceil(shell.getBoundingClientRect().height)+8;if(height!==previous){previous=height;notifyParent('stjernerne:resize');}}).observe(shell);
}
async function openLinkedPerson(id){
  $('chart-label').textContent='VALGT PERSON';$('chart-meta').textContent='';$('wheel').replaceChildren(create('p','Horoskopet vises, når fødselsoplysningerne er klar.','loading'));
  $('result-status').textContent='Henter personens fødselsoplysninger …';
  try{
    const response=await fetch('/static/famous-danes.json');if(!response.ok)throw Error('Fødselsoplysningerne kunne ikke hentes. Prøv at genindlæse siden.');
    const records=await response.json(),record=records.find(r=>r.id===id);
    if(!record)throw Error('Personen findes ikke i oversigten. Vælg en person under Vælg en kendt dansker.');
    applyFamousRecord(record);
    $('chart-label').textContent=record.name;$('chart-meta').textContent=`${record.date} · ${record.rating.startsWith('X')?'fødselstid ukendt':record.time}`;
    $('famous-applied').hidden=false;
    $('famous-applied').textContent=`${record.name} · rating ${record.rating}. ${record.rating.startsWith('X')?'Fødselstiden er ukendt; klokkeslættet er ikke udfyldt.':'Fødselsoplysningerne er indsat fra Stjernernes fødselsdata.'}`;
    if(record.rating.startsWith('X')){$('result-status').textContent='Horoskopet er ikke beregnet: fødselstiden er ukendt.';$('time').focus();}
    else await submit();
  }catch(e){showError(e.message);$('result-status').textContent='Personens horoskop kunne ikke åbnes.';}
}
if(params.has('person'))openLinkedPerson(params.get('person'));else submit(true);
