import {createSynastry} from './synastry.js';
import {renderWheel,dms} from './wheel.js';
import {createPlayer,nextTransitTime} from './playback.js';
const $=id=>document.getElementById(id);
const create=(tag,text,className)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(className)e.className=className;return e;};
let selected={id:'2618425',name:'København',country:'Denmark',latitude:55.67594,longitude:12.56553,timezone:'Europe/Copenhagen'};
let synastry=null;
let result=null,revision=0,searchAbort=null,searchTimer=null;
let derivedResult=null,techniqueSerial=0,techniqueAbort=null,returnPlace=null,returnSearchTimer=null,returnSearchAbort=null;
let natalPayload=null,transitResult=null,transitAspect=null,transitSerial=0,transitAbort=null,transitTimer=null;
const player=createPlayer(playbackFrame,active=>{
  $('transit-play').textContent=active?'Ⅱ Pause':'▶ Afspil';
  $('transit-play').setAttribute('aria-pressed',String(active));
  $('playback-status').textContent=active?'Afspiller · ét skridt ca. hvert 1,2 sekund.':'Afspilningen er sat på pause.';
  if(!active){transitSerial++;transitAbort?.abort();}
});
const phaseNames={applying:'Nærmer sig',separating:'Aftager',exact:'Eksakt',stationary:'Næsten stationær'};
const today=new Date();$('date').max=`${today.getFullYear()}-${String(today.getMonth()+1).padStart(2,'0')}-${String(today.getDate()).padStart(2,'0')}`;
function markChanged(resetFold=true){revision++;resetTechnique();clearTransit();$('stale').hidden=!result;$('download').disabled=true;$('error').hidden=true;if(resetFold){$('fold-panel').hidden=true;$('fold').value='';}}
function placeHint(p){$('place-hint').textContent=`${p.name} · ${p.latitude.toFixed(5)}°, ${p.longitude.toFixed(5)}° · ${p.timezone}`;}
function pick(p){selected=p;$('place-search').value=`${p.name}, ${p.country}`;$('place-results').hidden=true;placeHint(p);markChanged();$('place-search').focus();}
$('place-search').addEventListener('input',()=>{
  selected=null;markChanged();$('place-hint').textContent='Vælg et præcist sted fra søgeresultaterne.';
  clearTimeout(searchTimer);searchAbort?.abort();$('place-results').hidden=true;
  const q=$('place-search').value.trim();if(q.length<2)return;
  searchTimer=setTimeout(async()=>{
    const controller=new AbortController();searchAbort=controller;
    try{
      const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});
      if(!response.ok)throw Error('Bysøgningen kunne ikke gennemføres. Prøv igen.');
      const places=await response.json();if($('place-search').value.trim()!==q)return;
      const list=$('place-results');list.replaceChildren();
      if(!places.length)list.append(create('li','Ingen resultater. Prøv et andet navn, eller angiv stedet manuelt.','empty'));
      for(const p of places){const li=create('li'),button=create('button',p.name);button.type='button';button.append(create('small',`${p.country} · region ${p.region} · ${p.latitude.toFixed(2)}°, ${p.longitude.toFixed(2)}° · ${p.timezone}`));button.addEventListener('click',()=>pick(p));li.append(button);list.append(li);}list.hidden=false;
    }catch(e){if(e.name!=='AbortError'){$('place-hint').textContent=e.message;}}
  },230);
});
$('place-search').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('place-results').querySelector('button')?.focus();}if(e.key==='Escape')$('place-results').hidden=true;});
$('place-results').addEventListener('keydown',e=>{const buttons=[...$('place-results').querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(['ArrowDown','ArrowUp'].includes(e.key)){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length]?.focus();}if(e.key==='Escape'){$('place-results').hidden=true;$('place-search').focus();}});
document.addEventListener('click',e=>{if(!e.target.closest('.search-wrap'))$('place-results').hidden=true;});
$('manual-place').addEventListener('change',()=>{$('manual-fields').disabled=!$('manual-place').checked;$('place-search').disabled=$('manual-place').checked;for(const id of ['latitude','longitude','timezone'])$(id).required=$('manual-place').checked;});
$('manual-offset').addEventListener('change',()=>{$('offset-fields').disabled=!$('manual-offset').checked;for(const id of ['offset-minutes','offset-source'])$(id).required=$('manual-offset').checked;});
$('birth-form').addEventListener('input',e=>{if(e.target.id!=='place-search')markChanged(e.target.id!=='fold');});
function showError(message){$('error').textContent=message;$('error').hidden=false;}
function requestData(){
  const payload={date:$('date').value,time:$('time').value,include_dwarfs:$('include-dwarfs').checked};
  if($('manual-place').checked){
    if($('latitude').value===''||$('longitude').value==='')throw Error('Udfyld begge koordinater.');
    Object.assign(payload,{place_name:$('manual-name').value,latitude:Number($('latitude').value),longitude:Number($('longitude').value),timezone:$('timezone').value.trim()});
  }else{if(!selected)throw Error('Vælg dit fødested fra søgeresultaterne.');payload.place_id=selected.id;}
  if(!$('fold-panel').hidden&&$('fold').value!=='')payload.fold=Number($('fold').value);
  if($('manual-offset').checked){if($('offset-minutes').value==='')throw Error('Angiv UTC-forskellen.');payload.offset_minutes=Number($('offset-minutes').value);payload.offset_source=$('offset-source').value.trim();}
  return payload;
}
async function submit(example=false){
  $('error').hidden=true;let payload;try{payload=requestData();}catch(e){showError(e.message);return;}
  const generation=revision;resetTechnique();clearTransit();$('calculate').disabled=true;$('calculate').textContent='Beregner dit stjernekort …';$('result-status').textContent='Beregner horoskop.';
  try{
    const response=await fetch('/api/chart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(15000)});
    const data=await response.json();if(generation!==revision)return;
    if(!response.ok){
      if(data.error?.code==='ambiguous_time'){
        $('fold-panel').hidden=false;$('fold').replaceChildren(new Option('Vælg forekomst …',''));
        data.error.choices.forEach((c,i)=>$('fold').add(new Option(`${i===0?'Første':'Anden'} · UTC${c.offset_minutes>=0?'+':''}${c.offset_minutes/60} · ${c.abbreviation}`,String(c.fold))));
        $('fold').focus();
      }
      throw Error(data.error?.message||'Beregningen kunne ikke gennemføres.');
    }
    clearTransit();natalPayload=payload;result=data;render(data,example);$('stale').hidden=true;$('download').disabled=false;$('result-status').textContent='Dit horoskop er beregnet. Hjul, positioner og aspekter er klar.';if($('show-transits').checked)updateTransits();
  }catch(e){if(generation===revision){showError(e.name==='TimeoutError'?'Beregningen tog for lang tid. Prøv igen.':e.message==='Failed to fetch'?'Serveren svarer ikke. Kontrollér, at den lokale app kører.':e.message);$('result-status').textContent='Beregningen kunne ikke gennemføres.';if(!result)$('wheel').replaceChildren(create('p','Indtast fødselsoplysninger og beregn dit horoskop.','loading'));}}
  finally{$('calculate').disabled=false;$('calculate').replaceChildren(document.createTextNode('Se mit fødselshoroskop '),create('span','↗'));}
}
$('birth-form').addEventListener('submit',e=>{e.preventDefault();submit();});
function render(data,example){
  $('chart-title').textContent=data.display_title||'Dit fødselshoroskop';
  $('chart-label').textContent=`${data.chart_type?'DIT '+(data.chart_type==='solar'?'SOLRETURHOROSKOP':'PROGRESSIONSHOROSKOP'):example?'EKSEMPEL':'DIT STJERNEKORT'} · ${data.place.name.toLocaleUpperCase('da')}`;
  const local=data.birth.local.slice(0,19),date=new Date(local+'Z');
  $('chart-meta').textContent=`${new Intl.DateTimeFormat('da-DK',{dateStyle:'long',timeZone:'UTC'}).format(date)} · kl. ${local.slice(11)} · ${data.place.name}`;
  if(data.chart_type==='progressed')$('chart-meta').textContent=`For ${data.technique.target.local.slice(0,10)} · ${data.place.name} · Naibod-akser`;
  $('wheel').replaceChildren(renderWheel(data));
  const sun=data.planets.find(p=>p.id==='sun'),moon=data.planets.find(p=>p.id==='moon');
  $('big-three').replaceChildren(...[['SOL',sun],['MÅNE',moon],['ASCENDANT',data.ascendant]].map(([name,p])=>{const card=create('div'),v=dms(p.longitude);card.append(create('small',name),create('strong',v.sign),create('span',v.short,'degree'));return card;}));
  $('planet-rows').replaceChildren(...data.planets.map(p=>{const row=create('tr'),name=create('td');name.append(create('span',p.glyph,'planet-glyph'),document.createTextNode(p.name));row.append(name,create('td',`${dms(p.longitude).full} ${dms(p.longitude).sign}`),create('td',String(p.house)),create('td',p.retrograde?'℞ Retrograd':'Direkte'));return row;}));
  $('house-rows').replaceChildren(...data.houses.map(h=>{const row=create('tr');row.append(create('td',String(h.number)),create('td',`${dms(h.longitude).full} ${dms(h.longitude).sign}`));return row;}));
  const names=Object.fromEntries(data.planets.map(p=>[p.id,p.name]));
  $('aspect-rows').replaceChildren(...data.aspects.map(a=>{const row=create('tr');row.append(create('td',`${names[a.a]} · ${names[a.b]}`),create('td',`${a.label} ${a.angle}°`),create('td',dms(a.orb).full));return row;}));
  $('warnings').replaceChildren(...data.birth.warnings.map(w=>create('p',w)));$('warnings').hidden=!data.birth.warnings.length;
  const dl=create('dl');for(const [key,value] of Object.entries({'Fødested':`${data.place.name} · ${data.place.latitude}°, ${data.place.longitude}°`,'Horoskopets lokale efemeridetid':data.birth.local,'UTC':data.birth.utc,'Tidszone':data.birth.timezone,'Tidsforskel':`${data.birth.offset_minutes} minutter`,'Tidskilde':data.birth.source==='manual'?data.birth.source_note:`IANA ${data.birth.iana_version}`,'Beregning':`Swiss Ephemeris ${data.calculation.version} · DE441`,'Indstillinger':'Tropisk · geocentrisk · Placidus · True Node'+(data.chart_type==='progressed'?' · Naibod i rektascension':''),'Juliansk dag (TT)':data.calculation.jd_tt.toFixed(8),'Juliansk dag (UT1)':data.calculation.jd_ut1.toFixed(8)})){dl.append(create('dt',key),create('dd',String(value)));}$('calculation-details').replaceChildren(dl);
}
function setTab(button){for(const t of document.querySelectorAll('[role=tab]')){const on=t===button;t.setAttribute('aria-selected',String(on));t.tabIndex=on?0:-1;$('panel-'+t.dataset.tab).hidden=!on;}button.focus();}
for(const button of document.querySelectorAll('[role=tab]')){button.addEventListener('click',()=>setTab(button));button.addEventListener('keydown',e=>{const tabs=[...document.querySelectorAll('[role=tab]')].filter(t=>!t.hidden),i=tabs.indexOf(button);if(['ArrowLeft','ArrowRight','Home','End'].includes(e.key)){e.preventDefault();setTab(tabs[e.key==='Home'?0:e.key==='End'?tabs.length-1:(i+(e.key==='ArrowRight'?1:-1)+tabs.length)%tabs.length]);}});}
$('download').addEventListener('click',()=>{if(!result)return;const svg=$('wheel svg')||$('wheel').querySelector('svg');const markup=new XMLSerializer().serializeToString(svg);const url=URL.createObjectURL(new Blob([markup],{type:'image/svg+xml'})),a=create('a');a.href=url;a.download=`stjernerne-${$('chart-mode').value==='synastry'?'synastri':derivedResult?.chart_type||'foedselshoroskop'}.svg`;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);});

function drawTransit(){
  if(synastry?.data&&$('chart-mode').value==='synastry'){synastry.draw();return;}
  if(result)$('wheel').replaceChildren(renderWheel(derivedResult||result,derivedResult?null:transitResult,derivedResult?null:transitAspect));
  $('transit-caption').hidden=!transitResult;
  if(transitResult){
    const names=Object.fromEntries(result.planets.map(p=>[p.id,p.name]));
    $('transit-caption').textContent='Ydre ring: transitter · Indre ring: dit fødselshoroskop'+(transitAspect?` — ${names[transitAspect.transit]} i transit: ${transitAspect.label.toLowerCase()} til ${names[transitAspect.natal]} i fødselshoroskopet · orb ${dms(transitAspect.orb).full}`:'');
  }
}
function clearTransit(){
  player.stop();
  transitSerial++;transitAbort?.abort();clearTimeout(transitTimer);transitResult=null;transitAspect=null;
  $('transit-rows').replaceChildren();$('transit-table').hidden=true;$('transit-caption').hidden=true;
  $('transit-error').hidden=true;$('transit-status').textContent='';
  $('transit-intro').textContent=$('show-transits').checked?'Beregn fødselshoroskopet, og vælg et transittidspunkt.':'Slå “Vis transitter” til for at sammenligne himlen med dit fødselshoroskop.';
  drawTransit();
}
function transitNow(){
  const parts=Object.fromEntries(new Intl.DateTimeFormat('sv-SE',{timeZone:$('transit-zone').value,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'}).formatToParts(new Date()).map(p=>[p.type,p.value]));
  $('transit-date').value=`${parts.year}-${parts.month}-${parts.day}`;$('transit-time').value=`${parts.hour}:${parts.minute}:${parts.second}`;
}
function scheduleTransits(resetFold=true){
  clearTransit();
  if(resetFold){$('transit-fold-panel').hidden=true;$('transit-fold').value='';}
  transitTimer=setTimeout(()=>updateTransits(),220);
}
async function updateTransits(playbackTime=null){
  const animated=playbackTime!==null;
  if(animated){transitSerial++;transitAbort?.abort();clearTimeout(transitTimer);$('transit-error').hidden=true;}
  else clearTransit();
  if(!$('show-transits').checked)return;
  if(!result||!natalPayload||!$('stale').hidden){$('transit-status').textContent='Beregn først fødselshoroskopet med dine aktuelle oplysninger.';return;}
  if(!$('transit-form').reportValidity())return;
  const generation=transitSerial, birthRevision=revision;
  transitAbort=new AbortController();const controller=transitAbort;
  const deadline=setTimeout(()=>controller.abort(),15000);
  const transit={...(playbackTime||{date:$('transit-date').value,time:$('transit-time').value}),timezone:$('transit-zone').value};
  if(!animated&&!$('transit-fold-panel').hidden&&$('transit-fold').value!=='')transit.fold=Number($('transit-fold').value);
  if(!animated){$('transit-status').textContent='Beregner transitter …';$('transit-intro').textContent='Beregner transitter …';}
  try{
    const response=await fetch('/api/transits',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({birth:natalPayload,transit}),signal:controller.signal});
    const data=await response.json();if(generation!==transitSerial||birthRevision!==revision)return;
    if(!response.ok){
      if(animated){$('transit-date').value=transit.date;$('transit-time').value=transit.time;transitResult=null;transitAspect=null;drawTransit();$('transit-rows').replaceChildren();$('transit-table').hidden=true;}
      if(data.error?.code==='ambiguous_time'){
        $('transit-fold-panel').hidden=false;$('transit-fold').replaceChildren(new Option('Vælg forekomst …',''));
        data.error.choices.forEach((c,i)=>$('transit-fold').add(new Option(`${i===0?'Første':'Anden'} · UTC${c.offset_minutes>=0?'+':''}${c.offset_minutes/60} · ${c.abbreviation}`,String(c.fold))));
      }
      throw Error(data.error?.code==='nonexistent_time'?'Transittidspunktet findes ikke på grund af skift til sommertid. Vælg et andet klokkeslæt, og tryk Opdatér.':data.error?.message||'Transitterne kunne ikke beregnes.');
    }
    const previousAspect=transitAspect;
    transitResult=data;transitAspect=data.aspects.find(a=>a.transit===previousAspect?.transit&&a.natal===previousAspect?.natal&&a.type===previousAspect?.type)||data.aspects[0]||null;
    if(animated){$('transit-date').value=transit.date;$('transit-time').value=transit.time;$('transit-fold-panel').hidden=true;$('transit-fold').value='';}
    const local=data.timing.local;
    const stamp=`${new Intl.DateTimeFormat('da-DK',{dateStyle:'long',timeZone:'UTC'}).format(new Date(local.slice(0,10)+'T12:00:00Z'))} · kl. ${local.slice(11,19)} · ${data.timing.timezone} (UTC${local.slice(-6)})`;
    $('transit-status').textContent=stamp+(data.timing.warnings.length?' · '+data.timing.warnings.join(' '):'');
    $('transit-intro').textContent=data.aspects.length?`${data.aspects.length} aspekter til dit fødselshoroskop · ${stamp}`:'Ingen hovedaspekter inden for den valgte orb på dette tidspunkt.';
    $('transit-table').hidden=!data.aspects.length;
    const names=Object.fromEntries(result.planets.map(p=>[p.id,p.name]));
    $('transit-rows').replaceChildren(...data.aspects.map(a=>{
      const row=create('tr'),pair=create('td'),button=create('button',`${names[a.transit]} → ${names[a.natal]}`,'transit-link');button.type='button';
      button.setAttribute('aria-label',`Vis ${names[a.transit]} i transit ${a.label.toLowerCase()} til fødslens ${names[a.natal]} i hjulet`);
      button.addEventListener('click',()=>{transitAspect=a;drawTransit();setTab($('tab-wheel'));});pair.append(button);
      const aspect=create('td',a.label);aspect.append(create('small',dms(a.orb).full));
      row.append(pair,aspect,create('td',phaseNames[a.phase]));return row;
    }));drawTransit();return true;
  }catch(e){if(generation===transitSerial&&birthRevision===revision){$('transit-status').textContent='';$('transit-intro').textContent='Transitterne kunne ikke beregnes.';$('transit-error').hidden=false;$('transit-error').textContent=e.name==='AbortError'?'Serveren svarede ikke i tide. Prøv igen.':e.message;}}
  finally{clearTimeout(deadline);}
}
async function playbackFrame(){
  if(document.hidden||!$('show-transits').checked||!$('stale').hidden||!transitResult)return false;
  const next=nextTransitTime($('transit-date').value,$('transit-time').value,Number($('playback-step').value)*Number($('playback-direction').value));
  if(!next){player.stop();$('playback-status').textContent='Afspilningen er stoppet ved datogrænsen (1900–2099).';return false;}
  return await updateTransits(next);
}
$('transit-play').addEventListener('click',()=>{
  if(player.active){player.stop();return;}
  if(!transitResult||!$('stale').hidden){$('playback-status').textContent='Beregn først et gyldigt fødselshoroskop og transittidspunkt.';return;}
  setTab($('tab-wheel'));$('transit-play').focus();player.start();
});
for(const id of ['transit-date','transit-time','transit-zone','transit-fold','playback-step','playback-direction'])$(id).addEventListener('input',()=>player.stop());
document.addEventListener('visibilitychange',()=>{if(document.hidden)player.stop();});
$('show-transits').addEventListener('change',()=>{$('transit-tools').hidden=!$('show-transits').checked;if($('show-transits').checked)updateTransits();else clearTransit();});
$('transit-form').addEventListener('submit',e=>{e.preventDefault();updateTransits();});
for(const id of ['transit-date','transit-time','transit-zone'])$(id).addEventListener('change',()=>scheduleTransits());
$('transit-fold').addEventListener('change',()=>scheduleTransits(false));
$('transit-now').addEventListener('click',()=>{transitNow();scheduleTransits();});
for(const button of document.querySelectorAll('[data-days]'))button.addEventListener('click',()=>{
  const date=new Date($('transit-date').value+'T12:00:00Z');if(Number.isNaN(date.getTime()))return;
  date.setUTCDate(date.getUTCDate()+Number(button.dataset.days));const value=date.toISOString().slice(0,10);
  if(value<'1900-01-01'||value>'2099-12-31')return;
  $('transit-date').value=value;scheduleTransits();
});

function setTechniqueVisibility(){
  const mode=$('chart-mode').value;
  $('technique-form').hidden=!['solar','progressed'].includes(mode);
  $('synastry-controls').hidden=mode!=='synastry';$('tab-synastry').hidden=mode!=='synastry';
  $('tab-positions').hidden=mode==='synastry';$('tab-aspects').hidden=mode==='synastry';$('solar-fields').hidden=mode!=='solar';$('progress-fields').hidden=mode!=='progressed';
  $('return-year').required=mode==='solar';$('return-year').disabled=mode!=='solar';
  for(const id of ['progress-date','progress-time']){$(id).required=mode==='progressed';$(id).disabled=mode!=='progressed';}
  document.querySelector('.transit-controls').hidden=mode!=='natal';$('tab-transits').hidden=mode!=='natal';
  $('technique-method').textContent=mode==='solar'?'Det øjeblik, hvor Solen vender tilbage til fødselshoroskopets tropiske længdegrad. Stedet bestemmer solreturens akser og huse.':'Direkte progression: 1 dag efter fødslen = 1 år (365,2422 dage). Akser og Placidus-huse: Naibod i rektascension. Mål-tidspunkt angives i UTC.';
}
function clearTechnique(){
  synastry?.clear();
  techniqueSerial++;techniqueAbort?.abort();derivedResult=null;$('technique-error').hidden=true;$('technique-status').textContent='';
  if(result)render(result,false);
}
function resetTechnique(){
  clearTechnique();$('chart-mode').value='natal';setTechniqueVisibility();
}
$('chart-mode').addEventListener('change',()=>{
  clearTechnique();clearTransit();setTechniqueVisibility();setTab($('tab-wheel'));
  if($('chart-mode').value==='natal'){$('download').disabled=!result||!$('stale').hidden;if($('show-transits').checked)updateTransits();}
  else $('technique-status').textContent=$('chart-mode').value==='synastry'?'':'Vælg indstillinger, og tryk Beregn horoskop. Hjulet viser indtil da fødselshoroskopet.';
});
$('technique-form').addEventListener('input',()=>{clearTechnique();$('download').disabled=true;$('technique-status').textContent='Indstillinger ændret. Beregn igen; hjulet viser fødselshoroskopet.';});
$('return-birthplace').addEventListener('change',()=>{$('return-place-fields').hidden=$('return-birthplace').checked;});
$('return-place').addEventListener('input',()=>{
  returnPlace=null;clearTimeout(returnSearchTimer);returnSearchAbort?.abort();$('return-results').hidden=true;$('return-place-hint').textContent='Vælg et sted fra søgeresultaterne.';
  const q=$('return-place').value.trim();if(q.length<2)return;
  returnSearchTimer=setTimeout(async()=>{
    const controller=new AbortController();returnSearchAbort=controller;
    try{
      const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});
      if(!response.ok)throw Error('Bysøgningen kunne ikke gennemføres.');
      const places=await response.json();if($('return-place').value.trim()!==q)return;
      $('return-results').replaceChildren();
      for(const p of places){const li=create('li'),b=create('button',`${p.name} · ${p.country} · ${p.timezone}`);b.type='button';
        b.addEventListener('click',()=>{clearTechnique();returnPlace=p;$('return-place').value=`${p.name}, ${p.country}`;$('return-results').hidden=true;$('return-place-hint').textContent=`${p.latitude}°, ${p.longitude}° · ${p.timezone}`;});li.append(b);$('return-results').append(li);}
      if(!places.length)$('return-results').append(create('li','Ingen resultater. Prøv et andet bynavn.','empty'));
      $('return-results').hidden=false;
    }catch(e){if(e.name!=='AbortError')$('return-place-hint').textContent=e.message;}
  },230);
});
$('return-place').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){$('return-results').querySelector('button')?.focus();e.preventDefault();}if(e.key==='Escape')$('return-results').hidden=true;});
$('technique-form').addEventListener('submit',async e=>{
  e.preventDefault();clearTechnique();clearTransit();
  if(!result||!natalPayload||!$('stale').hidden){$('technique-error').textContent='Beregn først fødselshoroskopet med dine aktuelle oplysninger.';$('technique-error').hidden=false;return;}
  const mode=$('chart-mode').value,payload={birth:natalPayload,mode};
  if(mode==='solar'){
    payload.year=Number($('return-year').value);
    if(!$('return-birthplace').checked){if(!returnPlace){$('technique-error').textContent='Vælg solretursted fra søgeresultaterne.';$('technique-error').hidden=false;return;}payload.location={place_id:returnPlace.id};}
  }else payload.target={date:$('progress-date').value,time:$('progress-time').value,timezone:'UTC'};
  const generation=techniqueSerial,birthRevision=revision;
  const controller=new AbortController();techniqueAbort=controller;const timer=setTimeout(()=>controller.abort(),15000);
  $('calculate-technique').disabled=true;$('download').disabled=true;$('technique-status').textContent='Beregner …';
  try{
    const response=await fetch('/api/technique',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:controller.signal});
    const data=await response.json();if(generation!==techniqueSerial||birthRevision!==revision)return;
    if(!response.ok)throw Error(data.error?.message||'Horoskopet kunne ikke beregnes.');
    derivedResult=data;render(data,false);$('download').disabled=false;setTab($('tab-wheel'));
    $('technique-status').textContent=mode==='solar'?`Solretur: ${data.birth.local.slice(0,19).replace('T',' kl. ')} · ${data.birth.timezone} · ${data.place.name}.`:`Progression til ${payload.target.date} kl. ${payload.target.time} UTC. Efemeridetid: ${data.technique.progressed_utc.slice(0,19).replace('T',' kl. ')} UTC · ${data.technique.age_years.toFixed(4)} år · Naibod-akser.`;
  }catch(error){if(generation===techniqueSerial&&birthRevision===revision){$('technique-status').textContent='Hjulet viser fødselshoroskopet.';$('technique-error').hidden=false;$('technique-error').textContent=error.name==='AbortError'?'Beregningen tog for lang tid. Prøv igen.':error.message;}}
  finally{clearTimeout(timer);$('calculate-technique').disabled=false;}
});
$('return-year').value=String(today.getFullYear());$('progress-date').value=$('date').max;
synastry=createSynastry(()=>({valid:!!result&&!!natalPayload&&$('stale').hidden,payload:natalPayload}),()=>{if(result)render(result,false);$('transit-caption').hidden=true;},setTab);
setTechniqueVisibility();
transitNow();
const params=new URLSearchParams(location.search);
if(params.get('embed')==='1')document.body.classList.add('embedded');
const parents=new Set(['https://stjernerne.dk','https://www.stjernerne.dk','https://stjernerne.io','https://www.stjernerne.io',location.origin]);
const parentOrigin=params.get('parent');
if(window.parent!==window&&parents.has(parentOrigin)){
  let previous=0;
  new ResizeObserver(()=>{const height=Math.ceil(document.querySelector('.shell').getBoundingClientRect().height)+8;if(height!==previous){previous=height;window.parent.postMessage({type:'stjernerne:resize',height},parentOrigin);}}).observe(document.querySelector('.shell'));
}
submit(true);
