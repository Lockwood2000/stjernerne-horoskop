import {planetSymbol} from './symbols.js';
const NS='http://www.w3.org/2000/svg';
export const signs=["Aries","Taurus","Gemini","Cancer","Leo","Virgo","Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];
const glyphs=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
const mod360=value=>((value%360)+360)%360;
export function cuspDirection(houses){
  if(houses.length!==12||houses.some(h=>!Number.isFinite(h.longitude)))throw new Error('Invalid house cusps.');
  const total=direction=>houses.reduce((sum,h,i)=>sum+mod360((houses[(i+1)%12].longitude-h.longitude)*direction),0);
  if(Math.abs(total(1)-360)<=1e-6)return 1;
  if(Math.abs(total(-1)-360)<=1e-6)return -1;
  throw new Error('Invalid house cusps.');
}
export function houseMidpoints(houses){
  if(!houses.length)return [];
  const direction=cuspDirection(houses);
  return houses.map((h,i)=>mod360(h.longitude+direction*mod360((houses[(i+1)%12].longitude-h.longitude)*direction)/2));
}
export function dms(lon){
  const seconds=((Math.round(lon*3600)%(360*3600))+360*3600)%(360*3600);
  const sign=Math.floor(seconds/(30*3600)), degree=Math.floor(seconds/3600)%30;
  const minutes=Math.floor(seconds/60)%60, sec=seconds%60;
  return {sign:signs[sign],short:`${degree}°${String(minutes).padStart(2,'0')}′`,full:`${degree}°${String(minutes).padStart(2,'0')}′${String(sec).padStart(2,'0')}″`};
}
export function spreadLabels(planets,gap=11){
  const ordered=planets.map(p=>({...p,display:p.longitude})).sort((a,b)=>a.display-b.display);
  let cut=0,maxGap=-1;
  for(let i=0;i<ordered.length;i++){const next=(i+1)%ordered.length;const g=(ordered[next].display-ordered[i].display+360)%360;if(g>maxGap){maxGap=g;cut=next;}}
  const rotated=ordered.slice(cut).concat(ordered.slice(0,cut));
  for(let i=1;i<rotated.length;i++)while(rotated[i].display<rotated[i-1].display)rotated[i].display+=360;
  const originals=rotated.map(p=>p.display);
  // Merge overlapping clusters; keep each cluster centered on its true positions.
  let groups=rotated.map((p,i)=>({indices:[i],center:originals[i]}));
  for(let i=0;i<groups.length-1;){
    const a=groups[i],b=groups[i+1];
    if(b.center-(b.indices.length-1)*gap/2-(a.center+(a.indices.length-1)*gap/2)<gap){
      const indices=a.indices.concat(b.indices);
      groups.splice(i,2,{indices,center:indices.reduce((s,k)=>s+originals[k],0)/indices.length});i=Math.max(0,i-1);
    }else i++;
  }
  for(const group of groups)group.indices.forEach((k,i)=>rotated[k].display=group.center+(i-(group.indices.length-1)/2)*gap);
  return rotated;
}
function element(tag,attrs={},text){const el=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))el.setAttribute(k,String(v));if(text!==undefined)el.textContent=text;return el;}
export function renderWheel(data,transit=null,selectedAspect=null){
  const syn=transit?.kind==='synastry',prog=transit?.kind==='progressed';
  const svg=element('svg',{viewBox:transit?'-85 -85 1050 1050':'0 0 880 880',xmlns:NS,role:'img','aria-labelledby':'wheel-title wheel-desc'});
  svg.append(element('title',{id:'wheel-title'},`${data.display_title||'Birth chart'} · ${data.place.name} · ${data.birth.local}${transit?(syn?' · Synastry · Person '+transit.person+' · ':prog?' · Progressions ':' · Transits ')+transit.timing.local:''}`),element('desc',{id:'wheel-desc'},"Tropical chart wheel with Placidus houses. Round markers show planets; connecting lines point to their exact longitudes. The sickle is Ceres, Er is Eris, Ha is Haumea, Mk is Makemake. The key symbol is Chiron."));
  const center=440,asc=data.ascendant.longitude;
  const point=(lon,r)=>{const a=(180-lon+asc)*Math.PI/180;return [center+r*Math.cos(a),center+r*Math.sin(a)];};
  const add=(tag,attrs,text)=>{const el=element(tag,attrs,text);svg.append(el);return el;};
  const line=(a,b,color,width=1,extra={})=>add('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:color,'stroke-width':width,...extra});
  const txt=(lon,r,text,attrs={})=>{const [x,y]=point(lon,r);return add('text',{x,y,'text-anchor':'middle','dominant-baseline':'middle','font-family':'Nunito Sans,Arial,sans-serif',fill:'#435a48',...attrs},text);};
  const circle=(r,fill,stroke,width=1)=>add('circle',{cx:center,cy:center,r,fill,stroke,'stroke-width':width});
  circle(transit?515:412,'#fffdf8','#c8cdbd',1);
  if(transit){circle(511,syn?'#e9e1ee':'#f1e2d4','none');circle(426,'#fffdf8','#c9b29a',.8);}
  circle(405,'#fffdf8','#aebca9',1.4);
  const fills=['#f1dfd2','#e5e9dc','#eee5ed','#e0eae4'];
  const colors=['#996047','#737247','#836780','#487567'];
  for(let i=0;i<12;i++){
    const a=point(i*30,402),b=point((i+1)*30,402),c=point((i+1)*30,347),d=point(i*30,347);
    add('path',{d:`M${a} A402 402 0 0 0 ${b} L${c} A347 347 0 0 1 ${d} Z`,fill:fills[i%4],stroke:'#fffdf8','stroke-width':1.5});
    txt(i*30+15,376,glyphs[i]+'\uFE0E',{'font-size':31,fill:colors[i%4],'font-family':'Arial,sans-serif'});
  }
  for(const r of [347,335,250,205])circle(r,'none',r===205?'#c6d0bc':'#d1d9c9',r===205?1.1:.7);
  circle(204,'#f9faf5','none');
  for(let d=0;d<360;d++)line(point(d,d%5===0?324:329),point(d,335),d%30===0?'#526c50':'#9aa98e',d%5===0?1:.5);
  const houseCenters=houseMidpoints(data.houses);
  for(let i=0;i<12;i++){
    const h=data.houses[i],lon=h.longitude;
    line(point(lon,205),point(lon,347),[0,3,6,9].includes(i)?'#839776':'#c4ceb9',[0,3,6,9].includes(i)?1.7:.8);
    txt(houseCenters[i],228,String(i+1),{'font-size':16,fill:'#68795c','data-house-label':i+1});
  }
  const byId=Object.fromEntries(data.planets.map(p=>[p.id,p]));
  byId.ascendant=data.ascendant;byId.midheaven=data.midheaven;
  for(const a of data.aspects){
    if(a.type==='conjunction')continue;
    line(point(byId[a.a].longitude,204),point(byId[a.b].longitude,204),['trine','sextile'].includes(a.type)?'#62887c':'#ba836d',a.orb<2?1.3:.8,{'stroke-opacity':transit?.2:a.orb<2?.66:.3});
  }
  function badge(p,r,size,kind){
    const [x,y]=point(p.display,r),minor=['ceres','eris','haumea','makemake','chiron'].includes(p.id);
    const color=kind==='transit'?'#815036':minor?'#79634b':'#244a3c';
    const g=add('g',{'data-body':p.id,...(kind==='transit'?{[syn?'data-synastry':'data-transit']:p.id}:{})});
    g.append(element('circle',{cx:x,cy:y,r:size/2+5,fill:kind==='transit'?'#fff6eb':minor?'#f5eddf':'#f0f5e9',stroke:kind==='transit'?'#c6a281':minor?'#c6b38d':'#a8b79a','stroke-width':1}));
    g.append(planetSymbol(p.id,x,y,size,color,p.glyph));
    g.append(element('title',{},`${kind==='transit'?(syn?'Person '+transit.person+': ':prog?'Progressed: ':'Transit: '):syn?'Person '+data.person+': ':''}${p.name} · ${dms(p.longitude).full} ${dms(p.longitude).sign}${p.retrograde?' · retrograde':''}`));
    return g;
  }
  for(const p of spreadLabels(data.planets,12)){
    line(point(p.longitude,323),point(p.display,313),'#839776',.9);
    const end=point(p.longitude,323);add('circle',{cx:end[0],cy:end[1],r:2,fill:'#526c50'});
    badge(p,293,25,'natal');
    const [dx,dy]=point(p.display,293);add('text',{x:dx,y:dy+30,'text-anchor':'middle','font-family':'Nunito Sans,Arial,sans-serif','font-size':13,'font-weight':600,fill:'#526052'},`${dms(p.longitude).short}${p.retrograde?' ℞':''}`);
  }
  for(const [label,lon] of [['AC',asc],['MC',data.midheaven.longitude]]){
    line(point(lon,347),point(lon,416),'#435a48',1.6);
    const [x,y]=point(lon,415);add('rect',{x:x-15,y:y-9,width:30,height:18,rx:6,fill:'#fffdf8'});
    txt(lon,415,label,{'font-size':12,'font-weight':700,fill:'#344f3b'});
  }
  if(transit){
    if(syn||prog)for(const [label,pointData] of [['AC',transit.ascendant],['MC',transit.midheaven]]){line(point(pointData.longitude,426),point(pointData.longitude,446),'#836780',1.4);txt(pointData.longitude,438,label+' '+(prog?'P':transit.person),{'font-size':11,fill:'#68466e','font-weight':700});}
    for(const p of spreadLabels(transit.planets,10)){
      line(point(p.longitude,430),point(p.display,449),'#ad755a',1);
      badge(p,468,26,'transit');
      const [dx,dy]=point(p.display,468);add('text',{x:dx,y:dy+31,'text-anchor':'middle','font-family':'Nunito Sans,Arial,sans-serif','font-size':13,'font-weight':600,fill:'#815036'},`${dms(p.longitude).short}${p.retrograde?' ℞':''}`);
    }
    if(selectedAspect){
      const t=(transit.points||transit.planets).find(p=>p.id===selectedAspect.transit),n=byId[selectedAspect.natal];
      const color=['trine','sextile'].includes(selectedAspect.type)?'#48796b':'#a6684d';
      line(point(t.longitude,430),point(n.longitude,204),color,2.2,{'stroke-dasharray':'6 5',[syn?'data-synastry-aspect':'data-transit-aspect']:selectedAspect.type});
      for(const [lon,r] of [[t.longitude,430],[n.longitude,204]]){const [x,y]=point(lon,r);add('circle',{cx:x,cy:y,r:4,fill:color});}
    }
  }
  return svg;
}
