const frame=document.getElementById('stjernerne-frame');
frame.src='/?embed=1';
