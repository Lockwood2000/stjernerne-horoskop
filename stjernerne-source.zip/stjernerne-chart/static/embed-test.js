const frame=document.getElementById('stjernerne-frame');
frame.src='/?embed=1&parent='+encodeURIComponent(location.origin);
window.addEventListener('message',event=>{
  if(event.origin!==location.origin||event.source!==frame.contentWindow||event.data?.type!=='stjernerne:resize')return;
  const height=event.data.height;
  if(typeof height==='number'&&Number.isFinite(height)&&height>=300&&height<=10000)frame.style.height=Math.ceil(height)+'px';
});
