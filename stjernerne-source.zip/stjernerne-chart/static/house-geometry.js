const norm=value=>((value%360)+360)%360;

export function cuspDirection(cusps){
 if(cusps.length!==12||!cusps.every(Number.isFinite))throw Error('Invalid house cusps.');
 const forward=cusps.reduce((sum,cusp,i)=>sum+norm(cusps[(i+1)%12]-cusp),0);
 if(Math.abs(forward-360)<=1e-6)return 1;
 const reverse=cusps.reduce((sum,cusp,i)=>sum+norm(cusp-cusps[(i+1)%12]),0);
 if(Math.abs(reverse-360)<=1e-6)return -1;
 throw Error('Invalid house cusps.');
}

export function houseSectors(houses){
 if(!houses.length)return [];
 const cusps=houses.map(h=>h.longitude),direction=cuspDirection(cusps);
 return cusps.map((cusp,i)=>{
  const span=norm((cusps[(i+1)%12]-cusp)*direction);
  return {number:i+1,cusp,direction,span,midpoint:norm(cusp+direction*span/2)};
 });
}
