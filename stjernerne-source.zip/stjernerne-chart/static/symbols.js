const NS='http://www.w3.org/2000/svg';
// Original vector drawings on a 24×24 grid. Dwarf-planet initials avoid ambiguous
// competing glyph conventions and remain legible on systems without astro fonts.
const paths={
 sun:'M19 12a7 7 0 1 0-14 0a7 7 0 1 0 14 0 M12 11.3v1.4',
 moon:'M16 3C5 4 5 20 16 21C2 24-2 1 16 3Z',
 mercury:'M17 10a5 5 0 1 0-10 0a5 5 0 1 0 10 0 M7 2q5 7 10 0 M12 15v7 M8 19h8',
 venus:'M18 8a6 6 0 1 0-12 0a6 6 0 1 0 12 0 M12 14v8 M8 18h8',
 mars:'M15 15a6 6 0 1 0-12 0a6 6 0 1 0 12 0 M13.3 10.7L21 3 M15 3h6v6',
 jupiter:'M4 5c8-5 10 4 0 10h17 M15 3v19',
 saturn:'M8 2v20 M3 6h10 M8 13c9-11 13 2 8 6q-3 4 1 3',
 uranus:'M5 3v11 M19 3v11 M5 8h14 M12 3v13 M15 19a3 3 0 1 0-6 0a3 3 0 1 0 6 0',
 neptune:'M5 3v4q0 7 7 7q7 0 7-7V3 M12 2v20 M8 19h8 M2 5l3-3 3 3 M9 4l3-3 3 3 M16 5l3-3 3 3',
 pluto:'M15 5a3 3 0 1 0-6 0a3 3 0 1 0 6 0 M5 8q7 11 14 0 M12 14v8 M8 19h8',
 true_node:'M5 16V11a7 7 0 0 1 14 0v5 M7 18a2 2 0 1 0-4 0a2 2 0 1 0 4 0 M21 18a2 2 0 1 0-4 0a2 2 0 1 0 4 0',
 chiron:'M12 15V2 M12 9l7-7 M12 9l7 5 M16 19a4 4 0 1 0-8 0a4 4 0 1 0 8 0',
 ceres:'M7 3c12-5 16 10 4 11 M11 8v14 M7 18h8'
};
export function planetSymbol(id,x,y,size,color,initials){
 const g=document.createElementNS(NS,'g');g.setAttribute('transform',`translate(${x-size/2} ${y-size/2}) scale(${size/24})`);
 if(paths[id]){
  const p=document.createElementNS(NS,'path');
  for(const [key,value] of Object.entries({d:paths[id],fill:'none',stroke:color,'stroke-width':1.7,'stroke-linecap':'round','stroke-linejoin':'round'}))p.setAttribute(key,value);
  g.append(p);
 }else{
  const t=document.createElementNS(NS,'text');
  for(const [key,value] of Object.entries({x:12,y:13,'text-anchor':'middle','dominant-baseline':'middle','font-size':14,'font-family':'Nunito Sans,Arial,sans-serif','font-weight':700,fill:color}))t.setAttribute(key,value);
  t.textContent=initials;g.append(t);
 }
 return g;
}
