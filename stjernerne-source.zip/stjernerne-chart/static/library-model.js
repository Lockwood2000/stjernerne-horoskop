// A bounded, versioned input-only backup format. Never trust imported chart results.
export const FORMAT='stjernerne-horoskoper',VERSION=1,MAX_RECORDS=100,MAX_BYTES=1024*1024;
const fail=()=>{throw Error('Filen indeholder ugyldige eller ikke-understøttede horoskopdata.');};
const obj=(v,keys)=>{if(!v||typeof v!=='object'||Array.isArray(v)||Object.keys(v).some(k=>!keys.includes(k)))fail();};
const str=(v,max=80)=>{if(typeof v!=='string'||!v.trim()||v.length>max)fail();return v.trim();};
const num=(v,min,max,integer=false)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<min||v>max||(integer&&!Number.isInteger(v)))fail();return v;};
const bool=v=>{if(typeof v!=='boolean')fail();return v;};
const shift=v=>{num(v,-180,180);const seconds=Math.round(v*60);if(Math.abs(v*60-seconds)>1e-7)fail();return seconds/60;};
const date=v=>{if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v))fail();const d=new Date(v+'T12:00:00Z');if(Number.isNaN(+d)||d.toISOString().slice(0,10)!==v||v<'1500-01-01'||v>'2099-12-31')fail();return v;};
const time=v=>{if(typeof v!=='string'||!/^([01]\d|2[0-3]):[0-5]\d(:[0-5]\d)?$/.test(v))fail();return v;};
export function birth(v){
  obj(v,['date','time','include_dwarfs','place_id','place_name','latitude','longitude','timezone','fold','offset_minutes','offset_source']);
  const r={date:date(v.date),time:time(v.time),include_dwarfs:bool(v.include_dwarfs)};
  if(v.place_id!==undefined){r.place_id=str(v.place_id,20);if(['place_name','latitude','longitude','timezone'].some(k=>v[k]!==undefined))fail();}
  else{r.latitude=num(v.latitude,-90,90);r.longitude=num(v.longitude,-180,180);r.timezone=str(v.timezone);if(v.place_name!==undefined){if(typeof v.place_name!=='string'||v.place_name.length>120)fail();r.place_name=v.place_name.trim();}}
  if(v.fold!==undefined)r.fold=num(v.fold,0,1,true);
  if(v.offset_minutes!==undefined){r.offset_minutes=num(v.offset_minutes,-840,840,true);r.offset_source=str(v.offset_source,250);if(r.offset_source.length<8)fail();}else if(v.offset_source!==undefined)fail();
  return r;
}
function transit(v){obj(v,['date','time','timezone','fold']);const r={date:date(v.date),time:time(v.time),timezone:str(v.timezone)};if(v.fold!==undefined)r.fold=num(v.fold,0,1,true);return r;}
export function session(v){
  obj(v,['birth','mode','rectification','synastry','technique','transit']);
  if(!['natal','rectify','synastry','solar','progressed'].includes(v.mode))fail();
  const r={birth:birth(v.birth),mode:v.mode};
  const q=v.rectification;obj(q,['shifts','current','events']);
  if(!Array.isArray(q.shifts)||q.shifts.length<1||q.shifts.length>5||q.shifts[0]!==0||new Set(q.shifts).size!==q.shifts.length||!Array.isArray(q.events)||q.events.length>5)fail();
  r.rectification={shifts:q.shifts.map(shift),current:shift(q.current),events:q.events.map(e=>{obj(e,['label','date']);return {label:str(e.label),date:date(e.date)};})};
  if(new Set(r.rectification.shifts).size!==r.rectification.shifts.length)fail();
  if(v.mode==='synastry'){obj(v.synastry,['birth','order']);if(!['a','b'].includes(v.synastry.order))fail();r.synastry={birth:birth(v.synastry.birth),order:v.synastry.order};}else if(v.synastry!==undefined)fail();
  if(['solar','progressed'].includes(v.mode)){
    obj(v.technique,['mode','year','location','target']);if(v.technique.mode!==v.mode)fail();r.technique={mode:v.mode};
    if(v.mode==='solar'){r.technique.year=num(v.technique.year,1500,2099,true);if(v.technique.target!==undefined)fail();if(v.technique.location!==undefined){obj(v.technique.location,['place_id']);r.technique.location={place_id:str(v.technique.location.place_id,20)};}}
    else{r.technique.target=transit(v.technique.target);if(v.technique.year!==undefined||v.technique.location!==undefined)fail();}
  }else if(v.technique!==undefined)fail();
  if(v.transit!==undefined){if(v.mode!=='natal')fail();r.transit=transit(v.transit);}
  return r;
}
export function decodeBackup(text){
  if(typeof text!=='string'||new TextEncoder().encode(text).length>MAX_BYTES)throw Error('Backupfilen må højst være 1 MB.');
  let value;try{value=JSON.parse(text);}catch{throw Error('Filen er ikke en læsbar JSON-backup.');}
  obj(value,['format','version','records']);if(value.format!==FORMAT||value.version!==VERSION)throw Error('Backupformatet eller versionen understøttes ikke.');
  if(!Array.isArray(value.records)||!value.records.length||value.records.length>MAX_RECORDS)fail();
  return value.records.map(v=>{obj(v,['name','session','trashed']);return {name:str(v.name),session:session(v.session),trashed:v.trashed===undefined?false:bool(v.trashed)};});
}
export function encodeBackup(records){return JSON.stringify({format:FORMAT,version:VERSION,records:records.map(r=>({name:str(r.name),session:session(r.session),trashed:!!r.trashed}))},null,2);}
