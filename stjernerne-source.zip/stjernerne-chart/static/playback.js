// Calendar steps preserve the selected zone's wall clock. The server resolves DST.
export function nextTransitTime(date,time,hours){
  if(![1,24,168,-1,-24,-168].includes(hours))return null;
  const stamp=new Date(`${date}T${time}Z`);
  if(!Number.isFinite(stamp.getTime()))return null;
  stamp.setUTCHours(stamp.getUTCHours()+hours);
  const value=stamp.toISOString();
  if(value.slice(0,10)<'1900-01-01'||value.slice(0,10)>'2099-12-31')return null;
  return {date:value.slice(0,10),time:value.slice(11,19)};
}

// One request at a time; stop/restart invalidates every older loop, including awaits.
export function createPlayer(frame,onState,{delay=1200,schedule=setTimeout,cancel=clearTimeout}={}){
  let active=false,version=0,timer=null;
  function stop(){
    version++;cancel(timer);timer=null;
    if(active){active=false;onState(false);}
  }
  async function tick(token){
    if(!active||token!==version)return;
    let ok=false;
    try{ok=await frame();}catch{ok=false;}
    if(!active||token!==version)return;
    if(!ok){stop();return;}
    timer=schedule(()=>tick(token),delay);
  }
  return {get active(){return active;},stop,start(){
    if(active)return;
    active=true;const token=++version;onState(true);
    timer=schedule(()=>tick(token),delay);
  }};
}
