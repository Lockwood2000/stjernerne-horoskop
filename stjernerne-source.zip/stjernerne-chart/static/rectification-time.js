export const normalizeShift=value=>Math.max(-10800,Math.min(10800,Math.round(value*60)))/60;
export function formatShift(minutes){
  const seconds=Math.round(minutes*60),amount=Math.abs(seconds),m=Math.floor(amount/60),s=amount%60;
  return (seconds>0?'+':seconds<0?'−':'')+(m?m+' min.'+(s?' '+s+' sec.':''):s?s+' sec.':'0 min.');
}
