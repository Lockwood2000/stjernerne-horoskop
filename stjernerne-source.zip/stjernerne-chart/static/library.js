import {listRecords,changeRecord} from './library-store.js';
import {decodeBackup,encodeBackup,session,MAX_BYTES} from './library-model.js';
const $=id=>document.getElementById(id);
const modeNames={solar_arc:"Solar arc",natal:'Fødselshoroskop',rectify:'Fødselstidskorrektion',synastry:'Synastri',solar:'Solretur',progressed:'Sekundære progressioner'};
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
export function createLibrary(snapshot,open){
  let opened=null,busy=false;
  const channel=typeof BroadcastChannel==='function'?new BroadcastChannel('stjernerne-library-changes'):null;
  const status=message=>$('library-status').textContent=message;
  function controls(){for(const button of $('library').querySelectorAll('button,input'))button.disabled=busy;$('library-update').disabled=busy||!opened;}
  async function refresh(){
    const rows=await listRecords();$('library-count').textContent=String(rows.filter(r=>!r.trashed).length);const sorted=rows.sort((a,b)=>b.updated.localeCompare(a.updated));
    for(const trash of [false,true]){
      const list=$(trash?'library-trash':'library-list'),entries=sorted.filter(r=>r.trashed===trash);
      list.replaceChildren();if(!entries.length)list.append(el('p',trash?'Papirkurven er tom.':'Du har endnu ikke gemt et horoskop.'));
      for(const row of entries){const card=el('div');card.className='library-row';const title=el('div');title.append(el('strong',row.name),el('small',`${modeNames[row.session.mode]} · ${row.session.birth.date} · ${row.session.birth.time} · ${row.session.rectification.shifts.length} ${row.session.rectification.shifts.length===1?'tidskandidat':'tidskandidater'} · ${row.session.rectification.events.length} ${row.session.rectification.events.length===1?'begivenhed':'begivenheder'}`));card.append(title);
        const button=(label,handler)=>{const b=el('button',label);b.type='button';b.addEventListener('click',handler);card.append(b);};
        if(trash)button('Gendan',()=>run(async()=>{await changeRecord({type:'restore',id:row.id,revision:row.revision});await changed();status('Horoskopet er gendannet.');}));
        else{
          button('Åbn',()=>run(async()=>{const current=(await listRecords()).find(r=>r.id===row.id&&!r.trashed);if(!current)throw Error('Horoskopet findes ikke længere i biblioteket.');document.querySelector('.workspace').inert=true;status('Åbner og genberegner …');try{await open(session(current.session));opened=current;$('library-name').value=current.name;status('Åbnet: '+current.name+'. Tryk Gem ændringer for at bevare det videre arbejde.');}finally{document.querySelector('.workspace').inert=false;}}));
          button('Til papirkurv',()=>run(async()=>{await changeRecord({type:'trash',id:row.id,revision:row.revision});if(opened?.id===row.id)opened=null;await changed();status('Flyttet til papirkurven. Du kan gendanne det nedenfor.');}));
        }
        list.append(card);
      }
    }
    controls();return rows;
  }
  async function changed(){await refresh();channel?.postMessage('changed');}
  async function run(fn){if(busy)return;busy=true;controls();try{await fn();}catch(e){status(e.message||'Biblioteket kunne ikke opdateres.');}finally{busy=false;controls();}}
  async function save(update){await run(async()=>{const name=$('library-name').value.trim();if(!name)throw Error('Giv horoskopet et navn først.');const data=snapshot();const result=await changeRecord(update?{type:'update',id:opened.id,revision:opened.revision,name,session:data}:{type:'create',name,session:data});opened=Array.isArray(result)?result[0]:result;await changed();status('Gemt lokalt: '+opened.name+'. Du kan åbne det igen fra denne browser.');});}
  $('library-new').addEventListener('click',()=>save(false));$('library-update').addEventListener('click',()=>save(true));
  $('library-export').addEventListener('click',()=>run(async()=>{
    const records=await listRecords();if(!records.length)throw Error('Gem et horoskop før du eksporterer.');
    const file=new Blob([encodeBackup(records)],{type:'application/json'}),url=URL.createObjectURL(file),a=el('a');a.href=url;a.download='stjernerne-horoskoper-'+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);status('Backup downloadet. Den indeholder også eventuelle horoskoper i papirkurven.');
  }));
  $('library-import').addEventListener('change',()=>{const file=$('library-import').files[0];if(!file)return;run(async()=>{
    if(file.size>MAX_BYTES)throw Error('Backupfilen må højst være 1 MB.');const records=decodeBackup(await file.text());await changeRecord({type:'import',records});await changed();status(records.length+' horoskoper importeret som kopier. Eksisterende horoskoper er bevaret. Åbn et horoskop for at beregne det.');
  }).finally(()=>$('library-import').value='');});
  $('library').addEventListener('toggle',()=>{if($('library').open&&!busy)refresh().catch(e=>status(e.message));});
  window.addEventListener('focus',()=>{if(!busy)refresh().catch(e=>status(e.message));});
  if(channel)channel.onmessage=()=>{if(!busy)refresh().catch(e=>status(e.message));};
  refresh().catch(e=>status(e.message));
}
