import {listRecords,changeRecord} from './library-store.js';
import {decodeBackup,encodeBackup,session,MAX_BYTES} from './library-model.js';
const $=id=>document.getElementById(id);
const modeNames={natal:"Birth chart",rectify:"Birth time rectification",synastry:"Synastry",solar:"Solar return",progressed:"Secondary progressions"};
const el=(tag,text)=>{const e=document.createElement(tag);if(text!==undefined)e.textContent=text;return e;};
export function createLibrary(snapshot,open){
  let opened=null,busy=false;
  const channel=typeof BroadcastChannel==='function'?new BroadcastChannel("stjernerne-en-test-library-changes"):null;
  const status=message=>$('library-status').textContent=message;
  function controls(){for(const button of $('library').querySelectorAll('button,input'))button.disabled=busy;$('library-update').disabled=busy||!opened;}
  async function refresh(){
    const rows=await listRecords();$('library-count').textContent=String(rows.filter(r=>!r.trashed).length);const sorted=rows.sort((a,b)=>b.updated.localeCompare(a.updated));
    for(const trash of [false,true]){
      const list=$(trash?'library-trash':'library-list'),entries=sorted.filter(r=>r.trashed===trash);
      list.replaceChildren();if(!entries.length)list.append(el('p',trash?"The bin is empty.":"You have not saved a chart yet."));
      for(const row of entries){const card=el('div');card.className='library-row';const title=el('div');title.append(el('strong',row.name),el('small',`${modeNames[row.session.mode]} · ${row.session.birth.date} · ${row.session.birth.time} · ${row.session.rectification.shifts.length} ${row.session.rectification.shifts.length===1?'candidate time':'candidate times'} · ${row.session.rectification.events.length} ${row.session.rectification.events.length===1?'event':'events'}`));card.append(title);
        const button=(label,handler)=>{const b=el('button',label);b.type='button';b.addEventListener('click',handler);card.append(b);};
        if(trash)button("Restore",()=>run(async()=>{await changeRecord({type:'restore',id:row.id,revision:row.revision});await changed();status("The chart has been restored.");}));
        else{
          button("Open",()=>run(async()=>{const current=(await listRecords()).find(r=>r.id===row.id&&!r.trashed);if(!current)throw Error("The chart is no longer in the library.");document.querySelector('.workspace').inert=true;status("Opening and recalculating …");try{await open(session(current.session));opened=current;$('library-name').value=current.name;status("Opened: "+current.name+". Press Save changes to keep your further work.");}finally{document.querySelector('.workspace').inert=false;}}));
          button("Move to bin",()=>run(async()=>{await changeRecord({type:'trash',id:row.id,revision:row.revision});if(opened?.id===row.id)opened=null;await changed();status("Moved to the bin. You can restore it below.");}));
        }
        list.append(card);
      }
    }
    controls();return rows;
  }
  async function changed(){await refresh();channel?.postMessage('changed');}
  async function run(fn){if(busy)return;busy=true;controls();try{await fn();}catch(e){status(e.message||"The library could not be updated.");}finally{busy=false;controls();}}
  async function save(update){await run(async()=>{const name=$('library-name').value.trim();if(!name)throw Error("Give the chart a name first.");const data=snapshot();const result=await changeRecord(update?{type:'update',id:opened.id,revision:opened.revision,name,session:data}:{type:'create',name,session:data});opened=Array.isArray(result)?result[0]:result;await changed();status("Saved locally: "+opened.name+". You can reopen it in this browser.");});}
  $('library-new').addEventListener('click',()=>save(false));$('library-update').addEventListener('click',()=>save(true));
  $('library-export').addEventListener('click',()=>run(async()=>{
    const records=await listRecords();if(!records.length)throw Error("Save a chart before exporting.");
    const file=new Blob([encodeBackup(records)],{type:'application/json'}),url=URL.createObjectURL(file),a=el('a');a.href=url;a.download="stjernerne-chart-workshop-en-test-"+new Date().toISOString().slice(0,10)+'.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);status("Backup downloaded. It also includes any charts in the bin.");
  }));
  $('library-import').addEventListener('change',()=>{const file=$('library-import').files[0];if(!file)return;run(async()=>{
    if(file.size>MAX_BYTES)throw Error("The backup file must not exceed 1 MB.");const records=decodeBackup(await file.text());await changeRecord({type:'import',records});await changed();status("Imported charts: "+records.length+". Existing charts are preserved. Open a chart to calculate it.");
  }).finally(()=>$('library-import').value='');});
  $('library').addEventListener('toggle',()=>{if($('library').open&&!busy)refresh().catch(e=>status(e.message));});
  window.addEventListener('focus',()=>{if(!busy)refresh().catch(e=>status(e.message));});
  if(channel)channel.onmessage=()=>{if(!busy)refresh().catch(e=>status(e.message));};
  refresh().catch(e=>status(e.message));
}
