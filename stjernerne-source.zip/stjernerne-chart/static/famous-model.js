export const ARCHIVE='https://www.astrologi-arkaden.dk/dataarkiv/';
export function normalizeName(value){return value.toLocaleLowerCase('da').replaceAll('æ','ae').replaceAll('ø','o').replaceAll('å','a').normalize('NFD').replace(/[\u0300-\u036f]/g,'');}
export function searchPeople(records,query){const terms=normalizeName(query).trim().split(/\s+/);return records.filter(r=>terms.every(t=>normalizeName(r.name).includes(t)));}
export function unavailableReason(r){
  if(r.date<'1900-01-01')return 'Generatoren understøtter endnu ikke fødsler før 1900. Se oplysningerne i Excel-oversigten.';
  if(!Number.isFinite(r.latitude)||!Number.isFinite(r.longitude)||(r.latitude===0&&r.longitude===0))return 'Arkivets koordinater mangler. Find og kontrollér fødestedet, før du beregner horoskopet.';
  if(Math.abs(r.latitude)>=66)return 'Fødestedet ligger uden for generatorens område for Placidus-huse (66° nord/syd).';
  return '';
}
export function archiveBirth(r,includeDwarfs){
  const reason=unavailableReason(r);if(reason)throw Error(reason);
  return {date:r.date,time:r.rating.startsWith('X')?'':r.time,include_dwarfs:includeDwarfs,
    place_name:r.place==='Ikke angivet'?`Arkivets koordinater · ${r.name}`:r.place,
    latitude:r.latitude,longitude:r.longitude,timezone:'UTC',offset_minutes:r.offset,
    offset_source:`${r.name} · rating ${r.rating} · arkivzone ${r.zone} · ${ARCHIVE}`.slice(0,250)};
}
