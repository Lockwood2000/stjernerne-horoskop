import {searchPeople,unavailableReason} from './famous-model.js';
export function createFamousPicker(onChoose){
  const $=id=>document.getElementById(id),root=$('famous-picker');
  const search=$('famous-search'),select=$('famous-select'),status=$('famous-status'),detail=$('famous-detail'),use=$('famous-use');
  let records=null,loading=false,current=null;
  const text=(tag,value)=>{const e=document.createElement(tag);e.textContent=value;return e;};
  function show(){
    current=records?.find(r=>r.id===select.value)||null;detail.replaceChildren();use.disabled=true;
    if(!current)return;
    const r=current,blocked=unavailableReason(r);
    detail.append(text('strong',r.name),text('p',`${r.date} · ${r.rating.startsWith('X')?'fødselstid ukendt':'kl. '+r.time} · ${r.place} · rating ${r.rating}`));
    detail.append(text('p',`Koordinater: ${r.latitude.toFixed(5)}°, ${r.longitude.toFixed(5)}°. Arkivzone: ${r.zone}.`));
    if(r.note)detail.append(text('p',r.note));
    if(r.rating.startsWith('X'))detail.append(text('p','Fødselstiden er ikke dokumenteret. Klokkeslætsfeltet bliver tomt; indtast kun en tid, hvis du har en kilde til den.'));
    if(blocked)detail.append(text('p',blocked));
    for(const url of r.sources){const link=text('a','Supplerende kilde ↗');link.href=url;link.target='_blank';link.rel='noopener';detail.append(link);}
    use.disabled=!!blocked;
  }
  function filter(){
    const matches=searchPeople(records||[],search.value);
    select.replaceChildren(new Option(matches.length?'Vælg person og fødselstid …':'Ingen navne matcher søgningen',''));
    for(const r of matches)select.add(new Option(`${r.name} · ${r.date} · ${r.rating.startsWith('X')?'tid ukendt':r.time}${r.date<'1900-01-01'?' · før 1900':''}`,r.id));
    status.textContent=`${matches.length} af ${records.length} arkivposter. Alternative tider vises hver for sig.`;show();
  }
  async function load(){
    if(records||loading)return;loading=true;status.textContent='Henter oversigten …';$('famous-retry').hidden=true;
    try{const res=await fetch('/static/famous-danes.json');if(!res.ok)throw Error();records=await res.json();filter();search.disabled=false;select.disabled=false;}
    catch{status.textContent='Oversigten kunne ikke hentes. Du kan stadig indtaste oplysninger manuelt.';$('famous-retry').hidden=false;}
    finally{loading=false;}
  }
  root.addEventListener('toggle',()=>{if(root.open)load();});$('famous-retry').addEventListener('click',load);
  search.addEventListener('input',filter);select.addEventListener('change',show);
  use.addEventListener('click',()=>{if(current&&!unavailableReason(current)){onChoose(current);$('famous-applied').textContent=`Indsat fra arkivet: ${current.name} · rating ${current.rating}. ${current.rating.startsWith('X')?'Fødselstiden er ukendt; klokkeslættet er ikke udfyldt.':'Kontrollér oplysningerne, og tryk Se mit fødselshoroskop.'}`;$('famous-applied').hidden=false;root.open=false;$('date').focus();}});
  return {clear(){ $('famous-applied').hidden=true; }};
}
