import {dms} from './wheel.js';

export const SOLAR_KEY_METHODS=['kundig','kundig_argus'];
export const isSolarKey=method=>SOLAR_KEY_METHODS.includes(method);
export const solarKeyLabel=method=>({'kundig':"Kündig · whole degree",'kundig_argus':"ARGUS · centred",'naibod':'Naibod'}[method]||"Unknown method");
const el=(tag,text,cls)=>{const node=document.createElement(tag);if(text!==undefined)node.textContent=text;if(cls)node.className=cls;return node;};
const angle=value=>`${dms(value).full} ${dms(value).sign}`;
export function arcDms(value){
  const seconds=Math.round(Math.abs(value)*3600);
  return (value<0?'−':'')+Math.floor(seconds/3600)+'°'+String(Math.floor(seconds/60)%60).padStart(2,'0')+'′'+String(seconds%60).padStart(2,'0')+'″';
}
export function signedArcseconds(value){
  if(Math.abs(value)<.0005)return '≈ 0″';
  return (value<0?'−':'+')+new Intl.NumberFormat("en-GB",{minimumFractionDigits:2,maximumFractionDigits:3}).format(Math.abs(value))+'″';
}

export function renderSolarKeyComparison(container,chart,onChoose,buttonText="View in wheel"){
  container.replaceChildren();
  const comparison=chart.technique?.solar_key_comparison;
  container.hidden=!comparison;if(!comparison)return;
  container.classList.add('solar-key-comparison');
  container.append(el('h3',"Compare solar keys"),el('p',"Same birth details and progression date. Planet positions are identical; the solar key determines angles and houses.",'hint'));
  const cards=el('div',undefined,'solar-key-cards');
  for(const variant of comparison.variants){
    const card=el('article',undefined,'solar-key-card'),selected=variant.house_method_id===chart.technique.house_method_id;
    card.classList.toggle('selected',selected);card.append(el('h4',solarKeyLabel(variant.house_method_id)));
    const dl=el('dl');
    for(const [label,value] of [
      ["Solar key / year",dms(variant.degrees_per_year).full+' RA'],
      ["Exact key",variant.degrees_per_year.toFixed(8)+"° RA/year"],
      ["Total angle arc",arcDms(variant.arc_degrees)+' RA'],
      ["Progressed MC",angle(variant.midheaven.longitude)],
      ["Progressed AC",angle(variant.ascendant.longitude)]
    ])dl.append(el('dt',label),el('dd',value));
    card.append(dl);
    const button=el('button',selected?"Selected method":buttonText);button.type='button';button.disabled=selected;
    button.setAttribute('aria-label',selected?solarKeyLabel(variant.house_method_id)+" is selected":buttonText+': '+solarKeyLabel(variant.house_method_id));
    button.addEventListener('click',()=>onChoose(variant.house_method_id));card.append(button);cards.append(card);
  }
  const difference=comparison.difference_from_whole;
  container.append(cards,el('p',`ARGUS minus whole degree: solar key ${signedArcseconds(difference.key_arcseconds_per_year)}/year · MC ${signedArcseconds(difference.midheaven_arcseconds)} · AC ${signedArcseconds(difference.ascendant_arcseconds)}. + follows the zodiac direction; − goes against it.`,'hint solar-key-difference'));
}
