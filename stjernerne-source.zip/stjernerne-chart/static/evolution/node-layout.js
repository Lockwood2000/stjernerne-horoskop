// Dense node overlays use two ordered columns. Longitudes stay on the wheel;
// only the callouts move. Pool adjacent rows to share the available space
// without letting nearby labels overtake one another.
export function layoutNodeCallouts(nodes,ascendant=0,progressed=false,largeText=false){
  const radius=progressed?605:428,gap=largeText?54:42;
  const sides={left:[],right:[]};
  for(const node of nodes){
    const angle=(180-node.longitude+ascendant)*Math.PI/180;
    const right=Math.cos(angle)>=0;
    sides[right?'right':'left'].push({...node,sideColumn:right?'right':'left',targetY:500+Math.sin(angle)*(progressed?540:430)});
  }
  const height=Math.max(progressed?1160:1000,(Math.max(sides.left.length,sides.right.length)-1)*gap+64);
  const minY=500-height/2+28,maxY=500+height/2-28;
  const rows=[];
  for(const [side,points] of Object.entries(sides)){
    points.sort((a,b)=>a.targetY-b.targetY||a.longitude-b.longitude||a.id.localeCompare(b.id));
    const groups=[];
    points.forEach((p,i)=>{
      groups.push({start:i,end:i,sum:p.targetY-i*gap,count:1});
      while(groups.length>1){
        const a=groups.at(-2),b=groups.at(-1);
        if(a.sum/a.count<=b.sum/b.count)break;
        groups.splice(-2,2,{start:a.start,end:b.end,sum:a.sum+b.sum,count:a.count+b.count});
      }
    });
    const right=side==='right',badgeX=500+(right?radius:-radius);
    for(const group of groups){
      const start=Math.max(minY,Math.min(maxY-(points.length-1)*gap,group.sum/group.count));
      for(let i=group.start;i<=group.end;i++)rows.push({...points[i],x:badgeX,y:start+i*gap,textX:badgeX+(right?28:-28),anchor:right?'start':'end'});
    }
  }
  const width=radius*2+(largeText?344:264);
  return {rows,viewBox:[500-width/2,500-height/2,width,height]};
}
