import {dms} from '../wheel.js';
import {renderEvolution} from './wheel.js';
import {renderPrintSheet} from './print.js';
import {timingLayer,timingLabel,timingSummary} from './timing.js';

const $=id=>document.getElementById(id);
const EXTRA=['chiron','ceres','eris','haumea','makemake','sedna','quaoar','orcus','gonggong'];
const HOUSE={O:'Porphyry',P:'Placidus',W:'Whole Sign',E:'Equal House (ASC)',R:'Regiomontanus'};
const ASPECT={0:'☌ Conjunction',60:'⚹ Sextile',90:'□ Square',120:'△ Trine',150:'⚻ Quincunx',180:'☍ Opposition'};
const state={data:null,place:{id:'2618425',name:'Copenhagen, Denmark'},returnPlace:null,targetFold:null,focus:'pluto',visibleNodes:new Set(['pluto','uranus']),highlight:null,dirty:false,busy:false,abort:null,fold:null,birthMeta:{},extraSelection:EXTRA,includeExtraNodes:true};
const DEFAULT={birth:{date:'1990-06-15',time:'14:30:00',place_id:'2618425',place_name:'Copenhagen, Denmark'},house_system:'O',lunar_node:'true',node_reference:'geocentric',node_method:'mean_barycentric',extras:EXTRA,node_orb:3,quincunx:true,include_progressions:false,target:{date:'2026-10-16',time:'12:00:00',timezone:'UTC'},ruler_mode:'modern'};
const KEY='stjernerne.evolution.saved.v1';
const READING_VIEWS={
  evolutionary:{nodes:['pluto','uranus'],polarity:true,compare:false},
  outer:{nodes:['jupiter','saturn','uranus','neptune','pluto'],polarity:true,compare:false},
  lunar:{nodes:[],polarity:false,compare:true}
};
let toastTimer,searchTimer,placeAbort,returnSearchTimer,returnPlaceAbort;
function node(tag,text,cls){const e=document.createElement(tag);if(text!==undefined)e.textContent=text;if(cls)e.className=cls;return e;}
function toast(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,4000);}
function format(p,full=false){return p?`${full?dms(p.longitude).full:dms(p.longitude).short} ${dms(p.longitude).sign}`:'Unavailable';}
function house(p){return p?.house?`House ${p.house}`:'Houses omitted';}
function timingPoint(p){return ['progressed','solar_arc','solar_return'].includes(p.layer);}
function pointDetail(p){return `${format(p,true)} · ${house(p)}${p.house_in_natal?` in this layer · Natal house ${p.house_in_natal}`:''}${timingPoint(p)?' · '+timingLabel(state.data):''}`;}
function syncTimingControls(){
  const active=$('progressions').checked,returns=$('timing-mode').value==='solar_return',other=$('return-location').value==='other';
  $('progression-controls').hidden=!active;$('target-controls').hidden=returns;$('return-controls').hidden=!returns;$('return-other').hidden=!other;
  $('timing-help').textContent=returns?'Exact return to the natal Sun’s tropical apparent geocentric longitude. The chosen location sets return houses and angles.':$('timing-mode').value==='solar_arc'?'True solar arc from the secondary progressed Sun. The same arc directs all natal planets, angles and cusps.':'One ephemeris day per 365.2422 elapsed days. Naibod axes advance 0.98564733° per year in right ascension, at the birthplace.';
  $('return-place-detail').textContent=other?(state.returnPlace?`Selected: ${state.returnPlace.name}.`:'Select a return city or confirm manual coordinates.'):`Return houses use ${state.place?.name||'the selected birthplace'}.`;
}
function readReturnPlace(){
  if($('return-location').value==='birthplace')return null;
  if(!state.returnPlace)throw new Error('Select a return city from the results, or confirm its manual coordinates.');
  if(!state.returnPlace.manual)return {place_id:String(state.returnPlace.id)};
  if(!['return-latitude','return-longitude','return-timezone'].every(id=>$(id).value.trim()&&$(id).reportValidity()))throw new Error('Complete the return latitude, longitude and IANA time zone.');
  return {place_name:state.returnPlace.name,latitude:Number($('return-latitude').value),longitude:Number($('return-longitude').value),timezone:$('return-timezone').value.trim()};
}
function markDirty(event){state.dirty=true;if(['birth-date','birth-time','birthplace'].includes(event?.target?.id))state.fold=null;state.abort?.abort();state.busy=false;$('calculate').disabled=false;$('status').textContent='Settings changed · calculate to update the chart.';exportAvailability();}
function exportAvailability(){
  for(const id of ['save-chart','save-notes','export-json','export-svg','expand-wheel','print-chart','print-large'])$(id).disabled=!state.data||state.dirty||state.busy;
  for(const b of document.querySelectorAll('[data-view]'))b.disabled=!state.data;
  document.querySelector('.chart-paper').classList.toggle('is-calculating',state.busy);
  const notice=$('chart-notice');
  if(state.data&&(state.dirty||state.busy)){
    notice.textContent=state.busy?'Updating the chart…':'Settings have changed. Calculate to update the chart shown below.';
    notice.hidden=false;notice.classList.add('is-stale');
  }else{
    notice.textContent=state.data?.warnings.join(' ')||'';notice.hidden=!notice.textContent;notice.classList.remove('is-stale');
  }
}
function readInput(){
  const manual=state.place?.manual;
  if(!state.place)throw new Error('Select a birthplace from the search results, or use manual coordinates.');
  const birth={...state.birthMeta,date:$('birth-date').value,time:$('unknown-time').checked?null:$('birth-time').value,confidence:$('unknown-time').checked?'unknown':state.birthMeta.confidence==='approximate'?'approximate':'exact'};
  if(manual)Object.assign(birth,{place_name:state.place.name,latitude:Number($('latitude').value),longitude:Number($('longitude').value),timezone:$('timezone').value.trim()});
  else birth.place_id=String(state.place.id);
  if(state.fold!==null)birth.fold=state.fold;
  const enabled=$('progressions').checked,mode=$('timing-mode').value;
  if(enabled){
    const ids=mode==='solar_return'?['return-year']:['progression-date','target-time','target-timezone'];
    if(!ids.every(id=>$(id).reportValidity()))throw new Error('Complete the timing date, time and location settings.');
  }
  const target={date:$('progression-date').value,time:$('target-time').value,timezone:$('target-timezone').value.trim()};
  if(state.targetFold!==null)target.fold=state.targetFold;
  return {birth,house_system:$('houses').value,lunar_node:$('lunar-mode').value,node_reference:$('node-reference').value,node_method:$('node-method').value,
    node_orb:Number($('node-orb').value),ruler_mode:$('ruler-mode').value,quincunx:$('quincunx').checked,extras:state.extraSelection,
    include_extra_nodes:state.includeExtraNodes,include_progressions:enabled,timing_mode:mode,target:enabled&&mode!=='solar_return'?target:null,
    return_year:mode==='solar_return'?Number($('return-year').value):null,return_place:enabled&&mode==='solar_return'?readReturnPlace():null};
}
async function calculate(){
  let input;
  if(!$('chart-form').reportValidity())return false;
  try{input=readInput();}catch(error){showError(error.message);return false;}
  state.abort?.abort();const controller=new AbortController();state.abort=controller;state.busy=true;state.dirty=true;
  $('calculate').disabled=true;exportAvailability();$('error').hidden=true;$('time-choices').replaceChildren();$('status').textContent='Calculating positions, nodes and house cusps…';
  try{
    const response=await fetch('/api/evolution/chart',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(input),signal:controller.signal});
    const data=await response.json();if(state.abort!==controller)return false;
    if(!response.ok){
      if(data.error?.choices?.length){
        data.error.choices.forEach(choice=>{const b=node('button',`${data.error.context==='target'?'Target time: ':''}${choice.label||choice.offset||choice.utc||'Time occurrence'} · use this time`);b.type='button';b.addEventListener('click',()=>{if(data.error.context==='target')state.targetFold=choice.fold;else state.fold=choice.fold;calculate();});$('time-choices').append(b);});
      }
      throw new Error(data.error?.message||'The chart could not be calculated.');
    }
    state.data=data;state.highlight=null;state.dirty=false;
    if(!data.planetary_nodes.some(p=>p.body===state.focus))state.focus='pluto';
    $('status').textContent=`Chart calculated · ${data.natal.planets.length} bodies · ${data.planetary_nodes.length} node pairs.`;
    $('engine-version').textContent=data.calculation.version;
    render();return true;
  }catch(error){
    if(error.name!=='AbortError'){showError(error.message);$('status').textContent=state.data?'Previous calculation remains visible.':'No chart calculated.';}return false;
  }finally{if(state.abort===controller){state.busy=false;$('calculate').disabled=false;exportAvailability();}}
}
function showError(message){$('error').textContent=message;$('error').hidden=false;}
function viewOptions(){return {name:$('chart-name').value,focus:state.focus,showNodes:$('show-nodes').checked,showPolarity:$('show-polarity').checked,compareNodes:$('compare-nodes').checked,showExtras:$('show-extras').checked,visibleNodes:state.visibleNodes,highlight:state.highlight};}
function syncReadingViews(){
  const shown=$('show-nodes').checked?[...state.visibleNodes]:[];
  for(const b of document.querySelectorAll('[data-view]')){
    const preset=READING_VIEWS[b.dataset.view];
    const match=preset.nodes.length===shown.length&&preset.nodes.every(k=>shown.includes(k))&&preset.polarity===$('show-polarity').checked&&preset.compare===$('compare-nodes').checked;
    b.setAttribute('aria-pressed',match);
  }
}
function renderWheel(){
  if(!state.data)return;
  const opts=viewOptions();$('wheel').replaceChildren(renderEvolution(state.data,opts));
  const pairs=opts.showNodes?state.data.planetary_nodes.filter(p=>state.visibleNodes.has(p.body)):[];
  const count=pairs.length;
  if($('wheel-dialog').open){
    $('large-wheel').replaceChildren(renderEvolution(state.data,{...opts,idPrefix:'large-evo',largeText:true}));
    $('large-wheel-title').textContent=opts.name.trim()||'Your chart, in detail.';
    $('large-wheel-subtitle').textContent=$('chart-subtitle').textContent+(timingLayer(state.data)?' · '+timingSummary(state.data):'');
    $('large-wheel-context').textContent=(count?`${count} PLANETARY-NODE ${count===1?'PAIR':'PAIRS'}`:'THE EVOLUTIONARY WORKSPACE')+(timingLayer(state.data)?' · '+timingLabel(state.data).toUpperCase():'');
    $('large-wheel-detail').textContent='Select a planet or node for its exact position. Esc to close.';
    renderLargeNodeKey(pairs);
  }
  $('visible-node-count').textContent=count?`${count} planetary-node ${count===1?'pair':'pairs'} shown`:opts.compareNodes?'True & Mean lunar nodes':'Natal chart';
  $('focus-context').textContent='Exploring '+(state.data.planetary_nodes.find(p=>p.body===state.focus)?.name||'Pluto');
  $('progressed-legend').hidden=!timingLayer(state.data);$('timing-legend-label').textContent=timingLabel(state.data);
  $('timing-summary').hidden=!timingLayer(state.data);$('timing-summary').textContent=timingSummary(state.data);
  syncReadingViews();
}
function renderLargeNodeKey(pairs){
  const container=$('large-node-key');container.hidden=!pairs.length;
  const table=node('table'),caption=node('caption','Visible planetary nodes','sr-only'),head=node('thead'),heading=node('tr'),body=node('tbody');
  for(const label of ['Body','North node','South node']){const th=node('th',label);th.scope='col';heading.append(th);}
  head.append(heading);
  for(const pair of pairs){
    const row=node('tr');row.append(node('td',pair.name));
    for(const side of ['north','south']){
      const p=pair[side],position=dms(p.longitude),cell=node('td'),button=node('button',`${position.short} ${position.sign.slice(0,3)}`);
      button.type='button';button.className=side;button.setAttribute('data-node-key',p.id);
      button.setAttribute('aria-label',`${pair.name} ${side} node: ${format(p,true)}`);
      button.addEventListener('click',()=>button.dispatchEvent(new CustomEvent('evolution:point',{bubbles:true,detail:{...p,layer:'node'}})));
      cell.append(button);row.append(cell);
    }
    body.append(row);
  }
  table.append(caption,head,body);container.replaceChildren(table);
}
function render(){
  const d=state.data,b=d.natal,input=d.input;
  if(input.return_place&&timingLayer(d)?.kind==='solar_return'&&state.returnPlace){state.returnPlace.name=timingLayer(d).place.name;$('return-city').value=state.returnPlace.name;}
  syncTimingControls();
  $('chart-title').textContent=$('chart-name').value.trim()||'Untitled chart';
  const date=new Date(`${input.birth.date}T12:00:00Z`).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
  $('chart-subtitle').textContent=`${date} · ${input.birth.time||'Birth time unknown'} · ${b.place.name}`;
  $('house-badge').textContent=`${b.houses.length?HOUSE[input.house_system].toUpperCase():'NO BIRTH HOUSES'} · TROPICAL`;
  $('progressions').disabled=input.birth.confidence==='unknown';
  $('progression-hint').textContent=input.birth.confidence==='unknown'?'Requires a stated birth time':'Progressions, solar arc or solar return';
  const summary=[['☉','SUN',b.planets.find(p=>p.id==='sun')],['☽','MOON',b.planets.find(p=>p.id==='moon')],['↑','RISING',b.ascendant]];
  $('chart-signature').replaceChildren(...summary.map(([glyph,label,p])=>{
    const card=node('div',undefined,'signature-point'),details=node('div');
    details.append(node('small',label),node('strong',p?dms(p.longitude).sign:'Unknown time'),node('em',p?dms(p.longitude).short:'Angles omitted'));
    card.append(node('span',glyph),details);return card;
  }));
  $('wheel-caption').textContent=`${b.ascendant?'Ascendant at left':'0° Aries at left · birth time unknown'} · ${input.node_reference==='heliocentric'?'Heliocentric node longitudes':'Geocentric node points'} · Natal node epoch${timingLayer(d)?' · '+timingLabel(d)+' outer ring':''}`;
  $('timing-aspect-option').textContent=`${timingLabel(d)} → natal planets, angles & nodes`;
  const focusOptions=d.planetary_nodes.map(p=>new Option(p.name,p.body));$('focus-planet').replaceChildren(...focusOptions);$('focus-planet').value=state.focus;
  const currentFilter=$('aspect-filter').value;
  $('aspect-filter').replaceChildren(new Option('All planets','all'),...d.planetary_nodes.map(p=>new Option(p.name,p.body)));$('aspect-filter').value=currentFilter||'all';
  const buttons=d.planetary_nodes.map(p=>{const button=node('button',p.name);button.type='button';button.setAttribute('aria-pressed',state.visibleNodes.has(p.body));button.addEventListener('click',()=>{if(state.visibleNodes.has(p.body))state.visibleNodes.delete(p.body);else state.visibleNodes.add(p.body);button.setAttribute('aria-pressed',state.visibleNodes.has(p.body));renderWheel();});return button;});
  $('node-toggles').replaceChildren(...buttons);
  renderWheel();renderFocus();renderTables();renderAspects();renderMethod();
  $('selected-detail').textContent='Select a planet or node on the wheel to see its exact position.';
}
function renderFocus(){
  const d=state.data,pair=d.planetary_nodes.find(p=>p.body===state.focus),planet=d.natal.planets.find(p=>p.id===state.focus);
  if(!pair||!planet)return;
  $('focus-planet').value=state.focus;
  const stops=[['south','South node · familiar patterns',pair.south],['present','Natal planet · integration',planet],['north','North node · development',pair.north]];
  $('planet-story').replaceChildren(...stops.map(([cls,label,p])=>{const stop=node('div',undefined,`story-stop ${cls}`);stop.append(node('p',label,'stop-label'),node('h3',format(p)),node('small',`${house(p)}${cls==='present'&&p.retrograde?' · retrograde':''}`));return stop;}));
  $('focus-method').textContent=`${pair.method==='mean'?'Mean':'Osculating'} ${pair.name} nodes · ${d.input.node_reference} · ${HOUSE[d.input.house_system]} houses${!d.natal.houses.length?' omitted (unknown birth time)':''}.`;
  const f=d.focus;
  const rows=[['Natal Pluto',f.pluto],['Polarity point',f.polarity],['Lunar south node',f.south_node],['South-node ruler',f.south_ruler],['Lunar north node',f.north_node],['North-node ruler',f.north_ruler]];
  $('evolution-focus').replaceChildren(...rows.map(([label,p])=>{const row=node('div',undefined,'focus-row'),value=node('strong',label.includes('ruler')?p.name:format(p));value.append(node('small',`${label.includes('ruler')?format(p)+' · ':''}${house(p)}`));row.append(node('span',label),value);return row;}));
}
function positionCell(p){const cell=node('td',dms(p.longitude).short);cell.append(node('small',`${dms(p.longitude).sign} · ${house(p)}`));return cell;}
function renderTables(){
  const d=state.data,byId=Object.fromEntries(d.natal.planets.map(p=>[p.id,p]));
  $('nodes-table').replaceChildren(...d.planetary_nodes.map(pair=>{const row=node('tr'),label=node('td'),button=node('button',pair.name);button.type='button';button.addEventListener('click',()=>{state.focus=pair.body;state.visibleNodes.add(pair.body);$('show-nodes').checked=true;render();showTab('wheel');});label.append(button,node('small',pair.method));row.append(label,positionCell(pair.south),positionCell(byId[pair.body]),positionCell(pair.north));return row;}));
  const compare=node('div',undefined,'lunar-comparison');
  for(const mode of ['true','mean']){const [north,south]=d.lunar_nodes[mode];const p=node('p');p.append(node('span',mode==='true'?'True':'Mean'),node('strong',`☊ ${format(north)} · ☋ ${format(south)}`));compare.append(p);}
  $('lunar-comparison').replaceChildren(compare);
  renderPositions();
}
function renderPositions(){
  const d=state.data,timing=timingLayer(d),option=$('position-layer').querySelector('[value="timing"]');
  option.disabled=!timing;option.textContent=timingLabel(d);
  if(!timing)$('position-layer').value='natal';
  const overlay=$('position-layer').value==='timing',layer=overlay?timing:d.natal,label=overlay?timingLabel(d):'Natal';
  $('positions-title').textContent=label+' positions';
  $('positions-context').textContent=`${overlay?timingSummary(d)+' · ':''}ASC ${format(layer.ascendant)} · MC ${format(layer.midheaven)}. House numbers refer to this layer’s cusps${overlay?'; natal-house placement is shown separately':''}.`;
  $('natal-house-heading').hidden=!overlay;
  $('positions-table').replaceChildren(...layer.planets.map(p=>{const row=node('tr'),natalHouse=node('td',p.house_in_natal??'—');natalHouse.hidden=!overlay;row.append(node('td',p.name),node('td',format(p,true)),node('td',p.house??'—'),natalHouse,node('td',p.retrograde===null?'Symbolic':p.retrograde?'Retrograde':'Direct'));return row;}));
  $('house-layer-label').textContent=`${label} · ${HOUSE[d.input.house_system]}${overlay&&layer.kind==='solar_return'?' · '+layer.place.name:''}`;
  $('houses-table').replaceChildren(...layer.houses.map(h=>{const row=node('tr');row.append(node('td',h.number),node('td',format(h,true)));return row;}));
  if(!layer.houses.length){const row=node('tr'),cell=node('td','Houses omitted: birth time unknown.');cell.colSpan=2;row.append(cell);$('houses-table').append(row);}
}
function lookup(){
  const d=state.data,values=[...d.natal.planets,...d.planetary_nodes.flatMap(p=>[p.north,p.south]),d.focus.polarity];
  if(d.natal.ascendant)values.push({id:'ascendant',name:'Ascendant',...d.natal.ascendant});
  if(d.natal.midheaven)values.push({id:'midheaven',name:'Midheaven',...d.natal.midheaven});
  return Object.fromEntries(values.map(p=>[p.id,p]));
}
function renderAspects(){
  if(!state.data)return;const d=state.data,kind=$('aspect-group').value,filter=$('aspect-filter').value;
  let rows=kind==='nodes'?d.node_to_node_aspects:kind==='progressed'?(d.timing_aspects||d.progression_aspects):d.node_aspects;
  const names=lookup();
  rows=rows.filter(a=>filter==='all'||[a.a,a.b].some(id=>id===filter||id.startsWith(filter+'_'))).sort((a,b)=>a.orb-b.orb);
  $('aspect-count').textContent=d.node_aspects.length;
  $('aspect-summary').textContent=`${rows.length} contacts within a ${d.input.node_orb}° orb. Select a contact to highlight it on the wheel.`;
  $('aspects-table').replaceChildren(...rows.map(a=>{const tr=node('tr'),from=node('td'),button=node('button',(kind==='progressed'?timingLabel(d)+' · ':'')+(names[a.a]?.name||a.a));button.type='button';button.addEventListener('click',()=>{state.highlight={...a,group:kind};showTab('wheel');renderWheel();$('selected-detail').textContent=`${kind==='progressed'?timingLabel(d)+' ':''}${names[a.a]?.name||a.a} ${a.type} ${names[a.b]?.name||a.b} · orb ${(a.orb).toFixed(3)}°`;});from.append(button);tr.append(from,node('td',ASPECT[a.angle]||a.type),node('td',names[a.b]?.name||a.b),node('td',dms(a.orb).short));return tr;}));
  if(!rows.length){const tr=node('tr'),td=node('td',kind==='progressed'&&!timingLayer(d)?'Enable a timing overlay to view these contacts.':'No contacts within the selected orb.');td.colSpan=4;tr.append(td);$('aspects-table').append(tr);}
}
function renderMethod(){
  const d=state.data,c=d.calculation,b=d.natal.birth;
  const rows=[['Engine',`${c.engine} ${c.version} · pinned source ${c.source_commit}`],['Birth time',`${b.utc} UTC · ${b.timezone||d.natal.place.timezone}`],['Zodiac & houses',`Tropical · ${d.natal.houses.length?HOUSE[d.input.house_system]:'houses and angles omitted'}`],['Lunar nodes',d.input.lunar_node==='true'?'True (osculating) lunar nodes':'Mean lunar nodes'],['Planetary-node reference',d.input.node_reference==='geocentric'?'Geocentric orbital intersection points. North and south need not be opposite.':'Heliocentric node longitudes, symbolically projected onto natal houses.'],['Planetary-node method',d.input.node_method.replaceAll('_',' ')],['Pluto & small bodies',c.planetary_node_note],['House placement',c.house_assignment],['Node aspects',`${d.input.node_orb}° maximum orb · 0°, 60°, 90°, 120°, ${d.input.quincunx?'150°, ':''}180°`],['Sign rulership',`${d.input.ruler_mode} · single-ruler convention`],['Progressions',d.progressed?`${c.progression}. Target: ${d.progressed.technique.target_utc}. Ephemeris epoch: ${d.progressed.technique.ephemeris_utc}.`:'Not enabled. The optional progression layer uses direct secondary progressions with Naibod axes.'],['Data & storage','No chart database or analytics. Save stores one chart and notes in this browser. Export creates a local JSON file.'],['Planetary-node epoch','Birth epoch. Planetary nodes remain natal with every timing overlay.']];
  const layer=timingLayer(d);
  rows.splice(rows.findIndex(([label])=>label==='Progressions'),1,
    ['Timing overlay',layer?timingSummary(d):'Not enabled. Choose Secondary progressions, Solar arc or Solar return.'],
    ['Secondary progression convention',c.progression+(layer?.kind==='progressed'?` · Target ${layer.technique.target_utc} · Ephemeris epoch ${layer.technique.ephemeris_utc}`:'')],
    ['Solar arc convention',c.solar_arc+(layer?.kind==='solar_arc'?` · Arc ${layer.technique.arc.toFixed(8)}° · Ephemeris epoch ${layer.technique.ephemeris_utc}`:'')],
    ['Solar return convention',c.solar_return+(layer?.kind==='solar_return'?` · ${layer.technique.place_choice==='birthplace'?'Birthplace':'Selected return place'}: ${layer.place.name}, ${layer.place.latitude}°, ${layer.place.longitude}°, ${layer.place.timezone} · Local return ${layer.birth.local} · Solar error ${layer.technique.solar_error_arcsec.toFixed(6)} arcseconds.`:'')],
    ['Equal House','Twelve 30° houses, starting at the Ascendant. The MC is an independent angle, not necessarily cusp 10.'],
    ['Timing house placement','The outer ring shows the timing layer’s house ticks and ASC/MC. The position table distinguishes own houses from natal-house placement.']);
  $('method-details').replaceChildren(...rows.flatMap(([k,v])=>[node('dt',k),node('dd',v)]));
  $('warnings').replaceChildren(...d.warnings.map(w=>node('p',w)));
}
function showTab(name){
  for(const button of document.querySelectorAll('[data-tab]')){const active=button.dataset.tab===name;button.setAttribute('aria-selected',active);button.tabIndex=active?0:-1;$('panel-'+button.dataset.tab).hidden=!active;}
}
function viewState(){return {focus:state.focus,visible_nodes:[...state.visibleNodes],show_nodes:$('show-nodes').checked,show_polarity:$('show-polarity').checked,compare_nodes:$('compare-nodes').checked,show_extras:$('show-extras').checked,position_layer:$('position-layer').value};}
function fileData(){return {contract:'stjernerne-evolution-file-1',name:$('chart-name').value,notes:$('reading-notes').value,place_label:state.data.natal.place.name,input:state.data.input,view:viewState(),result:state.data};}
function download(content,type,filename){const url=URL.createObjectURL(new Blob([content],{type}));const a=node('a');a.href=url;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);}
function applyInput(input,name='Imported chart',label='',view={}){
  $('notes-state').textContent='';
  $('storage-note').textContent='';
  const b=input.birth;state.birthMeta=Object.fromEntries(['confidence','uncertainty_minutes','offset_minutes','offset_source'].filter(k=>b[k]!=null).map(k=>[k,b[k]]));state.extraSelection=input.extras||EXTRA;$('chart-name').value=name;$('birth-date').value=b.date;$('unknown-time').checked=b.confidence==='unknown';$('birth-time').value=b.time||'12:00:00';$('birth-time').disabled=b.confidence==='unknown';$('birth-time').required=b.confidence!=='unknown';
  state.place=b.place_id?{id:b.place_id,name:label||b.place_name||'Imported birthplace'}:{manual:true,name:b.place_name||label||'Manual coordinates'};
  $('birthplace').value=state.place.name;$('latitude').value=b.latitude??55.67594;$('longitude').value=b.longitude??12.56553;$('timezone').value=b.timezone||'Europe/Copenhagen';
  $('houses').value=input.house_system||'O';$('lunar-mode').value=input.lunar_node||'true';$('node-reference').value=input.node_reference||'geocentric';$('node-method').value=input.node_method||'mean_barycentric';if(![...$('node-orb').options].some(o=>o.value===String(input.node_orb||3)))$('node-orb').add(new Option(String(input.node_orb)+'°',String(input.node_orb)));$('node-orb').value=String(input.node_orb||3);$('ruler-mode').value=input.ruler_mode||'modern';$('quincunx').checked=input.quincunx!==false;$('progressions').checked=!!input.include_progressions;$('progression-controls').hidden=!input.include_progressions;$('progression-date').value=input.target?.date||'2026-10-16';
  $('show-nodes').checked=view.show_nodes!==false;$('show-polarity').checked=view.show_polarity!==false;$('compare-nodes').checked=!!view.compare_nodes;$('show-extras').checked=!!view.show_extras;
  state.visibleNodes=new Set(Array.isArray(view.visible_nodes)?view.visible_nodes:['pluto','uranus']);state.focus=view.focus||'pluto';state.fold=b.fold??null;
  state.includeExtraNodes=input.include_extra_nodes!==false;state.targetFold=input.target?.fold??null;
  $('timing-mode').value=input.timing_mode||'secondary';$('target-time').value=input.target?.time||'12:00:00';$('target-timezone').value=input.target?.timezone||'UTC';$('return-year').value=input.return_year||2026;
  const r=input.return_place;state.returnPlace=r?(r.place_id?{id:r.place_id,name:'Saved return location'}:{manual:true,name:r.place_name||'Manual return location'}):null;
  $('return-location').value=r?'other':'birthplace';$('return-city').value=state.returnPlace?.name||'';
  $('return-latitude').value=r?.latitude??55.67594;$('return-longitude').value=r?.longitude??12.56553;$('return-timezone').value=r?.timezone||'Europe/Copenhagen';syncTimingControls();
  $('position-layer').value=view.position_layer==='timing'?'timing':'natal';
}
async function loadFile(value){
  if(value.contract!=='stjernerne-evolution-file-1'||!value.input?.birth)throw new Error('Choose an Evolutionary Astrology JSON export.');
  if(typeof value.notes==='string'&&value.notes.length>10000)throw new Error('The notes are too long.');
  applyInput(value.input,String(value.name||'Imported chart').slice(0,80),value.place_label,value.view||{});$('reading-notes').value=value.notes||'';$('example-note').textContent='Your imported chart.';$('place-detail').textContent='Birthplace restored from the saved calculation.';
  const returnName=value.result?.timing?.place?.name;
  if(state.returnPlace&&returnName){state.returnPlace.name=returnName;$('return-city').value=returnName;syncTimingControls();}
  return calculate();
}
$('chart-form').addEventListener('submit',e=>{e.preventDefault();calculate();});
for(const el of document.querySelectorAll('#chart-form input:not(#chart-name), #chart-form select, .advanced select, .advanced input'))el.addEventListener('change',markDirty);
$('chart-name').addEventListener('input',()=>{if(state.data){$('chart-title').textContent=$('chart-name').value||'Untitled chart';renderWheel();}});
$('unknown-time').addEventListener('change',()=>{$('birth-time').disabled=$('unknown-time').checked;$('birth-time').required=!$('unknown-time').checked;$('progressions').disabled=$('unknown-time').checked;$('progression-hint').textContent=$('unknown-time').checked?'Requires a stated birth time':'Progressions, solar arc or solar return';if($('unknown-time').checked)$('progressions').checked=false;syncTimingControls();});
for(const id of ['show-nodes','show-polarity','compare-nodes','show-extras'])$(id).addEventListener('change',renderWheel);
$('focus-planet').addEventListener('change',()=>{state.focus=$('focus-planet').value;state.visibleNodes.add(state.focus);$('show-nodes').checked=true;state.highlight=null;render();});
for(const button of document.querySelectorAll('[data-view]'))button.addEventListener('click',()=>{
  const preset=READING_VIEWS[button.dataset.view];state.visibleNodes=new Set(preset.nodes.filter(k=>state.data?.planetary_nodes.some(p=>p.body===k)));
  $('show-nodes').checked=preset.nodes.length>0;$('show-polarity').checked=preset.polarity;$('compare-nodes').checked=preset.compare;state.highlight=null;
  render();
});
$('progressions').addEventListener('change',()=>{syncTimingControls();markDirty();if(!$('progressions').checked)calculate();});
$('timing-mode').addEventListener('change',()=>{syncTimingControls();markDirty();});
$('return-location').addEventListener('change',()=>{syncTimingControls();markDirty();});
for(const id of ['progression-date','target-time','target-timezone'])$(id).addEventListener('change',()=>{state.targetFold=null;markDirty();});
for(const id of ['return-year','return-latitude','return-longitude','return-timezone'])$(id).addEventListener('change',markDirty);
$('position-layer').addEventListener('change',renderPositions);
for(const id of ['apply-settings','apply-progression'])$(id).addEventListener('click',calculate);
for(const el of document.querySelectorAll('[data-tab]')){el.addEventListener('click',()=>showTab(el.dataset.tab));el.addEventListener('keydown',e=>{const tabs=[...document.querySelectorAll('[data-tab]')],index=tabs.indexOf(el);if(['ArrowRight','ArrowLeft','Home','End'].includes(e.key)){e.preventDefault();const target=e.key==='Home'?tabs[0]:e.key==='End'?tabs.at(-1):tabs[(index+(e.key==='ArrowRight'?1:tabs.length-1))%tabs.length];showTab(target.dataset.tab);target.focus();}});}
$('aspect-filter').addEventListener('change',renderAspects);$('aspect-group').addEventListener('change',renderAspects);
document.addEventListener('evolution:point',e=>{
  const p=e.detail,id=p.body||p.id;
  if(state.data.planetary_nodes.some(pair=>pair.body===id)){
    state.focus=id;renderFocus();
    $('focus-context').textContent='Exploring '+state.data.planetary_nodes.find(pair=>pair.body===id).name;
    for(const marker of document.querySelectorAll('svg [data-point]')){
      const selected=marker.dataset.body===id;marker.setAttribute('data-focus',selected);
      const circle=marker.querySelector('circle');circle.setAttribute('fill',selected?'#f2edda':marker.dataset.fill);circle.setAttribute('stroke',selected?'#a58a58':marker.dataset.ink);circle.setAttribute('stroke-width',selected?'1.8':'.9');
    }
  }
  $('selected-detail').replaceChildren(node('strong',p.name),document.createTextNode(` · ${pointDetail(p)}${p.method?' · '+p.method+' · '+p.reference:''}`));
  $('large-wheel-detail').textContent=`${p.name} · ${pointDetail(p)}`;
});
$('expand-wheel').addEventListener('click',()=>{if(!state.data||state.dirty)return;$('wheel-dialog').showModal();renderWheel();});
$('close-wheel').addEventListener('click',()=>$('wheel-dialog').close());
function preparePrint(){
  if(!state.data)return false;
  const options=viewOptions();
  $('print-document').replaceChildren(renderPrintSheet(state.data,options,'paper-evo'));
  $('print-preview-sheet').replaceChildren(renderPrintSheet(state.data,options,'preview-evo'));
  return true;
}
function fitPrintPreview(){
  if(!$('print-dialog').open)return;
  const stage=$('print-preview-stage'),sheet=$('print-preview-sheet');
  const scale=Math.max(.01,Math.min((stage.clientWidth-24)/sheet.offsetWidth,(stage.clientHeight-24)/sheet.offsetHeight));
  sheet.style.setProperty('--print-preview-scale',scale);
}
function openPrint(){if(state.dirty||state.busy||!preparePrint())return;$('print-dialog').showModal();fitPrintPreview();}
$('print-chart').addEventListener('click',openPrint);
$('print-large').addEventListener('click',openPrint);
$('close-print').addEventListener('click',()=>$('print-dialog').close());
$('confirm-print').addEventListener('click',()=>{if(preparePrint())window.print();});
window.addEventListener('beforeprint',preparePrint);
new ResizeObserver(fitPrintPreview).observe($('print-preview-stage'));
$('wheel-dialog').addEventListener('click',event=>{if(event.target!==$('wheel-dialog'))return;const r=$('wheel-dialog').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)$('wheel-dialog').close();});
for(const [button,target] of [['edit-birth','chart-form'],['edit-layers','layer-controls']])$(button).addEventListener('click',()=>{const destination=$(target);destination.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion:reduce)').matches?'auto':'smooth',block:'start'});destination.querySelector('input:not([disabled]),button:not([disabled])')?.focus({preventScroll:true});});
$('use-coordinates').addEventListener('click',()=>{if(![$('latitude'),$('longitude'),$('timezone')].every(e=>e.reportValidity()))return;state.fold=null;state.place={manual:true,name:$('birthplace').value.trim()||'Manual coordinates'};$('place-detail').textContent=`${$('latitude').value}°, ${$('longitude').value}° · ${$('timezone').value}`;markDirty();toast('Manual coordinates selected. Calculate to update.');});
$('birthplace').addEventListener('input',()=>{
  state.place=null;state.fold=null;markDirty();clearTimeout(searchTimer);placeAbort?.abort();const q=$('birthplace').value.trim();if(q.length<2){hidePlaces();return;}
  searchTimer=setTimeout(async()=>{const controller=new AbortController();placeAbort=controller;try{const r=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});if(!r.ok)throw new Error('Birthplace search unavailable.');const rows=await r.json();$('place-results').replaceChildren(...rows.map(p=>{const li=node('li'),b=node('button',`${p.name}, ${p.country}`);b.type='button';b.setAttribute('role','option');b.append(node('small',`${p.region||''} · ${p.timezone}`));b.addEventListener('click',()=>{state.place={id:p.id,name:`${p.name}, ${p.country}`};$('birthplace').value=state.place.name;$('latitude').value=p.latitude;$('longitude').value=p.longitude;$('timezone').value=p.timezone;$('place-detail').textContent=`${p.latitude.toFixed(3)}°, ${p.longitude.toFixed(3)}° · ${p.timezone}`;hidePlaces();$('birthplace').focus();});li.append(b);return li;}));if(!rows.length)$('place-results').append(node('li','No matching places. Use manual coordinates.'));$('place-results').hidden=false;$('birthplace').setAttribute('aria-expanded','true');}catch(error){if(error.name!=='AbortError'){$('place-detail').textContent=error.message;hidePlaces();}}},250);
});
function hidePlaces(){$('place-results').hidden=true;$('birthplace').setAttribute('aria-expanded','false');}
$('birthplace').addEventListener('keydown',e=>{if(e.key==='ArrowDown'){e.preventDefault();$('place-results').querySelector('button')?.focus();}if(e.key==='Escape')hidePlaces();});
$('place-results').addEventListener('keydown',e=>{const buttons=[...$('place-results').querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:buttons.length-1))%buttons.length]?.focus();}if(e.key==='Escape'){hidePlaces();$('birthplace').focus();}});
function hideReturnPlaces(){$('return-results').hidden=true;$('return-city').setAttribute('aria-expanded','false');}
$('use-return-coordinates').addEventListener('click',()=>{
  if(![$('return-latitude'),$('return-longitude'),$('return-timezone')].every(e=>e.value.trim()&&e.reportValidity()))return;
  state.returnPlace={manual:true,name:$('return-city').value.trim()||'Manual return location'};syncTimingControls();hideReturnPlaces();markDirty();toast('Return location selected. Apply the timing overlay to update.');
});
$('return-city').addEventListener('input',()=>{
  state.returnPlace=null;syncTimingControls();markDirty();clearTimeout(returnSearchTimer);returnPlaceAbort?.abort();const q=$('return-city').value.trim();
  if(q.length<2){hideReturnPlaces();return;}
  returnSearchTimer=setTimeout(async()=>{
    const controller=new AbortController();returnPlaceAbort=controller;
    try{
      const response=await fetch('/api/places?q='+encodeURIComponent(q),{signal:controller.signal});if(!response.ok)throw new Error('Return-place search unavailable.');
      const rows=await response.json();
      $('return-results').replaceChildren(...rows.map(p=>{const item=node('li'),button=node('button',`${p.name}, ${p.country}`);button.type='button';button.setAttribute('role','option');button.append(node('small',`${p.region||''} · ${p.timezone}`));button.addEventListener('click',()=>{state.returnPlace={id:p.id,name:`${p.name}, ${p.country}`};$('return-city').value=state.returnPlace.name;$('return-latitude').value=p.latitude;$('return-longitude').value=p.longitude;$('return-timezone').value=p.timezone;hideReturnPlaces();syncTimingControls();$('return-city').focus();});item.append(button);return item;}));
      if(!rows.length)$('return-results').append(node('li','No matching places. Use manual coordinates.'));
      $('return-results').hidden=false;$('return-city').setAttribute('aria-expanded','true');
    }catch(error){if(error.name!=='AbortError'){$('return-place-detail').textContent=error.message;hideReturnPlaces();}}
  },250);
});
$('return-city').addEventListener('keydown',event=>{if(event.key==='ArrowDown'){event.preventDefault();$('return-results').querySelector('button')?.focus();}if(event.key==='Escape')hideReturnPlaces();});
$('return-results').addEventListener('keydown',event=>{const buttons=[...$('return-results').querySelectorAll('button')],i=buttons.indexOf(document.activeElement);if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();buttons[(i+(event.key==='ArrowDown'?1:buttons.length-1))%buttons.length]?.focus();}if(event.key==='Escape'){hideReturnPlaces();$('return-city').focus();}});
document.addEventListener('click',e=>{if(!e.target.closest('.place-field')){hidePlaces();hideReturnPlaces();}});
function saveChart(){try{localStorage.setItem(KEY,JSON.stringify(fileData()));$('storage-note').textContent='Chart and notes saved in this browser.';$('notes-state').textContent='Saved locally';toast('Chart and notes saved.');}catch{toast('Browser storage is unavailable. Use JSON export.');}}
$('save-chart').addEventListener('click',saveChart);$('save-notes').addEventListener('click',saveChart);
$('reading-notes').addEventListener('input',()=>{$('notes-state').textContent='Unsaved notes';});
$('open-saved').addEventListener('click',async()=>{try{const text=localStorage.getItem(KEY);if(!text)return toast('No chart has been saved in this browser yet.');if(await loadFile(JSON.parse(text)))toast('Saved chart restored and recalculated.');}catch(error){toast(error.message||'The saved chart could not be opened.');}});
$('export-json').addEventListener('click',()=>download(JSON.stringify(fileData(),null,2),'application/json','evolutionary-chart.json'));
$('export-svg').addEventListener('click',()=>{
  const svg=$('wheel').querySelector('svg')?.cloneNode(true);if(!svg)return;
  const metadata=document.createElementNS('http://www.w3.org/2000/svg','metadata');
  svg.setAttribute('role','img');svg.removeAttribute('aria-roledescription');
  metadata.textContent=JSON.stringify({contract:state.data.contract,input:state.data.input,calculation:state.data.calculation,view:viewState()});svg.prepend(metadata);
  for(const marker of svg.querySelectorAll('[data-point]')){marker.removeAttribute('tabindex');marker.removeAttribute('role');}
  download(new XMLSerializer().serializeToString(svg),'image/svg+xml','evolutionary-chart.svg');
});
$('import-button').addEventListener('click',()=>$('import-file').click());
$('import-file').addEventListener('change',async()=>{try{const file=$('import-file').files[0];if(!file)return;if(file.size>2_000_000)throw new Error('Choose a JSON file smaller than 2 MB.');if(await loadFile(JSON.parse(await file.text())))toast('Chart imported and recalculated.');}catch(error){showError(error.message||'The JSON file could not be imported.');}finally{$('import-file').value='';}});
$('reset-demo').addEventListener('click',()=>{applyInput(DEFAULT,'Alex Morgan','Copenhagen, Denmark');$('reading-notes').value='';$('example-note').textContent='A fictional chart to explore the workspace.';$('place-detail').textContent='55.676° N · 12.566° E · Europe/Copenhagen';showTab('wheel');calculate();});

// Embedding contract: only the same-origin parent may supply birth data.
// Other workspaces can mount this page in an iframe without sharing global UI state.
window.addEventListener('message',async event=>{
  if(event.origin!==location.origin||event.source!==window.parent||window.parent===window)return;
  if(event.data?.type!=='stjernerne:evolution:birth')return;
  try{const input={...DEFAULT,...event.data.settings,birth:event.data.birth};applyInput(input,String(event.data.name||'Host chart').slice(0,80),event.data.place_label||'Host birthplace');$('example-note').textContent='Chart supplied by the parent workspace.';const ok=await calculate();window.parent.postMessage({type:'stjernerne:evolution:result',ok,contract:'stjernerne-evolution-1'},location.origin);}catch{showError('The parent workspace supplied invalid chart data.');}
});
if(new URLSearchParams(location.search).get('embed')==='1')document.body.classList.add('embedded');
if(window.parent!==window)window.parent.postMessage({type:'stjernerne:evolution:ready'},location.origin);
calculate();
