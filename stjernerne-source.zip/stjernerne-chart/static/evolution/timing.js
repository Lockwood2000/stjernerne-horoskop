// The former secondary-only response remains readable in saved charts.
export const timingLayer=data=>data.timing||data.progressed||null;
export function timingLabel(data){
  const layer=timingLayer(data);
  return layer?.kind==='solar_arc'?'Solar arc':layer?.kind==='solar_return'?'Solar return':'Secondary progressions';
}
export function timingSummary(data){
  const layer=timingLayer(data);if(!layer)return '';
  const utc=value=>new Date(value).toLocaleString('en-GB',{dateStyle:'medium',timeStyle:'short',timeZone:'UTC'})+' UTC';
  if(layer.kind==='solar_return')return `Solar return ${layer.technique.year} · ${layer.place.name} · ${utc(layer.birth.utc)}`;
  return `${timingLabel(data)} · Target ${utc(layer.technique.target_utc)}`;
}
