/** Mount the evolutionary workspace over an existing same-origin generator.
 * Usage: openEvolutionOverlay({birth, name, place_label, settings}).
 * The birth schema is shared with /api/school/chart; no birth data in URLs.
 */
export function openEvolutionOverlay(payload){
  const dialog=document.createElement('dialog');
  dialog.setAttribute('aria-label','Evolutionary astrology overlay');
  dialog.style.cssText='width:calc(100vw - 32px);max-width:1700px;height:calc(100vh - 32px);padding:0;border:1px solid #c5cabd;border-radius:10px;background:#f5f3ec;overflow:hidden;';
  const bar=document.createElement('div');bar.style.cssText='height:50px;display:flex;gap:20px;align-items:center;justify-content:space-between;padding:8px 20px;border-bottom:1px solid #ddd;font:12px Arial,sans-serif;color:#344e49;';
  const title=document.createElement('strong');title.textContent='Evolutionary astrology · '+String(payload.name||'Current chart');
  const close=document.createElement('button');close.type='button';close.textContent='Close overlay ×';close.style.cssText='padding:6px 10px;border:1px solid #c5cabd;border-radius:4px;background:transparent;color:inherit;cursor:pointer;';
  bar.append(title,close);
  const iframe=document.createElement('iframe');iframe.src='/evolution?embed=1';iframe.title='Evolutionary astrology workspace';iframe.style.cssText='display:block;width:100%;height:calc(100% - 50px);border:0;';iframe.setAttribute('sandbox','allow-scripts allow-same-origin allow-forms allow-downloads');
  let sent=false;
  const message=event=>{
    if(event.origin!==location.origin||event.source!==iframe.contentWindow||event.data?.type!=='stjernerne:evolution:ready'||sent)return;
    sent=true;
    const settings={...payload.settings};
    if(!['O','P','W','E','R'].includes(settings.house_system)){
      settings.house_system='O';title.textContent+=' · overlay uses Porphyry houses';
    }
    iframe.contentWindow.postMessage({type:'stjernerne:evolution:birth',...payload,settings},location.origin);
  };
  window.addEventListener('message',message);
  dialog.append(bar,iframe);document.body.append(dialog);dialog.showModal();
  close.addEventListener('click',()=>dialog.close());
  dialog.addEventListener('close',()=>{window.removeEventListener('message',message);dialog.remove();},{once:true});
  return dialog;
}
