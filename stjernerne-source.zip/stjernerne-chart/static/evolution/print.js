import {dms} from '../wheel.js';
import {renderEvolution} from './wheel.js';
import {timingLayer,timingLabel,timingSummary} from './timing.js';

const make=(tag,text,cls)=>{const element=document.createElement(tag);if(text!==undefined)element.textContent=text;if(cls)element.className=cls;return element;};
const method={mean_barycentric:'Mean where available',osculating_barycentric:'Osculating · barycentric outer orbits',osculating_heliocentric:'Osculating · heliocentric orbits'};

export function renderPrintSheet(data,options={},idPrefix='print-evo'){
  const sheet=make('article',undefined,'horoscope-sheet');
  sheet.setAttribute('aria-label','A4 landscape horoscope');
  const head=make('header',undefined,'paper-heading'),brand=make('div',undefined,'paper-brand');
  const title=options.name?.trim()||'Natal chart';
  if(title.length>45)head.className+=' is-long-title';
  brand.append(make('span','✳ STJERNERNE'),make('span','EVOLUTIONARY ASTROLOGY'));
  const date=new Date(`${data.input.birth.date}T12:00:00Z`).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric',timeZone:'UTC'});
  const time=data.input.birth.time||'Birth time unknown';
  head.append(brand,make('h1',title),make('p',`${date} · ${time} · ${data.natal.place.name}`));

  const main=make('div',undefined,'paper-main'),chart=make('figure',undefined,'paper-wheel');
  const svg=renderEvolution(data,{...options,largeText:true,idPrefix});
  svg.setAttribute('role','img');svg.removeAttribute('aria-roledescription');
  for(const marker of svg.querySelectorAll('[data-point]')){marker.removeAttribute('tabindex');marker.removeAttribute('role');}
  chart.append(svg);

  const pairs=options.showNodes?data.planetary_nodes.filter(p=>options.visibleNodes?.has(p.body)):[];
  const side=make('aside',undefined,'paper-nodes');
  side.append(make('p','THE PLANETARY NODES','paper-eyebrow'),make('h2',`${pairs.length} ${pairs.length===1?'pair':'pairs'} · ${pairs.length*2} points`));
  if(pairs.length){
    const table=make('table'),thead=make('thead'),heading=make('tr'),tbody=make('tbody');
    for(const label of ['Body','North','South']){const th=make('th',label);th.scope='col';heading.append(th);}
    thead.append(heading);
    for(const pair of pairs){
      const row=make('tr');row.append(make('th',pair.name));
      row.firstChild.scope='row';
      for(const name of ['north','south']){const p=dms(pair[name].longitude);row.append(make('td',`${p.short} ${p.sign.slice(0,3)}`,name));}
      tbody.append(row);
    }
    table.append(thead,tbody);side.append(table);
  }else side.append(make('p','Planetary-node overlay hidden.','paper-note'));
  const legend=make('div',undefined,'paper-legend');
  legend.append(make('span','● Natal planets','natal'),make('span','● North nodes','north'),make('span','● South nodes','south'));
  if(timingLayer(data))legend.append(make('span','● '+timingLabel(data),'progressed'));
  side.append(legend,make('p','Lines connect the labels to the exact node positions. N = north; S = south.','paper-note'));
  if(data.warnings?.length)side.append(make('p',data.warnings.join(' '),'paper-warning'));
  main.append(chart,side);

  const foot=make('footer',undefined,'paper-footer');
  const houses=data.natal.houses.length?data.natal.calculation.houses+' houses':'Houses omitted · birth time unknown';
  const lunar=data.input.lunar_node==='true'?'True lunar nodes':'Mean lunar nodes';
  const reference=data.input.node_reference==='heliocentric'?'Heliocentric node longitudes':'Geocentric node points';
  const lines=make('div');
  lines.append(make('p',`${houses} · Tropical zodiac · ${lunar}`),make('p',`${reference} · ${method[data.input.node_method]||data.input.node_method} · Natal node epoch`));
  if(timingLayer(data))lines.append(make('p',timingSummary(data)));
  foot.append(lines,make('span','STJERNERNE · 1 / 1'));
  sheet.append(head,main,foot);return sheet;
}
