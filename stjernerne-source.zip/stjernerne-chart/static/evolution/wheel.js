import {spreadLabels,dms,houseMidpoints} from '../wheel.js';
import {planetSymbol} from '../symbols.js';
import {layoutNodeCallouts} from './node-layout.js';
import {timingLayer,timingLabel} from './timing.js';
const NS='http://www.w3.org/2000/svg';
const ZODIAC=['♈','♉','♊','♋','♌','♍','♎','♏','♐','♑','♒','♓'];
const CORE=['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto','north_node','south_node'];
const SHORT={north_node:'☊',south_node:'☋',sedna:'Se',quaoar:'Qa',orcus:'Or',gonggong:'Gg',pluto_polarity:'PP'};
const C={ink:'#345444',gold:'#a58a58',muted:'#93a18a',line:'#d6ddca',south:'#ae7959',north:'#4c7c73',prog:'#867293'};
function el(tag,attrs={},text){const node=document.createElementNS(NS,tag);for(const [k,v] of Object.entries(attrs))node.setAttribute(k,v);if(text!==undefined)node.textContent=text;return node;}

export function renderEvolution(data,options={}){
  const base=data.natal,asc=base.ascendant?.longitude??0,timing=timingLayer(data);
  const prefix=options.idPrefix||'evo';
  const svg=el('svg',{viewBox:'-12 -12 1024 1024',xmlns:NS,role:'group','aria-roledescription':'Interactive astrology chart','aria-labelledby':`${prefix}-title ${prefix}-description`});
  svg.append(el('title',{id:`${prefix}-title`},`${options.name||'Natal chart'} · Evolutionary astrology`),el('desc',{id:`${prefix}-description`},`${base.calculation.houses} houses. Natal planets on the inner ring, selected planetary nodes outside the zodiac${timing?' and '+timingLabel(data).toLowerCase()+' in the outermost ring':''}. ${base.ascendant?'Natal Ascendant at the left.':'Unknown birth time: no houses or angles; zero Aries at the left.'} Exact longitudes are indicated by connecting ticks.`));
  const add=(tag,attrs,text)=>{const n=el(tag,attrs,text);svg.append(n);return n;};
  const point=(lon,r)=>{const a=(180-lon+asc)*Math.PI/180;return [500+r*Math.cos(a),500+r*Math.sin(a)];};
  const line=(a,b,color,width=1,extra={})=>add('line',{x1:a[0],y1:a[1],x2:b[0],y2:b[1],stroke:color,'stroke-width':width,...extra});
  const circle=(r,fill='none',stroke=C.line,width=.8)=>add('circle',{cx:500,cy:500,r,fill,stroke,'stroke-width':width});
  const text=(lon,r,t,attrs={})=>{const [x,y]=point(lon,r);return add('text',{x,y,fill:C.ink,'font-family':'Mulish, Arial, sans-serif','font-size':13,'text-anchor':'middle','dominant-baseline':'middle',...attrs},t);};
  circle(393,'#fffefb',C.gold,1);circle(399,'none','#e4e4d6',.6);
  for(let i=0;i<12;i++){
    const a=point(i*30,389),b=point((i+1)*30,389),c=point((i+1)*30,344),d=point(i*30,344);
    add('path',{d:`M${a} A389 389 0 0 0 ${b} L${c} A344 344 0 0 1 ${d} Z`,fill:['#f3e7dc','#ebeddf','#eee6ee','#e5eeea'][i%4],stroke:'#fffefb','stroke-width':1.3});
    text(i*30+15,366,ZODIAC[i]+'\uFE0E',{'font-family':'Arial, sans-serif','font-size':32,fill:['#a17a5e','#7c8660','#927c9c','#668781'][i%4]});
  }
  for(const r of [344,337,324,241,209,193])circle(r,'none',r===193?'#c9d3bf':C.line,r===193?1:.6);
  circle(192,'#f7f8f2','none');
  for(let d=0;d<360;d++)line(point(d,d%30===0?326:d%5===0?330:333),point(d,337),d%30===0?C.gold:'#a9b5a4',d%5===0?1:.5);
  const houses=base.houses,houseCenters=houseMidpoints(houses);
  houses.forEach((h,i)=>{
    const angular=[0,3,6,9].includes(i);
    line(point(h.longitude,193),point(h.longitude,344),angular?'#9caa92':'#d2dacb',angular?1.3:.7);
    text(houseCenters[i],224,i+1,{'font-size':15,fill:'#8a9979','data-house-label':i+1,'data-house-layer':'natal'});
  });
  const visiblePlanets=base.planets.filter(p=>options.showExtras||CORE.includes(p.id));
  const byId=Object.fromEntries(base.planets.map(p=>[p.id,p]));
  if(base.ascendant)byId.ascendant=base.ascendant;if(base.midheaven)byId.midheaven=base.midheaven;
  for(const a of base.aspects){
    if(a.type==='conjunction'||!visiblePlanets.some(p=>p.id===a.a)||!visiblePlanets.some(p=>p.id===a.b))continue;
    const harmony=[60,120].includes(a.angle);
    if(byId[a.a]&&byId[a.b])line(point(byId[a.a].longitude,190),point(byId[a.b].longitude,190),harmony?'#78987e':'#bb947b',a.orb<2?1.1:.7,{'stroke-opacity':options.highlight?.18:.5});
  }
  function marker(p,r,size,color,layer,caption,position){
    const [x,y]=position||point(p.display??p.longitude,r);
    const owner=p.body||(p.id==='pluto_polarity'?'pluto':p.id),focused=owner===options.focus;
    const fill=layer==='natal'?'#fffefb':'#f7f6ee';
    const g=add('g',{'data-point':p.id,'data-body':owner,'data-ink':color,'data-fill':fill,'data-focus':focused,'data-layer':layer,tabindex:0,role:'button','aria-label':`${caption||p.name}: ${dms(p.longitude).full} ${dms(p.longitude).sign}${p.house?' · house '+p.house:''}`});
    g.append(el('circle',{cx:x,cy:y,r:size/2+5,fill:focused?'#f2edda':fill,stroke:focused?C.gold:color,'stroke-width':focused?1.8:.9}));
    if(layer==='node'||p.id==='north_node'||p.id==='south_node'){
      const symbol=planetSymbol('true_node',x,y,size,color);
      if(p.side==='south'||p.id==='south_node')symbol.setAttribute('transform',`rotate(180 ${x} ${y}) ${symbol.getAttribute('transform')}`);
      g.append(symbol);
    }else g.append(planetSymbol(p.id,x,y,size,color,SHORT[p.id]||p.name.slice(0,2)));
    g.append(el('title',{},`${caption||p.name} · ${dms(p.longitude).full} ${dms(p.longitude).sign}${p.house?' · H'+p.house:''}${p.retrograde?' · retrograde':''}`));
    const select=()=>svg.dispatchEvent(new CustomEvent('evolution:point',{bubbles:true,detail:{...p,layer}}));
    g.addEventListener('click',select);g.addEventListener('keydown',e=>{if(['Enter',' '].includes(e.key)){e.preventDefault();select();}});
    return g;
  }
  for(const p of spreadLabels(visiblePlanets,12)){
    line(point(p.longitude,324),point(p.display,311),'#a7b29e',.8,{'class':'exact-tick'});
    const [x,y]=point(p.longitude,324);add('circle',{cx:x,cy:y,r:1.8,fill:C.ink});
    marker(p,286,27,C.ink,'natal');text(p.display,256,dms(p.longitude).short+(p.retrograde?' ℞':''),{'font-size':13,fill:'#6b8060'});
  }
  if(options.showPolarity){
    const p=data.focus.polarity;
    const g=marker(p,243,16,C.gold,'polarity');g.querySelector('circle').setAttribute('fill','#f8f0df');
    line(point(p.longitude,195),point(p.longitude,239),C.gold,.8,{'stroke-dasharray':'3 5'});
  }
  if(options.showNodes){
    circle(421,'none','#d5d8c7',.6);
    const nodes=data.planetary_nodes.filter(p=>options.visibleNodes?.has(p.body)).flatMap(pair=>[pair.north,pair.south]);
    if(nodes.length>12){
      const layout=layoutNodeCallouts(nodes,asc,!!timing,!!options.largeText);
      svg.setAttribute('viewBox',layout.viewBox.join(' '));
      svg.setAttribute('data-node-layout','columns');
      const routeRadius=timing?575:411,rail=timing?580:405;
      for(const p of layout.rows){
        const color=p.side==='north'?C.north:C.south,right=p.sideColumn==='right';
        const exact=point(p.longitude,397),out=point(p.longitude,routeRadius),elbow=500+(right?rail:-rail);
        const edge=p.x+(right?-14:14);
        add('polyline',{points:[exact,out,[elbow,out[1]],[elbow,p.y],[edge,p.y]].map(v=>v.join(',')).join(' '),fill:'none',stroke:color,'stroke-width':.8,'stroke-opacity':.48,'class':'exact-tick'});
        add('circle',{cx:exact[0],cy:exact[1],r:2.2,fill:color,'data-node-tick':p.id});
        const g=marker(p,0,16,color,'node',undefined,[p.x,p.y]);
        const name=data.planetary_nodes.find(pair=>pair.body===p.body)?.name||p.body;
        const labelColor=options.largeText?(p.side==='north'?'#245747':'#7b492f'):color;
        const label=el('g',{'data-node-label':p.id,'font-family':'Mulish, Arial, sans-serif','text-anchor':p.anchor,fill:labelColor});
        label.append(el('text',{x:p.textX,y:p.y-4,'font-size':options.largeText?22:16,'font-weight':700},`${name} ${p.side==='north'?'N':'S'}`),el('text',{x:p.textX,y:p.y+(options.largeText?22:15),'font-size':options.largeText?18:13,'font-weight':options.largeText?650:400},dms(p.longitude).short));
        g.append(label);
      }
    }else for(const p of spreadLabels(nodes,12)){
      const color=p.side==='north'?C.north:C.south;
      line(point(p.longitude,397),point(p.display,416),color,1);
      marker(p,434,20,color,'node');
      const name=data.planetary_nodes.find(pair=>pair.body===p.body)?.name||p.body;
      const [x,y]=point(p.display,474);
      add('text',{x,y:y-5,'text-anchor':'middle','font-family':'Mulish, Arial, sans-serif','font-size':12,fill:color},`${name} ${p.side==='north'?'N':'S'}`);
      add('text',{x,y:y+11,'text-anchor':'middle','font-family':'Mulish, Arial, sans-serif','font-size':11,fill:color},dms(p.longitude).short);
    }
  }
  if(options.compareNodes){
    const alternate=data.input.lunar_node==='true'?'mean':'true';
    for(const p of data.lunar_nodes[alternate]){
      line(point(p.longitude,339),point(p.longitude,354),C.gold,1.5,{'stroke-dasharray':'2 2'});
      text(p.longitude,318,alternate==='mean'?'M':'T',{'font-size':14,fill:C.gold,'font-weight':800});
    }
  }
  if(timing){
    circle(504,'none','#d8cfe0',.8);
    const timingHouses=timing.houses||[],timingCenters=houseMidpoints(timingHouses);
    timingHouses.forEach((h,i)=>{
      line(point(h.longitude,483),point(h.longitude,504),C.prog,.8,{'data-timing-house':h.number});
      text(timingCenters[i],489,h.number,{'font-size':11,fill:C.prog,'data-house-label':h.number,'data-house-layer':'timing'});
    });
    for(const p of spreadLabels(timing.planets.filter(p=>options.showExtras||CORE.includes(p.id)),10)){
      line(point(p.longitude,504),point(p.display,513),C.prog,.8,{'stroke-opacity':.7});
      const [x,y]=point(p.longitude,504);add('circle',{cx:x,cy:y,r:1.6,fill:C.prog});
      marker(p,529,21,C.prog,timing.kind||'progressed');
      text(p.display,555,dms(p.longitude).short,{'font-size':11,fill:C.prog});
    }
    for(const [label,key] of [['ASC','ascendant'],['MC','midheaven']])if(timing[key]){
      const p=timing[key];line(point(p.longitude,478),point(p.longitude,505),C.prog,1.8,{'data-timing-angle':key});
      text(p.longitude,470,label,{'font-size':10,'font-weight':700,fill:C.prog});
    }
    if(svg.getAttribute('data-node-layout')!=='columns')svg.setAttribute('viewBox','-75 -75 1150 1150');
  }
  for(const [label,p] of [['ASC',base.ascendant],['MC',base.midheaven]])if(p){
    line(point(p.longitude,338),point(p.longitude,404),C.gold,1.4);
    const [x,y]=point(p.longitude,406);add('rect',{x:x-17,y:y-8,width:34,height:16,rx:3,fill:'#fffefb'});
    text(p.longitude,406,label,{'font-size':11,'font-weight':800,fill:C.gold});
  }
  if(options.highlight){
    const h=options.highlight,all=Object.fromEntries([...base.planets,...data.planetary_nodes.flatMap(p=>[p.north,p.south]),data.focus.polarity].map(p=>[p.id,p]));
    if(base.ascendant)all.ascendant=base.ascendant;if(base.midheaven)all.midheaven=base.midheaven;
    const from=h.group==='progressed'?(timing?.planets.find(p=>p.id===h.a)||timing?.[h.a]):all[h.a];
    const to=all[h.b];
    if(from&&to){line(point(from.longitude,191),point(to.longitude,191),C.gold,2.5,{'stroke-dasharray':'5 4','data-highlight':'true'});for(const p of [from,to]){const [x,y]=point(p.longitude,191);add('circle',{cx:x,cy:y,r:4,fill:C.gold});}}
  }
  return svg;
}
