"""Numerical contract for house choices and all three evolutionary timing layers."""
from datetime import datetime, timedelta, timezone
import subprocess

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.evolution import ROOT, EvolutionRequest, build_evolution
from app.engine import CalculationError, separation, house_for
from app.school_engine import NAIBOD
from app.techniques import YEAR_DAYS

BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}
TARGET={'date':'2026-10-17','time':'18:45:30','timezone':'Europe/Copenhagen'}
LONDON={'place_name':'London','latitude':51.50853,'longitude':-.12574,'timezone':'Europe/London'}

def result(**kwargs):
    return build_evolution(EvolutionRequest(birth=BIRTH,**kwargs))

def cli(jd,flags):
    return subprocess.check_output([str(ROOT/'build/swetest'),'-edir'+str(ROOT/'data/ephe'),
        '-bj'+str(jd),'-p0','-fPl','-g,','-head',*flags],text=True).strip().splitlines()

@pytest.mark.parametrize('system',['O','P','E','R','W'])
def test_natal_houses_agree_with_swiss_cli_and_nodes_keep_actual_house(system):
    data=result(house_system=system)
    base=data['natal'];where=base['place']
    rows=cli(base['jd_ut1'],['-ut',f"-house{where['longitude']},{where['latitude']},{system}"])
    cusps=[float(row.split(',')[1]) for row in rows if row.startswith('house ')]
    assert len(cusps)==12
    assert all(separation(h['longitude'],c)<1e-6 for h,c in zip(base['houses'],cusps))
    for pair in data['planetary_nodes']:
        for side in ('north','south'):
            assert pair[side]['house']==house_for(pair[side]['longitude'],cusps)
    if system=='E':
        assert separation(cusps[0],base['ascendant']['longitude'])<1e-6
        assert all(separation(cusps[i],cusps[0]+30*i)<1e-6 for i in range(12))
        assert separation(cusps[9],base['midheaven']['longitude'])>1

@pytest.mark.parametrize('system',['O','P','E','R','W'])
@pytest.mark.parametrize('mode',['secondary','solar_arc','solar_return'])
def test_all_timing_layers_keep_17_natal_pairs_and_the_selected_house_method(system,mode):
    plain=result(house_system=system)
    data=result(house_system=system,include_progressions=True,timing_mode=mode,target=TARGET,return_year=2026)
    layer=data['timing']
    assert len(data['planetary_nodes'])==17 and data['planetary_nodes']==plain['planetary_nodes']
    assert len(layer['planets'])==21 and len(layer['houses'])==12
    assert layer['settings']['house_system']==system
    assert layer['kind']=={'secondary':'progressed'}.get(mode,mode)
    assert bool(data['progressed'])==(mode=='secondary')
    assert any(a.get('target_layer')=='planetary_nodes' for a in data['timing_aspects'])
    assert all(p['house_in_natal']==house_for(p['longitude'],[h['longitude'] for h in plain['natal']['houses']]) for p in layer['planets'])
    if system=='E':
        assert all(separation(h['longitude'],layer['ascendant']['longitude']+30*i)<1e-8 for i,h in enumerate(layer['houses']))

def test_secondary_exact_elapsed_time_and_naibod_armc_with_cli_solar_longitude():
    data=result(include_progressions=True,target=TARGET)
    born=datetime.fromisoformat(data['natal']['birth']['utc'])
    target=datetime(2026,10,17,16,45,30,tzinfo=timezone.utc)
    age=(target-born).total_seconds()/(86400*YEAR_DAYS)
    layer=data['timing'];stamp=datetime.fromisoformat(layer['technique']['ephemeris_utc'])
    assert stamp==born+timedelta(days=age)
    assert separation(layer['armc'],data['natal']['armc']+NAIBOD*age)<1e-10
    solar=float(cli(layer['jd_tt'],[])[0].split(',')[1])
    assert separation(layer['planets'][0]['longitude'],solar)<1e-6
    for p in layer['planets']:
        assert p['speed']==pytest.approx(p['ephemeris_speed']/YEAR_DAYS)

def test_solar_arc_directs_every_planet_angle_and_cusp_by_secondary_sun_arc():
    sec=result(include_progressions=True,target=TARGET)
    data=result(include_progressions=True,timing_mode='solar_arc',target=TARGET)
    base=data['natal'];layer=data['timing']
    arc=(sec['timing']['planets'][0]['longitude']-base['planets'][0]['longitude'])%360
    assert layer['technique']['arc']==pytest.approx(arc,abs=1e-10)
    assert layer['technique']['ephemeris_utc']==sec['timing']['technique']['ephemeris_utc']
    for a,b in zip(base['planets'],layer['planets']):
        assert a['id']==b['id'] and separation(a['longitude']+arc,b['longitude'])<1e-10
        assert b['speed'] is None and b['retrograde'] is None
        assert b['latitude'] is None and b['distance_au'] is None
    for a,b in zip(base['houses'],layer['houses']):
        assert separation(a['longitude']+arc,b['longitude'])<1e-10
    for angle in ('ascendant','midheaven'):
        assert separation(base[angle]['longitude']+arc,layer[angle]['longitude'])<1e-10

@pytest.mark.parametrize('birth,year',[(BIRTH,2026),({'date':'1988-02-29','time':'23:30:00','place_id':'2618425'},2025),({'date':'1990-12-31','time':'23:59:00','place_id':'2618425'},2027)])
def test_solar_return_precision_from_official_cli_at_the_actual_return_epoch(birth,year):
    data=build_evolution(EvolutionRequest(birth=birth,include_progressions=True,timing_mode='solar_return',return_year=year,return_place=LONDON))
    layer=data['timing'];solar=float(cli(layer['jd_tt'],[])[0].split(',')[1])
    target=data['natal']['planets'][0]['longitude']
    assert separation(solar,target)<1e-6
    assert layer['technique']['solar_error_arcsec']<.0001
    assert layer['technique']['residual_degrees']<1e-8
    assert layer['place']['name']=='London' and layer['birth']['local']
    assert layer['technique']['place_choice']=='selected'

def test_return_location_changes_houses_but_not_epoch_planets_or_natal_nodes():
    local=result(include_progressions=True,timing_mode='solar_return',return_year=2026)
    away=result(include_progressions=True,timing_mode='solar_return',return_year=2026,return_place=LONDON)
    a=local['timing'];b=away['timing']
    assert a['birth']['utc']==b['birth']['utc']
    assert [p['longitude'] for p in a['planets']]==[p['longitude'] for p in b['planets']]
    assert separation(a['ascendant']['longitude'],b['ascendant']['longitude'])>1
    assert local['planetary_nodes']==away['planetary_nodes']
    assert a['technique']['place_choice']=='birthplace'

def test_saved_return_place_id_is_resolved_and_manual_place_is_strict():
    data=result(include_progressions=True,timing_mode='solar_return',return_year=2026,return_place={'place_id':'2643743'})
    assert data['timing']['place']['timezone']=='Europe/London'
    with pytest.raises(ValidationError):EvolutionRequest(birth=BIRTH,return_place={'place_id':'2643743',**LONDON})
    with pytest.raises(ValidationError):EvolutionRequest(birth=BIRTH,return_place={'latitude':51})

@pytest.mark.parametrize('mode',['secondary','solar_arc','solar_return'])
def test_timing_requires_birth_time_and_required_date_or_year(mode):
    with pytest.raises(ValidationError):EvolutionRequest(birth=BIRTH,include_progressions=True,timing_mode=mode)
    with pytest.raises(ValidationError):EvolutionRequest(birth={**BIRTH,'time':None,'confidence':'unknown'},include_progressions=True,timing_mode=mode,target=TARGET,return_year=2026)
    with pytest.raises(CalculationError):result(include_progressions=True,timing_mode=mode,target={'date':'1980-01-01'},return_year=1980)

def test_api_preserves_all_fields_and_disambiguates_target_clock_not_birth_clock():
    with TestClient(app) as client:
        payload={'birth':BIRTH,'include_progressions':True,'timing_mode':'solar_arc','house_system':'R',
            'target':{'date':'2026-10-25','time':'02:30:00','timezone':'Europe/Copenhagen'}}
        response=client.post('/api/evolution/chart',json=payload)
        assert response.status_code==422
        assert response.json()['error']['context']=='target'
        payload['target']['fold']=1
        response=client.post('/api/evolution/chart',json=payload)
        assert response.status_code==200
        data=response.json();assert data['input']==EvolutionRequest(**payload).model_dump(mode='json')
        assert len(data['planetary_nodes'])==17 and data['timing']['kind']=='solar_arc'
        assert data['timing']['technique']['target_utc']=='2026-10-25T01:30:00+00:00'
        for update in ({'house_system':'invalid'},{'timing_mode':'made_up'},{'timing_mode':'solar_return','return_year':2100}):
            assert client.post('/api/evolution/chart',json={**payload,**update}).status_code==422

def test_polar_return_does_not_silently_change_placidus():
    kwargs={'include_progressions':True,'timing_mode':'solar_return','return_year':2026,
        'return_place':{**LONDON,'latitude':70}}
    with pytest.raises(CalculationError):result(house_system='P',**kwargs)
    assert len(result(house_system='E',**kwargs)['timing']['houses'])==12
