"""A public, independently printed ARGUS output, not a regenerated fixture.

The key is constrained indirectly by two axis orbs. The source does NOT print
an exact key. Preserve the source's unusual coordinates/time zone verbatim.
"""
from datetime import datetime, timedelta
from functools import lru_cache
import json
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.engine import separation
from app.main import app, Birth, chart
from app.solar_key import right_ascension
from app.techniques import secondary_progressions
REF = json.loads(Path(__file__).with_name('argus-progressions-published-reference.json').read_text())

def degrees(dms):
    return dms[0] + dms[1] / 60 + dms[2] / 3600

@pytest.fixture(scope='module')
def manual_example():
    natal = chart(Birth(**REF['birth']))
    assert natal['birth']['utc'] == '1944-01-09T03:17:21+00:00'
    birth = datetime.fromisoformat(natal['birth']['utc'])
    target = datetime.fromisoformat(REF['target_utc'])

    @lru_cache(maxsize=3)
    def progressed(method='kundig_argus', days_after_target=0):
        return secondary_progressions(birth, target + timedelta(days=days_after_target), natal, REF['birth']['latitude'], REF['birth']['longitude'], False, method)[0]
    return (natal, progressed)

def body_longitude(natal, body):
    return next((p['longitude'] for p in natal['planets'] if p['id'] == body))

def axis_orb(progressed, natal, row):
    return abs(separation(progressed[row['progressed_axis']]['longitude'], body_longitude(natal, row['natal_body'])) - row['angle_degrees']) * 3600

@pytest.mark.parametrize('row', REF['radix_positions'], ids=lambda r: r['id'])
def test_exact_published_input_reproduces_relevant_radix_positions(manual_example, row):
    natal, _ = manual_example
    lon = natal[row['id']]['longitude'] if row['id'] in ('ascendant', 'midheaven') else body_longitude(natal, row['id'])
    assert separation(lon, degrees(row['longitude_dms'])) * 3600 <= REF['precision']['nearest_minute_tolerance_arcseconds']

@pytest.mark.parametrize('row', REF['printed_aspects'], ids=lambda r: r['progressed_axis'])
def test_centered_variant_matches_independently_printed_argus_orbs(manual_example, row):
    natal, progressed = manual_example
    expected = degrees(row['orb_dms']) * 3600
    actual = axis_orb(progressed(), natal, row)
    assert abs(actual - expected) <= REF['precision']['nearest_minute_tolerance_arcseconds']
    assert round(actual / 60) == round(expected / 60)
    assert abs(axis_orb(progressed('kundig'), natal, row) - expected) > 60
    assert row['motion'] == 'separating'
    assert axis_orb(progressed('kundig_argus', 1), natal, row) > actual

@pytest.mark.parametrize('row', REF['printed_aspects'], ids=lambda r: r['progressed_axis'])
def test_absolute_axes_within_intervals_inferred_only_from_printed_values(manual_example, row):
    _, progressed = manual_example
    printed_body = next((r for r in REF['radix_positions'] if r['id'] == row['natal_body']))
    inferred = degrees(printed_body['longitude_dms']) + row['angle_degrees'] + degrees(row['orb_dms'])
    actual = progressed()[row['progressed_axis']]['longitude']
    assert separation(actual, inferred) * 3600 <= REF['precision']['axis_inferred_from_two_rounded_values_tolerance_arcseconds']

def test_key_is_inside_mc_implied_range_but_not_a_direct_published_key(manual_example):
    natal, progressed = manual_example
    result = progressed()
    technique = result['technique']
    mc_row = next((r for r in REF['printed_aspects'] if r['progressed_axis'] == 'midheaven'))
    pluto = next((r for r in REF['radix_positions'] if r['id'] == 'pluto'))
    inferred_mc = degrees(pluto['longitude_dms']) + 90 + degrees(mc_row['orb_dms'])
    tolerance = REF['precision']['axis_inferred_from_two_rounded_values_tolerance_arcseconds'] / 3600
    rates = [(right_ascension(inferred_mc + d, technique['obliquity']) - natal['armc']) / technique['age_years'] for d in (-tolerance, tolerance)]
    assert rates[0] <= technique['degrees_per_year'] <= rates[1]
    assert progressed('kundig')['technique']['degrees_per_year'] > rates[1]
    assert REF['direct_argus_solar_key'] is None, 'Never relabel an inferred key as a direct ARGUS output'

def test_published_example_through_public_api(manual_example):
    natal, _ = manual_example
    client = TestClient(app, client=('192.0.2.184', 1234))
    response = client.post('/api/technique', json={'birth': REF['birth'], 'target': REF['target'], 'mode': 'progressed', 'house_method': 'kundig_argus'})
    assert response.status_code == 200, response.text
    result = response.json()
    assert result['technique']['target_utc'] == REF['target_utc']
    for row in REF['printed_aspects']:
        assert abs(axis_orb(result, natal, row) - degrees(row['orb_dms']) * 3600) <= 30
