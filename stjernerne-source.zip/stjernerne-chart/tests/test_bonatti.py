from datetime import datetime,timezone,timedelta
import pytest
from fastapi.testclient import TestClient
from app.main import app,chart,Birth
from app.bonatti import bonatti_roots,bonatti_geometry
from app.kundig import kundig_cuts,signed
from app.engine import separation

B={'date':'1990-06-15','time':'14:30:00','place_id':'2618425','include_dwarfs':True}

def sphere(t,planet=0,speed=0):
    return {'angles':{'AC':(t/240)%360,'DC':(t/240+180)%360,
                      'MC':(t/240+90)%360,'IC':(t/240+270)%360},
            'planets':{'sun':{'longitude':(planet+t*speed)%360}}}

def test_analytic_four_axes_and_boundaries():
    rows=bonatti_roots(sphere,-21600,64800)
    assert [(round(r['seconds']),r['axis']) for r in rows]==[
        (-21600,'MC'),(0,'AC'),(21600,'IC'),(43200,'DC'),(64800,'MC')]

def test_moving_planet_and_discontinuity():
    rows=bonatti_roots(lambda t:sphere(t,1,1/3600),0,600)
    assert len(rows)==1 and rows[0]['axis']=='AC'
    assert rows[0]['seconds']==pytest.approx(1/(1/240-1/3600),abs=.001)
    # A +180/-180 jump for AC is a genuine DC contact, not an AC root.
    rows=bonatti_roots(lambda t:sphere(t,0),43190,43210)
    assert len(rows)==1 and rows[0]['axis']=='DC'

def test_close_contacts_are_retained_per_planet():
    def g(t):
        result=sphere(t)
        result['planets']['venus']={'longitude':.002}
        return result
    rows=bonatti_roots(g,-10,10)
    assert [r['seconds'] for r in rows]==pytest.approx([0,.48],abs=.001)
    assert [r['planet'] for r in rows]==['sun','venus']

@pytest.mark.parametrize('latitude',[0,55.67594,-60,65.9,-65.9])
def test_native_geometry_and_rounded_contact_bracket(latitude):
    birth={k:v for k,v in B.items() if k!='place_id'}
    birth.update(latitude=latitude,longitude=12.56553,timezone='Europe/Copenhagen')
    base=chart(Birth(**birth))
    result=kundig_cuts(base,180,'bonatti')
    assert result['candidates']
    origin=datetime.fromisoformat(base['birth']['utc'])
    for row in result['candidates']:
        utc=datetime.fromisoformat(row['utc'])
        assert (utc-origin).total_seconds()==row['shift_seconds']
        g=bonatti_geometry(utc,latitude,12.56553)
        assert separation(g['angles']['MC'],row['mc']['longitude'])<1e-7
        for contact in row['bonatti_contacts']:
            residual=[]
            for delta in (-.51,.51):
                q=bonatti_geometry(utc+timedelta(seconds=delta),latitude,12.56553)
                residual.append(signed(q['angles'][contact['axis']]-q['planets'][contact['planet']]['longitude']))
            assert residual[0]<=1e-7 and residual[1]>=-1e-7
            assert contact['planet'] not in ('true_node','chiron','ceres','eris','haumea','makemake')

def test_combined_is_union_and_coincident_roots_keep_both_methods():
    base=chart(Birth(**B))
    a=kundig_cuts(base,60,'kundig');b=kundig_cuts(base,60,'bonatti');c=kundig_cuts(base,60,'both')
    key=lambda d:{r['shift_seconds'] for r in d['candidates']}
    assert key(c)==key(a)|key(b)
    assert len(c['candidates'])==7
    shared=next(r for r in c['candidates'] if r['local'][11:19]=='15:19:09')
    assert shared['methods']==['kundig','bonatti']
    assert shared['bonatti_contacts'][0]['axis']=='IC'
    assert shared['bonatti_contacts'][0]['planet']=='saturn'
    assert shared['partners']
    assert c['method']['counts']=={'kundig':3,'bonatti':5}
    assert sum(r['nearest'] for r in c['candidates'])==3
    assert c['candidates']==sorted(c['candidates'],key=lambda r:r['utc'])

@pytest.mark.parametrize('birth',[
    {**B,'date':'2025-10-26','time':'02:30:00','fold':0},
    {**B,'date':'2025-03-30','time':'01:55:00'},
    {**B,'offset_minutes':90,'offset_source':'Documented historical source'},
    {**B,'date':'1500-01-01','time':'00:00:00'},
])
def test_timing_bounds_and_preview_consistency(birth):
    base=chart(Birth(**birth));result=kundig_cuts(base,180,'both')
    for row in result['candidates']:
        assert row['local'][:10]>='1500-01-01'
        assert row['shift_minutes']*60==pytest.approx(row['shift_seconds'])
        assert row['local']==datetime.fromisoformat(row['utc']).astimezone(
            datetime.fromisoformat(row['local']).tzinfo if 'offset_minutes' in birth else __import__('zoneinfo').ZoneInfo(base['birth']['timezone'])).isoformat()

def test_api_filter_validation_default_and_comparison():
    client=TestClient(app,client=('192.0.2.171',4321))
    old=client.post('/api/rectify/kundig',json={'birth':B}).json()
    assert old['method']['cut_mode']=='kundig' and len(old['candidates'])==3
    response=client.post('/api/rectify/kundig',json={'birth':B,'cut_mode':'bonatti'})
    assert response.status_code==200 and response.headers['cache-control']=='no-store'
    assert response.json()['method']['coordinate']=='ecliptic longitude'
    assert response.json()['method']['divisions'] is None
    rows=response.json()['candidates'];assert len(rows)==5
    chosen=rows[0]
    comparison=client.post('/api/rectify/compare',json={'birth':B,'shifts':[0,chosen['shift_minutes']],
        'events':['2020-06-01'],'method':'kundig'}).json()
    assert comparison['charts'][1]['birth']['local']==chosen['local']
    assert comparison['events'][0]['candidates'][1]['progressed']['technique']['house_method_id']=='kundig'
    for invalid in ['bad',None,True,{},['both']]:
        assert client.post('/api/rectify/kundig',json={'birth':B,'cut_mode':invalid}).status_code==422
