"""Isolation and language contracts specific to the separate English test app."""
from pathlib import Path
from fastapi.testclient import TestClient
from app.main import app

ROOT=Path(__file__).resolve().parents[1]

def test_english_page_has_same_modes_without_danish_archive():
    client=TestClient(app,client=('192.0.2.197',1234))
    page=client.get('/')
    assert '<html lang="en">' in page.text
    for mode in ('natal','transit','solar','progressed','synastry','rectify'):
        assert f'data-mode="{mode}"' in page.text
    assert 'famous-picker' not in page.text
    for name in ('famous-danes.json','famous-danes.js','famous-model.js','directory.js','kendte-danskere.html'):
        assert not (ROOT/'static'/name).exists()
        assert client.get('/static/'+name).status_code==404
    assert "frame-ancestors 'self'" in page.headers['content-security-policy']
    assert page.headers['content-security-policy']==page.headers['content-security-policy'].strip()
    assert 'stjernerne.io' not in page.headers['content-security-policy']
    assert 'noindex' in page.headers['x-robots-tag']

def test_test_library_is_separate_and_contains_no_seeded_charts():
    store=(ROOT/'static/library-store.js').read_text()
    assert 'stjernerne-en-test-library' in store
    assert 'stjernerne-en-test-library-changes' in (ROOT/'static/library.js').read_text()
    controller=(ROOT/'static/app.js').read_text()
    assert 'famous' not in controller and 'openLinkedPerson' not in controller
    assert 'createLibrary(librarySnapshot,openLibrarySession)' in controller
    # Explicit backup import remains compatible; storage and origin provide isolation.
    assert "FORMAT='stjernerne-horoskoper'" in (ROOT/'static/library-model.js').read_text()

def test_english_planets_signs_aspects_and_error_messages():
    client=TestClient(app,client=('192.0.2.198',1234))
    birth={'date':'1990-06-15','time':'14:30:00','place_id':'2643743','include_dwarfs':True}
    chart=client.post('/api/chart',json=birth).json()
    assert chart['planets'][0]['name']=='Sun'
    assert chart['planets'][1]['name']=='Moon'
    assert chart['planets'][0]['sign']=='Gemini'
    assert {r['label'] for r in chart['aspects']}<={'Conjunction','Sextile','Square','Trine','Opposition'}
    error=client.post('/api/chart',json={**birth,'date':'1990-02-30'}).json()
    assert 'Check the date' in error['error']['message']
    assert client.post('/api/chart',json=birth,headers={'Origin':'https://www.stjernerne.io'}).status_code==403
