from fastapi.testclient import TestClient
import pytest
from app.main import app

@pytest.fixture
def client(): return TestClient(app)
BASE={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}

def test_full_chart_and_security_headers(client):
    response=client.post('/api/chart',json=BASE)
    assert response.status_code==200
    data=response.json()
    assert len(data['planets'])==11 and len(data['houses'])==12
    assert data['birth']['utc']=='1990-06-15T12:30:00+00:00'
    assert data['place']['timezone']=='Europe/Copenhagen'
    assert response.headers['cache-control']=='no-store'
    assert "frame-ancestors 'self' https://stjernerne.dk" in response.headers['content-security-policy']
    assert response.headers['referrer-policy']=='no-referrer'

@pytest.mark.parametrize('changes',[
    {'date':'2023-02-29'},{'date':'1899-12-31'},{'date':'2099-01-01'},
    {'time':'24:00'},{'time':'12:30:60'},{'time':'12:30+02:00'},
    {'place_id':'missing'},{'latitude':55},{'unexpected':'ignored?'},
    {'fold':2},{'offset_minutes':900},{'fold':True},
])
def test_invalid_inputs(client,changes):
    response=client.post('/api/chart',json={**BASE,**changes})
    assert response.status_code==422
    assert 'error' in response.json()

def test_manual_coordinates_and_zone_validation(client):
    data={'date':'2000-01-01','time':'12:00','latitude':-33.86,'longitude':151.2,'timezone':'Australia/Sydney','place_name':'Sydney'}
    r=client.post('/api/chart',json=data)
    assert r.status_code==200 and r.json()['place']['source']=='manual'
    assert r.json()['birth']['warnings']
    for change in [{'latitude':91},{'longitude':181},{'timezone':'Europe/fake'},{'latitude':'nan'}]:
        assert client.post('/api/chart',json={**data,**change}).status_code==422

def test_dst_contract(client):
    ambiguous={**BASE,'date':'2024-10-27','time':'02:30'}
    r=client.post('/api/chart',json=ambiguous)
    assert r.status_code==422 and len(r.json()['error']['choices'])==2
    a=client.post('/api/chart',json={**ambiguous,'fold':0}).json()
    b=client.post('/api/chart',json={**ambiguous,'fold':1}).json()
    assert a['ascendant']['longitude']!=b['ascendant']['longitude']
    r=client.post('/api/chart',json={**BASE,'date':'2024-03-31','time':'02:30'})
    assert r.json()['error']['code']=='nonexistent_time'

def test_atlas_danish_and_international_names(client):
    for term,name in [('København','København'),('Copenhagen','København'),('Kobenhavn','København'),('New York','New York City')]:
        r=client.get('/api/places',params={'q':term})
        assert r.status_code==200
        assert name in [p['name'] for p in r.json()]
    assert client.get('/api/places',params={'q':'" OR *'}).status_code==200

def test_no_cross_origin_or_mass_payload(client):
    assert client.post('/api/chart',json=BASE,headers={'Origin':'https://evil.example'}).status_code==403
    assert client.post('/api/chart',content='x'*9000,headers={'Content-Type':'application/json'}).status_code==413
    assert client.post('/api/chart',content='oops').status_code==415
    assert client.get('/',headers={'host':'evil.example'}).status_code==400

def test_rate_limit():
    client=TestClient(app,client=('192.0.2.1',12345))
    for _ in range(120): assert client.get('/api/health').status_code==200
    assert client.get('/api/health').status_code==429

def test_static_and_no_private_files(client):
    assert client.get('/').status_code==200
    assert client.get('/embed-test').status_code==200
    assert client.get('/data/places.sqlite').status_code==404
    assert client.get('/vendor/swisseph/sweph.c').status_code==404
