import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {cuspDirection,houseSectors} from '../static/house-geometry.js';
import {wheel} from '../static/school/wheel.js';
import {renderWheel} from '../static/wheel.js';

const fixtures=JSON.parse(readFileSync(new URL('./fixtures/polar-regiomontanus.json',import.meta.url)));
const norm=value=>((value%360)+360)%360;
class SvgElement{
 constructor(tag){this.tagName=tag;this.attributes={};this.children=[];this.textContent='';}
 setAttribute(key,value){this.attributes[key]=String(value);}
 append(...nodes){this.children.push(...nodes);}
}
for(const fixture of fixtures)for(const school of ['institut','university','retained-wheel']){
 test(`${school} places all twelve house numbers inside actual ${fixture.name} polar Regiomontanus sectors`,()=>{
  const before=globalThis.document;globalThis.document={createElementNS:(_,tag)=>new SvgElement(tag)};
  try{
   const data={houses:fixture.cusps.map((longitude,i)=>({number:i+1,longitude})),ascendant:{longitude:fixture.cusps[0]},midheaven:{longitude:fixture.cusps[9]},planets:[],aspects:[],birth:{local:'2000-06-15',confidence:'exact'},place:{name:'Polar regression fixture'}};
   const old=school==='retained-wheel',svg=old?renderWheel(data):wheel([data],{visibility:{signs:true,houses:true,aspects:true},bodyName:id=>id,positionText:String,title:fixture.name,school});
   const labels=svg.children.filter(e=>e.attributes['data-house']);assert.equal(labels.length,12);
   const sorted=data.houses.toSorted((a,b)=>a.longitude-b.longitude),center=old?440:490;
   for(const label of labels){
    const lon=norm(180+data.ascendant.longitude-Math.atan2(Number(label.attributes.y)-center,Number(label.attributes.x)-center)*180/Math.PI);
    const owner=sorted.find(h=>h.longitude>=lon)||sorted[0];
    assert.equal(Number(label.textContent),owner.number);
    assert.equal(Number(label.attributes['data-house']),owner.number);
   }
  }finally{if(before===undefined)delete globalThis.document;else globalThis.document=before;}
 });
}
test('forward equal houses across zero retain their centers; omitted houses stay omitted',()=>{
 const cusps=Array.from({length:12},(_,i)=>norm(350+30*i));
 assert.equal(cuspDirection(cusps),1);
 assert.deepEqual(houseSectors(cusps.map(longitude=>({longitude}))).map(h=>h.midpoint),cusps.map(lon=>norm(lon+15)));
 assert.deepEqual(houseSectors([]),[]);
});
test('invalid cusp orders fail explicitly instead of silently selecting a direction',()=>{
 for(const cusps of [[],Array(12).fill(0),Array.from({length:11},(_,i)=>i),[NaN,...Array.from({length:11},(_,i)=>i)],[0,60,30,90,120,150,180,210,240,270,300,330]]){
  assert.throws(()=>cuspDirection(cusps),/Invalid house cusps/);
 }
 for(const fixture of fixtures)assert.equal(cuspDirection(fixture.cusps),-1);
});
