import test from 'node:test';
import assert from 'node:assert/strict';
import {session,encodeBackup,decodeBackup} from '../static/library-model.js';
const base=()=>({birth:{date:'1990-06-15',time:'14:30:00',place_id:'2618425',include_dwarfs:true},mode:'rectify',rectification:{shifts:[0,-142/60],current:-142/60,events:[{label:'Testflytning',date:'2020-06-01'}]}});
test('solar-key settings survive backup and old settings keep their defaults',()=>{
 const old=base();assert.deepEqual(session(old),old);
 const rect=base();rect.rectification.method='kundig';
 assert.deepEqual(decodeBackup(encodeBackup([{name:'Test',session:rect}]))[0].session,rect);
 const progressed={...base(),mode:'progressed',technique:{mode:'progressed',house_method:'kundig',target:{date:'2026-10-15',time:'12:00:00',timezone:'UTC'}}};
 assert.deepEqual(decodeBackup(encodeBackup([{name:'Progression',session:progressed}]))[0].session,progressed);
 delete progressed.technique.house_method;assert.deepEqual(session(progressed),progressed);
});
test('reject imported unknown methods and methods on a solar return',()=>{
 for(const method of ['bad',null,{},true]){
  const v=base();v.rectification.method=method;assert.throws(()=>session(v));
  v.rectification.method='transits';v.mode='progressed';v.technique={mode:'progressed',house_method:method,target:{date:'2026-10-15',time:'12:00',timezone:'UTC'}};assert.throws(()=>session(v));
 }
 const v={...base(),mode:'solar',technique:{mode:'solar',year:2026,house_method:'kundig'}};assert.throws(()=>session(v));
});
