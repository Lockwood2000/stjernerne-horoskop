import test from 'node:test';
import assert from 'node:assert/strict';
import {session,encodeBackup,decodeBackup} from '../static/library-model.js';
import {arcDms} from '../static/solar-key.js';
const base=()=>({birth:{date:'1990-06-15',time:'14:30:00',place_id:'2618425',include_dwarfs:true},mode:'rectify',rectification:{shifts:[0,-142/60],current:-142/60,events:[{label:'Testflytning',date:'2020-06-01'}]}});
test('solar-key settings survive backup and old settings keep their defaults',()=>{
 const old=base();assert.deepEqual(session(old),old);
 const rect=base();rect.rectification.method='kundig';
 assert.deepEqual(decodeBackup(encodeBackup([{name:'Test',session:rect}]))[0].session,rect);
 const progressed={...base(),mode:'progressed',technique:{mode:'progressed',house_method:'kundig',target:{date:'2026-10-15',time:'12:00:00',timezone:'UTC'}}};
 assert.deepEqual(decodeBackup(encodeBackup([{name:'Progression',session:progressed}]))[0].session,progressed);
 delete progressed.technique.house_method;assert.deepEqual(session(progressed),progressed);
});
test('reject imported unknown methods and methods on a solar return',()=>{
 for(const method of ['bad',null,{},true]){
  const v=base();v.rectification.method=method;assert.throws(()=>session(v));
  v.rectification.method='transits';v.mode='progressed';v.technique={mode:'progressed',house_method:method,target:{date:'2026-10-15',time:'12:00',timezone:'UTC'}};assert.throws(()=>session(v));
 }
 const v={...base(),mode:'solar',technique:{mode:'solar',year:2026,house_method:'kundig'}};assert.throws(()=>session(v));
});
test('ARGUS and whole-degree choices survive input-only export and import independently',()=>{
 for(const method of ['kundig','kundig_argus']){
  const rect=base();rect.rectification.method=method;
  const progressed={...base(),mode:'progressed',technique:{mode:'progressed',house_method:method,target:{date:'2026-10-15',time:'12:00:00',timezone:'UTC'}}};
  const decoded=decodeBackup(encodeBackup([{name:'Begivenheder',session:rect},{name:"Progressions",session:progressed}]));
  assert.deepEqual(decoded[0].session,rect);assert.deepEqual(decoded[1].session,progressed);
 }
 const solar={...base(),mode:'solar',technique:{mode:'solar',year:2026,house_method:'kundig_argus'}};
 assert.throws(()=>session(solar));
});
test('comparison arcs preserve total degrees rather than wrapping at a zodiac sign',()=>{
 assert.equal(arcDms(39.5),'39°30′00″');
 assert.equal(arcDms(360.125),'360°07′30″');
 assert.equal(arcDms(29.999999),'30°00′00″');
});
