import ctypes as C
from datetime import datetime,timedelta,timezone
import math
import subprocess
import pytest
from fastapi.testclient import TestClient
from app.engine import ROOT,lib,calculate,positions_at,separation
from app.techniques import solar_return,secondary_progressions,YEAR_DAYS,NAIBOD
from app.main import app

BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425','include_dwarfs':True}
UTC=datetime(1990,6,15,12,30,tzinfo=timezone.utc)
@pytest.fixture
def natal():return calculate(UTC,55.67594,12.56553,True)

@pytest.mark.parametrize('year',[1900,1990,2026,2099])
def test_four_dwarfs_against_official_cli(year):
    stamp=datetime(year,6,15,12,tzinfo=timezone.utc)
    ps=positions_at(stamp,True)['planets'][-4:]
    assert [p['id'] for p in ps]==['ceres','eris','haumea','makemake']
    for p,options in zip(ps,[['-pF'],['-ps','-xs136199'],['-ps','-xs136108'],['-ps','-xs136472']]):
        output=subprocess.check_output([str(ROOT/'build/swetest'),f'-b15.6.{year}','-utc12:00:00','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPls','-g,','-head',*options],text=True)
        row=[l.split(',') for l in output.splitlines() if ',' in l][0]
        assert separation(p['longitude'],float(row[1]))<1e-6
        assert abs(p['speed']-float(row[2]))<1e-6
        assert p['flags']&2 and p['retrograde']==(float(row[2])<0)

@pytest.mark.parametrize('year',[1991,2026,2050,2099])
def test_solar_matches_native_crossing_and_exact_longitude(natal,year):
    chart,stamp=solar_return(UTC,natal,year,55.67,12.56,True)
    assert chart['technique']['solar_error_arcsec']<.001
    assert abs((stamp-UTC.replace(year=year)).total_seconds())<3*86400
    lib.swe_solcross.argtypes=[C.c_double,C.c_double,C.c_int32,C.c_char_p];lib.swe_solcross.restype=C.c_double
    start=positions_at(UTC.replace(year=year)-timedelta(days=3))['jd_tt']
    reference=lib.swe_solcross(natal['planets'][0]['longitude'],start,2,C.create_string_buffer(256))
    assert abs(reference-chart['calculation']['jd_tt'])*86400<.05
    # Bracket the solution, so matching angles cannot conceal a wrong crossing direction.
    a=positions_at(stamp-timedelta(seconds=1))['planets'][0]['longitude']
    b=positions_at(stamp+timedelta(seconds=1))['planets'][0]['longitude']
    target=natal['planets'][0]['longitude']
    assert (a-target+180)%360-180<0<(b-target+180)%360-180

def test_solar_relocation_keeps_instant_and_planets(natal):
    a,ta=solar_return(UTC,natal,2026,55.67,12.56,True)
    b,tb=solar_return(UTC,natal,2026,-33.86,151.21,True)
    assert ta==tb
    assert [p['longitude'] for p in a['planets']]==[p['longitude'] for p in b['planets']]
    assert a['ascendant']!=b['ascendant'] and a['houses']!=b['houses']

def test_solar_leap_day_and_zodiac_zero():
    for birth in [datetime(2000,2,29,12,tzinfo=timezone.utc),datetime(2000,3,20,7,tzinfo=timezone.utc),datetime(2000,1,1,0,tzinfo=timezone.utc)]:
        n=calculate(birth,55,12)
        c,t=solar_return(birth,n,2025,55,12)
        assert c['technique']['solar_error_arcsec']<.001

def test_progression_zero_reproduces_natal(natal):
    chart,stamp=secondary_progressions(UTC,UTC,natal,55.67594,12.56553,True)
    assert stamp==UTC
    for a,b in zip(chart['houses'],natal['houses']):assert separation(a['longitude'],b['longitude'])<1e-8
    for a,b in zip(chart['planets'],natal['planets']):assert a['longitude']==b['longitude']

@pytest.mark.parametrize('years',[1,30,90])
def test_progression_day_year_key_and_naibod_geometry(natal,years):
    target=UTC+timedelta(days=YEAR_DAYS*years)
    chart,stamp=secondary_progressions(UTC,target,natal,55.67594,12.56553,True)
    assert abs((stamp-(UTC+timedelta(days=years))).total_seconds())<1e-4
    reference=positions_at(stamp,True)['planets']
    for p,q in zip(chart['planets'],reference):
        assert p['longitude']==q['longitude'] and abs(p['speed']-q['speed']/YEAR_DAYS)<1e-12
    armc=math.radians((natal['armc']+NAIBOD*years)%360)
    eps=math.radians(chart['technique']['obliquity']);lat=math.radians(55.67594)
    ac=(math.degrees(math.atan2(-math.cos(armc),math.sin(armc)*math.cos(eps)+math.tan(lat)*math.sin(eps)))+180)%360
    mc=math.degrees(math.atan2(math.sin(armc)/math.cos(eps),math.cos(armc)))%360
    assert separation(ac,chart['ascendant']['longitude'])<1e-8
    assert separation(mc,chart['midheaven']['longitude'])<1e-8

def test_api_techniques_and_dwarf_transits():
    c=TestClient(app,client=('192.0.2.42',3456))
    for request in [{'mode':'solar','year':2026},{'mode':'solar','year':2026,'location':{'place_id':'2147714'}},{'mode':'progressed','target':{'date':'2026-10-13','time':'12:00','timezone':'UTC'}}]:
        r=c.post('/api/technique',json={'birth':BIRTH,**request})
        assert r.status_code==200,r.text
        data=r.json();assert len(data['planets'])==16 and len(data['houses'])==12
        assert data['chart_type']==request['mode']
        assert r.headers['cache-control']=='no-store'
    assert len(c.post('/api/transits',json={'birth':BIRTH,'transit':{'date':'2026-10-13','time':'12:00'}}).json()['planets'])==16

@pytest.mark.parametrize('payload',[
    {'mode':'solar'}, {'mode':'solar','year':1899},{'mode':'solar','year':2100},{'mode':'solar','year':1980},
    {'mode':'solar','year':2026,'location':{'place_id':'missing'}},
    {'mode':'progressed'}, {'mode':'progressed','target':{'date':'1980-01-01','time':'12:00'}},
    {'mode':'progressed','target':{'date':'2026-03-29','time':'02:30','timezone':'Europe/Copenhagen'}},
    {'mode':'other','year':2026},
])
def test_invalid_requests(payload):
    c=TestClient(app,client=('192.0.2.43',3456))
    assert c.post('/api/technique',json={'birth':BIRTH,**payload}).status_code==422


@pytest.mark.parametrize('year',[1900,2026,2099])
def test_chiron_cli(year):
    p=next(p for p in positions_at(datetime(year,6,15,12,tzinfo=timezone.utc),True)['planets'] if p['id']=='chiron')
    output=subprocess.check_output([str(ROOT/'build/swetest'),f'-b15.6.{year}','-utc12:00:00','-pD','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPls','-g,','-head'],text=True)
    row=[line.split(',') for line in output.splitlines() if ',' in line][0]
    assert separation(p['longitude'],float(row[1]))<1e-6
    assert abs(p['speed']-float(row[2]))<1e-6
