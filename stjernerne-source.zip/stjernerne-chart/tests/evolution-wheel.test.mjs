import test from 'node:test';
import assert from 'node:assert/strict';
import {renderEvolution} from '../static/evolution/wheel.js';
import {layoutNodeCallouts} from '../static/evolution/node-layout.js';
import {renderPrintSheet} from '../static/evolution/print.js';
import {timingLayer,timingLabel,timingSummary} from '../static/evolution/timing.js';
import {renderWheel} from '../static/wheel.js';
import {wheel as renderSchoolWheel} from '../static/school/wheel.js';
import {readFileSync} from 'node:fs';

// Lightweight SVG tree for geometric and accessibility regression checks.
// Browser appearance and interactions are checked separately in the live app.
class SVGNode {
  constructor(tag){this.tag=tag;this.attrs={};this.children=[];this.listeners={};}
  setAttribute(k,v){this.attrs[k]=String(v);}
  getAttribute(k){return this.attrs[k]??null;}
  removeAttribute(k){delete this.attrs[k];}
  get firstChild(){return this.children[0];}
  append(...nodes){this.children.push(...nodes);}
  addEventListener(k,fn){this.listeners[k]=fn;}
  querySelector(tag){return this.children.find(n=>n.tag===tag)||this.children.map(n=>n.querySelector(tag)).find(Boolean)||null;}
  querySelectorAll(selector){return this.children.flatMap(n=>[...(selector==='[data-point]'&&n.attrs['data-point']?[n]:[]),...n.querySelectorAll(selector)]);}
}
globalThis.document={createElementNS:(_ns,tag)=>new SVGNode(tag),createElement:tag=>new SVGNode(tag)};
const flatten=n=>[n,...n.children.flatMap(flatten)];
const point=(id,longitude)=>({id,name:id[0].toUpperCase()+id.slice(1),longitude,house:1,retrograde:false});
function fixture(){
  const planets=[point('sun',310),point('moon',20),point('pluto',359),point('uranus',1),point('north_node',120),point('south_node',300)];
  const pair=(body,north,south)=>({body,name:body,north:{...point(body+'_north_node',north),body,side:'north'},south:{...point(body+'_south_node',south),body,side:'south'}});
  return {natal:{calculation:{houses:'Porphyry'},ascendant:{longitude:40},midheaven:{longitude:310},houses:Array.from({length:12},(_,i)=>({longitude:i*30})),planets,aspects:[]},
    planetary_nodes:[pair('pluto',80,260),pair('uranus',79,259)],focus:{polarity:point('pluto_polarity',179)},
    input:{lunar_node:'true'},lunar_nodes:{mean:[point('north_node',121),point('south_node',301)]},
    progressed:{planets:planets.map(p=>({...p,longitude:(p.longitude+2)%360}))}};
}
const options={showNodes:true,showPolarity:true,compareNodes:true,visibleNodes:new Set(['pluto','uranus']),focus:'pluto'};

test('planetary-node annotations remain inside the separate progression band',()=>{
  const tree=flatten(renderEvolution(fixture(),options));
  const markers=layer=>tree.filter(n=>n.attrs['data-layer']===layer);
  const radius=n=>{const circle=n.querySelector('circle');return Math.hypot(Number(circle.attrs.cx)-500,Number(circle.attrs.cy)-500);};
  const nodeEdge=Math.max(...markers('node').map(n=>radius(n)+Number(n.querySelector('circle').attrs.r)));
  const progressionEdge=Math.min(...markers('progressed').map(n=>radius(n)-Number(n.querySelector('circle').attrs.r)));
  // Space is also reserved for the two lines of node annotations.
  assert.ok(progressionEdge-nodeEdge>55,'progressed badges must clear node badges and annotations');
  assert.ok(tree.filter(n=>n.attrs['data-point']).every(n=>Number.isFinite(radius(n))));
});

test('spreading labels and highlighting focus never changes input longitudes',()=>{
  const input=fixture(),before=JSON.stringify(input);
  const tree=flatten(renderEvolution(input,options));
  assert.equal(JSON.stringify(input),before);
  const focused=tree.filter(n=>n.attrs['data-focus']==='true');
  assert.ok(focused.length>=3);
  assert.ok(focused.every(n=>n.attrs['data-body']==='pluto'));
  assert.ok(tree.some(n=>n.attrs['data-body']==='uranus'&&n.attrs['data-focus']==='false'));
});

test('normal and enlarged charts have distinct accessible labels and focusable points',()=>{
  const main=renderEvolution(fixture(),options),large=renderEvolution(fixture(),{...options,idPrefix:'large-evo'});
  const nodes=[...flatten(main),...flatten(large)],ids=nodes.map(n=>n.attrs.id).filter(Boolean);
  assert.equal(ids.length,new Set(ids).size);
  for(const svg of [main,large]){
    assert.equal(svg.attrs.role,'group');
    for(const id of svg.attrs['aria-labelledby'].split(' '))assert.ok(ids.includes(id));
    assert.ok(flatten(svg).filter(n=>n.attrs['data-point']).every(n=>n.attrs.tabindex==='0'&&n.attrs['aria-label']));
  }
});

const bodies=['mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto','chiron','ceres','eris','haumea','makemake','sedna','quaoar','orcus','gonggong'];
function denseFixture(clustered=false){
  const data=fixture();
  data.planetary_nodes=bodies.map((body,i)=>({body,name:body,north:{...point(body+'_north_node',clustered?359.99:(i*7+65)%360),body,side:'north'},south:{...point(body+'_south_node',clustered?.01:(i*11+240)%360),body,side:'south'}}));
  return data;
}

test('all 34 callouts have separate rows, including a cluster crossing zero Aries',()=>{
  for(const clustered of [false,true])for(const ascendant of [0,40,90,180,270,359.9])for(const progressed of [false,true])for(const largeText of [false,true]){
    const input=denseFixture(clustered).planetary_nodes.flatMap(p=>[p.north,p.south]),before=JSON.stringify(input);
    const {rows,viewBox:[x,y,w,h]}=layoutNodeCallouts(input,ascendant,progressed,largeText);
    assert.equal(rows.length,34);
    assert.equal(new Set(rows.map(p=>p.id)).size,34);
    assert.equal(JSON.stringify(input),before);
    for(const side of ['left','right']){
      const column=rows.filter(p=>p.sideColumn===side).sort((a,b)=>a.y-b.y);
      column.forEach((p,i)=>{
        assert.ok(p.y-(largeText?26:18)>y&&p.y+(largeText?26:16)<y+h,'both text lines must fit vertically');
        const labelWidth=largeText?130:100;
        assert.ok(p.textX-labelWidth>x&&p.textX+labelWidth<x+w,'room for the longest body name');
        if(i)assert.ok(p.y-column[i-1].y>=(largeText?53.999:41.999),'a full row must separate adjacent callouts');
        if(progressed)assert.ok(Math.abs(p.x-500)>565,'callouts must clear the progression ring');
      });
    }
  }
});

test('dense overlays retain all exact longitude ticks and interactive name labels',()=>{
  for(const progressed of [false,true]){
    const data=denseFixture();if(!progressed)data.progressed=null;
    const before=JSON.stringify(data),svg=renderEvolution(data,{...options,visibleNodes:new Set(bodies)}),tree=flatten(svg);
    assert.equal(JSON.stringify(data),before);
    assert.equal(svg.attrs['data-node-layout'],'columns');
    const labels=tree.filter(n=>n.attrs['data-node-label']);
    assert.equal(labels.length,34);
    assert.ok(labels.every(n=>n.children.length===2&&n.children[1].textContent.includes('°')));
    const ticks=tree.filter(n=>n.attrs['data-node-tick']);
    assert.equal(ticks.length,34);
    for(const p of data.planetary_nodes.flatMap(pair=>[pair.north,pair.south])){
      const tick=ticks.find(n=>n.attrs['data-node-tick']===p.id),angle=(180-p.longitude+data.natal.ascendant.longitude)*Math.PI/180;
      assert.ok(Math.abs(Number(tick.attrs.cx)-(500+397*Math.cos(angle)))<1e-8);
      assert.ok(Math.abs(Number(tick.attrs.cy)-(500+397*Math.sin(angle)))<1e-8);
      const marker=tree.find(n=>n.attrs['data-point']===p.id);
      assert.ok(marker.listeners.click&&marker.listeners.keydown&&marker.attrs['aria-label'].includes('house 1'));
    }
  }
});

for(const kind of ['progressed','solar_arc','solar_return'])test(`${kind} travels through wheel, highlighting and print with all 17 node pairs`,()=>{
  const data=denseFixture();data.timing={...data.progressed,kind,houses:data.natal.houses.map((h,i)=>({...h,number:i+1,longitude:(h.longitude+13)%360})),ascendant:{longitude:53},midheaven:{longitude:323},place:{name:'London'},birth:{utc:'2026-06-15T04:05:06+00:00'},technique:{year:2026,target_utc:'2026-10-17T12:00:00+00:00'}};data.progressed=kind==='progressed'?data.timing:null;
  data.input={...data.input,birth:{date:'1990-06-15',time:'14:30:00'},node_reference:'geocentric',node_method:'mean_barycentric'};data.natal.place={name:'Copenhagen'};data.warnings=[];
  const opts={...options,visibleNodes:new Set(bodies),highlight:{group:'progressed',a:'sun',b:'pluto'}};
  const before=JSON.stringify(data),wheel=flatten(renderEvolution(data,opts));
  assert.equal(wheel.filter(n=>n.attrs['data-node-tick']).length,34);
  assert.equal(wheel.filter(n=>n.attrs['data-layer']===kind).length,6);
  assert.equal(wheel.filter(n=>n.attrs['data-timing-house']).length,12);
  assert.equal(wheel.filter(n=>n.attrs['data-timing-angle']).length,2);
  const highlight=wheel.find(n=>n.attrs['data-highlight']),angle=(180-data.timing.planets[0].longitude+40)*Math.PI/180;
  assert.ok(Math.abs(Number(highlight.attrs.x1)-(500+191*Math.cos(angle)))<1e-8);
  const paper=renderPrintSheet(data,opts),nodes=flatten(paper);
  assert.equal(nodes.filter(n=>n.attrs['data-layer']==='node').length,34);
  assert.equal(nodes.find(n=>n.tag==='tbody').children.length,17);
  assert.ok(nodes.some(n=>n.textContent===timingSummary(data)));
  assert.ok(nodes.some(n=>n.textContent==='● '+timingLabel(data)));
  assert.ok(nodes.filter(n=>n.attrs['data-point']).every(n=>!n.attrs.tabindex&&!n.attrs.role));
  assert.equal(JSON.stringify(data),before);
});

test('legacy secondary response and selected return location keep their labels',()=>{
  const legacy=fixture();assert.equal(timingLayer(legacy),legacy.progressed);assert.equal(timingLabel(legacy),'Secondary progressions');
  legacy.timing={kind:'solar_return',place:{name:'New York'},birth:{utc:'2026-06-15T04:05:06+00:00'},technique:{year:2026}};
  assert.equal(timingLabel(legacy),'Solar return');assert.match(timingSummary(legacy),/2026 · New York · 15 Jun 2026, 04:05 UTC/);
});

test('every local wheel and the print sheet label actual clockwise polar sectors correctly',()=>{
  const polar=JSON.parse(readFileSync(new URL('./polar-houses-reference.json',import.meta.url),'utf8'));
  const data=denseFixture(),base=data.natal;
  base.houses=polar.cusps.map((longitude,i)=>({number:i+1,longitude}));
  base.ascendant={longitude:polar.ascendant};base.midheaven={longitude:polar.midheaven};
  base.birth={local:'2026-06-21T00:00:00+00:00',confidence:'exact'};base.place={name:'Tromso polar regression'};base.calculation.houses='Regiomontanus';
  data.timing={...base,kind:'progressed',technique:{target_utc:'2050-06-21T12:00:00+00:00'}};data.progressed=null;
  data.input={birth:polar.birth,lunar_node:'true',node_reference:'geocentric',node_method:'mean_barycentric'};data.warnings=[];
  const opts={...options,visibleNodes:new Set(bodies)},before=JSON.stringify(data);
  const examples=[
    [renderWheel(base),440,228],
    [renderSchoolWheel([base],{visibility:{houses:true,signs:false,aspects:false},bodyName:id=>id,positionText:lon=>String(lon),title:'Polar regression'}),490,207],
    [renderEvolution(data,opts),500,224],
    [renderPrintSheet(data,opts),500,224],
  ];
  for(const [tree,center,radius] of examples){
    const nodes=flatten(tree),labels=nodes.filter(n=>n.attrs['data-house-label']&&n.attrs['data-house-layer']!=='timing');
    assert.equal(labels.length,12);
    for(const [i,label] of labels.entries()){
      const angle=(180-polar.clockwise_midpoints[i]+polar.ascendant)*Math.PI/180;
      assert.equal(String(label.textContent),String(i+1));
      assert.ok(Math.abs(Number(label.attrs.x)-(center+radius*Math.cos(angle)))<1e-8);
      assert.ok(Math.abs(Number(label.attrs.y)-(center+radius*Math.sin(angle)))<1e-8);
    }
    if(center===500){
      const timing=nodes.filter(n=>n.attrs['data-house-layer']==='timing');assert.equal(timing.length,12);
      timing.forEach((label,i)=>{
        const angle=(180-polar.clockwise_midpoints[i]+polar.ascendant)*Math.PI/180;
        assert.ok(Math.abs(Number(label.attrs.x)-(500+489*Math.cos(angle)))<1e-8);
        assert.ok(Math.abs(Number(label.attrs.y)-(500+489*Math.sin(angle)))<1e-8);
      });
    }
  }
  assert.equal(JSON.stringify(data),before);
});
