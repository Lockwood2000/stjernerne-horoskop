from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
import json
import math
from pathlib import Path
import subprocess
import astronomy
import pytest
from app.engine import calculate, separation, aspects_for, house_for, CalculationError, ROOT, COMMIT

EPOCHS=['1900-01-01T12:00:00','1950-07-01T00:00:00','1990-06-15T12:30:00','2000-01-01T12:00:00','2024-02-29T23:59:59']
def utc(s): return datetime.fromisoformat(s).replace(tzinfo=timezone.utc)

@pytest.mark.parametrize('epoch',EPOCHS)
def test_independent_astronomy_engine(epoch):
    result=calculate(utc(epoch),55.67594,12.56553)
    for planet in result['planets'][:-1]:
        other=astronomy.Ecliptic(astronomy.GeoVector(getattr(astronomy.Body,planet['id'].capitalize()),astronomy.Time(epoch+'Z'),True))
        assert separation(planet['longitude'],other.elon)*3600<60,planet['id']

@pytest.mark.parametrize('epoch,lat,lon',[
    ('1990-06-15T12:30:00',55.67594,12.56553),
    ('2000-01-01T12:00:00',40.7128,-74.0060),
    ('2024-02-29T23:59:59',-33.8688,151.2093),
    ('1900-01-01T12:00:00',0,0),
])
def test_official_cli_all_bodies_houses_speed(epoch,lat,lon):
    stamp=utc(epoch)
    result=calculate(stamp,lat,lon)
    args=[str(ROOT/'build/swetest'),f'-b{stamp.day}.{stamp.month}.{stamp.year}',f'-utc{stamp:%H:%M:%S}',
          '-p0123456789t','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPls','-g,','-head',f'-house{lon},{lat},P']
    output=subprocess.check_output(args,text=True)
    rows=[line.split(',') for line in output.splitlines() if ',' in line]
    assert len(rows)>=25
    for p,row in zip(result['planets'],rows[:11]):
        assert separation(p['longitude'],float(row[1]))<1e-6
        assert abs(p['speed']-float(row[2]))<1e-6
        assert p['retrograde']==(float(row[2])<0)
    for h,row in zip(result['houses'],rows[11:23]):
        assert separation(h['longitude'],float(row[1]))<1e-6
    assert separation(result['ascendant']['longitude'],float(rows[23][1]))<1e-6
    assert separation(result['midheaven']['longitude'],float(rows[24][1]))<1e-6

@pytest.mark.parametrize('epoch,lat,lon',[(EPOCHS[2],55.67594,12.56553),(EPOCHS[3],-33.8688,151.2093),(EPOCHS[4],40.7128,-74.006)])
def test_independent_ascendant_mc_geometry(epoch,lat,lon):
    # Independent GAST from Astronomy Engine and standard spherical geometry.
    # Mean obliquity used here; 0.02 deg budget includes nutation approximation.
    t=astronomy.Time(epoch+'Z')
    theta=math.radians((astronomy.SiderealTime(t)*15+lon)%360)
    eps=math.radians(23.4392911-0.013004167*(t.tt/36525))
    asc=(math.degrees(math.atan2(-math.cos(theta),math.sin(theta)*math.cos(eps)+math.tan(math.radians(lat))*math.sin(eps)))+180)%360
    mc=math.degrees(math.atan2(math.sin(theta)/math.cos(eps),math.cos(theta)))%360
    result=calculate(utc(epoch),lat,lon)
    assert separation(asc,result['ascendant']['longitude'])<0.02
    assert separation(mc,result['midheaven']['longitude'])<0.02

def test_true_node_can_move_direct_and_retrograde():
    a=calculate(utc(EPOCHS[2]),55,12)['planets'][-1]
    b=calculate(utc(EPOCHS[3]),55,12)['planets'][-1]
    assert a['id']==b['id']=='true_node'
    assert not a['retrograde'] and b['retrograde']

@pytest.mark.parametrize('lat',[-89,-66,66,69.65,89])
def test_polar_region_does_not_silently_fallback(lat):
    with pytest.raises(CalculationError,match='Placidus'): calculate(utc(EPOCHS[2]),lat,12)

def test_aspects_wrap_orbs_and_node_limit():
    p=lambda key,lon:{'id':key,'longitude':lon}
    assert aspects_for([p('sun',359),p('moon',1)])[0]['orb']==2
    assert aspects_for([p('sun',0),p('moon',188)])[0]['type']=='opposition'
    assert not aspects_for([p('sun',0),p('moon',188.01)])
    assert not aspects_for([p('sun',0),p('true_node',4)])
    assert aspects_for([p('sun',0),p('true_node',3)])[0]['orb']==3

def test_house_boundary_and_wrap():
    cusps=[(350+i*30)%360 for i in range(12)]
    assert house_for(350,cusps)==1
    assert house_for(0,cusps)==1
    assert house_for(20,cusps)==2
    assert house_for(349.999,cusps)==12

def test_thread_safety():
    expected=[calculate(utc(e),55.67594,12.56553) for e in EPOCHS]
    with ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(lambda i:calculate(utc(EPOCHS[i%5]),55.67594,12.56553),range(40)))
    assert all(result==expected[i%5] for i,result in enumerate(results))

def test_missing_data_refuses_automatic_moshier(monkeypatch):
    from app import engine
    monkeypatch.setattr(engine.lib,'swe_calc',lambda *args:260)  # Moshier + speed
    with pytest.raises(CalculationError): engine.calculate(utc(EPOCHS[2]),55,12)

def test_fixture_file():
    fixture=json.loads((ROOT/'tests/reference.json').read_text())
    result=calculate(utc(fixture['utc']),fixture['latitude'],fixture['longitude'])
    assert fixture['swisseph_commit']==COMMIT
    for p,ref in zip(result['planets'],fixture['planets']): assert separation(p['longitude'],ref['longitude'])<1e-6
