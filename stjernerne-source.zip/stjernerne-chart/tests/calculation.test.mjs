import test from 'node:test';
import assert from 'node:assert/strict';
import {chartMetadata,methodGuide,HOUSE_NAMES} from '../static/school/calculation-model.js';
import {decodeFile,defaults} from '../static/school/model.js';

const birth={date:'1990-06-15',time:'14:30:00',place_id:'2618425'};
const natalPlace={name:'Copenhagen',timezone:'Europe/Copenhagen'};
const returning={kind:'solar_return',houses:[{}],place:{name:'Sydney',timezone:'Australia/Sydney'},birth:{local:'2026-06-15T08:32:12.123456+10:00',utc:'2026-06-14T22:32:12.123456+00:00'},technique:{location_basis:'selected_place'}};
const result={mode:'solar_return',input:{birth,return_year:2026,return_place_id:'2147714'},birth_places:[natalPlace],settings:defaults('institut'),layers:[returning]};

test('solar return cover uses the calculated return time and selected location',()=>{
 const values=chartMetadata(result,0,'en').map(r=>r[1]).join('|');
 assert.match(values,/2026-06-15 08:32:12\+10:00/);assert.match(values,/Sydney/);assert.match(values,/2026-06-14 22:32:12 UTC/);
 assert.doesNotMatch(values,/1990|Copenhagen/);
 assert.match(methodGuide(result).map(r=>r.text).join('|'),/1990-06-15.*Copenhagen/);
});
test('workshop-only print metadata keeps the natal basis even from a solar return',()=>{
 const values=chartMetadata(result,0,'da',{natal:true}).map(r=>r[1]).join('|');
 assert.match(values,/1990-06-15/);assert.match(values,/Copenhagen/);assert.doesNotMatch(values,/Sydney/);
});
test('progression print preserves a target timezone and repeated-time choice',()=>{
 const r={...result,mode:'progressed',input:{birth,target:{date:'2026-10-25',time:'02:30:00',timezone:'Europe/Copenhagen',fold:1}},layers:[{kind:'natal',houses:[{}],place:natalPlace}]};
 assert.match(chartMetadata(r,0,'en')[3][1],/02:30:00 · Europe\/Copenhagen · occurrence 2/);
});
test('saved timing work retains all house, date, place, note and axis choices',()=>{
 for(const house of ['P','E','R'])for(const mode of ['progressed','solar_arc','solar_return']){
  const request={...result.input,school:'institut',mode,settings:{...defaults('institut'),house_system:house,progression_method:'kundig_argus'},target:{date:'2026-10-25',time:'02:30:00',timezone:'Europe/Copenhagen',fold:1}};
  const saved=decodeFile(JSON.stringify({format:'stjernerne-school-chart',version:1,name:'Timing practice',request,notes:{observation:'Keep my work'}}));
  assert.deepEqual(saved.request,request);assert.equal(saved.notes.observation,'Keep my work');
 }
 assert.equal(HOUSE_NAMES.E,'Equal House');
});
