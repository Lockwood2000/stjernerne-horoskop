"""Clockwise Regiomontanus houses, using real polar cusps and native geometry."""
import ctypes as C
import json
import math
import subprocess

import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import ROOT, COMMIT, LOCK, DP, lib, house_for, cusp_direction, separation, CalculationError
from app.evolution import EvolutionRequest, build_evolution

REF=json.loads((ROOT/'tests/polar-houses-reference.json').read_text())
lib.swe_house_pos.argtypes=[C.c_double,C.c_double,C.c_double,C.c_int,DP,C.c_char_p]
lib.swe_house_pos.restype=C.c_double

def flat_native_house(chart,longitude):
    # Use Swiss's separate spherical house-position calculation at zero ecliptic
    # latitude, matching this app's explicit longitude-only placement convention.
    with LOCK:
        error=C.create_string_buffer(256)
        value=lib.swe_house_pos(chart['armc'],chart['place']['latitude'],chart['obliquity'],ord('R'),(C.c_double*2)(longitude,0),error)
    assert value>0 and not error.value
    return math.floor(value)

def chart(birth=None,**kwargs):
    return build_evolution(EvolutionRequest(birth=birth or REF['birth'],house_system='R',**kwargs))

def test_real_polar_regiomontanus_cusps_match_cli_and_run_clockwise_without_fallback():
    data=chart();base=data['natal'];cusps=[h['longitude'] for h in base['houses']]
    assert COMMIT==REF['source_commit']
    assert cusps==pytest.approx(REF['cusps'],abs=1e-9)
    args=[str(ROOT/'build/swetest'),'-edir'+str(ROOT/'data/ephe'),'-b21.6.2026greg','-utc00:00:00',
        '-p0','-fPl','-g,','-head','-house18.9553,69.6492,R']
    output=subprocess.check_output(args,text=True)
    cli_cusps=[float(line.split(',')[1]) for line in output.splitlines() if line.startswith('house ')]
    assert len(cli_cusps)==12
    assert all(separation(a,b)<1e-6 for a,b in zip(cusps,cli_cusps))
    assert sum((cusps[(i+1)%12]-c)%360 for i,c in enumerate(cusps))==pytest.approx(3960)
    assert cusp_direction(cusps)==-1
    assert base['calculation']['houses']=='Regiomontanus' and base['settings']['house_system']=='R'
    assert not data['warnings'] and len(data['planetary_nodes'])==17
    assert base['planets'][0]['house']==11  # The old forward-only loop returned 1.
    # Confirm successful R output from the actual native call; compare with O.
    with LOCK:
        native=(C.c_double*13)();angles=(C.c_double*10)();other=(C.c_double*13)()
        assert lib.swe_houses_ex(base['jd_ut1'],0,69.6492,18.9553,ord('R'),native,angles)==0
        assert lib.swe_houses_ex(base['jd_ut1'],0,69.6492,18.9553,ord('O'),other,angles)==0
    assert list(native)[1:]==cusps
    assert max(separation(a,b) for a,b in zip(cusps,list(other)[1:]))>1

@pytest.mark.parametrize('latitude,time,direction',[(69.6492,'00:00:00',-1),(69.6492,'12:00:00',1),(-69.6492,'09:00:00',-1),(-69.6492,'00:00:00',1)])
def test_every_polar_planet_and_all_34_node_points_match_native_longitude_house_geometry(latitude,time,direction):
    data=chart(birth={**REF['birth'],'latitude':latitude,'time':time});base=data['natal']
    assert cusp_direction([h['longitude'] for h in base['houses']])==direction
    points=base['planets']+[pair[side] for pair in data['planetary_nodes'] for side in ('north','south')]
    assert len(points)==55
    for point in points:
        assert point['house']==flat_native_house(base,point['longitude']),point['id']

@pytest.mark.parametrize('direction',[1,-1])
def test_sector_midpoints_and_boundaries_cover_the_circle_in_both_directions(direction):
    cusps=REF['cusps'] if direction==-1 else [(350+i*30)%360 for i in range(12)]
    assert cusp_direction(cusps)==direction
    for i,cusp in enumerate(cusps):
        assert house_for(cusp,cusps)==i+1
        assert house_for(cusp+direction*1e-5,cusps)==i+1
        assert house_for(cusp-direction*1e-5,cusps)==(i-1)%12+1
    if direction==-1:
        assert [house_for(lon,cusps) for lon in REF['clockwise_midpoints']]==list(range(1,13))

@pytest.mark.parametrize('mode',['secondary','solar_arc','solar_return'])
def test_timing_layers_keep_correct_own_and_natal_assignments_at_polar_latitude(mode):
    data=chart(include_progressions=True,timing_mode=mode,target={'date':'2050-06-21'},return_year=2027)
    base=data['natal'];layer=data['timing']
    assert cusp_direction([h['longitude'] for h in base['houses']])==-1
    assert layer['settings']['house_system']=='R' and len(data['planetary_nodes'])==17
    assert not data['warnings']
    for point in layer['planets']:
        assert point['house_in_natal']==flat_native_house(base,point['longitude'])
        if mode=='solar_arc':
            expected=flat_native_house(base,point['longitude']-layer['technique']['arc'])
        else:expected=flat_native_house(layer,point['longitude'])
        assert point['house']==expected,point['id']

@pytest.mark.parametrize('cusps',[[],[0]*12,list(range(11)),list(range(13)),[float('nan')]+list(range(11)),[float('inf')]+list(range(11)),[0,60,30]+list(range(90,360,30))])
def test_invalid_cusp_sequences_are_rejected_instead_of_assigning_a_house(cusps):
    with pytest.raises(CalculationError,match='Invalid house cusps'):cusp_direction(cusps)
    with pytest.raises(CalculationError,match='Invalid house cusps'):house_for(20,cusps)

def test_polar_api_keeps_regiomontanus_and_explicitly_rejects_unavailable_placidus():
    with TestClient(app) as client:
        response=client.post('/api/evolution/chart',json={'birth':REF['birth'],'house_system':'R'})
        assert response.status_code==200
        data=response.json()
        assert data['input']['house_system']=='R' and data['natal']['planets'][0]['house']==11
        assert len(data['planetary_nodes'])==17
        response=client.post('/api/evolution/chart',json={'birth':REF['birth'],'house_system':'P'})
        assert response.status_code==422
        assert 'restricted' in response.json()['error']['message']
