from fastapi.testclient import TestClient
from app.main import app
from app.engine import synastry_aspects

A={'date':'1990-06-15','time':'14:30','place_id':'2618425','include_dwarfs':True}
B={'date':'1992-03-21','time':'10:15','place_id':'2643743','include_dwarfs':True}

def client():return TestClient(app,client=('192.0.2.89',1234))

def test_cross_chart_positions_angles_houses_and_symmetry():
    c=client();r=c.post('/api/synastry',json={'a':A,'b':B});assert r.status_code==200
    result=r.json()
    for key,birth in [('a',A),('b',B)]:
        reference=c.post('/api/chart',json=birth).json()
        assert len(result[key]['planets'])==16
        for p,q in zip(result[key]['planets'],reference['planets']):
            assert p['longitude']==q['longitude'] and p['house']==q['house']
            assert 1<=p['house_in_other']<=12
    assert any('ascendant' in (x['a'],x['b']) for x in result['aspects'])
    assert all('phase' not in x for x in result['aspects'])
    inverse=c.post('/api/synastry',json={'a':B,'b':A}).json()
    forward={(x['a'],x['b'],x['type']):x['orb'] for x in result['aspects']}
    reverse={(x['b'],x['a'],x['type']):x['orb'] for x in inverse['aspects']}
    assert forward.keys()==reverse.keys()
    assert all(abs(v-reverse[k])<1e-10 for k,v in forward.items())

def test_identical_charts_have_same_body_conjunctions_and_houses():
    result=client().post('/api/synastry',json={'a':A,'b':A}).json()
    exact=[x for x in result['aspects'] if x['a']==x['b'] and x['type']=='conjunction' and x['orb']==0]
    assert len(exact)==18
    assert all(p['house']==p['house_in_other'] for p in result['a']['planets'])

def test_second_birth_dst_fold_and_gap():
    c=client();b={**A,'date':'2026-10-25','time':'02:30'}
    # This future date cannot be a birth; use a historical fold.
    b['date']='2025-10-26'
    r=c.post('/api/synastry',json={'a':A,'b':b})
    assert r.status_code==422 and r.json()['error']['person']=='B'
    assert r.json()['error']['code']=='ambiguous_time' and len(r.json()['error']['choices'])==2
    first=c.post('/api/synastry',json={'a':A,'b':{**b,'fold':0}}).json()
    second=c.post('/api/synastry',json={'a':A,'b':{**b,'fold':1}}).json()
    assert first['b']['birth']['utc']!=second['b']['birth']['utc']
    b['date']='2025-03-30'
    assert c.post('/api/synastry',json={'a':A,'b':b}).json()['error']['code']=='nonexistent_time'

def test_invalid_place_identifies_person_and_rejects_extra_fields():
    c=client()
    r=c.post('/api/synastry',json={'a':A,'b':{**B,'place_id':'missing'}})
    assert r.status_code==422 and r.json()['error']['person']=='B'
    assert c.post('/api/synastry',json={'a':A,'b':B,'score':100}).status_code==422

def test_cross_zero_and_orb_boundaries():
    def chart(id,lon):return {'planets':[{'id':id,'longitude':lon}], 'ascendant':{'longitude':130},'midheaven':{'longitude':220}}
    pair=lambda a,b:[x for x in synastry_aspects(a,b) if x['a']=='sun' and x['b']=='moon']
    assert pair(chart('sun',359),chart('moon',1))[0]['orb']==2
    assert pair(chart('sun',0),chart('moon',8))[0]['orb']==8
    assert pair(chart('sun',0),chart('moon',8.01))==[]
    restricted=[x for x in synastry_aspects(chart('chiron',0),chart('moon',3.01)) if x['a']=='chiron' and x['b']=='moon']
    assert restricted==[]
