from datetime import timedelta
import pytest
from app.timing import resolve_time, TimeProblem

@pytest.mark.parametrize('day,clock,zone,expected,minutes',[
    ('1990-06-15','14:30','Europe/Copenhagen','1990-06-15T12:30:00+00:00',120),
    ('1990-01-15','14:30','Europe/Copenhagen','1990-01-15T13:30:00+00:00',60),
    ('2024-02-29','00:10','Asia/Kolkata','2024-02-28T18:40:00+00:00',330),
    ('1985-06-01','12:00','Asia/Kathmandu','1985-06-01T06:30:00+00:00',330),
    ('1986-06-01','12:00','Asia/Kathmandu','1986-06-01T06:15:00+00:00',345),
    ('2024-01-01','12:00','Australia/Lord_Howe','2024-01-01T01:00:00+00:00',660),
    ('2024-07-01','12:00','Australia/Lord_Howe','2024-07-01T01:30:00+00:00',630),
])
def test_local_to_utc(day,clock,zone,expected,minutes):
    utc,meta=resolve_time(day,clock,zone)
    assert utc.isoformat()==expected
    assert meta['offset_minutes']==minutes
    assert meta['iana_version']=='2026e'

@pytest.mark.parametrize('day,clock,zone',[
    ('2024-03-31','02:30','Europe/Copenhagen'),
    ('2011-12-30','12:00','Pacific/Apia'),
    ('2024-10-06','02:15','Australia/Lord_Howe'),
])
def test_nonexistent(day,clock,zone):
    with pytest.raises(TimeProblem) as err: resolve_time(day,clock,zone)
    assert err.value.code=='nonexistent_time'

def test_ambiguous_must_choose():
    with pytest.raises(TimeProblem) as err: resolve_time('2024-10-27','02:30','Europe/Copenhagen')
    assert err.value.code=='ambiguous_time'
    assert len(err.value.choices)==2
    early,_=resolve_time('2024-10-27','02:30','Europe/Copenhagen',fold=0)
    late,_=resolve_time('2024-10-27','02:30','Europe/Copenhagen',fold=1)
    assert late-early==timedelta(hours=1)
    assert early.isoformat()=='2024-10-27T00:30:00+00:00'
    assert late.isoformat()=='2024-10-27T01:30:00+00:00'

def test_historical_warning_and_auditable_override():
    _,meta=resolve_time('1943-06-01','12:00','Europe/Copenhagen')
    assert meta['historical_review_required'] and meta['warnings']
    with pytest.raises(TimeProblem): resolve_time('1943-06-01','12:00','Europe/Copenhagen',offset_minutes=120)
    utc,meta=resolve_time('1943-06-01','12:00','Europe/Copenhagen',offset_minutes=120,offset_source='Test fixture: documented +02:00')
    assert utc.hour==10 and meta['source']=='manual'
    assert meta['source_note']=='Test fixture: documented +02:00'

@pytest.mark.parametrize('zone',['Europe/Invalid','../../etc/passwd','/etc/passwd'])
def test_bad_zones(zone):
    with pytest.raises(TimeProblem): resolve_time('2000-01-01','12:00',zone)
