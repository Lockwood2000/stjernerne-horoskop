"""Published school fixtures, branch-aware phases and progression time inversion."""
from datetime import datetime,timedelta,timezone
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.engine import separation,CalculationError
from app.school_models import LoopRequest
from app.school_loops import loop_workshop,cycle_at,body_pair,phase_at,life_date
from app.techniques import YEAR_DAYS

UTC=timezone.utc
BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}
def dt(s):return datetime.fromisoformat(s)
def run(planet='mercury',**kw):return loop_workshop(LoopRequest(birth=BIRTH,planet=planet,mode='transits',date='2025-03-23',**kw))

@pytest.fixture(scope='module')
def mercury():return run()

# Kirsebom's image table, publicly published 3 March 2025:
# https://www.astrologiskinstitut.dk/post/det-sj%C3%A6ldne-sammenfald-mellem-merkur-og-venus-i-2025
# Table is rounded (half/whole degrees and calendar dates; no time zone).
# The Venus first encounter-degree passage is printed 7 Feb; exact solving
# gives 8 Feb 02:13 UTC. Treat the table as a coarse fixture, never a time oracle.
@pytest.mark.parametrize('planet,n,date,longitude',[
 ('mercury',2,'2025-03-01',357),('mercury',3,'2025-03-06',4.5),
 ('mercury',4,'2025-03-15',9.5),('mercury',5,'2025-03-24',4.5),
 ('mercury',6,'2025-04-07',357),('mercury',7,'2025-04-21',4.5),('mercury',8,'2025-04-26',9.5),
 ('venus',2,'2025-01-28',354.5),('venus',3,'2025-02-07',2.5),
 ('venus',4,'2025-03-02',11),('venus',5,'2025-03-23',2.5),
 ('venus',6,'2025-04-13',354.5),('venus',7,'2025-05-05',2.5),('venus',8,'2025-05-16',11),
])
def test_public_school_table(planet,n,date,longitude):
    stage=run(planet)['stages'][n-1]
    assert abs((dt(stage['utc'])-dt(date+'T12:00:00+00:00')).total_seconds())<86400
    assert separation(stage['longitude'],longitude)<.25

@pytest.mark.parametrize('planet',['mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'])
def test_actual_stations_solar_geometry_and_three_passages(planet):
    data=run(planet);s=data['stages']
    assert all(dt(a['utc'])<dt(b['utc']) for a,b in zip(s[1:7],s[2:8]))
    for family in ([2,6],[3,5,7],[4,8]):
        assert max(separation(s[n-1]['longitude'],s[family[0]-1]['longitude']) for n in family)<.00001
    for n,sign_before,sign_after in [(4,1,-1),(6,-1,1)]:
        t=dt(s[n-1]['utc'])
        assert abs(body_pair(planet,t)[1]['speed'])<.000001
        assert body_pair(planet,t-timedelta(minutes=5))[1]['speed']*sign_before>0
        assert body_pair(planet,t+timedelta(minutes=5))[1]['speed']*sign_after>0
    for n in [1,9]:assert separation(s[n-1]['longitude'],s[n-1]['sun_longitude'])<.00001
    angle=0 if planet in ('mercury','venus') else 180
    assert abs(separation(s[4]['longitude'],s[4]['sun_longitude'])-angle)<.00001
    assert [s[n-1]['speed']>0 for n in [2,3,7,8]]==[True]*4
    assert s[4]['speed']<0
    assert data['previous']<s[4]['utc'][:10]<data['next']

def test_aries_wrap_is_a_small_loop_not_347_degrees(mercury):
    assert mercury['stages'][5]['longitude']>350
    assert mercury['stages'][3]['longitude']<10
    assert 12<mercury['span_degrees']<13

def test_outer_conjunctions_are_not_relabelled_to_force_numeric_order():
    d=run('pluto');s=d['stages']
    assert not d['conjunctions_frame_shadow']
    assert s[1]['utc']<s[0]['utc']<s[3]['utc']
    assert s[5]['utc']<s[8]['utc']<s[7]['utc']

def test_cycle_navigation_roundtrip_and_cache_is_not_mutated(mercury):
    next_cycle=run(cycle_date=mercury['next'])
    back=run(cycle_date=next_cycle['previous'])
    assert abs((dt(back['stages'][4]['utc'])-dt(mercury['stages'][4]['utc'])).total_seconds())<.5
    mercury['stages'][0]['contacts'].append({'id':'not-real','orb':0})
    assert not any(c['id']=='not-real' for c in run()['stages'][0]['contacts'])

@pytest.mark.parametrize('n',[3,5,7])
def test_phase_nearness_is_on_the_actual_pass_not_all_three(mercury,n):
    stamp=dt(mercury['stages'][n-1]['utc'])
    birth={**BIRTH,'date':stamp.date().isoformat(),'time':stamp.time().isoformat(),'place_id':None,'latitude':55,'longitude':12,'timezone':'UTC'}
    d=loop_workshop(LoopRequest(birth=birth))
    assert n in [p['stage'] for p in d['near']]
    assert not any(p['stage'] in set([3,5,7])-{n} for p in d['near'])

def test_focus_outside_loop_is_explicit():
    d=loop_workshop(LoopRequest(birth=BIRTH,mode='transits',date='2025-02-10'))
    assert d['phase'] is None and d['near']==[]

def test_unknown_time_has_no_houses_and_reports_boundary():
    birth={'date':'2025-03-15','confidence':'unknown','place_id':'2618425'}
    d=loop_workshop(LoopRequest(birth=birth))
    assert 4 in d['boundary_stages']
    assert all(s['house'] is None for s in d['stages'])
    assert not any(c['id'] in ['ascendant','midheaven'] for s in d['stages'] for c in s['contacts'])

def test_progression_dates_invert_chart_engine_and_expand_birth_uncertainty():
    d=loop_workshop(LoopRequest(birth={**BIRTH,'confidence':'approximate','uncertainty_minutes':30},mode='progressed',date='2025-03-23'))
    born=dt(d['birth']['utc'])
    assert abs((dt(d['focus_utc'])-(born+(dt('2025-03-23T12:00:00+00:00')-born)/YEAR_DAYS)).total_seconds())<.001
    available=[s for s in d['stages'] if s['life_utc']]
    assert available
    for s in available:
        actual=dt(s['life_utc']);ephemeris=born+(actual-born)/YEAR_DAYS
        assert abs((ephemeris-dt(s['utc'])).total_seconds())<.001
        a,b=map(dt,s['life_uncertainty'])
        assert abs((b-a).total_seconds()-3600*(YEAR_DAYS-1))<.1
        assert a<actual<b

def test_lifeline_bounds_and_noon_before_birth():
    born=dt('1990-06-15T18:00:00+00:00')
    assert life_date(born-timedelta(days=1),born,'progressed') is None
    assert life_date(born+timedelta(days=150),born,'progressed') is None
    with pytest.raises(CalculationError):
        loop_workshop(LoopRequest(birth={**BIRTH,'time':'23:00:00'},mode='progressed',date='1990-06-15'))

@pytest.mark.parametrize('date',['1500-01-01','2099-12-31'])
def test_supported_date_edges(date):
    d=loop_workshop(LoopRequest(birth={**BIRTH,'date':date},settings={'bodies':['sun','moon']}))
    assert len(d['stages'])==9
    assert all(not s['life_utc'] or dt(s['life_utc']).year<=2099 for s in d['stages'])

@pytest.mark.parametrize('patch',[
 {'orb':2},{'orb':float('nan')},{'planet':'moon'},{'mode':'transits'},
 {'mode':'progressed','date':'1989-01-01'}, {'date':'2100-01-01'},{'cycle_date':'1499-01-01'},
])
def test_invalid_requests(patch):
    with pytest.raises(ValidationError):LoopRequest(birth=BIRTH,**patch)

def test_unknown_progressions_rejected_and_endpoint_works():
    client=TestClient(app)
    assert client.post('/api/school/loops',json={'birth':BIRTH}).status_code==200
    r=client.post('/api/school/loops',json={'birth':{'date':'1990-06-15','confidence':'unknown','place_id':'2618425'},'mode':'progressed','date':'2025-03-23'})
    assert r.status_code==422
