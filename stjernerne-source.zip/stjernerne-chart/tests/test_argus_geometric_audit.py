"""Geometric cross-checks without another call to the production RA/house solver.

These checks supplement the published ARGUS reference. They do not constitute
new ARGUS outputs or establish ARGUS-specific year/obliquity conventions.
"""
from datetime import datetime, timedelta
import math

import pytest

from app.engine import calculate, separation
from app.solar_key import centered_key, degree_key
from app.techniques import secondary_progressions


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0])


def geometric_axes(armc, latitude, obliquity):
    """Intersect the ecliptic with horizon/meridian planes in 3D.

    Select the eastern intersection for AC and the upper intersection for MC.
    Tested latitudes stay outside the polar region where Placidus is undefined.
    """
    theta, phi, eps = map(math.radians, (armc, latitude, obliquity))
    zenith = (math.cos(phi)*math.cos(theta), math.cos(phi)*math.sin(theta), math.sin(phi))
    east = (-math.sin(theta), math.cos(theta), 0)
    normal = (0, -math.sin(eps), math.cos(eps))
    ecliptic_y = (0, math.cos(eps), math.sin(eps))

    def intersection(plane_normal, preferred_direction):
        v = cross(normal, plane_normal)
        if dot(v, preferred_direction) < 0:
            v = tuple(-x for x in v)
        return math.degrees(math.atan2(dot(v, ecliptic_y), v[0])) % 360

    return intersection(zenith, east), intersection(east, zenith)


def integrated_ra_span(start, obliquity):
    """Integrate d(RA)/d(longitude), avoiding endpoint atan2 and its wrap.

    Simpson integration over exactly one degree; no production key function,
    right_ascension function or Swiss coordinate/house transform is used here.
    """
    sine_squared = math.sin(math.radians(obliquity))**2
    cosine = math.cos(math.radians(obliquity))
    panels = 64
    f = lambda x: cosine / (1-sine_squared*math.sin(math.radians(x))**2)
    samples = [f(start+i/panels) for i in range(panels+1)]
    return (samples[0]+samples[-1]+4*sum(samples[1:-1:2])+2*sum(samples[2:-1:2])) / (3*panels)


@pytest.mark.parametrize('obliquity', [0, 23.1, 23.44, 23.7])
def test_solar_keys_against_integral_across_the_zodiac(obliquity):
    # Dense coverage plus both sides of wrap/sign boundaries and the half-degree
    # points where centered and whole conventions must coincide.
    longitudes = [i/4 for i in range(1440)] + [-.000001, .000001, 29.999999, 30.000001, 359.999999, 360.000001]
    for longitude in longitudes:
        assert abs(centered_key(longitude, obliquity)-integrated_ra_span(longitude-.5, obliquity)) < 1e-10
        assert abs(degree_key(longitude, obliquity)-integrated_ra_span(math.floor(longitude % 360), obliquity)) < 1e-10


@pytest.mark.parametrize('years', [0, 35, 100])
@pytest.mark.parametrize('birth_iso,latitude,longitude', [
    ('1944-01-09T03:17:21+00:00', 50.083333333333336, -5.266666666666667),
    ('1990-06-15T12:30:00+00:00', 55.67594, 12.56553),
    ('2000-03-20T07:00:00+00:00', 0, -179.99),
    ('2000-12-21T12:00:00+00:00', -55, 151.2093),
])
def test_both_progression_variants_against_3d_plane_intersections(birth_iso, latitude, longitude, years):
    birth = datetime.fromisoformat(birth_iso)
    natal = calculate(birth, latitude, longitude)
    # Explicit documented convention, not inferred from the returned age.
    target = birth + timedelta(days=365.2422*years)
    for method in ('kundig_argus', 'kundig'):
        result, _ = secondary_progressions(birth, target, natal, latitude, longitude, False, method)
        key = result['technique']['solar_key']
        start = key['sun_longitude']-.5 if method == 'kundig_argus' else math.floor(key['sun_longitude'] % 360)
        rate = integrated_ra_span(start, key['obliquity'])
        expected_armc = (natal['armc'] + years*rate) % 360
        assert separation(result['armc'], expected_armc) < 1e-8
        expected_ac, expected_mc = geometric_axes(expected_armc, latitude, result['technique']['obliquity'])
        assert separation(result['ascendant']['longitude'], expected_ac) < 1e-8
        assert separation(result['midheaven']['longitude'], expected_mc) < 1e-8
