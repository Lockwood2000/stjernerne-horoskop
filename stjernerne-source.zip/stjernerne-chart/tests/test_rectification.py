from datetime import datetime,timezone
from fastapi.testclient import TestClient
from app.main import app
from app.engine import calculate,positions_at
from app.rectification import angle_contacts

B={'date':'1990-06-15','time':'14:30:12','place_id':'2618425','include_dwarfs':True}
def client():return TestClient(app,client=('192.0.2.91',1234))
def shifted(c,b=B,s=0):return c.post('/api/rectify',json={'birth':b,'shift_minutes':s})

def test_shift_zero_and_independent_calculation_preserve_original():
    c=client();original=c.post('/api/chart',json=B).json();zero=shifted(c).json()
    assert zero['planets']==original['planets'] and zero['houses']==original['houses']
    result=shifted(c,s=15).json()
    assert result['birth']['local']=='1990-06-15T14:45:12+02:00'
    independent=calculate(datetime(1990,6,15,12,45,12,tzinfo=timezone.utc),55.67594,12.56553,True)
    assert result['ascendant']==independent['ascendant'] and result['planets']==independent['planets']
    assert result['rectification']['original_local']==original['birth']['local']
    assert c.post('/api/chart',json=B).json()==original

def test_midnight_leap_day_and_date_limits():
    c=client();b={**B,'date':'2000-03-01','time':'00:05:00'}
    assert shifted(c,b,-15).json()['birth']['local']=='2000-02-29T23:50:00+01:00'
    assert shifted(c,{**B,'date':'1500-01-01','time':'00:00'},-1).status_code==422
    assert shifted(c,{**B,'date':datetime.now(timezone.utc).date().isoformat(),'time':'23:59'},180).status_code==422

def test_dst_steps_on_timeline_and_keeps_fold_explicit():
    c=client();b={**B,'date':'2025-10-26','time':'02:30','fold':0}
    r=shifted(c,b,60).json()
    assert r['birth']['local']=='2025-10-26T02:30:00+01:00' and r['birth']['fold']==1
    assert r['birth']['offset_minutes']==60
    assert shifted(c,{**B,'date':'2025-10-26','time':'02:30'},0).json()['error']['code']=='ambiguous_time'
    spring=shifted(c,{**B,'date':'2025-03-30','time':'01:55'},15).json()
    assert spring['birth']['local']=='2025-03-30T03:10:00+02:00'

def test_documented_manual_offset_is_preserved():
    c=client();r=shifted(c,{**B,'offset_minutes':90,'offset_source':'Historical source example'},15).json()
    assert r['birth']['local']=='1990-06-15T14:45:12+01:30'
    assert r['birth']['source']=='manual' and r['birth']['source_note']=='Historical source example'

def test_event_grid_daily_planets_axes_and_no_scoring():
    c=client();r=c.post('/api/rectify/compare',json={'birth':B,'shifts':[0,15,-15],'events':['2010-06-01','2020-09-12']})
    assert r.status_code==200;data=r.json();assert len(data['charts'])==3 and len(data['events'])==2
    for e in data['events']:
        assert e['timing']['utc'].endswith('T12:00:00+00:00')
        raw=positions_at(datetime.fromisoformat(e['timing']['utc']))['planets']
        assert {p['id'] for p in e['planets']}=={'jupiter','saturn','uranus','neptune','pluto'}
        for p in e['planets']:assert p==next(q for q in raw if q['id']==p['id'])
        for result,chart in zip(e['candidates'],data['charts']):
            assert result['aspects']==angle_contacts(e['planets'],chart)
            assert all(a['natal'] in ('ascendant','midheaven') and a['orb']<=2 for a in result['aspects'])
    assert all('score' not in c for e in data['events'] for c in e['candidates'])
    assert all('score' not in c for c in data['charts'])

def test_contact_geometry_wrap_and_inclusive_boundary():
    chart={'ascendant':{'longitude':359},'midheaven':{'longitude':140}}
    r=angle_contacts([{'id':'saturn','longitude':1}],chart)
    assert r==[{'transit':'saturn','natal':'ascendant','type':'conjunction','label':'Konjunktion','angle':0,'orb':2,'max_orb':2}]
    assert angle_contacts([{'id':'saturn','longitude':1.01}],chart)==[]
    assert angle_contacts([{'id':'moon','longitude':359}],chart)==[]

def test_limits_validation_and_events_before_birth():
    c=client()
    for value in [181,-181,1.5,True,'15']:
        assert shifted(c,s=value).status_code==422
    for update in [{'shifts':[0]*6},{'events':[]},{'events':['1899-01-01']},{'events':['2099-01-01']},{'events':['not-a-date']},{'labels':['private text']}]:
        assert c.post('/api/rectify/compare',json={'birth':B,'shifts':[0],'events':['2010-01-01'],**update}).status_code==422
    r=c.post('/api/rectify/compare',json={'birth':B,'shifts':[0],'events':['1989-01-01']})
    assert r.status_code==422 and 'før' in r.json()['error']['message']
    assert shifted(c,{**B,'place_id':'missing'}).status_code==422
