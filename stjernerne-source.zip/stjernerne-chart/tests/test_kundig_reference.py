"""Independent published numbers; never regenerate the reference from our engine.

Provenance, precision and limitations are in kundig-published-reference.json and
docs/CROSSCHECK.md. This checks agreement within stated tolerances, not exact
identity with every ARGUS version or every interpretation of Kündig.
"""
from datetime import datetime, timedelta
from functools import lru_cache
import json
import math
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from app.engine import calculate, kundig_geometry, separation
from app.kundig import cut_roots
from app.main import app, Birth, chart
from app.solar_key import degree_key, right_ascension
REFERENCE = json.loads(Path(__file__).with_name('kundig-published-reference.json').read_text())
CUTS = REFERENCE['argus_cuts']
KEYS = REFERENCE['solar_key']

def degrees(dms):
    d, m, s = dms
    return d + m / 60 + s / 3600

def published_time(row):
    return datetime.fromisoformat(f"{CUTS['birth']['date']}T{row['local_time']}+01:00")

@pytest.fixture(scope='module')
def tarnas_reference():
    base = chart(Birth(**CUTS['birth']))
    assert isinstance(base, dict), 'Published reference input must resolve successfully'
    assert base['birth']['utc'] == '1950-02-21T11:30:00+00:00'
    origin = datetime.fromisoformat(base['birth']['utc'])

    @lru_cache(maxsize=6000)
    def geometry(seconds):
        return kundig_geometry(origin + timedelta(seconds=seconds), CUTS['birth']['longitude'])
    return (base, origin, cut_roots(geometry, -180 * 60, 180 * 60))

@pytest.mark.parametrize('published', CUTS['rows'], ids=lambda row: row['local_time'])
def test_published_argus_cut_and_unrounded_geometry(tarnas_reference, published):
    base, origin, roots = tarnas_reference
    tolerance = CUTS['tolerances']
    expected = published_time(published)
    matches = [r for r in roots if abs((origin + timedelta(seconds=r['seconds']) - expected).total_seconds()) <= tolerance['unrounded_time_seconds']]
    assert len(matches) == 1, 'Each published ARGUS cut must have one corresponding root'
    stamp = origin + timedelta(seconds=matches[0]['seconds'])
    result = calculate(stamp, base['place']['latitude'], base['place']['longitude'])
    assert separation(result['armc'], degrees(published['armc_dms'])) * 3600 <= tolerance['armc_arcseconds']
    assert separation(result['midheaven']['longitude'], degrees(published['mc_dms'])) * 3600 <= tolerance['printed_axis_arcseconds']
    assert separation(result['ascendant']['longitude'], degrees(published['asc_dms'])) * 3600 <= tolerance['printed_axis_arcseconds']

@pytest.fixture(scope='module')
def tarnas_api():
    client = TestClient(app, client=('192.0.2.178', 1234))
    response = client.post('/api/rectify/kundig', json={'birth': CUTS['birth'], 'radius_minutes': 180, 'cut_mode': 'kundig'})
    assert response.status_code == 200, response.text
    return response.json()

@pytest.mark.parametrize('published', CUTS['rows'], ids=lambda row: row['local_time'])
def test_published_argus_clock_through_public_api(tarnas_api, published):
    expected = published_time(published)
    matches = [r for r in tarnas_api['candidates'] if abs((datetime.fromisoformat(r['local']) - expected).total_seconds()) <= CUTS['tolerances']['rounded_time_seconds']]
    assert len(matches) == 1
    assert matches[0]['offset_minutes'] == CUTS['birth']['offset_minutes']
    assert matches[0]['methods'] == ['kundig']

@pytest.mark.parametrize('example', KEYS['whole_degree_examples'], ids=lambda row: row['id'])
def test_published_whole_degree_solar_keys(example):
    actual = degree_key(example['sun_longitude'], KEYS['obliquity_degrees'])
    assert abs(actual - degrees(example['key_dms'])) * 3600 <= KEYS['tolerance_arcseconds']

@pytest.mark.parametrize('published', KEYS['wilde_geometric_example']['rows'], ids=lambda row: str(row['age_years']))
def test_borup_approximate_progressed_mc_table(published):
    example = KEYS['wilde_geometric_example']
    eps = KEYS['obliquity_degrees']
    armc = (right_ascension(degrees(example['natal_mc_dms']), eps) + published['age_years'] * degree_key(example['sun_longitude'], eps)) % 360
    ra = math.radians(armc)
    mc = math.degrees(math.atan2(math.sin(ra), math.cos(ra) * math.cos(math.radians(eps)))) % 360
    assert separation(mc, degrees(published['mc_dms'])) * 3600 <= example['tolerance_arcseconds']
