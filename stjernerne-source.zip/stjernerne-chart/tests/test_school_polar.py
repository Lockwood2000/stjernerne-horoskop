"""Real reverse-order Regiomontanus cusps, checked without a replacement system."""
from bisect import bisect_left, bisect_right
from datetime import datetime
import json
from pathlib import Path
import subprocess
import pytest
from fastapi.testclient import TestClient
from app.engine import ROOT, CalculationError, cusp_direction, house_for, separation
from app.main import app
from app.school_engine import build
from app.school_models import ChartRequest, LoopRequest, VenusRequest, WorkshopRequest
from app.school_loops import loop_workshop
from app.school_workshops import venus_workshop
from app.university_workshops import lunation_workshop

FIXTURES=json.loads((Path(__file__).parent/'fixtures/polar-regiomontanus.json').read_text())

def chart(fixture,**extra):
    return build(ChartRequest.model_validate({'birth':fixture['birth'],'settings':{'house_system':'R'},**extra}))

def sorted_boundary_house(lon,cusps,reverse=True):
    # Independent ownership oracle: a reverse house begins at the next cusp
    # above the longitude. Forward houses begin at the preceding cusp.
    ordered=sorted((cusp,i+1) for i,cusp in enumerate(cusps))
    bounds=[cusp for cusp,_ in ordered]
    index=bisect_left(bounds,lon%360) if reverse else bisect_right(bounds,lon%360)-1
    return ordered[index%12][1]

@pytest.mark.parametrize('fixture',FIXTURES,ids=lambda f:f['name'])
def test_actual_reverse_cusps_match_official_cli_and_assign_full_zodiac(fixture):
    c=chart(fixture)['layers'][0];cusps=[h['longitude'] for h in c['houses']]
    b=fixture['birth'];stamp=datetime.fromisoformat(b['date'])
    output=subprocess.check_output([str(ROOT/'build/swetest'),f'-b{stamp.day}.{stamp.month}.{stamp.year}greg',f"-utc{b['time']}",'-p0','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPl','-g,','-head',f"-house{b['longitude']},{b['latitude']},R"],text=True)
    rows=[line.split(',') for line in output.splitlines() if ',' in line]
    assert c['settings']['house_system']=='R' and c['calculation']['houses']=='Regiomontanus'
    assert cusp_direction(cusps)==-1
    for got,saved,row in zip(cusps,fixture['cusps'],rows[1:13]):
        assert separation(got,saved)<1e-10
        assert separation(got,float(row[1]))<1e-6
    assert len(rows)>=15
    for lon in [n/4 for n in range(1440)]+cusps:
        assert house_for(lon,cusps)==sorted_boundary_house(lon,cusps)
    for i,cusp in enumerate(cusps):
        assert house_for(cusp,cusps)==i+1
        assert house_for(cusp-1e-7,cusps)==i+1
        assert house_for(cusp+1e-7,cusps)==(i-1)%12+1
    for p in c['planets']:
        assert p['house']==sorted_boundary_house(p['longitude'],cusps)
        if p['id'] in fixture['expected_houses']:assert p['house']==fixture['expected_houses'][p['id']]

@pytest.mark.parametrize('school',['institut','university'])
@pytest.mark.parametrize('mode',['progressed','combined','solar_arc','solar_return','synastry'])
def test_school_timing_and_synastry_keep_regiomontanus_at_high_latitude(school,mode):
    fixture=FIXTURES[0]
    result=chart(fixture,school=school,mode=mode,target={'date':'2026-06-15','time':'00:00:00','timezone':'UTC'},return_year=2026,other=FIXTURES[1]['birth'])
    assert result['settings']['house_system']=='R'
    for layer in result['layers']:
        assert layer['settings']['house_system']=='R'
        cusps=[h['longitude'] for h in layer['houses']]
        if not cusps:continue
        reverse=cusp_direction(cusps)==-1
        for p in layer['planets']:assert p['house']==sorted_boundary_house(p['longitude'],cusps,reverse)
    if mode=='solar_arc':
        assert [p['house'] for p in result['layers'][0]['planets']]==[p['house'] for p in result['layers'][1]['planets']]
    if mode=='synastry':
        for a,b in [(0,1),(1,0)]:
            cusps=[h['longitude'] for h in result['layers'][b]['houses']]
            for p in result['layers'][a]['planets']:assert p['house_in_other']==sorted_boundary_house(p['longitude'],cusps)

def test_school_workshop_points_share_correct_reverse_house_ownership():
    fixture=FIXTURES[0];args={'birth':fixture['birth'],'settings':{'house_system':'R'}};cusps=fixture['cusps']
    venus=venus_workshop(VenusRequest(**args,horizon_years=40))
    loops=loop_workshop(LoopRequest(**args))
    lunation=lunation_workshop(WorkshopRequest(**args))
    for result in [venus,loops,lunation]:assert result['settings']['house_system']=='R'
    for p in venus['points']+loops['stages']:assert p['house']==sorted_boundary_house(p['longitude'],cusps)
    for event in lunation['lunations']:
        assert event['house']==sorted_boundary_house(event['moon']['longitude'],cusps)
        assert event['sun_house']==sorted_boundary_house(event['sun']['longitude'],cusps)

@pytest.mark.parametrize('school',['institut','university'])
def test_school_api_accepts_reverse_regiomontanus_but_never_substitutes_for_placidus(school):
    client=TestClient(app,client=('192.0.2.219',3456))
    payload={'school':school,'birth':FIXTURES[0]['birth'],'settings':{'house_system':'R'}}
    r=client.post('/api/school/chart',json=payload)
    assert r.status_code==200,r.text
    assert r.json()['layers'][0]['planets'][0]['house']==11
    payload['settings']['house_system']='P'
    r=client.post('/api/school/chart',json=payload)
    assert r.status_code==422,r.text
    assert '66' in r.text

@pytest.mark.parametrize('cusps',[[],[0]*12,list(range(11)),[float('nan')]+list(range(11)),[0,60,30,90,120,150,180,210,240,270,300,330]])
def test_invalid_cusp_cycles_are_rejected(cusps):
    with pytest.raises(CalculationError,match='Invalid house cusps'):cusp_direction(cusps)
    with pytest.raises(CalculationError,match='Invalid house cusps'):house_for(100,cusps)
