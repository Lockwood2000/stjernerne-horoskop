import test from 'node:test';
import assert from 'node:assert/strict';
import {session,encodeBackup,decodeBackup} from '../static/library-model.js';
const base=()=>({birth:{date:'1990-06-15',time:'14:30:00',place_id:'2618425',include_dwarfs:true},mode:'rectify',rectification:{shifts:[0,-1127/60,49.15],current:49.15,method:'kundig',events:[{label:'Testflytning',date:'2020-06-01'}]}});
test('both cut methods and shared candidate provenance survive backup without changing seconds',()=>{
 const value=base();value.rectification.cut_mode='both';value.rectification.cut_types=[{shift_minutes:-1127/60,methods:['bonatti']},{shift_minutes:49.15,methods:['kundig','bonatti']}];
 assert.deepEqual(decodeBackup(encodeBackup([{name:'Snitprøve',session:value}]))[0].session,value);
 const saved=session(value);value.rectification.cut_types[1].methods.pop();assert.equal(saved.rectification.cut_types[1].methods.length,2);
 assert.deepEqual(session(base()),base());
});
test('untrusted cut metadata must reference a unique kept second with known methods',()=>{
 for(const cut_types of [null,{},[{shift_minutes:1,methods:['bonatti']}],[{shift_minutes:0,methods:[]}],[{shift_minutes:0,methods:['bad']}],[{shift_minutes:0,methods:['kundig','kundig']}],[{shift_minutes:0,methods:['kundig'],html:'x'}],[{shift_minutes:0.001,methods:['kundig']}],[{shift_minutes:0,methods:['kundig']},{shift_minutes:1e-12,methods:['bonatti']}],Array(6).fill({shift_minutes:0,methods:['bonatti']})]){
  const v=base();v.rectification.cut_types=cut_types;assert.throws(()=>session(v));
 }
 for(const cut_mode of ['bad',{},null,true]){const v=base();v.rectification.cut_mode=cut_mode;assert.throws(()=>session(v));}
});
