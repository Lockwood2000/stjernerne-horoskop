"""Independent numerical checks for the school timing and house choices."""
import ctypes as C
from datetime import datetime, timedelta, timezone
import math
import subprocess
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import ROOT, lib, LOCK, positions_at, separation, CalculationError
from app.school_engine import build
from app.school_models import ChartRequest
from app.techniques import YEAR_DAYS, NAIBOD

BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}
UTC=timezone.utc

def chart(**kw):
    return build(ChartRequest.model_validate({'birth':BIRTH,**kw}))

@pytest.mark.parametrize('system',['P','E','R'])
@pytest.mark.parametrize('date,time,lat,lon,zone',[
    ('1990-06-15','12:30:00',55.67594,12.56553,'UTC'),
    ('2024-02-29','23:59:59',-33.8688,151.2093,'UTC'),
])
def test_school_houses_match_official_swiss_cli(system,date,time,lat,lon,zone):
    c=chart(birth={'date':date,'time':time,'latitude':lat,'longitude':lon,'timezone':zone},settings={'house_system':system})['layers'][0]
    stamp=datetime.fromisoformat(date+'T'+time)
    output=subprocess.check_output([str(ROOT/'build/swetest'),f'-b{stamp.day}.{stamp.month}.{stamp.year}greg',f'-utc{time}','-p0','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPl','-g,','-head',f'-house{lon},{lat},{system}'],text=True)
    rows=[line.split(',') for line in output.splitlines() if ',' in line]
    assert len(rows)>=15
    for h,row in zip(c['houses'],rows[1:13]):assert separation(h['longitude'],float(row[1]))<1e-6
    assert separation(c['ascendant']['longitude'],float(rows[13][1]))<1e-6
    assert separation(c['midheaven']['longitude'],float(rows[14][1]))<1e-6
    if system=='E':
        for i,h in enumerate(c['houses']):assert separation(h['longitude'],c['ascendant']['longitude']+30*i)<1e-10
        assert separation(c['midheaven']['longitude'],c['houses'][9]['longitude'])>.1

@pytest.mark.parametrize('system',['P','E','R'])
@pytest.mark.parametrize('years',[0,1,36])
def test_progression_key_and_independent_angle_geometry(system,years):
    born=datetime(1990,6,15,12,30,tzinfo=UTC);target=born+timedelta(days=YEAR_DAYS*years)
    a,b=chart(mode='progressed',settings={'house_system':system},target={'date':target.date().isoformat(),'time':target.time().isoformat(),'timezone':'UTC'})['layers']
    assert datetime.fromisoformat(b['technique']['ephemeris_utc'])==born+timedelta(days=years)
    reference=positions_at(born+timedelta(days=years))['planets']
    for p in reference:
        key='north_node' if p['id']=='true_node' else p['id']
        q=next(p for p in b['planets'] if p['id']==key)
        assert separation(p['longitude'],q['longitude'])<1e-10
    armc=math.radians((a['armc']+NAIBOD*years)%360)
    eps=math.radians(b['obliquity']);lat=math.radians(a['place']['latitude'])
    asc=(math.degrees(math.atan2(-math.cos(armc),math.sin(armc)*math.cos(eps)+math.tan(lat)*math.sin(eps)))+180)%360
    mc=math.degrees(math.atan2(math.sin(armc)/math.cos(eps),math.cos(armc)))%360
    assert separation(asc,b['ascendant']['longitude'])<1e-8
    assert separation(mc,b['midheaven']['longitude'])<1e-8
    if years==0:
        for x,y in zip(a['houses'],b['houses']):assert separation(x['longitude'],y['longitude'])<1e-8
    if system=='E':
        for i,h in enumerate(b['houses']):assert separation(h['longitude'],asc+30*i)<1e-8

@pytest.mark.parametrize('system',['P','E','R'])
def test_true_solar_arc_uses_progressed_sun_and_all_angles_and_cusps(system):
    target={'date':'2026-10-17','time':'12:00:00','timezone':'UTC'}
    request={'mode':'solar_arc','settings':{'house_system':system},'target':target}
    a,b=chart(**request)['layers']
    born=datetime.fromisoformat(a['birth']['utc']);stamp=datetime(2026,10,17,12,tzinfo=UTC)
    ephemeris=born+(stamp-born)/YEAR_DAYS
    sun=positions_at(ephemeris)['planets'][0]['longitude']
    arc=(sun-a['planets'][0]['longitude'])%360
    assert b['technique']['arc']==pytest.approx(arc,abs=1e-9)
    for x,y in zip(a['planets']+a['houses']+[a['ascendant'],a['midheaven']],b['planets']+b['houses']+[b['ascendant'],b['midheaven']]):
        assert separation(y['longitude'],x['longitude']+arc)<1e-10
    alternate=chart(**{**request,'settings':{'house_system':system,'progression_method':'kundig_argus'}})['layers'][1]
    assert [p['longitude'] for p in alternate['planets']]==[p['longitude'] for p in b['planets']]

@pytest.mark.parametrize('year',[1991,2026,2099])
@pytest.mark.parametrize('system',['P','E','R'])
def test_school_solar_return_matches_native_crossing_and_relocation(year,system):
    base=chart(settings={'house_system':system})['layers'][0]
    a=chart(mode='solar_return',return_year=year,settings={'house_system':system})['layers'][0]
    b=chart(mode='solar_return',return_year=year,return_place_id='2147714',settings={'house_system':system})['layers'][0]
    target=base['planets'][0]['longitude']
    assert separation(a['planets'][0]['longitude'],target)<1e-8
    assert a['technique']['residual_degrees']<1e-8
    stamp=datetime.fromisoformat(a['birth']['utc'])
    with LOCK:
        lib.swe_solcross.argtypes=[C.c_double,C.c_double,C.c_int32,C.c_char_p];lib.swe_solcross.restype=C.c_double
        reference=lib.swe_solcross(target,positions_at(stamp-timedelta(days=2))['jd_tt'],2,C.create_string_buffer(256))
    assert abs(reference-a['jd_tt'])*86400<.05
    assert a['birth']['utc']==b['birth']['utc']
    assert [p['longitude'] for p in a['planets']]==[p['longitude'] for p in b['planets']]
    assert separation(a['ascendant']['longitude'],b['ascendant']['longitude'])>1
    assert a['houses']!=b['houses'] and b['place']['name']=='Sydney'

@pytest.mark.parametrize('birth',[
    {'date':'2000-02-29','time':'12:00:00','place_id':'2618425'},
    {'date':'2000-03-20','time':'08:00:00','place_id':'2618425'},
    {'date':'2000-01-01','time':'00:30:00','latitude':-33.86,'longitude':151.21,'timezone':'Australia/Sydney'},
    {'date':'1999-12-31','time':'23:30:00','latitude':40.7,'longitude':-74,'timezone':'America/New_York'},
])
def test_return_uses_local_birthday_year_across_new_year_and_leap_day(birth):
    base=chart(birth=birth)['layers'][0]
    year=int(birth['date'][:4])
    first=chart(birth=birth,mode='solar_return',return_year=year)['layers'][0]
    assert abs((datetime.fromisoformat(first['birth']['utc'])-datetime.fromisoformat(base['birth']['utc'])).total_seconds())<.01
    with pytest.raises(CalculationError,match='precede'):chart(birth=birth,mode='solar_return',return_year=year-1)
    ret=chart(birth=birth,mode='solar_return',return_year=2026)['layers'][0]
    local=datetime.fromisoformat(base['birth']['local'])
    try:anchor=local.replace(year=2026)
    except ValueError:anchor=local.replace(year=2026,day=28)
    assert abs((datetime.fromisoformat(ret['birth']['utc'])-anchor).total_seconds())<3*86400
    assert separation(ret['planets'][0]['longitude'],base['planets'][0]['longitude'])<1e-8

def test_target_timezone_roundtrip_and_both_profile_defaults():
    request=ChartRequest.model_validate({'school':'university','birth':BIRTH,'mode':'progressed','settings':{'house_system':'R','progression_method':'kundig'},'target':{'date':'2026-10-25','time':'02:30:00','timezone':'Europe/Copenhagen','fold':1}})
    a=build(request);b=build(ChartRequest.model_validate(a['input']))
    assert a==b
    assert a['layers'][1]['technique']['target_utc']=='2026-10-25T01:30:00+00:00'
    client=TestClient(app,client=('192.0.2.218',2345))
    profiles=client.get('/api/school/profiles').json()['profiles']
    assert {p['id']:p['settings']['house_system'] for p in profiles}=={'institut':'P','university':'W'}

def test_return_keeps_birth_timing_for_opening_lifeline_progressions():
    result=chart(mode='solar_return',return_year=2026,return_place_id='2147714')
    assert result['birth_times'][0]['utc']=='1990-06-15T12:30:00+00:00'
    assert result['layers'][0]['birth']['utc'].startswith('2026-06-15')
