import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyWorkshops,validateWorkshops,validDay,timelinePositions} from '../static/school/workshop-model.js';
import {validateRecord,decodeFile} from '../static/school/model.js';
const old={format:'stjernerne-school-chart',version:1,name:'Old study',request:{school:'institut',birth:{date:'1990-06-15'}},notes:{}};
test('old study records receive an empty, independent workshop state',()=>{
 const a=validateRecord(old),b=validateRecord(old);a.workshops.reflections.venus='Private note';
 assert.equal(b.workshops.reflections.venus,'');assert.deepEqual(b.workshops,emptyWorkshops());
});
test('all workshop reflections, settings and events survive a JSON roundtrip',()=>{
 const w=emptyWorkshops();w.active='life';w.reflections.south='Egen refleksion';w.shift=4.5;w.events=[{id:'event-1',date:'2014-04-01',label:'Ny retning',note:'Mine ord'}];w.selectedEvent='event-1';
 const r=decodeFile(JSON.stringify({...old,workshops:w}));assert.deepEqual(r.workshops,w);
 r.workshops.events[0].note='Edited';assert.equal(w.events[0].note,'Mine ord');
});
test('calendar validity and limits are checked before import',()=>{
 assert(validDay('2024-02-29'));assert(!validDay('2023-02-29'));assert(!validDay('2100-01-01'));
 for(const patch of [{orb:NaN},{shift:181},{active:'other'},{selectedStar:5},{reflections:{venus:7}},{events:[{id:'<bad>',date:'2020-01-01',label:'x',note:''}]}])assert.throws(()=>validateWorkshops({...emptyWorkshops(),...patch}));
 const event={id:'e',date:'2020-01-01',label:'Example',note:''};assert.throws(()=>validateWorkshops({...emptyWorkshops(),events:[event,event]}));
});
test('timeline uses elapsed time including leap years and handles birth-day events',()=>{
 const events=[{date:'2000-01-01'},{date:'2010-01-01'},{date:'2020-01-01'}];const p=timelinePositions(events,'2000-01-01');
 assert.equal(p[0].percent,8);assert.equal(p[2].percent,92);assert(Math.abs(p[1].percent-50)<.02);
 assert.equal(timelinePositions([{date:'2000-01-01'}],'2000-01-01')[0].percent,8);
});
