from datetime import datetime, timezone
import math
from zoneinfo import ZoneInfo
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import calculate, kundig_geometry, separation
from app.kundig import cut_roots
B = {'date': '1990-06-15', 'time': '14:30:00', 'place_id': '2618425', 'include_dwarfs': True}

def geometry(armc, venus=100):
    return {'armc': armc % 360, 'mc': armc % 360, 'ra': {'mars': 0, 'venus': venus, 'mercury': 125, 'jupiter': 260, 'moon': 170, 'saturn': 220, 'sun': 100}}

def test_analytic_uniform_meridian_and_sign_boundary():
    roots = cut_roots(lambda t: geometry(15 + t / 240), -3600, 3600)
    assert [r['seconds'] for r in roots] == pytest.approx([-3600, -1200, 1200, 3600], abs=0.001)

def test_subsecond_spacing_is_not_lost_to_a_sampling_grid():

    def close(t):
        g = geometry(10 + t / 240, 10.02)
        g['ra']['mars'] = 10
        return g
    roots = cut_roots(close, -10, 10)
    assert len(roots) == 11
    assert [r['seconds'] for r in roots] == pytest.approx([i * 0.48 for i in range(11)], abs=0.001)

def test_partner_order_change_cannot_create_a_false_cut():

    def crossing(t):
        g = geometry(20 + t / 240, 10 + t / 6000)
        g['ra']['mars'] = 10
        return g
    roots = cut_roots(crossing, -3600, 3600)
    assert roots and all((abs(r['seconds']) > 30 for r in roots))
    assert all((math.isfinite(r['seconds']) for r in roots))

def test_meridian_geometry_agrees_with_existing_chart_at_high_and_low_latitude():
    utc = datetime(2000, 1, 1, 11, tzinfo=timezone.utc)
    g = kundig_geometry(utc, 12.56553)
    for latitude in (0, 55.67594, -60):
        chart = calculate(utc, latitude, 12.56553)
        assert separation(g['mc'], chart['midheaven']['longitude']) < 1e-07
        assert separation(g['armc'], chart['armc']) < 1e-07

def client():
    return TestClient(app, client=('192.0.2.92', 1234))

def test_real_cuts_preview_comparison_and_original_are_consistent():
    c = client()
    original = c.post('/api/chart', json=B).json()
    response = c.post('/api/rectify/kundig', json={'birth': B, 'radius_minutes': 180})
    assert response.status_code == 200
    data = response.json()
    rows = data['candidates']
    assert rows and rows == sorted(rows, key=lambda row: row['utc'])
    assert len({row['utc'] for row in rows}) == len(rows)
    assert sum((row['nearest'] for row in rows)) == min(3, len(rows))
    assert all(('score' not in row for row in rows))
    chosen = min(rows, key=lambda row: abs(row['shift_minutes']))
    assert chosen['shift_minutes'] != int(chosen['shift_minutes'])
    preview = c.post('/api/rectify', json={'birth': B, 'shift_minutes': chosen['shift_minutes']}).json()
    assert preview['birth']['local'] == chosen['local']
    assert separation(preview['midheaven']['longitude'], chosen['mc']['longitude']) < 1e-07
    comparison = c.post('/api/rectify/compare', json={'birth': B, 'shifts': [0, chosen['shift_minutes']], 'events': ['2020-06-01']}).json()
    assert comparison['charts'][1] == preview
    assert c.post('/api/chart', json=B).json() == original
    assert data['method']['bonatti'] is False and data['method']['rulers'] == 'traditional'

@pytest.mark.parametrize('birth', [{**B, 'date': '2025-10-26', 'time': '02:30:00', 'fold': 0}, {**B, 'date': '2025-03-30', 'time': '01:55:00'}, {**B, 'offset_minutes': 90, 'offset_source': 'Documented historical source'}, {**B, 'date': '1500-01-01', 'time': '00:00:00'}])
def test_dst_manual_offset_and_lower_date_bound(birth):
    c = client()
    base = c.post('/api/chart', json=birth).json()
    response = c.post('/api/rectify/kundig', json={'birth': birth, 'radius_minutes': 180})
    assert response.status_code == 200
    for row in response.json()['candidates']:
        utc = datetime.fromisoformat(row['utc'])
        assert (utc - datetime.fromisoformat(base['birth']['utc'])).total_seconds() == row['shift_seconds']
        assert row['local'][:10] >= '1500-01-01'
        if 'offset_minutes' in birth:
            assert row['offset_minutes'] == 90
        else:
            local = utc.astimezone(ZoneInfo('Europe/Copenhagen'))
            assert local.isoformat() == row['local'] and local.fold == row['fold']

@pytest.mark.parametrize('value', [0, 181, True, '60', 60.5])
def test_search_interval_is_bounded_and_strict(value):
    assert client().post('/api/rectify/kundig', json={'birth': B, 'radius_minutes': value}).status_code == 422

def test_second_resolution_and_rejection_of_malformed_candidates():
    c = client()
    result = c.post('/api/rectify', json={'birth': B, 'shift_minutes': 1 / 60})
    assert result.status_code == 200 and result.json()['birth']['local'] == '1990-06-15T14:30:01+02:00'
    for value in [True, '0.5', 0.001]:
        assert c.post('/api/rectify', json={'birth': B, 'shift_minutes': value}).status_code == 422
    assert c.post('/api/rectify/kundig', json={'birth': {**B, 'date': '2025-10-26', 'time': '02:30'}}).status_code == 422
