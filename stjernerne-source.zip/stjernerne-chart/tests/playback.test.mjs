import test from 'node:test';
import assert from 'node:assert/strict';
import {createPlayer,nextTransitTime} from '../static/playback.js';

test('calendar steps cross year/leap-day boundaries and respect limits',()=>{
  assert.deepEqual(nextTransitTime('2024-02-28','12:30:00',24),{date:'2024-02-29',time:'12:30:00'});
  assert.deepEqual(nextTransitTime('2026-01-01','00:30:00',-1),{date:'2025-12-31',time:'23:30:00'});
  assert.deepEqual(nextTransitTime('2026-10-20','12:30:00',-168),{date:'2026-10-13',time:'12:30:00'});
  assert.equal(nextTransitTime('2099-12-31','23:30:00',1),null);
  assert.equal(nextTransitTime('1900-01-01','00:30:00',-1),null);
});
function clock(){let id=0;const jobs=new Map();return {jobs,schedule:f=>{jobs.set(++id,f);return id;},cancel:id=>jobs.delete(id),run:()=>{const [key,f]=jobs.entries().next().value;jobs.delete(key);return f();}};}
test('waits for each calculation, never overlaps, cancels a pending frame',async()=>{
  const c=clock();let done,calls=0;const states=[];
  const player=createPlayer(()=>{calls++;return new Promise(resolve=>done=resolve);},s=>states.push(s),c);
  player.start();player.start();assert.equal(c.jobs.size,1);
  const inFlight=c.run();assert.equal(calls,1);assert.equal(c.jobs.size,0);
  done(true);await inFlight;assert.equal(c.jobs.size,1);
  player.stop();assert.equal(c.jobs.size,0);assert.deepEqual(states,[true,false]);
});
test('a paused and restarted loop ignores its older in-flight response',async()=>{
  const c=clock();const completions=[];
  const player=createPlayer(()=>new Promise(resolve=>completions.push(resolve)),()=>{},c);
  player.start();const old=c.run();player.stop();player.start();const fresh=c.run();
  completions[0](true);await old;assert.equal(c.jobs.size,0);
  completions[1](true);await fresh;assert.equal(c.jobs.size,1);player.stop();
});
test('failed calculation or exception pauses without retry storm',async()=>{
  for(const frame of [async()=>false,async()=>{throw Error('offline');}]){
    const c=clock();const player=createPlayer(frame,()=>{},c);player.start();await c.run();
    assert.equal(player.active,false);assert.equal(c.jobs.size,0);
  }
});
