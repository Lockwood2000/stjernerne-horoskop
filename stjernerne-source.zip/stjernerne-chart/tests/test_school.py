from copy import deepcopy
from datetime import datetime,timezone
import math
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.engine import calculate,separation,CalculationError
from app.school_models import Settings,BirthInput,ChartRequest,EventsRequest,RectificationRequest
from app.school_engine import natal,build,aspects,midpoint,positions
from app.school_events import diary
from app.school_rectification import compare,cuts

BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}
OTHER={'date':'1988-01-01','time':'12:00:00','place_id':'2643743'}
TARGET={'date':'2026-10-16','time':'12:00:00','timezone':'UTC'}
def request(**kw):return ChartRequest.model_validate({'birth':BIRTH,**kw})

def test_retained_calculation_agrees_for_same_conventions():
    old=calculate(datetime(1990,6,15,12,30,tzinfo=timezone.utc),55.67594,12.56553,True)
    new=build(request())['layers'][0]
    assert separation(new['ascendant']['longitude'],old['ascendant']['longitude'])<1e-10
    for p in old['planets']:
        key='north_node' if p['id']=='true_node' else p['id']
        other=next(q for q in new['planets'] if q['id']==key)
        assert separation(p['longitude'],other['longitude'])<1e-10

@pytest.mark.parametrize('system',['P','W','E','K','O','C','T','R'])
def test_house_systems_are_explicit_and_propagate(system):
    r=build(request(settings={'house_system':system},mode='combined',target=TARGET))
    for c in r['layers'][:2]:
        assert len(c['houses'])==12
        assert c['settings']['house_system']==system
    if system=='W':
        assert all(abs(h['degree'])<1e-10 for c in r['layers'][:2] for h in c['houses'])

def test_au_bowie_public_teaching_chart():
    # Kelly Surtees, AU 2016 slides pp.12/55. Brixworth as printed, not Brixton.
    # https://www.astrologyuniversity.com/pdf/WebinarSurteesPredictive_Slides.pdf
    b=BirthInput(date='1947-01-08',time='09:00:00',latitude=52+20/60,longitude=-(54/60),timezone='Europe/London',offset_minutes=0,offset_source='AU teaching slide: 09:00 UT')
    c=natal(b,Settings(house_system='W'))
    expected={'sun':270+17+14/60,'moon':120+3+49/60,'ascendant':300+52/60,'midheaven':240+3+12/60}
    lookup={p['id']:p for p in c['planets']}|{'ascendant':c['ascendant'],'midheaven':c['midheaven']}
    for key,lon in expected.items():assert separation(lookup[key]['longitude'],lon)<1/60,key
    assert c['houses'][9]['longitude']!=c['midheaven']['longitude']

def test_au_george_vi_placidus_public_teaching_chart():
    # Same public slides p.59, rounded chart axes. Gregorian/New Style as printed.
    b=BirthInput(date='1895-12-14',time='03:00:00',latitude=52+50/60,longitude=.5,timezone='Europe/London',offset_minutes=0,offset_source='AU teaching slide: 03:00 UT')
    c=natal(b,Settings())
    assert separation(c['ascendant']['longitude'],180+26+17/60)<1/60
    assert separation(c['midheaven']['longitude'],120+5+39/60)<1/60

def test_unknown_time_has_no_real_houses_and_has_sampled_range():
    b=BirthInput(**{**BIRTH,'time':None,'confidence':'unknown'})
    c=natal(b,Settings())
    assert c['ascendant'] is None and not c['houses'] and all(p['house'] is None for p in c['planets'])
    moon=next(p for p in c['planets'] if p['id']=='moon')
    assert 10<moon['sampled_range']['width']<17
    assert c['birth']['nominal_time_only']
    solar=natal(b,Settings(),solar=True)
    assert len(solar['houses'])==12 and solar['ascendant'] is None and solar['midheaven'] is None
    assert 'not actual birth houses' in solar['synthetic_houses']

def test_approximate_time_is_explicit():
    c=natal(BirthInput(**{**BIRTH,'confidence':'approximate','uncertainty_minutes':45}),Settings())
    assert c['birth']['confidence']=='approximate' and c['ascendant']
    assert 'uncertainty' in c

def test_mean_true_nodes_and_south_node():
    a=natal(BirthInput(**BIRTH),Settings());b=natal(BirthInput(**BIRTH),Settings(node='mean'))
    point=lambda c,k:next(p for p in c['planets'] if p['id']==k)
    assert separation(point(a,'north_node')['longitude'],point(b,'north_node')['longitude'])>.01
    assert separation(point(a,'north_node')['longitude'],point(a,'south_node')['longitude'])==pytest.approx(180)
    assert point(a,'north_node')['declination']==-point(a,'south_node')['declination']
    assert point(a,'sun')['longitude']==point(b,'sun')['longitude']

def test_selected_asteroids_and_declinations():
    c=natal(BirthInput(**BIRTH),Settings(bodies=['sun','moon','pallas','juno','vesta']))
    assert [p['id'] for p in c['planets']]==['sun','moon','pallas','juno','vesta']
    for p in c['planets']:
        assert math.isfinite(p['declination'])
        assert p['out_of_bounds']==(abs(p['declination'])>c['obliquity'])

def test_custom_orb_inclusive_and_wrap_and_quincunx():
    p=lambda name,lon:{'id':name,'longitude':lon}
    s=Settings(orbs={'0':1.5,'150':1.5})
    assert aspects([p('sun',359.5)],[p('moon',1)],s)[0]['orb']==1.5
    assert not aspects([p('sun',359.5)],[p('moon',1.0001)],s)
    assert aspects([p('sun',0)],[p('moon',150)],s)[0]['type']=='quincunx'

@pytest.mark.parametrize('mode',['natal','event','solar_chart','transits','progressed','combined','solar_arc','synastry','composite','compare','solar_return'])
def test_every_mode(mode):
    c=build(request(mode=mode,target=TARGET,other=OTHER,return_year=2026))
    assert c['mode']==mode
    assert all(len(layer['planets'])==17 for layer in c['layers'])

@pytest.mark.parametrize('method',['naibod','kundig','kundig_argus'])
def test_progressed_moon_phase_uses_progressed_sun(method):
    c=build(request(mode='combined',target=TARGET,settings={'progression_method':method}))
    assert len(c['layers'])==3 and len(c['cross_aspects'])==3
    prog=c['layers'][1];by={p['id']:p for p in prog['planets']}
    assert prog['phase']['angle']==pytest.approx((by['moon']['longitude']-by['sun']['longitude'])%360)
    assert prog['technique']['axis_method']==method

def test_solar_arc_is_uniform_and_not_solar_return():
    c=build(request(mode='solar_arc',target=TARGET));a,b=c['layers'];arc=b['technique']['arc']
    for p,q in zip(a['planets'],b['planets']):
        assert (q['longitude']-p['longitude'])%360==pytest.approx(arc)
        assert q['declination'] is None and q['retrograde'] is None

def test_composite_midpoints_and_symmetry():
    assert midpoint(350,10)==0
    with pytest.raises(CalculationError):midpoint(0,180)
    a=build(request(mode='composite',other=OTHER))['layers'][0]
    b=build(ChartRequest.model_validate({'birth':OTHER,'other':BIRTH,'mode':'composite'}))['layers'][0]
    for p,q in zip(a['planets'],b['planets']):assert separation(p['longitude'],q['longitude'])<1e-10
    assert separation(a['ascendant']['longitude'],b['ascendant']['longitude'])<1e-10

def test_station_scan_and_exact_residuals():
    r=EventsRequest.model_validate({'birth':BIRTH,'start':'2025-03-10','end':'2025-04-10','planet':'mercury','target_body':'sun','settings':{'orbs':{'0':2,'90':2,'180':2}}})
    d=diary(r)
    stations=[e for e in d['events'] if e['kind'].startswith('station_')]
    assert [e['kind'] for e in stations]==['station_retrograde','station_direct']
    assert stations[0]['utc'].startswith('2025-03-15')
    assert stations[1]['utc'].startswith('2025-04-07')
    for e in d['events']:
        if e['kind']=='exact_aspect':assert abs(separation(e['longitude'],d['target']['longitude'])-e['angle'])<1e-4
    assert all('start_clipped' in i and 'end_clipped' in i for i in d['intervals'])

def test_rectification_preserves_original_and_seconds():
    payload={'birth':BIRTH,'shifts':[0,15+1/60],'events':['2026-10-16'],'method':'progressed','settings':{'progression_method':'kundig_argus','house_system':'W'}}
    original=deepcopy(payload);r=compare(RectificationRequest.model_validate(payload))
    assert payload==original
    a,b=r['charts'];assert (datetime.fromisoformat(b['birth']['utc'])-datetime.fromisoformat(a['birth']['utc'])).total_seconds()==901
    assert r['sample_time']=='12:00 UTC' and len(r['events'][0]['candidates'])==2
    assert all(h['degree']==0 for h in b['houses'])
    for c in r['events'][0]['candidates']:
        assert all(a['orb']<=1 and (a['a'] in ('ascendant','midheaven') or a['b'] in ('ascendant','midheaven')) for a in c['aspects'])

def test_rectification_range_boundary_is_an_actionable_error():
    with pytest.raises(CalculationError,match='date range'):
        compare(RectificationRequest.model_validate({'birth':{**BIRTH,'date':'1500-01-01','time':'00:00:00'},'shifts':[-15]}))

def test_section_reuse_returns_candidates():
    r=cuts(RectificationRequest.model_validate({'birth':BIRTH,'cut_mode':'both'}))
    assert r['candidates'] and r['method']['cut_mode']=='both'

@pytest.mark.parametrize('data',[
    {'birth':{**BIRTH,'time':None}},
    {'birth':{**BIRTH,'confidence':'unknown'}},
    {'birth':{**BIRTH,'time':None,'confidence':'unknown'},'mode':'progressed','target':TARGET},
    {'birth':BIRTH,'settings':{'orbs':{'0':float('nan')}}},
    {'birth':BIRTH,'settings':{'bodies':['sun','moon','unknown']}},
])
def test_invalid_requests_are_rejected(data):
    with pytest.raises(ValidationError):ChartRequest.model_validate(data)

def test_school_routes_and_actionable_validation():
    client=TestClient(app,client=('192.0.2.211',1234))
    for route in ['/institut','/university','/schools']:assert client.get(route).status_code==200
    assert client.post('/api/school/chart',json={'birth':BIRTH,'mode':'combined','target':TARGET}).status_code==200
    bad=client.post('/api/school/chart',json={'birth':BIRTH,'settings':{'orbs':{'10':3}}})
    assert bad.status_code==422 and 'aspects' in bad.json()['error']['message']
    assert client.post('/api/school/chart',json={'birth':BIRTH},headers={'Origin':'https://example.org'}).status_code==403
