import test from 'node:test';
import assert from 'node:assert/strict';
import {formatShift,normalizeShift} from '../static/rectification-time.js';
import {session,encodeBackup,decodeBackup} from '../static/library-model.js';
test('cut offsets are readable to seconds, including negative sub-minute shifts',()=>{
  assert.equal(formatShift(-142/60),'−2 min. 22 sec.');
  assert.equal(formatShift(1/60),"+1 sec.");
  assert.equal(formatShift(-1/60),"−1 sec.");
  assert.equal(formatShift(15),'+15 min.');
  assert.equal(formatShift(0),'0 min.');
  assert.equal(normalizeShift(-142/60),-142/60);
  assert.equal(normalizeShift(1000),180);
});
test('backup/import preserves fractional-minute cuts and the preview without drift',()=>{
  const value={birth:{date:'1990-06-15',time:'14:30:00',place_id:'2618425',include_dwarfs:true},mode:'rectify',
    rectification:{shifts:[0,-142/60,2949/60],current:1/60,events:[{label:'Eksempel',date:'2020-06-01'}]}};
  const rows=[{name:'Kündig-test',session:value,trashed:false}];
  assert.deepEqual(decodeBackup(encodeBackup(rows)),rows);
  assert.deepEqual(session(value),value);
  assert.throws(()=>session({...value,rectification:{...value.rectification,current:.001}}));
  assert.throws(()=>session({...value,rectification:{...value.rectification,shifts:[0,1/60,1/60+1e-12]}}));
});
