"""Integration and independent CLI checks for the evolutionary overlay."""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import math
import subprocess

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.evolution import ROOT, EvolutionRequest, build_evolution
from app.engine import separation
from app.school_engine import natal
from app.school_models import BirthInput, Settings
from app.techniques import YEAR_DAYS

BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}


def chart(**kwargs):
    return build_evolution(EvolutionRequest(birth=BIRTH,extras=[],**kwargs))


@pytest.mark.parametrize('reference',['geocentric','heliocentric'])
def test_seven_planet_mean_nodes_match_official_swetest(reference):
    result=chart(node_reference=reference)
    args=[str(ROOT/'build/swetest'),'-edir'+str(ROOT/'data/ephe'),
          '-bj'+str(result['natal']['jd_tt']),'-p2345678','-fPn','-g,','-head','-speed']
    if reference=='heliocentric':args.append('-hel')
    lines=subprocess.check_output(args,text=True).strip().splitlines()
    for pair,line in zip(result['planetary_nodes'],lines):
        name,north,south=line.split(',')
        assert name.strip()==pair['name']
        assert separation(pair['north']['longitude'],float(north))<1e-6
        assert separation(pair['south']['longitude'],float(south))<1e-6


def test_pluto_osculating_heliocentric_orbit_matches_cli():
    result=chart(node_method='osculating_heliocentric')
    line=subprocess.check_output([str(ROOT/'build/swetest'),'-edir'+str(ROOT/'data/ephe'),
        '-bj'+str(result['natal']['jd_tt']),'-p9','-fPN','-g,','-head','-speed'],text=True).strip()
    _,north,south=line.split(',')
    pair=next(p for p in result['planetary_nodes'] if p['body']=='pluto')
    assert separation(pair['north']['longitude'],float(north))<1e-6
    assert separation(pair['south']['longitude'],float(south))<1e-6


def test_geocentric_descending_nodes_are_not_manufactured_oppositions():
    result=chart()
    venus=next(p for p in result['planetary_nodes'] if p['body']=='venus')
    assert separation(venus['north']['longitude'],venus['south']['longitude'])<90
    pluto=next(p for p in result['planetary_nodes'] if p['body']=='pluto')
    assert abs(separation(pluto['north']['longitude'],pluto['south']['longitude'])-180)>.5
    assert pluto['method']=='osculating'
    assert next(p for p in result['planetary_nodes'] if p['body']=='uranus')['method']=='mean'


def test_heliocentric_nodes_are_opposite_and_differ_from_geocentric():
    geo=chart();hel=chart(node_reference='heliocentric')
    for a,b in zip(geo['planetary_nodes'],hel['planetary_nodes']):
        assert abs(separation(b['north']['longitude'],b['south']['longitude'])-180)<.001
        assert separation(a['north']['longitude'],b['north']['longitude'])>.001


@pytest.mark.parametrize('system',['O','P','W'])
def test_shared_school_engine_and_explicit_houses(system):
    result=chart(house_system=system)
    base=natal(BirthInput(**BIRTH),Settings(house_system=system,bodies=['sun','moon','pluto','north_node','south_node']))
    assert result['natal']['ascendant']['longitude']==base['ascendant']['longitude']
    for p in base['planets']:
        actual=next(q for q in result['natal']['planets'] if q['id']==p['id'])
        assert actual['longitude']==p['longitude']
    assert all(1<=n[side]['house']<=12 for n in result['planetary_nodes'] for side in ('north','south'))
    if system=='W':assert all(h['degree']==0 for h in result['natal']['houses'])


def test_true_and_mean_modes_change_only_the_lunar_nodes():
    a=chart();b=chart(lunar_node='mean')
    assert a['planetary_nodes']==b['planetary_nodes']
    lunar=lambda r:next(p for p in r['natal']['planets'] if p['id']=='north_node')
    assert separation(lunar(a)['longitude'],lunar(b)['longitude'])>.01
    for mode in ('true','mean'):
        north,south=a['lunar_nodes'][mode]
        assert separation(north['longitude'],south['longitude'])==pytest.approx(180)


def test_additional_bodies_and_their_nodes_are_real_and_available():
    result=build_evolution(EvolutionRequest(birth=BIRTH))
    assert not result['warnings']
    assert len(result['natal']['planets'])==21
    assert len(result['planetary_nodes'])==17
    assert {'eris','sedna','haumea','makemake','quaoar','orcus','gonggong'}<=set(p['body'] for p in result['planetary_nodes'])
    for pair in result['planetary_nodes']:
        for side in ('north','south'):
            assert 0<=pair[side]['longitude']<360
            assert math.isfinite(pair[side]['speed'])


def test_secondary_progressions_use_shared_epoch_and_keep_nodes_natal():
    base=chart()
    result=chart(include_progressions=True,target={'date':'2026-10-16'})
    born=datetime.fromisoformat(result['natal']['birth']['utc'])
    target=datetime(2026,10,16,12,tzinfo=timezone.utc)
    expected=born+timedelta(days=(target-born).total_seconds()/(86400*YEAR_DAYS))
    actual=datetime.fromisoformat(result['progressed']['technique']['ephemeris_utc'])
    assert abs((actual-expected).total_seconds())<.00001
    assert result['planetary_nodes']==base['planetary_nodes']
    assert result['progressed']['technique']['axis_method']=='naibod'
    assert any(a.get('target_layer')=='planetary_nodes' for a in result['progression_aspects'])


def test_unknown_time_omits_angles_and_all_house_claims():
    b={**BIRTH,'time':None,'confidence':'unknown'}
    result=build_evolution(EvolutionRequest(birth=b,extras=[]))
    assert not result['natal']['houses'] and result['natal']['ascendant'] is None
    assert all(pair[side]['house'] is None for pair in result['planetary_nodes'] for side in ('north','south'))
    with pytest.raises(ValidationError):EvolutionRequest(birth=b,include_progressions=True,target={'date':'2026-10-16'})


def test_orb_restriction_is_monotonic():
    broad=chart(node_orb=3);narrow=chart(node_orb=1)
    identity=lambda a:(a['a'],a['b'],a['angle'])
    assert set(map(identity,narrow['node_aspects']))<set(map(identity,broad['node_aspects']))
    assert all(a['orb']<=1 for a in narrow['node_aspects'])


def test_api_rejects_invalid_settings_and_serves_the_workspace():
    with TestClient(app) as client:
        assert client.get('/evolution').status_code==200
        assert client.get('/static/evolution/bridge.js').status_code==200
        response=client.post('/api/evolution/chart',json={'birth':BIRTH,'extras':[]})
        assert response.status_code==200 and response.json()['contract']=='stjernerne-evolution-1'
        for change in ({'node_orb':0},{'house_system':'invalid'},{'include_progressions':True},{'extras':['nibiru']},{'node_reference':'barycentric'}):
            response=client.post('/api/evolution/chart',json={'birth':BIRTH,**change})
            assert response.status_code==422
            assert response.json()['error']['code']=='invalid_input'


def test_overlay_does_not_silently_replace_unavailable_placidus():
    b={**BIRTH,'place_id':None,'latitude':70,'longitude':20,'timezone':'UTC'}
    with TestClient(app) as client:
        response=client.post('/api/evolution/chart',json={'birth':b,'house_system':'P','extras':[]})
        assert response.status_code==422
        assert 'no fallback' in response.text or 'restricted' in response.text
        response=client.post('/api/evolution/chart',json={'birth':b,'house_system':'W','extras':[]})
        assert response.status_code==200


def test_dedicated_deployment_can_open_evolution_at_root_without_changing_local_default(monkeypatch):
    with TestClient(app) as client:
        monkeypatch.delenv('EVOLUTION_HOME',raising=False)
        assert 'id="chart-mode"' in client.get('/').text
        monkeypatch.setenv('EVOLUTION_HOME','1')
        assert 'id="timing-mode"' in client.get('/').text
        assert client.get('/api/health').status_code==200
        assert 'id="timing-mode"' in client.get('/evolution').text
