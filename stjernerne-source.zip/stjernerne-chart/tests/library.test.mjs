import test from 'node:test';
import assert from 'node:assert/strict';
import {session,decodeBackup,encodeBackup,MAX_BYTES} from '../static/library-model.js';
const base=()=>({birth:{date:'1990-06-15',time:'14:30:12',place_id:'2618425',include_dwarfs:true},mode:'rectify',rectification:{shifts:[0,15,-10],current:17,events:[{label:'Flytning (eksempel)',date:'2011-04-01'}]}});
const backup=rows=>JSON.stringify({format:'stjernerne-horoskoper',version:1,records:rows});
test('backup round-trip preserves candidates, unsaved preview offset, labels, seconds and trash',()=>{
 const rows=[{name:'Eksempel æøå',session:base(),trashed:false},{name:'Tidligere',session:base(),trashed:true}];
 assert.deepEqual(decodeBackup(encodeBackup(rows)),rows);
});
test('all chart configurations round-trip with explicit time and place choices',()=>{
 const b=base();b.birth={date:'1950-10-15',time:'02:30',include_dwarfs:false,place_name:'',latitude:55.7,longitude:12.5,timezone:'Europe/Copenhagen',fold:1,offset_minutes:90,offset_source:'Documented historical source'};
 for(const extra of [{mode:'natal',transit:{date:'2025-10-26',time:'02:30',timezone:'Europe/Copenhagen',fold:1}},{mode:'synastry',synastry:{birth:base().birth,order:'b'}},{mode:'solar',technique:{mode:'solar',year:2026,location:{place_id:'2643743'}}},{mode:'progressed',technique:{mode:'progressed',target:{date:'2026-10-13',time:'12:00:00',timezone:'UTC'}}}]){const value={...b,...extra};assert.deepEqual(session(value),value);}
});
test('bad version, oversized files and non-backup JSON are rejected',()=>{
 for(const text of ['{','{}',JSON.stringify({format:'stjernerne-horoskoper',version:2,records:[]}), 'x'.repeat(MAX_BYTES+1)])assert.throws(()=>decodeBackup(text));
});
test('whole import is rejected if any entry is invalid',()=>{
 const good={name:'Eksempel',session:base()},bad={name:'Ugyldig',session:{...base(),birth:{...base().birth,date:'2023-02-29'}}};
 assert.throws(()=>decodeBackup(backup([good,bad])));
 assert.throws(()=>decodeBackup(backup(Array.from({length:101},()=>good))));
});
test('invalid counts, shifts, dates and labels cannot enter saved state',()=>{
 for(const rect of [{shifts:[]},{shifts:[15]},{shifts:[0,0]},{shifts:[0,181]},{shifts:[0,1.501]},{shifts:[0,1,2,3,4,5]},{current:Infinity},{current:'15'},{events:[{label:' ',date:'2020-01-01'}]},{events:[{label:'x',date:'2021-02-29'}]},{events:Array.from({length:6},()=>({label:'x',date:'2020-01-01'}))}])assert.throws(()=>session({...base(),rectification:{...base().rectification,...rect}}));
});
test('unknown keys and prototype payloads are rejected and do not alter objects',()=>{
 const value=base();value.rectification.events[0].html='<script>alert(1)</script>';assert.throws(()=>session(value));
 assert.throws(()=>decodeBackup(backup([{name:'Test',session:base(),__proto__:null,unknown:1}])));
 const poisoned=JSON.parse(JSON.stringify(base()).replace('"mode":"rectify"','"__proto__":{"polluted":true},"mode":"rectify"'));assert.throws(()=>session(poisoned));assert.equal({}.polluted,undefined);
});
test('birth payloads cannot mix atlas and manual coordinates or accept non-finite values',()=>{
 for(const patch of [{latitude:55},{time:'25:00'},{include_dwarfs:'true'},{offset_minutes:60},{fold:2}])assert.throws(()=>session({...base(),birth:{...base().birth,...patch}}));
 assert.throws(()=>session({...base(),birth:{date:'1990-01-01',time:'12:00',include_dwarfs:true,latitude:NaN,longitude:12,timezone:'UTC'}}));
});
test('mode-specific extras cannot silently restore as another calculation type',()=>{
 for(const patch of [{mode:'unknown'},{mode:'solar',technique:{mode:'progressed',year:2026}},{mode:'synastry',synastry:{birth:base().birth,order:'c'}},{mode:'rectify',transit:{date:'2020-01-01',time:'12:00',timezone:'UTC'}}])assert.throws(()=>session({...base(),...patch}));
});
test('returned sessions are detached from input and exclude computed planetary caches',()=>{
 const input=base(),saved=session(input);input.rectification.events[0].label='Changed';assert.equal(saved.rectification.events[0].label,'Flytning (eksempel)');
 assert.throws(()=>session({...base(),planets:[{id:'sun',longitude:0}]}));
});
