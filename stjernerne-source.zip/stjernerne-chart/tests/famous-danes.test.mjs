import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {searchPeople,archiveBirth,unavailableReason} from '../static/famous-model.js';
const rows=JSON.parse(fs.readFileSync(new URL('../static/famous-danes.json',import.meta.url)));
test('reviewed main sheet only; alternatives stay separate',()=>{
  assert.equal(rows.length,189);assert.equal(new Set(rows.map(r=>r.id)).size,189);
  assert.equal(searchPeople(rows,'birthe kirk').length,2);
  assert.equal(searchPeople(rows,'troinski').length,0);
  assert.equal(searchPeople(rows,'kardas').length,0);
  assert(searchPeople(rows,'moller').some(r=>r.name.includes('Møller')));
});
test('uses source offset, seconds and coordinates rather than modern city defaults',()=>{
  const r=rows.find(r=>r.name==='Kirk, Birthe 2');const b=archiveBirth(r,true);
  assert.equal(b.date,'1942-10-22');assert.equal(b.time,'06:12:17');assert.equal(b.offset_minutes,120);
  assert.equal(b.latitude,55+32/60);assert.equal(b.longitude,11+21/60);
  assert.equal(b.timezone,'UTC');assert.match(b.offset_source,/Kirk, Birthe 2/);assert.match(b.offset_source,/rating C/);
  assert.equal(b.place_id,undefined);assert.equal(b.include_dwarfs,true);
});
test('historic dates from 1500 work while earlier dates and missing coordinates cannot populate the form',()=>{
  const old=rows.find(r=>r.date<'1900-01-01');assert.equal(archiveBirth(old,true).date,old.date);assert.throws(()=>archiveBirth({...old,date:'1499-12-31'},true),/1500/);
  const r=rows.find(r=>!unavailableReason(r));assert.throws(()=>archiveBirth({...r,latitude:0,longitude:0},true),/koordinater/);
});
test('X ratings do not turn an unknown birth time into a real time',()=>{
  const r=rows.find(r=>!unavailableReason(r));assert.equal(archiveBirth({...r,rating:'X'},false).time,'');
  assert.equal(archiveBirth({...r,rating:'Ikke angivet'},false).time,r.time);
});
test('all usable records have valid location and offset, and round-trip archive seconds',()=>{
  for(const r of rows.filter(r=>!unavailableReason(r))){const b=archiveBirth(r,false);
    assert(/^\d{4}-\d{2}-\d{2}$/.test(b.date));assert(Number.isInteger(b.offset_minutes)&&Math.abs(b.offset_minutes)<=840);
    assert(Math.abs(b.longitude)<=180);assert(b.offset_source.length<=250);
    assert(r.rating.startsWith('X')?b.time==='':/^\d{2}:\d{2}:\d{2}$/.test(b.time));
  }
});
