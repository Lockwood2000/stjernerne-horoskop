import test from 'node:test';
import assert from 'node:assert/strict';
import {dms,spreadLabels} from '../static/wheel.js';

test('rounded zodiac degree carries into the next sign',()=>{
  assert.equal(dms(29.999999).sign,'Tyren');
  assert.equal(dms(29.999999).full,'0°00′00″');
  assert.equal(dms(359.999999).sign,'Vædderen');
  assert.equal(dms(-1).sign,'Fiskene');
});
test('a tight cluster across Aries stays readable without changing true longitude',()=>{
  const input=[357,358,359,0,1,2,3,4,5,6,7].map((longitude,i)=>({id:String(i),longitude}));
  const output=spreadLabels(input);
  const positions=output.map(p=>(p.display+720)%360).sort((a,b)=>a-b);
  for(let i=0;i<positions.length;i++)assert.ok((positions[(i+1)%positions.length]-positions[i]+360)%360>=10.999);
  for(const p of output)assert.equal(p.longitude,input.find(i=>i.id===p.id).longitude);
});
test('separated planets remain at their actual angles',()=>{
  const input=[15,60,110,150,210,260,310].map(longitude=>({longitude}));
  for(const p of spreadLabels(input))assert.equal((p.display+360)%360,p.longitude);
});
