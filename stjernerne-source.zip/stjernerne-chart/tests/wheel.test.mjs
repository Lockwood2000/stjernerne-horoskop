import test from 'node:test';
import assert from 'node:assert/strict';
import {dms,spreadLabels,cuspDirection,houseMidpoints} from '../static/wheel.js';
import {readFileSync} from 'node:fs';

test('rounded zodiac degree carries into the next sign',()=>{
  assert.equal(dms(29.999999).sign,"Taurus");
  assert.equal(dms(29.999999).full,'0°00′00″');
  assert.equal(dms(359.999999).sign,"Aries");
  assert.equal(dms(-1).sign,"Pisces");
});
test('a tight cluster across Aries stays readable without changing true longitude',()=>{
  const input=[357,358,359,0,1,2,3,4,5,6,7].map((longitude,i)=>({id:String(i),longitude}));
  const output=spreadLabels(input);
  const positions=output.map(p=>(p.display+720)%360).sort((a,b)=>a-b);
  for(let i=0;i<positions.length;i++)assert.ok((positions[(i+1)%positions.length]-positions[i]+360)%360>=10.999);
  for(const p of output)assert.equal(p.longitude,input.find(i=>i.id===p.id).longitude);
});
test('separated planets remain at their actual angles',()=>{
  const input=[15,60,110,150,210,260,310].map(longitude=>({longitude}));
  for(const p of spreadLabels(input))assert.equal((p.display+360)%360,p.longitude);
});

test('actual clockwise Swiss polar cusps and ordinary cusps give the intended sectors',()=>{
  const polar=JSON.parse(readFileSync(new URL('./polar-houses-reference.json',import.meta.url),'utf8'));
  const houses=polar.cusps.map(longitude=>({longitude})),before=JSON.stringify(houses);
  assert.equal(cuspDirection(houses),-1);
  houseMidpoints(houses).forEach((lon,i)=>assert.ok(Math.abs(lon-polar.clockwise_midpoints[i])<1e-9));
  const normal=Array.from({length:12},(_,i)=>({longitude:(350+i*30)%360}));
  assert.equal(cuspDirection(normal),1);
  assert.deepEqual(houseMidpoints(normal),Array.from({length:12},(_,i)=>(5+i*30)%360));
  assert.equal(JSON.stringify(houses),before);
});

test('unknown-time wheels have no house midpoints and malformed cusp cycles are rejected',()=>{
  assert.deepEqual(houseMidpoints([]),[]);
  for(const values of [[],Array(12).fill(0),Array(11).fill(0),Array(13).fill(0),[NaN,...Array(11).fill(0)],[Infinity,...Array(11).fill(0)],[0,60,30,90,120,150,180,210,240,270,300,330]]){
    const houses=values.map(longitude=>({longitude}));
    assert.throws(()=>cuspDirection(houses),/Invalid house cusps/);
    if(houses.length)assert.throws(()=>houseMidpoints(houses),/Invalid house cusps/);
  }
});
