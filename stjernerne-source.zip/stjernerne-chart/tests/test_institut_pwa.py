from fastapi.testclient import TestClient
from app.main import app


def test_institut_installation_is_scoped_and_assets_are_served():
    with TestClient(app) as c:
        institute = c.get('/institut')
        assert institute.status_code == 200
        assert 'rel="manifest"' in institute.text
        assert 'pwa/install.js' in institute.text
        assert 'rel="manifest"' not in c.get('/university').text
        manifest = c.get('/static/school/pwa/manifest.webmanifest').json()
        assert manifest['start_url'] == manifest['scope'] == manifest['id'] == '/institut'
        assert manifest['display'] == 'standalone'
        for icon in manifest['icons']:
            r = c.get(icon['src'])
            assert r.status_code == 200 and r.content.startswith(b'\x89PNG')
        worker = c.get('/institut-sw.js')
        assert worker.status_code == 200
        assert worker.headers['service-worker-allowed'] == '/institut'
        assert 'javascript' in worker.headers['content-type']
        assert c.get('/static/school/pwa/offline.html').status_code == 200
