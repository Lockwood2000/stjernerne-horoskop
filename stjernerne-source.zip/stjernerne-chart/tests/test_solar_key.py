import ctypes as C
from datetime import datetime, timedelta, timezone, date
import math
import pytest
from fastapi.testclient import TestClient
from app.engine import calculate, lib, separation
from app.solar_key import degree_key, kundig_solar_key
from app.techniques import secondary_progressions, YEAR_DAYS
from app.rectification import event_comparison, progressed_contacts
from app.main import app, chart, Birth
UTC = datetime(1990, 6, 15, 12, 30, tzinfo=timezone.utc)
BIRTH = {'date': '1990-06-15', 'time': '14:30:00', 'place_id': '2618425', 'include_dwarfs': True}

@pytest.mark.parametrize('longitude', [0, 23.9, 67.843, 89.999, 90, 179.1, 269.9, 359.999])
def test_key_against_native_coordinate_rotation(longitude):
    eps = 23.4392911
    lib.swe_cotrans.argtypes = [C.POINTER(C.c_double), C.POINTER(C.c_double), C.c_double]
    lib.swe_cotrans.restype = None
    ras = []
    for lon in (math.floor(longitude), math.floor(longitude) + 1):
        out = (C.c_double * 3)()
        lib.swe_cotrans((C.c_double * 3)(lon, 0, 1), out, -eps)
        ras.append(out[0])
    assert degree_key(longitude, eps) == pytest.approx((ras[1] - ras[0]) % 360, abs=1e-10)
    assert 0.91 < degree_key(longitude, eps) < 1.1

def test_whole_degree_convention_and_simple_geometries():
    assert degree_key(67.001, 23.44) == degree_key(67.999, 23.44)
    assert degree_key(67, 23.44) != degree_key(68, 23.44)
    assert degree_key(359.9, 0) == pytest.approx(1)
    assert degree_key(90, 0) == pytest.approx(1)
    assert abs(degree_key(67.843, 23.45) * 3600 - (3600 + 3 * 60 + 39)) < 1

@pytest.mark.parametrize('years', [0, 1, 35, 100])
def test_progressions_use_fixed_natal_key_without_moving_planets(years):
    n = calculate(UTC, 55.67594, 12.56553, True)
    target = UTC + timedelta(days=YEAR_DAYS * years)
    k, stamp = secondary_progressions(UTC, target, n, 55.67594, 12.56553, True, 'kundig')
    old, _ = secondary_progressions(UTC, target, n, 55.67594, 12.56553, True)
    assert stamp == UTC + timedelta(days=years)
    key = kundig_solar_key(n)
    assert k['technique']['solar_key'] == key
    assert k['armc'] == pytest.approx((n['armc'] + key['degrees_per_year'] * years) % 360)
    assert [p['longitude'] for p in k['planets']] == [p['longitude'] for p in old['planets']]
    assert [p['speed'] for p in k['planets']] == [p['speed'] for p in old['planets']]
    if years == 0:
        assert separation(k['ascendant']['longitude'], n['ascendant']['longitude']) < 1e-08
    else:
        assert k['houses'] != old['houses']
    armc = math.radians(k['armc'])
    eps = math.radians(k['technique']['obliquity'])
    expected = math.degrees(math.atan2(math.sin(armc), math.cos(armc) * math.cos(eps))) % 360
    assert separation(expected, k['midheaven']['longitude']) < 1e-09

def test_candidate_comparison_agrees_with_standalone_progression():
    base = chart(Birth(**BIRTH))
    dates = [date(2020, 6, 1), date(2026, 10, 1)]
    result = event_comparison(base, [0, -142 / 60, 49.15], dates, True, 'kundig')
    assert result['method']['id'] == 'kundig'
    for event, d in zip(result['events'], dates):
        for row, n in zip(event['candidates'], result['charts']):
            expected, _ = secondary_progressions(datetime.fromisoformat(n['birth']['utc']), datetime(d.year, d.month, d.day, 12, tzinfo=timezone.utc), n, 55.67594, 12.56553, True, 'kundig')
            assert row['progressed'] == expected
            assert row['shift_minutes'] == n['rectification']['shift_minutes']
            assert all((a['orb'] <= 1 for a in row['aspects']))
            assert 'transit' not in row['progressed']

def test_contact_groups_and_orb_boundary():

    def c(ac, mc, planet):
        return {'ascendant': {'longitude': ac}, 'midheaven': {'longitude': mc}, 'planets': [{'id': 'sun', 'name': 'Sun', 'longitude': planet}]}
    found = progressed_contacts(c(10, 45, 200), c(199, 230, 11))
    assert any((a['a'] == 'ascendant' and a['b'] == 'sun' and (a['orb'] == 1) for a in found))
    assert any((a['a'] == 'sun' and a['b'] == 'ascendant' and (a['orb'] == 1) for a in found))
    assert all((a['source'] == 'progressed' for a in found))
    assert not any((a['a'] == 'ascendant' and a['b'] == 'sun' for a in progressed_contacts(c(10, 45, 200), c(199, 230, 11.0001))))

def test_api_method_and_invalid_inputs():
    client = TestClient(app, client=('192.0.2.154', 4567))
    payload = {'birth': BIRTH, 'mode': 'progressed', 'house_method': 'kundig', 'target': {'date': '2026-10-15', 'time': '12:00:00', 'timezone': 'UTC'}}
    r = client.post('/api/technique', json=payload)
    assert r.status_code == 200, r.text
    assert r.json()['technique']['house_method_id'] == 'kundig'
    assert r.headers['cache-control'] == 'no-store'
    for invalid in ['unknown', {}, None, True]:
        assert client.post('/api/technique', json={**payload, 'house_method': invalid}).status_code == 422
    assert client.post('/api/technique', json={'birth': BIRTH, 'mode': 'solar', 'year': 2026, 'house_method': 'kundig'}).status_code == 422
    payload = {'birth': BIRTH, 'shifts': [0, -142 / 60], 'events': ['2020-06-01'], 'method': 'kundig'}
    r = client.post('/api/rectify/compare', json=payload)
    assert r.status_code == 200, r.text
    assert r.json()['method']['orb'] == 1
    assert client.post('/api/rectify/compare', json={**payload, 'method': 'bad'}).status_code == 422
    old = client.post('/api/rectify/compare', json={k: v for k, v in payload.items() if k != 'method'}).json()
    assert old['method']['id'] == 'transits' and old['method']['orb'] == 2
