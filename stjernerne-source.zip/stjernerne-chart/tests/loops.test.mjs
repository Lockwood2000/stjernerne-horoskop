import test from 'node:test';
import assert from 'node:assert/strict';
import {emptyWorkshops,emptyLoops,validateWorkshops,validateLoops} from '../static/school/workshop-model.js';
import {decodeFile} from '../static/school/model.js';
test('three-workshop studies get independent, backwards-compatible loop defaults',()=>{
 const legacy=emptyWorkshops();delete legacy.loops;
 const a=validateWorkshops(legacy),b=validateWorkshops(legacy);
 assert.deepEqual(a.loops,emptyLoops());a.loops.notes['mercury|2025-03-24|5']='My note';assert.deepEqual(b.loops.notes,{});
});
test('loop selection, planet, progression, orb, navigation and notes roundtrip',()=>{
 const w=emptyWorkshops();w.active='loops';w.loops={planet:'venus',mode:'progressed',date:'2025-03-23',cycleDate:'1990-01-18',orb:.8,selected:6,notes:{'venus|1990-01-18|6':'Mit eget rodpunkt\nEt nyt afsnit'}};
 const record={format:'stjernerne-school-chart',version:1,name:'Sløjfe',request:{school:'institut',birth:{date:'1990-06-15'}},notes:{},workshops:w};
 const restored=decodeFile(JSON.stringify(record));assert.deepEqual(restored.workshops,w);
 restored.workshops.loops.notes['venus|1990-01-18|6']='Changed';assert.notEqual(restored.workshops.loops.notes['venus|1990-01-18|6'],w.loops.notes['venus|1990-01-18|6']);
});
test('loop state rejects malformed, unsafe or excessive imported values',()=>{
 for(const patch of [{planet:'moon'},{mode:'all'},{orb:0},{orb:1.6},{orb:NaN},{selected:10},{selected:1.5},{date:'2025-02-30'},{cycleDate:'2100-01-01'},{notes:[]},{notes:{'mercury|2025-03-24|5':'x'.repeat(4001)}}]){
  assert.throws(()=>validateLoops({...emptyLoops(),...patch}));
 }
 assert.throws(()=>validateLoops({...emptyLoops(),notes:JSON.parse('{"__proto__":"bad"}')}));
 const notes=Object.fromEntries(Array.from({length:121},(_,i)=>[`mercury|${1800+i}-03-24|5`,'a']));assert.throws(()=>validateLoops({...emptyLoops(),notes}));
});
