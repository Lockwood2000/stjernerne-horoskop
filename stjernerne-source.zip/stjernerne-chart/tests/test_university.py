"""Published lunar-phase/profection fixtures and birth-time boundary behaviour."""
from datetime import date, datetime, timedelta, timezone
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.school_models import UniversityYearRequest, WorkshopRequest
from app.university_workshops import (profection, anniversary, lunations,
                                      lunation_workshop, year_workshop)

UTC=timezone.utc
BIRTH={'date':'1990-06-15','time':'14:30','place_id':'2643743'}
UTC_PLACE={'latitude':0,'longitude':0,'timezone':'UTC'}

@pytest.mark.parametrize('stamp,kind',[
 ('2024-03-10T09:00:00+00:00','new'),
 ('2024-03-25T07:00:00+00:00','full'),
 ('2024-04-08T18:21:00+00:00','new'),
 ('2024-04-23T23:49:00+00:00','full'),
])
def test_syzygies_against_us_naval_observatory(stamp,kind):
    # https://aa.usno.navy.mil/calculated/moon/phases?date=2024-03-01&format=p&nump=8
    # Published Universal Time rounded to the minute, independent of our engine.
    expected=datetime.fromisoformat(stamp)
    found=lunations(expected-timedelta(days=1),expected+timedelta(days=1))
    assert len(found)==1
    assert found[0]['kind']==kind
    assert abs((datetime.fromisoformat(found[0]['utc'])-expected).total_seconds())<60
    assert found[0]['residual_degrees']<0.00005


def test_no_false_syzygies_at_residual_wraps_or_quarters():
    found=lunations(datetime(2024,3,1,tzinfo=UTC),datetime(2024,5,1,tzinfo=UTC))
    assert [p['utc'][:10] for p in found]==['2024-03-10','2024-03-25','2024-04-08','2024-04-23']
    assert [p['kind'] for p in found]==['new','full','new','full']

@pytest.mark.parametrize('time,expected', [('18:20','2024-03-25'),('18:23','2024-04-08')])
def test_last_full_or_new_moon_not_always_last_new_moon(time,expected):
    result=lunation_workshop(WorkshopRequest(birth={**UTC_PLACE,'date':'2024-04-08','time':time}))
    assert result['personal']['utc'].startswith(expected)
    assert datetime.fromisoformat(result['personal']['utc'])<=datetime.fromisoformat(result['natal']['birth']['utc'])

@pytest.mark.parametrize('confidence', ['unknown','approximate'])
def test_birth_interval_crossing_a_lunation_returns_both_candidates(confidence):
    birth={**UTC_PLACE,'date':'2024-04-08','confidence':confidence}
    if confidence=='approximate':birth.update(time='18:21',uncertainty_minutes=5)
    result=lunation_workshop(WorkshopRequest(birth=birth))
    assert [p['kind'] for p in result['ambiguity']]==['full','new']
    assert result['natal']['birth']['confidence']==confidence
    if confidence=='unknown':
        assert all(p['house'] is None and p['sun_house'] is None for p in result['lunations'])
        assert all(c['b'] not in ['ascendant','midheaven'] for p in result['lunations'] for c in p['contacts'])


def test_lunation_ruler_uses_traditional_moon_end_of_full_moon_axis():
    r=lunation_workshop(WorkshopRequest(birth={**UTC_PLACE,'date':'2024-04-24','time':'12:00'},settings={'ruler_mode':'modern','bodies':['sun','moon'],'include_angles':False}))
    p=r['personal']
    assert p['kind']=='full' and p['moon']['sign_index']==7 and p['sun']['sign_index']==1
    assert p['lord']=='mars' and p['lord_natal']['id']=='mars'
    assert all(c['b'] not in ['ascendant','midheaven'] for c in p['contacts'])

@pytest.mark.parametrize('age,house',[(0,1),(11,12),(12,1),(24,1),(36,1),(37,2),(38,3),(71,12)])
def test_ages_from_kelly_surtees_published_profection_worksheet(age,house):
    # https://kellysastrology.com/pdf/ProfectionsWorksheet.pdf
    r=profection(date(1988,5,5),date(1988+age,5,5),90)
    assert r['house']==house and r['age']==age


def test_kelly_published_adele_example_age_37_cancer_rising():
    # https://www.kellysastrology.com/tag/profections/
    # “Predicting with Profections: Adele as a Chart Example” (May 2025).
    r=profection(date(1988,5,5),date(2025,6,1),100)
    assert (r['house'],r['sign_index'],r['lord'])==(2,4,'sun')
    assert r['start']=='2025-05-05' and r['end']=='2026-05-05'


def test_birthday_boundary_and_february_29_convention():
    before=profection(date(1990,6,15),date(2026,6,14),190)
    after=profection(date(1990,6,15),date(2026,6,15),190)
    assert (before['age'],before['house'])==(35,12)
    assert (after['age'],after['house'])==(36,1)
    assert anniversary(date(2000,2,29),2025)==date(2025,2,28)
    assert profection(date(2000,2,29),date(2025,2,27),0)['age']==24
    assert profection(date(2000,2,29),date(2025,2,28),0)['age']==25
    assert anniversary(date(2000,2,29),2024)==date(2024,2,29)


def test_profection_independent_of_natal_house_and_modern_dispositor_settings():
    req={'birth':BIRTH,'date':'2026-10-16'}
    a=year_workshop(UniversityYearRequest(**req,settings={'house_system':'P','ruler_mode':'modern'}))
    b=year_workshop(UniversityYearRequest(**req,settings={'house_system':'W','ruler_mode':'traditional'}))
    assert [a['profection'][k] for k in ['age','house','sign_index','lord']]==[b['profection'][k] for k in ['age','house','sign_index','lord']]
    assert a['natal']['settings']['house_system']=='P' and b['natal']['settings']['house_system']=='W'
    assert len(a['cycle'])==12 and [c['age'] for c in a['cycle']]==list(range(36,48))
    assert a['progressed']['technique']['target_utc']=='2026-10-16T12:00:00+00:00'


def test_unknown_time_still_has_transits_but_no_false_annual_lord():
    r=year_workshop(UniversityYearRequest(birth={**BIRTH,'confidence':'unknown','time':None},date='2026-10-16'))
    assert r['profection'] is None and r['progressed'] is None and r['cycle']==[]
    assert r['transit_contacts']
    assert all(c['b'] not in ['ascendant','midheaven'] for c in r['transit_contacts'])


def test_approximate_time_samples_multiple_possible_profection_signs():
    r=year_workshop(UniversityYearRequest(birth={**BIRTH,'confidence':'approximate','uncertainty_minutes':180},date='2026-10-16'))
    assert len(r['alternatives'])>1
    assert len({p['sign_index'] for p in r['alternatives']})==len(r['alternatives'])
    assert all(p['house']==r['profection']['house'] for p in r['alternatives'])


def test_study_on_birth_date_does_not_progress_before_birth():
    r=year_workshop(UniversityYearRequest(birth={**UTC_PLACE,'date':'2024-04-08','time':'23:30'},date='2024-04-08'))
    assert r['utc']=='2024-04-08T23:30:00+00:00'
    assert r['profection']['age']==0
    assert r['progressed']['technique']['ephemeris_utc']==r['natal']['birth']['utc']

@pytest.mark.parametrize('date', ['1989-01-01','2100-01-01','2026-02-30'])
def test_year_invalid_dates_are_rejected(date):
    with pytest.raises(ValidationError):UniversityYearRequest(birth=BIRTH,date=date)


def test_year_cycle_stops_at_supported_dates():
    r=year_workshop(UniversityYearRequest(birth={**UTC_PLACE,'date':'2099-01-01','time':'12:00'},date='2099-12-31'))
    assert len(r['cycle'])==1
    assert r['profection']['end']=='2100-01-01'

@pytest.mark.parametrize('path,extra,key',[
 ('year',{'date':'2026-10-16'},'profection'),('lunation',{},'personal')])
def test_public_api_contract(path,extra,key):
    client=TestClient(app)
    response=client.post('/api/school/university/'+path,json={'birth':BIRTH,**extra})
    assert response.status_code==200 and key in response.json()
    assert response.json()['sources']
    bad=client.post('/api/school/university/'+path,json={'birth':BIRTH,**extra,'invented':'value'})
    assert bad.status_code==422
