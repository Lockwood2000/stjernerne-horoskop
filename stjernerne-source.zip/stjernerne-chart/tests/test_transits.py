from datetime import datetime, timezone
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import positions_at, calculate, transit_aspects
BIRTH = {'date': '1990-06-15', 'time': '14:30:00', 'place_id': '2618425'}

def post(t, **changes):
    with TestClient(app, client=('192.0.2.22', 3456)) as client:
        return client.post('/api/transits', json={'birth': BIRTH, 'transit': {'date': '2026-10-13', 'time': '12:00', 'timezone': 'Europe/Copenhagen', **t}}, **changes)

@pytest.mark.parametrize('year', [1900, 2000, 2026, 2099])
def test_positions_match_validated_natal_engine(year):
    utc = datetime(year, 6, 15, 12, tzinfo=timezone.utc)
    positions = positions_at(utc)
    natal = calculate(utc, 55.67594, 12.56553)
    assert positions['jd_tt'] == natal['calculation']['jd_tt']
    for t, n in zip(positions['planets'], natal['planets']):
        assert t['longitude'] == n['longitude'] and t['speed'] == n['speed']
        assert 'house' not in t and t['flags'] & 2

def test_transit_contract_and_date_changes():
    r = post({})
    assert r.status_code == 200
    data = r.json()
    assert len(data['planets']) == 11
    assert data['timing']['utc'] == '2026-10-13T10:00:00+00:00'
    assert 'houses' not in data
    assert data['aspects'] == sorted(data['aspects'], key=lambda a: a['orb'])
    assert all((a['orb'] <= a['max_orb'] for a in data['aspects']))
    next_day = post({'date': '2026-10-14'}).json()
    assert data['planets'][1]['longitude'] != next_day['planets'][1]['longitude']
    assert r.headers['cache-control'] == 'no-store'

def test_birth_instant_contains_all_self_conjunctions():
    data = post({'date': BIRTH['date'], 'time': BIRTH['time']}).json()
    own = [a for a in data['aspects'] if a['transit'] == a['natal']]
    assert len(own) == 11
    assert all((a['type'] == 'conjunction' and a['orb'] == 0 and (a['phase'] == 'exact') for a in own))

def test_transit_dst_gap_fold():
    r = post({'date': '2026-03-29', 'time': '02:30'})
    assert r.status_code == 422 and r.json()['error']['code'] == 'nonexistent_time'
    t = {'date': '2026-10-25', 'time': '02:30'}
    assert len(post(t).json()['error']['choices']) == 2
    a, b = (post({**t, 'fold': f}).json() for f in (0, 1))
    assert a['timing']['utc'] != b['timing']['utc']
    assert a['planets'][1]['longitude'] != b['planets'][1]['longitude']

@pytest.mark.parametrize('change', [{'date': '1499-12-31'}, {'date': '2100-01-01'}, {'date': '2026-02-30'}, {'time': '24:00'}, {'timezone': 'invalid'}, {'fold': True}, {'extra': 1}])
def test_transit_input_validation(change):
    assert post(change).status_code == 422

def test_same_instant_in_two_zones():
    assert post({'time': '12:00'}).json()['planets'] == post({'time': '10:00', 'timezone': 'UTC'}).json()['planets']

def planet(id, lon, speed):
    return {'id': id, 'longitude': lon, 'speed': speed}

@pytest.mark.parametrize('lon,speed,phase', [(359, 1, 'applying'), (359, -1, 'separating'), (1, -1, 'applying'), (1, 1, 'separating'), (0, 1, 'exact'), (1, 0, 'stationary')])
def test_phase_at_zodiac_wrap(lon, speed, phase):
    a = transit_aspects([planet('sun', lon, speed)], [planet('moon', 0, 99)])[0]
    assert a['phase'] == phase

def test_opposition_phase_and_orb_limits():
    for lon, speed, phase in [(179, 1, 'applying'), (181, 1, 'separating'), (181, -1, 'applying')]:
        a = transit_aspects([planet('sun', lon, speed)], [planet('moon', 0, 0)])[0]
        assert a['type'] == 'opposition' and a['phase'] == phase
    assert transit_aspects([planet('sun', 3.01, 1)], [planet('moon', 0, 0)]) == []
    assert transit_aspects([planet('true_node', 2.01, 1)], [planet('moon', 0, 0)]) == []

def test_transit_endpoint_origin_guard():
    assert post({}, headers={'Origin': 'https://evil.example'}).status_code == 403

@pytest.mark.parametrize('epoch', ['2026-10-13T10:00:00', '2050-06-15T12:00:00', '2099-12-31T12:00:00'])
def test_transits_against_cli_and_independent_engine(epoch):
    import subprocess
    import astronomy
    from app.engine import ROOT, separation
    stamp = datetime.fromisoformat(epoch).replace(tzinfo=timezone.utc)
    positions = positions_at(stamp)
    planets = positions['planets']
    same_tt = astronomy.Time.FromTerrestrialTime(positions['jd_tt'] - 2451545)
    output = subprocess.check_output([str(ROOT / 'build/swetest'), f'-b{stamp.day}.{stamp.month}.{stamp.year}', f'-utc{stamp:%H:%M:%S}', '-p0123456789t', '-eswe', '-tidacc-25.936', f'-edir{ROOT}/data/ephe', '-fPls', '-g,', '-head'], text=True)
    rows = [line.split(',') for line in output.splitlines() if ',' in line]
    for p, row in zip(planets, rows):
        assert separation(p['longitude'], float(row[1])) < 1e-06
        assert abs(p['speed'] - float(row[2])) < 1e-06
    assert len(rows) == 11
    for p in planets[:-1]:
        independent = astronomy.Ecliptic(astronomy.GeoVector(getattr(astronomy.Body, p['id'].capitalize()), same_tt, True))
        assert separation(p['longitude'], independent.elon) * 3600 < 60

def test_phase_just_before_exact_does_not_step_over_contact():
    a = transit_aspects([planet('moon', 359.99999, 15)], [planet('sun', 0, 0)])[0]
    assert a['phase'] == 'applying'
