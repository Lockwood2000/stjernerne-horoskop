"""Independent published Venus fixtures and study-workspace edge cases."""
from datetime import datetime,timedelta,timezone
import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError
from app.main import app
from app.engine import separation
from app.school_models import VenusRequest,WorkshopRequest,LifelineRequest
from app.school_workshops import conjunctions,venus_workshop,node_workshop,lifeline

UTC=timezone.utc
BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}

@pytest.mark.parametrize('stamp,longitude,retrograde',[
 ('2020-06-03T17:43:00+00:00',60+13+35/60,True),
 ('2022-10-22T21:17:00+00:00',180+29+26/60,False),
 ('2023-08-13T11:15:00+00:00',120+20+28/60,True),
])
def test_venus_against_published_guttman_table(stamp,longitude,retrograde):
    # https://sophiavenus.com/wp-content/uploads/2020/05/FindYourVenusStarPoint.pdf
    # p.5 table; p.6 explicitly states CDT (UTC−5). Printed to a whole minute.
    target=datetime.fromisoformat(stamp)
    result=conjunctions(target-timedelta(days=4),target+timedelta(days=4))
    assert len(result)==1
    p=result[0]
    assert abs((datetime.fromisoformat(p['utc'])-target).total_seconds())<120
    assert separation(p['longitude'],longitude)<1/60
    assert p['retrograde']==retrograde
    assert p['residual_degrees']<1e-5

@pytest.fixture(scope='module')
def venus():return venus_workshop(VenusRequest(birth=BIRTH))

def test_venus_three_before_two_after_and_published_personal_point(venus):
    born=datetime.fromisoformat(venus['birth']['utc'])
    assert len(venus['points'])==5
    assert [datetime.fromisoformat(p['utc'])<=born for p in venus['points']]==[True]*3+[False]*2
    p=venus['points'][2]
    assert p['utc'].startswith('1990-01-18T22:41:')
    assert separation(p['longitude'],270+28+35/60)<1/60
    assert p['personal'] and p['star']=='morning'
    assert all(p['retrograde']!=q['retrograde'] for p,q in zip(venus['points'],venus['points'][1:]))

def test_venus_echoes_are_actual_conjunctions_and_alternate_types(venus):
    anchor=venus['points'][2]
    assert len(venus['rhythm'])==21
    for p in venus['rhythm'][1:]:
        assert p['residual_degrees']<1e-5
        assert p['retrograde']==(anchor['retrograde'] if p['cycle_years']%8==0 else not anchor['retrograde'])
        assert separation(p['longitude'],anchor['longitude'])<30
        assert p['utc']<'2100'
    assert venus['rhythm'][1]['utc'].startswith('1994-01-17')
    assert venus['rhythm'][2]['utc'].startswith('1998-01-16')

def test_birth_straddling_conjunction_and_unknown_time_are_explicit():
    b={'date':'2023-08-13','latitude':0,'longitude':0,'timezone':'UTC'}
    before=venus_workshop(VenusRequest(birth={**b,'time':'11:14'}))
    after=venus_workshop(VenusRequest(birth={**b,'time':'11:17'}))
    assert before['points'][2]['utc'].startswith('2022-10-22')
    assert after['points'][2]['utc'].startswith('2023-08-13')
    unknown=venus_workshop(VenusRequest(birth={**b,'confidence':'unknown'}))
    assert len(unknown['ambiguity'])==2
    assert all(p['house'] is None for p in unknown['points'])
    approximate=venus_workshop(VenusRequest(birth={**b,'time':'11:15','confidence':'approximate','uncertainty_minutes':30}))
    assert len(approximate['ambiguity'])==2

@pytest.mark.parametrize('year',[1500,2099])
def test_venus_edge_years_and_clipped_rhythms(year):
    v=venus_workshop(VenusRequest(birth={**BIRTH,'date':f'{year}-06-15'},horizon_years=120))
    assert len(v['points'])==5
    assert all(p['utc']<'2100' for p in v['rhythm'])

def test_node_rulers_obey_teacher_settings_and_are_available_when_hidden():
    s={'bodies':['sun','moon'],'ruler_mode':'traditional'}
    a=node_workshop(WorkshopRequest(birth=BIRTH,settings=s))
    b=node_workshop(WorkshopRequest(birth=BIRTH,settings={**s,'ruler_mode':'modern'}))
    assert a['axis'][0]['ruler']['id']=='sun'
    assert a['axis'][1]['ruler']['id']=='saturn'
    assert b['axis'][1]['ruler']['id']=='uranus'
    assert separation(a['axis'][0]['point']['longitude'],a['axis'][1]['point']['longitude'])==pytest.approx(180)
    m=node_workshop(WorkshopRequest(birth=BIRTH,settings={**s,'node':'mean'}))
    assert separation(a['axis'][0]['point']['longitude'],m['axis'][0]['point']['longitude'])>.01
    assert all({x['a'],x['b']}!={'north_node','south_node'} for n in a['axis'] for x in n['aspects'])

def test_lifeline_sorts_dates_and_preserves_original_with_candidate():
    r=LifelineRequest(birth=BIRTH,events=['2026-10-16','2010-05-01'],shift_minutes=7,orb=.5,focus='all')
    data=lifeline(r)
    assert [e['date'] for e in data['events']]==['2010-05-01','2026-10-16']
    for event in data['events']:
        a,b=event['candidates']
        assert a['birth']['utc']==data['birth']['utc']
        assert a['birth']['local'].startswith('1990-06-15T14:30:00')
        assert b['birth']['local'].startswith('1990-06-15T14:37:00')
        assert separation(a['ascendant']['longitude'],b['ascendant']['longitude'])>.5
        for candidate in event['candidates']:
            assert candidate['progressed_phase'] is not None
            assert all(c['orb']<=.5+1e-10 for c in candidate['contacts'])
            assert {c['method'] for c in candidate['contacts']}=={'transits','progressed'}
    assert r.birth.time.isoformat()=='14:30:00'

def test_unknown_birth_time_retains_transits_but_no_angles_or_progressions():
    birth={**BIRTH,'time':None,'confidence':'unknown'}
    data=lifeline(LifelineRequest(birth=birth,events=['2026-10-16']))
    candidate=data['events'][0]['candidates'][0]
    assert not data['progressions_available'] and candidate['ascendant'] is None
    assert candidate['progressed_phase'] is None
    assert all(c['method']=='transits' and c['b'] not in ('ascendant','midheaven') for c in candidate['contacts'])
    with pytest.raises(ValidationError):LifelineRequest(birth=birth,shift_minutes=1)

@pytest.mark.parametrize('extra',[
 {'events':['1980-01-01']},{'events':['2100-01-01']},{'events':['2020-01-01']*2},
 {'shift_minutes':181},{'shift_minutes':.001},{'orb':0},{'orb':float('nan')},
])
def test_lifeline_invalid_requests(extra):
    with pytest.raises(ValidationError):LifelineRequest(birth=BIRTH,**extra)

def test_workshop_api_contracts_and_validation():
    client=TestClient(app)
    for endpoint in ('venus','nodes','lifeline'):
        response=client.post('/api/school/'+endpoint,json={'birth':BIRTH})
        assert response.status_code==200,response.text
    assert client.post('/api/school/lifeline',json={'birth':BIRTH,'events':['2020-02-30']}).status_code==422
    assert client.post('/api/school/venus',json={'birth':BIRTH,'horizon_years':999}).status_code==422


def test_personal_focus_excludes_slow_progressed_self_contacts_and_minor_bodies():
    data=lifeline(LifelineRequest(birth=BIRTH,events=['2014-05-20']))
    contacts=data['events'][0]['candidates'][0]['contacts']
    assert contacts
    assert any(c['a']=='mars' and c['b']=='ascendant' and c['method']=='transits' for c in contacts)
    for c in contacts:
        assert c['b'] in ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto','ascendant','midheaven']
        if c['method']=='progressed':assert c['a'] in ['sun','moon','mercury','venus','mars','ascendant','midheaven']


def test_same_birth_day_does_not_progress_backwards():
    data=lifeline(LifelineRequest(birth=BIRTH,events=['1990-06-15']))
    row=data['events'][0]['candidates'][0]
    assert row['progression_before_birth'] and row['progressed_phase'] is None
    assert all(c['method']=='transits' for c in row['contacts'])
