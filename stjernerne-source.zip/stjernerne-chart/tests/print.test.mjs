import test from 'node:test';
import assert from 'node:assert/strict';
import {noteParagraphs,printFilename,printableLink} from '../static/school/print-model.js';

test('PDF filenames retain Danish names but remove path separators and control characters',()=>{
 const value=printFilename('  Louise: æøå / stjerner\\noter\n  ', 'institut');
 assert.equal(value,'Louise æøå stjerner noter · Astrologisk Institut');
 assert.equal(printFilename('', 'university'),'Studieark · Astrology University');
 assert.ok(printFilename('X'.repeat(1000),'institut').length<150);
});
test('notes retain every word, Unicode and single line break across paragraph boundaries',()=>{
 const first='Æble, ønske og åbenhed.\nAnden linje ☽',last='Slutningen '+ 'x'.repeat(12000);
 assert.deepEqual(noteParagraphs(first+'\r\n\r\n'+last),[first,last]);
 assert.deepEqual(noteParagraphs(' \n\n '),[]);
});
test('printed sources accept ordinary web links and reject executable and data URLs',()=>{
 assert.equal(printableLink('https://example.com/course','https://study.example/'),'https://example.com/course');
 assert.equal(printableLink('/course','https://study.example/'),'https://study.example/course');
 for(const value of ['javascript:alert(1)','data:text/html,test','file:///private/test'])assert.equal(printableLink(value,'https://study.example/'),null);
});
