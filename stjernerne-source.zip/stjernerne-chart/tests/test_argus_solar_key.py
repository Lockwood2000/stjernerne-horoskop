"""The Borup-described ARGUS convention: RA(Sun + 30') - RA(Sun - 30')."""
import ctypes as C
from datetime import date, datetime, timedelta, timezone
import pytest
from fastapi.testclient import TestClient
from app.engine import calculate, lib, separation, CalculationError
from app.main import app, Birth, chart
from app.rectification import event_comparison
from app.solar_key import centered_key, degree_key, kundig_solar_key
from app.techniques import secondary_progressions, YEAR_DAYS
BIRTH = {'date': '1990-06-15', 'time': '14:30:00', 'place_id': '2618425', 'include_dwarfs': True}
UTC = datetime(1990, 6, 15, 12, 30, tzinfo=timezone.utc)
LAT, LON = (55.67594, 12.56553)

@pytest.mark.parametrize('longitude', [0, 0.1, 29.9999, 67.8436111111, 90, 179.9, 269.9, 359.9])
def test_centered_key_against_independent_native_rotation(longitude):
    eps = 23.45
    lib.swe_cotrans.argtypes = [C.POINTER(C.c_double), C.POINTER(C.c_double), C.c_double]
    lib.swe_cotrans.restype = None
    ras = []
    for lon in (longitude - 0.5, longitude + 0.5):
        result = (C.c_double * 3)()
        lib.swe_cotrans((C.c_double * 3)(lon, 0, 1), result, -eps)
        ras.append(result[0])
    assert centered_key(longitude, eps) == pytest.approx((ras[1] - ras[0]) % 360, abs=1e-10)
    assert 0.91 < centered_key(longitude, eps) < 1.1

def test_continuity_boundaries_and_distinct_conventions():
    eps = 23.45
    for longitude in (0.5, 67.5, 89.5, 359.5):
        assert centered_key(longitude, eps) == pytest.approx(degree_key(longitude, eps), abs=1e-12)
    assert centered_key(360.1, eps) == pytest.approx(centered_key(0.1, eps), abs=1e-12)
    assert abs(centered_key(29.999999, eps) - centered_key(30.000001, eps)) < 1e-08
    assert abs(centered_key(67.8436111111, eps) - degree_key(67.8436111111, eps)) * 3600 > 2

@pytest.mark.parametrize('years', [0, 1, 35, 100])
def test_comparison_matches_each_independently_selected_chart(years):
    natal = calculate(UTC, LAT, LON, True)
    target = UTC + timedelta(days=YEAR_DAYS * years)
    whole, whole_stamp = secondary_progressions(UTC, target, natal, LAT, LON, True, 'kundig')
    argus, argus_stamp = secondary_progressions(UTC, target, natal, LAT, LON, True, 'kundig_argus')
    assert whole_stamp == argus_stamp
    assert [p['longitude'] for p in whole['planets']] == [p['longitude'] for p in argus['planets']]
    assert [p['speed'] for p in whole['planets']] == [p['speed'] for p in argus['planets']]
    assert [p['retrograde'] for p in whole['planets']] == [p['retrograde'] for p in argus['planets']]
    assert whole['technique']['solar_key_comparison'] == argus['technique']['solar_key_comparison']
    comparison = argus['technique']['solar_key_comparison']
    for method, result in [('kundig', whole), ('kundig_argus', argus)]:
        variant = next((v for v in comparison['variants'] if v['house_method_id'] == method))
        for axis in ('ascendant', 'midheaven'):
            assert variant[axis] == result[axis]
        assert variant['armc'] == result['armc']
        assert variant['solar_key'] == kundig_solar_key(natal, method)
    if years == 0:
        assert separation(whole['midheaven']['longitude'], argus['midheaven']['longitude']) < 1e-10
        assert comparison['difference_from_whole']['arc_arcseconds'] == 0
    else:
        assert argus['houses'] != whole['houses']
        assert comparison['difference_from_whole']['arc_arcseconds'] == pytest.approx((argus['technique']['degrees_per_year'] - whole['technique']['degrees_per_year']) * years * 3600, abs=1e-08)
    key = argus['technique']['solar_key']
    assert separation(key['degree_start'], key['sun_longitude'] - 0.5) < 1e-10
    assert separation(key['degree_end'], key['sun_longitude'] + 0.5) < 1e-10

def test_event_comparison_uses_selected_argus_key_for_every_candidate():
    base = chart(Birth(**BIRTH))
    dates = [date(2020, 6, 1), date(2026, 10, 1)]
    result = event_comparison(base, [0, -142 / 60, 49.15], dates, True, 'kundig_argus')
    assert result['method']['id'] == 'kundig_argus'
    for event, d in zip(result['events'], dates):
        for row, natal in zip(event['candidates'], result['charts']):
            expected, _ = secondary_progressions(datetime.fromisoformat(natal['birth']['utc']), datetime(d.year, d.month, d.day, 12, tzinfo=timezone.utc), natal, LAT, LON, True, 'kundig_argus')
            assert row['progressed'] == expected
            assert all((a['orb'] <= 1 for a in row['aspects']))

def test_api_comparison_metadata_and_backward_compatible_defaults():
    client = TestClient(app, client=('192.0.2.183', 1234))
    payload = {'birth': BIRTH, 'mode': 'progressed', 'house_method': 'kundig_argus', 'target': {'date': '2026-10-15', 'time': '12:00:00', 'timezone': 'UTC'}}
    response = client.post('/api/technique', json=payload)
    assert response.status_code == 200, response.text
    technique = response.json()['technique']
    assert technique['house_method_id'] == 'kundig_argus'
    assert len(technique['solar_key_comparison']['variants']) == 2
    assert response.headers['cache-control'] == 'no-store'
    old = client.post('/api/technique', json={**payload, 'house_method': 'kundig'}).json()
    assert old['technique']['solar_key']['variant'] == 'whole containing zodiac degree'
    default = client.post('/api/technique', json={k: v for k, v in payload.items() if k != 'house_method'}).json()
    assert default['technique']['house_method_id'] == 'naibod'
    assert 'solar_key_comparison' not in default['technique']
    compare = client.post('/api/rectify/compare', json={'birth': BIRTH, 'shifts': [0, -142 / 60], 'events': ['2020-06-01'], 'method': 'kundig_argus'})
    assert compare.status_code == 200, compare.text
    assert compare.json()['events'][0]['candidates'][1]['progressed']['technique']['house_method_id'] == 'kundig_argus'
    assert client.post('/api/technique', json={'birth': BIRTH, 'mode': 'solar', 'year': 2026, 'house_method': 'kundig_argus'}).status_code == 422
    with pytest.raises(CalculationError):
        kundig_solar_key(chart(Birth(**BIRTH)), 'unknown')
