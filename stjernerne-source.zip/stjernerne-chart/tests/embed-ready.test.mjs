import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import vm from 'node:vm';
const source=readFileSync(new URL('../static/app.js',import.meta.url),'utf8');
const start=source.indexOf('const params=new URLSearchParams(location.search);');
const end=source.indexOf('async function openLinkedPerson',start);
assert.ok(start>=0&&end>start);
const setup=source.slice(start,end);
function run(parentOrigin='https://www.stjernerne.io',standalone=false){
 const messages=[],listeners=new Map();let resized;
 const parent={postMessage:(data,origin)=>messages.push({data,origin})};
 const win={parent,addEventListener:(type,fn)=>listeners.set(type,fn)};
 if(standalone)win.parent=win;
 vm.runInNewContext(setup,{window:win,location:{origin:'https://stjernerne-horoskop.onrender.com',search:'?embed=1&parent='+encodeURIComponent(parentOrigin)},document:{body:{classList:{add(){}}},querySelector:()=>({getBoundingClientRect:()=>({height:550})})},URLSearchParams,ResizeObserver:class{constructor(fn){resized=fn;}observe(){}}});
 return {messages,listeners,parent,resize:()=>resized?.()};
}
test('embedded app explicitly announces readiness to the permitted parent',()=>{
 const app=run();assert.equal(app.messages.length,1);assert.equal(app.messages[0].data.type,'stjernerne:ready');assert.equal(app.messages[0].data.height,558);assert.equal(app.messages[0].origin,'https://www.stjernerne.io');
});
test('hello requests require both the allowed origin and the actual parent window',()=>{
 const app=run(),message=app.listeners.get('message');
 message({origin:'https://example.com',source:app.parent,data:{type:'stjernerne:hello'}});
 message({origin:'https://www.stjernerne.io',source:{},data:{type:'stjernerne:hello'}});
 message({origin:'https://www.stjernerne.io',source:app.parent,data:{type:'unrelated'}});
 assert.equal(app.messages.length,1);
 message({origin:'https://www.stjernerne.io',source:app.parent,data:{type:'stjernerne:hello'}});
 assert.equal(app.messages.length,2);assert.equal(app.messages[1].data.type,'stjernerne:ready');
});
test('resize messages remain compatible with existing Squarespace integrations',()=>{
 const app=run();app.resize();assert.equal(app.messages.at(-1).data.type,'stjernerne:resize');assert.equal(app.messages.at(-1).data.height,558);
});
test('standalone app and unapproved parent origins receive no readiness messages',()=>{
 assert.equal(run('https://example.com').messages.length,0);assert.equal(run('https://www.stjernerne.io',true).messages.length,0);
});
