from fastapi.responses import FileResponse,JSONResponse
from .engine import CalculationError
from .timing import TimeProblem
from .school_models import ChartRequest,EventsRequest,RectificationRequest,Settings
from .school_engine import build,ROOT
from .school_events import diary
from .school_rectification import compare,cuts

def register(app):
    @app.get('/schools')
    @app.get('/institut')
    @app.get('/university')
    def school_page():
        return FileResponse(ROOT/'static/school/index.html')

    @app.get('/api/school/profiles')
    def profiles():
        return {'version':1,'profiles':[
            {'id':'institut','name':'Astrologisk Institut','locale':'da','settings':Settings().model_dump()},
            {'id':'university','name':'Astrology University','locale':'en','settings':Settings(house_system='W',orbs={'0':8,'60':4,'90':6,'120':6,'150':3,'180':8}).model_dump()}],
            'status':'Suggested editable teaching profiles, not official or approved defaults.'}

    @app.post('/api/school/chart')
    def school_chart(request:ChartRequest):
        try:return build(request)
        except TimeProblem as error:
            return JSONResponse({'error':{'code':error.code,'message':error.message,'choices':error.choices}},status_code=422)
        except CalculationError as error:
            return JSONResponse({'error':{'code':'calculation_unavailable','message':str(error)}},status_code=422)

    @app.post('/api/school/events')
    def school_events(request:EventsRequest):
        try:return diary(request)
        except (TimeProblem,CalculationError) as error:
            return JSONResponse({'error':{'code':'event_search_unavailable','message':str(error)}},status_code=422)

    @app.post('/api/school/rectify')
    def school_rectify(request:RectificationRequest):
        try:return compare(request)
        except (TimeProblem,CalculationError) as error:
            return JSONResponse({'error':{'code':'rectification_unavailable','message':str(error)}},status_code=422)

    @app.post('/api/school/cuts')
    def school_cuts(request:RectificationRequest):
        try:return cuts(request)
        except (TimeProblem,CalculationError) as error:
            return JSONResponse({'error':{'code':'cuts_unavailable','message':str(error)}},status_code=422)
