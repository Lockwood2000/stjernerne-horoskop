"""Ecliptic axis/planet conjunctions, independently implemented. See BONATTI.md."""
import math
from .engine import calculate
from .kundig import signed, bisect

SOURCE='https://www.electric-ephemeris.dk/download/argus421.pdf'

def bonatti_geometry(utc,latitude,longitude,house_system="P"):
    # Use exactly the same native angles and moving planets as the preview.
    chart=calculate(utc,latitude,longitude,house_system=house_system)
    return {'angles':{'AC':chart['ascendant']['longitude'],
                      'DC':(chart['ascendant']['longitude']+180)%360,
                      'MC':chart['midheaven']['longitude'],
                      'IC':(chart['midheaven']['longitude']+180)%360},
            'planets':{p['id']:p for p in chart['planets'] if p['id']!='true_node'}}

def bonatti_roots(geometry,start,end):
    """Bounded search, 30 s brackets, then roots to 0.00002 s.

    Ecliptic AC/MC advance monotonically relative to these planets within the
    app's |latitude| < 66° range. Reject the ±180° residual discontinuity.
    Oppositions to AC/MC are represented once as conjunctions to DC/IC.
    """
    count=max(1,math.ceil((end-start)/30))
    grid=[start+(end-start)*i/count for i in range(count+1)]
    samples={t:geometry(t) for t in grid}
    roots=[];seen=set()
    for body in samples[start]['planets']:
        for axis in ('AC','DC','MC','IC'):
            def residual(t):
                g=samples[t] if t in samples else geometry(t)
                return signed(g['angles'][axis]-g['planets'][body]['longitude'])
            for left,right in zip(grid,grid[1:]):
                a,b=residual(left),residual(right)
                if abs(a)<1e-8:t=left
                elif abs(b)<1e-8:t=right
                elif a*b<0 and abs(b-a)<180:t=bisect(residual,left,right)
                else:continue
                if abs(residual(t))>1e-5:continue
                key=(body,axis,round(t,3))
                if key in seen:continue
                seen.add(key)
                roots.append({'seconds':t,'axis':axis,'planet':body})
    return sorted(roots,key=lambda r:(r['seconds'],r['axis'],r['planet']))
