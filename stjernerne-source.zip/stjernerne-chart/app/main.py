from collections import defaultdict, deque
from datetime import date, datetime, timezone
import json
import math
import os
from pathlib import Path
import re
import sqlite3
import time
import unicodedata
from urllib.parse import urlparse
from typing import Literal, Annotated

from fastapi import FastAPI, Request, Query
from fastapi.exceptions import RequestValidationError
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from starlette.middleware.trustedhost import TrustedHostMiddleware
from .engine import calculate, CalculationError, VERSION, positions_at, transit_aspects, synastry_aspects, house_for
from .timing import resolve_time, TimeProblem, load_zone
from .techniques import solar_return, secondary_progressions
from .rectification import shifted_chart, event_comparison
from .kundig import kundig_cuts

ROOT = Path(__file__).resolve().parents[1]
PUBLIC_ORIGIN = os.environ.get('PUBLIC_ORIGIN',os.environ.get('RENDER_EXTERNAL_URL','http://127.0.0.1:8765')).rstrip('/')
PARENTS = os.environ.get('FRAME_ANCESTORS','https://stjernerne.dk https://www.stjernerne.dk https://stjernerne.io https://www.stjernerne.io').split()
if any(not re.fullmatch(r'https://[a-zA-Z0-9.-]+(?::[0-9]+)?',p) for p in PARENTS):
    raise RuntimeError('FRAME_ANCESTORS must contain explicit HTTPS origins')
app=FastAPI(title='Stjernerne · fødselshoroskop',docs_url=None,redoc_url=None,openapi_url=None)
app.add_middleware(TrustedHostMiddleware,allowed_hosts=os.environ.get('ALLOWED_HOSTS','127.0.0.1,localhost,testserver,'+(urlparse(PUBLIC_ORIGIN).hostname or 'localhost')).split(','))

class Guard:
    """Bound body before parsing, same-origin browser API, bounded in-memory rate limit.
    Run one worker locally. Shared edge rate limiting is needed for multi-instance deployment.
    """
    def __init__(self,app):
        self.app=app
        self.requests=defaultdict(deque)

    async def __call__(self,scope,receive,send):
        if scope['type']!='http':
            return await self.app(scope,receive,send)
        headers=dict(scope['headers'])
        async def respond(code,message):
            await JSONResponse({'error':{'code':'request_rejected','message':message}},status_code=code)(scope,receive,secure_send)
        async def secure_send(event):
            if event['type']=='http.response.start':
                extra=[(b'cache-control',b'no-store'),(b'x-content-type-options',b'nosniff'),
                       (b'referrer-policy',b'no-referrer'),(b'x-robots-tag',b'noindex, nofollow, noarchive'),(b'permissions-policy',b'geolocation=(), camera=(), microphone=()'),
                       (b'content-security-policy',("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'self' "+' '.join(PARENTS)).encode())]
                event['headers']=event.get('headers',[])+extra
            await send(event)
        if scope['path'].startswith('/api/'):
            now=time.monotonic()
            # Full TTL sweep is intentionally simple and bounded for a single-process MVP.
            for key in list(self.requests):
                q=self.requests[key]
                while q and q[0]<now-60: q.popleft()
                if not q: del self.requests[key]
            peer=(scope.get('client') or ('unknown',0))[0]
            if peer not in self.requests and len(self.requests)>=5000:
                return await respond(429,'Serveren er optaget. Prøv igen om et minut.')
            q=self.requests[peer]
            if len(q)>=120:
                return await respond(429,'For mange forespørgsler. Prøv igen om et minut.')
            q.append(now)
        if scope['method']=='POST':
            if headers.get(b'content-type',b'').split(b';')[0]!=b'application/json':
                return await respond(415,'Send JSON-data.')
            origin=headers.get(b'origin',b'').decode()
            if origin and origin!=PUBLIC_ORIGIN:
                return await respond(403,'Denne oprindelse er ikke tilladt.')
            if headers.get(b'sec-fetch-site')==b'cross-site':
                return await respond(403,'Forespørgslen skal komme fra horoskopappen.')
            size=0
            messages=[]
            while True:
                message=await receive()
                if message['type']=='http.disconnect': return
                size+=len(message.get('body',b''))
                if size>8192: return await respond(413,'Forespørgslen er for stor.')
                messages.append(message)
                if not message.get('more_body',False): break
            async def replay():
                if messages: return messages.pop(0)
                return await receive()
            return await self.app(scope,replay,secure_send)
        return await self.app(scope,receive,secure_send)

app.add_middleware(Guard)

class Birth(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    date:str=Field(pattern=r'^\d{4}-\d{2}-\d{2}$')
    time:str=Field(pattern=r'^\d{2}:\d{2}(:\d{2})?$')
    include_dwarfs:bool=Field(default=False,strict=True)
    place_id:str|None=Field(default=None,max_length=20)
    place_name:str|None=Field(default=None,max_length=120)
    latitude:float|None=Field(default=None,ge=-90,le=90)
    longitude:float|None=Field(default=None,ge=-180,le=180)
    timezone:str|None=Field(default=None,max_length=80)
    fold:int|None=Field(default=None,ge=0,le=1,strict=True)
    offset_minutes:int|None=Field(default=None,ge=-840,le=840,strict=True)
    offset_source:str|None=Field(default=None,max_length=250)

    @field_validator('date')
    @classmethod
    def valid_date(cls,value):
        parsed=date.fromisoformat(value)
        if parsed<date(1500,1,1) or parsed>datetime.now(timezone.utc).date():
            raise ValueError('Datoen skal ligge mellem 1500 og i dag.')
        return value

    @field_validator('time')
    @classmethod
    def valid_time(cls,value):
        datetime.strptime(value,'%H:%M:%S' if len(value)==8 else '%H:%M')
        return value

    @model_validator(mode='after')
    def valid_place(self):
        if self.place_id:
            if any(v is not None for v in (self.latitude,self.longitude,self.timezone,self.place_name)):
                raise ValueError('Brug enten et valgt sted eller manuelle koordinater.')
        elif any(v is None for v in (self.latitude,self.longitude,self.timezone)):
            raise ValueError('Vælg et fødested eller angiv koordinater og tidszone.')
        return self

def connection():
    con=sqlite3.connect(f'file:{ROOT}/data/places.sqlite?mode=ro',uri=True)
    con.row_factory=sqlite3.Row
    return con

def normalize(text):
    text=text.lower().translate(str.maketrans({'ø':'o','æ':'ae','ð':'d','þ':'th'}))
    return ''.join(c for c in unicodedata.normalize('NFKD',text) if not unicodedata.combining(c))

def failure(code,message,status=422,**kwargs):
    return JSONResponse({'error':{'code':code,'message':message,**kwargs}},status_code=status)

@app.exception_handler(RequestValidationError)
async def validation_error(request,exc):
    # Do not echo user input or Pydantic's full exception (contains birth data).
    if request.url.path.startswith('/api/rectify'):
        return failure('invalid_input','Kontrollér fødselsdata, forskydning (−180 til +180 hele minutter), højst fem kandidater og fem begivenhedsdatoer fra 1500 til i dag.')
    if request.url.path=='/api/technique':
        return failure('invalid_input','Kontrollér år, dato, klokkeslæt og sted for det valgte horoskop. Tilladt interval: 1500–2099.')
    if request.url.path=='/api/transits':
        return failure('invalid_input','Kontrollér fødselsdata og transittidspunkt. Transitdato skal være fra 1500 til 2099, og klokkeslæt og tidszone skal være gyldige.')
    return failure('invalid_input','Kontrollér dato, klokkeslæt og fødested. Datoen skal være fra 1500 til i dag; alle felter skal være gyldige.')

@app.get('/api/health')
def health():
    return {'status':'ok','engine':VERSION,'mode':'local-mvp'}

@app.get('/api/places')
def places(q:str=Query(min_length=2,max_length=80)):
    terms=re.findall(r'\w+',normalize(q))
    if not terms: return []
    match=' AND '.join('"'+t+'"*' for t in terms)
    with connection() as con:
        rows=con.execute('SELECT p.* FROM places p JOIN search s ON s.id=p.id WHERE search MATCH ? ORDER BY p.population DESC LIMIT 10',(match,)).fetchall()
    return [dict(r) for r in rows]

@app.post('/api/chart')
def chart(birth:Birth):
    if birth.place_id:
        with connection() as con:
            row=con.execute('SELECT * FROM places WHERE id=?',(birth.place_id,)).fetchone()
        if row is None: return failure('unknown_place','Vælg et fødested fra søgeresultaterne.')
        place=dict(row)
        place['source']='GeoNames'
    else:
        place={'name':birth.place_name or 'Manuelt fødested','country':'','region':'',
               'latitude':birth.latitude,'longitude':birth.longitude,'timezone':birth.timezone,'source':'manual'}
    try:
        utc,timing=resolve_time(birth.date,birth.time,place['timezone'],birth.fold,birth.offset_minutes,birth.offset_source)
        if utc>datetime.now(timezone.utc):
            return failure('future_birth','Fødselstidspunktet ligger i fremtiden.')
        result=calculate(utc,place['latitude'],place['longitude'],birth.include_dwarfs)
    except TimeProblem as e:
        return failure(e.code,e.message,choices=e.choices)
    except CalculationError as e:
        return failure('calculation_unavailable',str(e))
    if place['source']=='manual':
        timing['warnings'].append('Koordinater og IANA-tidszone er manuelt valgt; deres indbyrdes sammenhæng skal kontrolleres.')
    return {**result,'birth':timing,'place':place}

class TransitTime(BaseModel):
    model_config=ConfigDict(extra='forbid')
    date:str=Field(pattern=r'^\d{4}-\d{2}-\d{2}$')
    time:str=Field(pattern=r'^\d{2}:\d{2}(:\d{2})?$')
    timezone:str=Field(default='Europe/Copenhagen',max_length=80)
    fold:int|None=Field(default=None,ge=0,le=1,strict=True)

    @field_validator('date')
    @classmethod
    def valid_date(cls,value):
        if not date(1500,1,1)<=date.fromisoformat(value)<=date(2099,12,31):
            raise ValueError('Transitdato uden for interval.')
        return value

    @field_validator('time')
    @classmethod
    def valid_time(cls,value):
        datetime.strptime(value,'%H:%M:%S' if len(value)==8 else '%H:%M')
        return value

class TransitRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    birth:Birth
    transit:TransitTime

@app.post('/api/transits')
def transits(request:TransitRequest):
    natal=chart(request.birth)
    if isinstance(natal,JSONResponse): return natal
    t=request.transit
    try:
        utc,timing=resolve_time(t.date,t.time,t.timezone,t.fold)
        positions=positions_at(utc,request.birth.include_dwarfs)
    except TimeProblem as e:
        return failure(e.code,e.message,choices=e.choices)
    except CalculationError as e:
        return failure('calculation_unavailable',str(e))
    return {**positions,'timing':timing,
            'aspects':transit_aspects(positions['planets'],natal['planets']),
            'calculation':{'engine':VERSION,'zodiac':'tropical','node':'true',
                           'orb':3,'node_orb':2,'targets':'natal planets and true node',
                           'phase':'instantaneous; natal positions held fixed'}}

class ReturnLocation(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    place_id:str=Field(min_length=1,max_length=20)

class TechniqueRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    birth:Birth
    mode:Literal['solar','progressed']
    year:int|None=Field(default=None,ge=1500,le=2099,strict=True)
    target:TransitTime|None=None
    location:ReturnLocation|None=None
    house_method:Literal['naibod','kundig']='naibod'

    @model_validator(mode='after')
    def required_inputs(self):
        if self.mode=='solar' and (self.year is None or self.target is not None):
            raise ValueError('Solretur kræver år.')
        if self.mode=='solar' and self.house_method!='naibod':
            raise ValueError('Solnøglen anvendes kun til progressioner.')
        if self.mode=='progressed' and (self.target is None or self.year is not None or self.location is not None):
            raise ValueError('Progression kræver mål-dato.')
        return self

@app.post('/api/technique')
def technique(request:TechniqueRequest):
    natal=chart(request.birth)
    if isinstance(natal,JSONResponse):return natal
    birth_utc=datetime.fromisoformat(natal['birth']['utc'])
    place=natal['place']
    try:
        if request.mode=='solar':
            if request.location:
                with connection() as con:
                    row=con.execute('SELECT * FROM places WHERE id=?',(request.location.place_id,)).fetchone()
                if row is None:return failure('unknown_place','Vælg solretursted fra søgeresultaterne.')
                place={**dict(row),'source':'GeoNames'}
            result,stamp=solar_return(birth_utc,natal,request.year,place['latitude'],place['longitude'],request.birth.include_dwarfs)
            title='Solretur · '+str(request.year)
        else:
            t=request.target
            target,timing=resolve_time(t.date,t.time,t.timezone,t.fold)
            result,stamp=secondary_progressions(birth_utc,target,natal,place['latitude'],place['longitude'],request.birth.include_dwarfs,request.house_method)
            result['technique']['target']=timing
            title='Sekundære progressioner'
        local=stamp.astimezone(load_zone(place['timezone']))
        _,timing=resolve_time(local.date().isoformat(),local.time().isoformat(),place['timezone'],local.fold)
        timing['warnings']=list(dict.fromkeys(timing['warnings']+natal['birth']['warnings']))
        result['technique']['natal_utc']=birth_utc.isoformat()
        return {**result,'birth':timing,'place':place,'display_title':title,'chart_type':request.mode}
    except TimeProblem as e:
        return failure(e.code,e.message,choices=e.choices)
    except CalculationError as e:
        return failure('calculation_unavailable',str(e))

class SynastryRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    a:Birth
    b:Birth

@app.post('/api/synastry')
def synastry(request:SynastryRequest):
    charts=[]
    for person,birth in [('A',request.a),('B',request.b)]:
        result=chart(birth)
        if isinstance(result,JSONResponse):
            error=json.loads(result.body)['error']
            return failure(error['code'],f"Person {person}: {error['message']}",
                           person=person,choices=error.get('choices',[]))
        charts.append(result)
    a,b=charts
    for current,other in [(a,b),(b,a)]:
        cusps=[h['longitude'] for h in other['houses']]
        for planet in current['planets']:
            planet['house_in_other']=house_for(planet['longitude'],cusps)
    return {'a':a,'b':b,'aspects':synastry_aspects(a,b),
            'method':{'zodiac':'tropical','houses':'Placidus','angles':['AC','MC'],
                      'restricted_orb':3,'house_overlay':'ecliptic longitude'}}

class RectifyRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    birth:Birth
    shift_minutes:float=Field(default=0,ge=-180,le=180,strict=True,allow_inf_nan=False)

    @field_validator('shift_minutes')
    @classmethod
    def whole_seconds(cls,value):
        if abs(value*60-round(value*60))>1e-7: raise ValueError('Vælg et helt antal sekunder.')
        return round(value*60)/60

class RectifyComparison(BaseModel):
    model_config=ConfigDict(extra='forbid')
    birth:Birth
    shifts:list[Annotated[float,Field(ge=-180,le=180,strict=True,allow_inf_nan=False)]]=Field(min_length=1,max_length=5)
    events:list[date]=Field(min_length=1,max_length=5)
    method:Literal['transits','kundig']='transits'

    @field_validator('shifts')
    @classmethod
    def whole_seconds(cls,values):
        return [RectifyRequest.whole_seconds(v) for v in values]

    @field_validator('events')
    @classmethod
    def valid_events(cls,values):
        if any(not date(1500,1,1)<=v<=datetime.now(timezone.utc).date() for v in values):
            raise ValueError('Begivenhedsdato skal ligge mellem 1500 og i dag.')
        return values

@app.post('/api/rectify')
def rectify(request:RectifyRequest):
    base=chart(request.birth)
    if isinstance(base,JSONResponse):return base
    try:return shifted_chart(base,request.shift_minutes,request.birth.include_dwarfs)
    except (TimeProblem,CalculationError) as e:return failure('invalid_candidate',str(e))

@app.post('/api/rectify/compare')
def rectify_compare(request:RectifyComparison):
    base=chart(request.birth)
    if isinstance(base,JSONResponse):return base
    try:return event_comparison(base,request.shifts,request.events,request.birth.include_dwarfs,request.method)
    except (TimeProblem,CalculationError) as e:return failure('invalid_comparison',str(e))

class KundigRequest(BaseModel):
    model_config=ConfigDict(extra='forbid')
    birth:Birth
    radius_minutes:int=Field(default=60,ge=15,le=180,strict=True)
    cut_mode:Literal['kundig','bonatti','both']='kundig'

@app.post('/api/rectify/kundig')
def kundig(request:KundigRequest):
    base=chart(request.birth)
    if isinstance(base,JSONResponse):return base
    try:return kundig_cuts(base,request.radius_minutes,request.cut_mode)
    except (TimeProblem,CalculationError) as e:return failure('invalid_kundig',str(e))

@app.get('/source')
def source():
    return FileResponse(ROOT/'source/stjernerne-source.zip',filename='stjernerne-source.zip',media_type='application/zip')

@app.get('/')
def index():
    return FileResponse(ROOT/'static/index.html')

@app.get('/embed-test')
def embed_test():
    return FileResponse(ROOT/'static/embed-test.html')

app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')
