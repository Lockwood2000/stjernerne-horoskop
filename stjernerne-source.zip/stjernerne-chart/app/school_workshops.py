"""Source-linked study tools; interpretation and personal notes stay with the pupil.

Venus: last apparent geocentric Sun–Venus longitude conjunction at/before birth;
two preceding and two following conjunctions complete the surrounding five.
This implements the public Guttman convention, not unpublished school material.
"""
from datetime import datetime, timedelta, timezone, time
from functools import lru_cache
from .engine import positions_at, position, house_for, VERSION
from .school_engine import natal, aspects, points, progressed, positions, empty_houses, finish
from .school_rectification import candidate
from .school_events import signed, root
from .techniques import YEAR_DAYS

UTC = timezone.utc
MAJOR = ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto']
VENUS_BODIES = [(0,'sun','Sun','sun'),(3,'venus','Venus','venus')]
VENUS_SOURCES = [
    'https://www.astrologiskinstitut.dk/product-page/venus-star-point',
    'https://sophiavenus.com/how-do-we-find-and-analysis-our-vsp/',
    'https://theastrologypodcast.com/2022/10/12/the-venus-star-point-cycle-with-arielle-guttman/',
]

def conjunctions(start, end):
    """Bracket both inferior and superior conjunctions; never confuse opposition.

    Sun–Venus elongation is continuous in [-48°, 48°]. A two-day step cannot
    skip successive conjunctions, which are separated by several months.
    Root tolerance is numerical, not a claim of historical time accuracy.
    """
    duration = (end-start).total_seconds()
    @lru_cache(maxsize=2048)
    def state(seconds):
        return positions_at(start+timedelta(seconds=seconds),bodies=VENUS_BODIES)['planets']
    def elongation(seconds):
        sun,venus=state(seconds)
        return signed(venus['longitude']-sun['longitude'])
    grid=list(range(0,int(duration),2*86400))+[duration]
    found=[]
    for a,b in zip(grid,grid[1:]):
        fa,fb=elongation(a),elongation(b)
        if abs(fa)<1e-10:t=a
        elif fa*fb<0:t=root(elongation,a,b)
        else:continue
        utc=start+timedelta(seconds=t)
        if found and abs((utc-datetime.fromisoformat(found[-1]['utc'])).total_seconds())<1:continue
        sun,venus=state(t)
        retro=venus['speed']<0
        found.append({'utc':utc.isoformat(),**position(sun['longitude']),
                      'retrograde':retro,'type':'inferior' if retro else 'superior',
                      'star':'morning' if retro else 'evening','residual_degrees':abs(elongation(t))})
    return found

def workshop_settings(settings, required):
    return settings.model_copy(update={'bodies':list(dict.fromkeys([*settings.bodies,*required]))})

def venus_workshop(request):
    settings=workshop_settings(request.settings,['venus'])
    base=natal(request.birth,settings)
    born=datetime.fromisoformat(base['birth']['utc'])
    surrounding=conjunctions(born-timedelta(days=1000),born+timedelta(days=700))
    before=[p for p in surrounding if datetime.fromisoformat(p['utc'])<=born]
    after=[p for p in surrounding if datetime.fromisoformat(p['utc'])>born]
    star=[dict(p) for p in before[-3:]+after[:2]]
    personal=star[2]
    cusps=[h['longitude'] for h in base['houses']]
    for i,p in enumerate(star):
        p.update(index=i,personal=i==2,house=house_for(p['longitude'],cusps) if cusps else None)
        p['aspects']=aspects([{'id':'venus_star',**p}],points(base,settings.include_angles),settings)
    anchor=datetime.fromisoformat(personal['utc'])
    rhythm=[{**personal,'cycle_years':0,'age_years':(anchor-born).total_seconds()/86400/YEAR_DAYS}]
    # Locate actual conjunctions near each four-year echo; do not add calendar years
    # and present those estimated dates as astronomical events.
    for years in range(4,request.horizon_years+1,4):
        centre=anchor+timedelta(days=years*YEAR_DAYS)
        if centre.year>2099:break
        matches=conjunctions(centre-timedelta(days=45),min(centre+timedelta(days=45),datetime(2100,1,1,tzinfo=UTC)))
        if not matches:continue
        p=dict(min(matches,key=lambda p:abs((datetime.fromisoformat(p['utc'])-centre).total_seconds())))
        p.update(cycle_years=years,age_years=(datetime.fromisoformat(p['utc'])-born).total_seconds()/86400/YEAR_DAYS,
                 drift_degrees=signed(p['longitude']-personal['longitude']))
        rhythm.append(p)
    natal_sun=next(p for p in base['planets'] if p['id']=='sun')
    natal_venus=next(p for p in base['planets'] if p['id']=='venus')
    elongation=signed(natal_venus['longitude']-natal_sun['longitude'])
    ambiguity=[]
    if base.get('uncertainty'):
        a=datetime.fromisoformat(base['uncertainty']['from_utc']);b=datetime.fromisoformat(base['uncertainty']['to_utc'])
        boundaries=[p for p in surrounding if a<=datetime.fromisoformat(p['utc'])<b]
        if boundaries:
            previous=max((p for p in surrounding if datetime.fromisoformat(p['utc'])<a),key=lambda p:p['utc'])
            ambiguity=[previous,*boundaries]
    return {'points':star,'personal_index':2,'rhythm':rhythm,'ambiguity':ambiguity,
            'natal_venus':natal_venus,'natal_star':'conjunction' if abs(elongation)<.01 else 'evening' if elongation>0 else 'morning',
            'natal_elongation':elongation,'birth':base['birth'],'uncertainty':base.get('uncertainty'),
            'settings':settings.model_dump(),'engine':VERSION,'sources':VENUS_SOURCES,
            'method':{'personal':'Last Sun–Venus conjunction at or before the nominal birth instant.',
                      'five_points':'Three conjunctions before birth (including the personal point), followed by two after birth.',
                      'coordinates':'Apparent geocentric tropical ecliptic longitude; Swiss Ephemeris.',
                      'star_labels':'Inferior/retrograde starts a morning-star cycle; superior/direct starts an evening-star cycle. Natal elongation is reported separately; visibility is not calculated.',
                      'rhythm':'Actual conjunctions within 45 days of multiples of four tropical years from the prenatal point; clipped before 2100. Eight-year echoes retain cycle type.',
                      'precision':'Two-day bracket, numerical roots refined to 0.25 s. Displayed times are UTC.'}}

def node_workshop(request):
    # Rulers must remain calculable even if hidden in the main teaching wheel.
    settings=workshop_settings(request.settings,[*MAJOR,'north_node','south_node'])
    base=natal(request.birth,settings)
    by_id={p['id']:p for p in base['planets']}
    axis=[]
    for key in ('south_node','north_node'):
        p=by_id[key];ruler=by_id[p['dispositor']]
        targets=[q for q in points(base,settings.include_angles) if q['id'] not in ('north_node','south_node')]
        axis.append({'point':p,'ruler':ruler,'aspects':aspects([p],targets,settings),
                     'ruler_aspects':[a for a in base['aspects'] if ruler['id'] in (a['a'],a['b'])]})
    return {'chart':base,'axis':axis,'settings':settings.model_dump(),
            'source':'https://www.astrologiskinstitut.dk/product-page/m%C3%A5neknuderne-2026',
            'method':'Both nodes and all Sun–Pluto rulers are included in this view. Node type, house system, aspect orbs and traditional/modern rulers follow the selected teacher settings.'}

def lifeline(request):
    settings=request.settings
    base=natal(request.birth,settings)
    charts=[base]
    if request.shift_minutes:charts.append(candidate(request.birth,base,request.shift_minutes,settings))
    effective=settings.model_copy(update={'orbs':{k:min(v,request.orb) for k,v in settings.orbs.items()}})
    rows=[]
    for day in sorted(request.events):
        utc=datetime.combine(day,time(12),UTC)
        transit=None
        if request.method in ('both','transits'):
            transit=positions(utc,settings);transit.update(empty_houses())
            transit.update(kind='transits',birth={'utc':utc.isoformat()},place=base['place'])
            finish(transit,settings)
        candidates=[]
        for index,chart in enumerate(charts):
            contacts=[];progression=None
            targets=points(chart,settings.include_angles)
            if request.focus=='personal':targets=[p for p in targets if p['id'] in MAJOR+['ascendant','midheaven']]
            if transit:
                source=points(transit,False)
                if request.focus=='personal':source=[p for p in source if p['id'] in MAJOR]
                contacts.extend({**a,'method':'transits'} for a in aspects(source,targets,effective))
            if request.method in ('both','progressed') and request.birth.confidence!='unknown' and utc>=datetime.fromisoformat(chart['birth']['utc']):
                progression=progressed(chart,utc,settings)
                source=points(progression,settings.include_angles)
                if request.focus=='personal':source=[p for p in source if p['id'] in MAJOR[:5]+['ascendant','midheaven']]
                contacts.extend({**a,'method':'progressed'} for a in aspects(source,targets,effective))
            contacts.sort(key=lambda a:(a['orb'],a['method'],a['a'],a['b']))
            candidates.append({'shift_minutes':0 if index==0 else request.shift_minutes,'birth':chart['birth'],
                               'ascendant':chart['ascendant'],'midheaven':chart['midheaven'],
                               'contacts':contacts,'progression_before_birth':request.method in ('both','progressed') and utc<datetime.fromisoformat(chart['birth']['utc']),'progressed_phase':progression['phase'] if progression else None})
        rows.append({'date':day.isoformat(),'utc':utc.isoformat(),
                     'age_years':(utc-datetime.fromisoformat(base['birth']['utc'])).total_seconds()/86400/YEAR_DAYS,
                     'candidates':candidates})
    return {'events':rows,'birth':base['birth'],'settings':settings.model_dump(),'effective_orbs':effective.orbs,
            'method':request.method,'focus':request.focus,'progressions_available':request.birth.confidence!='unknown',
            'sample_time':'12:00 UTC','source':'https://www.astrologiskinstitut.dk/product-page/horoskopets-tid',
            'meaning':'Snapshots at noon UTC on the selected dates, not searches for exact transit times. The original birth time is preserved. Contacts are sorted by orb, not interpreted or scored.'}
