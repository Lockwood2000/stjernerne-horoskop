"""Original study exercises based on public Astrology University course outlines.

Annual profections: completed calendar age, whole-sign houses, traditional rulers.
Prenatal lunation: the last geocentric new OR full moon at/before birth.
The course sources describe the techniques, not these original worksheets.
"""
from datetime import date, datetime, time, timedelta, timezone
from functools import lru_cache
from .engine import positions_at, position, house_for
from .school_engine import (natal, aspects, points, positions, progressed, finish,
                            empty_houses, houses_at, TRADITIONAL)
from .school_events import signed, root
from .school_workshops import workshop_settings, MAJOR

UTC = timezone.utc
LUMINARIES = [(0,'sun','Sun','sun'), (1,'moon','Moon','moon')]
YEAR_SOURCES = [
    'https://www.astrologyuniversity.com/shop/search-by-astrologer/kelly-surtees/plan-2026-course/',
    'https://www.astrologyuniversity.com/shop/search-by-astrologer/kelly-surtees/progressions-profections-france-2027/',
    'https://kellysastrology.com/pdf/ProfectionsWorksheet.pdf',
]
LUNATION_SOURCE = 'https://www.astrologyuniversity.com/shop/search-by-astrologer/israel-ajose/the-prenatal-lunation/'

def anniversary(born, year):
    """Explicit local calendar convention: 29 February -> 28 February."""
    try:
        return born.replace(year=year)
    except ValueError:
        return born.replace(year=year,day=28)

def profection(born, study, ascendant):
    age = study.year-born.year-(study < anniversary(born,study.year))
    sign = (int(ascendant//30)+age)%12
    return {'age':age, 'house':age%12+1, 'sign_index':sign,
            'lord':TRADITIONAL[sign],
            'start':anniversary(born,born.year+age).isoformat(),
            'end':anniversary(born,born.year+age+1).isoformat()}

def year_workshop(request):
    settings=workshop_settings(request.settings,MAJOR)
    base=natal(request.birth,settings)
    born=datetime.fromisoformat(base['birth']['utc'])
    stamp=datetime.combine(request.date,time(12),UTC)
    # A birth on the study day may be later than noon. Do not progress backwards.
    stamp=max(stamp,born)
    annual=None; alternatives=[]; cycle=[]
    if base['ascendant']:
        annual=profection(request.birth.date,request.date,base['ascendant']['longitude'])
        annual['lord_natal']=next(p for p in base['planets'] if p['id']==annual['lord'])
        if base.get('uncertainty'):
            a=datetime.fromisoformat(base['uncertainty']['from_utc'])
            b=datetime.fromisoformat(base['uncertainty']['to_utc'])
            signs=set()
            for i in range(25):
                jd=positions_at(a+(b-a)*i/24,bodies=LUMINARIES)['jd_ut1']
                ac=houses_at(jd,base['place']['latitude'],base['place']['longitude'],'W')['ascendant']['longitude']
                item=profection(request.birth.date,request.date,ac)
                if item['sign_index'] not in signs:
                    signs.add(item['sign_index']);alternatives.append(item)
        first=(annual['age']//12)*12
        for age in range(first,first+12):
            if request.birth.date.year+age>2099:break
            d=anniversary(request.birth.date,request.birth.date.year+age)
            cycle.append(profection(request.birth.date,d,base['ascendant']['longitude']))
    transit=positions(stamp,settings)
    transit.update(empty_houses(),kind='transits',birth={'utc':stamp.isoformat(),'confidence':'exact'},place=base['place'])
    transit=finish(transit,settings)
    slow=[p for p in transit['planets'] if p['id'] in ['jupiter','saturn','uranus','neptune','pluto','north_node','south_node']]
    targets=points(base,settings.include_angles)
    contacts=aspects(slow,targets,settings)
    prog=progressed(base,stamp,settings) if request.birth.confidence!='unknown' else None
    prog_contacts=aspects([p for p in prog['planets'] if p['id']=='moon'],targets,settings) if prog else []
    return {'natal':base,'profection':annual,'alternatives':alternatives,'cycle':cycle,
            'date':request.date.isoformat(),'utc':stamp.isoformat(),'transits':transit,
            'transit_contacts':contacts,'progressed':prog,'progressed_moon_contacts':prog_contacts,
            'settings':settings.model_dump(),'sources':YEAR_SOURCES,
            'method':{
                'profection':'Completed calendar age modulo 12, first house at age 0. Birthday-to-birthday; 29 February birthdays use 28 February in common years. End date is exclusive.',
                'houses':'Profection always uses the natal Ascendant sign and whole-sign houses. The displayed natal chart retains the selected house system.',
                'rulers':'Traditional sign rulers for the annual time lord, independent of the selected natal dispositor setting.',
                'timing':'Daily snapshot at 12:00 UTC, or at birth if birth is later on the study date. Transits are not a search for exact annual events.',
                'uncertainty':'No profection or progression for unknown birth time. Approximate Ascendant signs are sampled 25 times across the stated interval; nominal houses and annual lord remain provisional.',
                'progressions':'Secondary progressed Moon, one ephemeris day per 365.2422 elapsed days. Angles follow the selected progression setting.'}}

def lunations(start,end):
    """6-hour brackets; reject wrapped residuals, refine each syzygy to 0.25 s."""
    duration=(end-start).total_seconds()
    @lru_cache(maxsize=4096)
    def state(seconds):
        return positions_at(start+timedelta(seconds=seconds),bodies=LUMINARIES)['planets']
    grid=list(range(0,int(duration),21600))+[duration]
    found=[]
    for angle in (0,180):
        def residual(seconds):
            sun,moon=state(seconds)
            return signed(moon['longitude']-sun['longitude']-angle)
        for a,b in zip(grid,grid[1:]):
            fa,fb=residual(a),residual(b)
            if abs(fa)<1e-10:t=a
            elif abs(fb)<1e-10:t=b
            elif fa*fb<0 and abs(fb-fa)<180:t=root(residual,a,b)
            else:continue
            utc=start+timedelta(seconds=t)
            if any(abs((utc-datetime.fromisoformat(x['utc'])).total_seconds())<1 for x in found):continue
            sun,moon=state(t)
            found.append({'utc':utc.isoformat(),'kind':'new' if angle==0 else 'full',
                          'sun':position(sun['longitude']),'moon':position(moon['longitude']),
                          'residual_degrees':abs(residual(t))})
    return sorted(found,key=lambda x:x['utc'])

def lunation_workshop(request):
    settings=workshop_settings(request.settings,MAJOR[:7])
    base=natal(request.birth,settings)
    born=datetime.fromisoformat(base['birth']['utc'])
    events=lunations(born-timedelta(days=35),born+timedelta(days=17))
    before=[p for p in events if datetime.fromisoformat(p['utc'])<=born]
    personal=before[-1]
    cusps=[h['longitude'] for h in base['houses']]
    for event in events:
        event['house']=house_for(event['moon']['longitude'],cusps) if cusps else None
        event['sun_house']=house_for(event['sun']['longitude'],cusps) if cusps else None
        event['lord']=TRADITIONAL[event['moon']['sign_index']]
        event['lord_natal']=next(p for p in base['planets'] if p['id']==event['lord'])
        event['contacts']=aspects([{'id':'lunation',**event['moon']}],points(base,settings.include_angles),settings)
    ambiguity=[]
    if base.get('uncertainty'):
        a=datetime.fromisoformat(base['uncertainty']['from_utc']);b=datetime.fromisoformat(base['uncertainty']['to_utc'])
        boundaries=[p for p in events if a<=datetime.fromisoformat(p['utc'])<b]
        if boundaries:
            previous=max((p for p in events if datetime.fromisoformat(p['utc'])<a),key=lambda x:x['utc'])
            ambiguity=[previous,*boundaries]
    return {'natal':base,'personal':personal,'lunations':events,'ambiguity':ambiguity,
            'settings':settings.model_dump(),'sources':[LUNATION_SOURCE],
            'method':{
                'point':'Last new OR full moon at or before the nominal birth instant, by apparent geocentric tropical ecliptic longitude.',
                'axis':'Both luminaries are shown. The study degree and its traditional ruler use the Moon end of the full-moon axis.',
                'houses':'The lunation degree is placed in the natal houses, not houses for the lunation instant. Natal house settings and aspect orbs are retained.',
                'uncertainty':'If the birth interval crosses a lunation, both possible prenatal events are returned. Unknown time omits houses and angles.',
                'precision':'Six-hour brackets, 0.25-second numerical root tolerance. Displayed times are UTC.'}}
