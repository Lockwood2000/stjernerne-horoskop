"""Fixed personal RA key for secondary angles. See docs/SOLAR-KEY.md."""
import ctypes as C
import math
from .engine import lib, LOCK, CalculationError

SOLAR_KEY_METHODS=('kundig','kundig_argus')
SOLAR_KEY_LABELS={'kundig':'Kündig · hel grad','kundig_argus':'ARGUS · centreret'}

def right_ascension(longitude, obliquity):
    lon, eps = map(math.radians, (longitude, obliquity))
    return math.degrees(math.atan2(math.sin(lon)*math.cos(eps), math.cos(lon))) % 360

def degree_key(longitude, obliquity):
    """RA extent of the whole zodiac degree containing the natal Sun.

    Deliberately not the daily solar speed, nor a moving secondary solar arc.
    Using the whole containing degree makes the convention reproducible.
    """
    start = math.floor(longitude % 360)
    return (right_ascension(start+1, obliquity)-right_ascension(start, obliquity)) % 360

def centered_key(longitude, obliquity):
    """RA extent of the one-degree arc centred on the exact natal Sun.

    ARGUS convention described by Christian Borup, PDF p. 76. Both boundaries
    are evaluated independently; the positive span handles the 360/0 seam.
    """
    return (right_ascension(longitude+.5,obliquity)
            -right_ascension(longitude-.5,obliquity)) % 360

def kundig_solar_key(natal,method='kundig'):
    if method not in SOLAR_KEY_METHODS:raise CalculationError('Ukendt solnøglevariant.')
    with LOCK:
        values=(C.c_double*6)();error=C.create_string_buffer(256)
        if lib.swe_calc(natal['calculation']['jd_tt'],-1,0,values,error)<0:
            raise CalculationError('Solnøglens ekliptikahældning kunne ikke beregnes.')
        eps=values[0]
    sun=next(p['longitude'] for p in natal['planets'] if p['id']=='sun')
    centered=method=='kundig_argus'
    start=(sun-.5)%360 if centered else math.floor(sun % 360)
    return {'degrees_per_year':(centered_key if centered else degree_key)(sun,eps),
            'sun_longitude':sun,'degree_start':start,'degree_end':(start+1)%360,'obliquity':eps,
            'coordinate':'right ascension','variant':('one degree centred on exact natal Sun' if centered else 'whole containing zodiac degree'),
            'source':('https://astrologi-arkaden.dk/ebooks/christian-korrektion.pdf' if centered else
                      'https://tonylouis.wordpress.com/2016/07/30/the-kundig-sun-key-for-directing-a-chart/')}
