"""Fixed personal RA key for secondary angles. See docs/SOLAR-KEY.md."""
import ctypes as C
import math
from .engine import lib, LOCK, CalculationError

def right_ascension(longitude, obliquity):
    lon, eps = map(math.radians, (longitude, obliquity))
    return math.degrees(math.atan2(math.sin(lon)*math.cos(eps), math.cos(lon))) % 360

def degree_key(longitude, obliquity):
    """RA extent of the whole zodiac degree containing the natal Sun.

    Deliberately not the daily solar speed, nor a moving secondary solar arc.
    Using the whole containing degree makes the convention reproducible.
    """
    start = math.floor(longitude % 360)
    return (right_ascension(start+1, obliquity)-right_ascension(start, obliquity)) % 360

def kundig_solar_key(natal):
    with LOCK:
        values=(C.c_double*6)();error=C.create_string_buffer(256)
        if lib.swe_calc(natal['calculation']['jd_tt'],-1,0,values,error)<0:
            raise CalculationError('Solnøglens ekliptikahældning kunne ikke beregnes.')
        eps=values[0]
    sun=next(p['longitude'] for p in natal['planets'] if p['id']=='sun')
    start=math.floor(sun % 360)
    return {'degrees_per_year':degree_key(sun,eps),'sun_longitude':sun,
            'degree_start':start,'degree_end':(start+1)%360,'obliquity':eps,
            'coordinate':'right ascension','variant':'whole containing zodiac degree',
            'source':'https://www.electric-ephemeris.dk/download/argus421.pdf'}
