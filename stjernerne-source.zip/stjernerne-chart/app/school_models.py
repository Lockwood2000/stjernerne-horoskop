"""Explicit, versioned inputs for the two teaching workspaces."""
from datetime import date, time as ClockTime
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

BODY_IDS = ('sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto',
            'north_node','south_node','chiron','ceres','eris','haumea','makemake','pallas','juno','vesta')
DEFAULT_BODIES = list(BODY_IDS[:17])
HOUSE_NAMES = {'P':'Placidus','W':'Whole Sign','E':'Equal','K':'Koch','O':'Porphyry','C':'Campanus','T':'Topocentric','R':'Regiomontanus'}

class StrictModel(BaseModel):
    model_config = ConfigDict(extra='forbid', allow_inf_nan=False)

class Settings(StrictModel):
    house_system: Literal['P','W','E','K','O','C','T','R'] = 'P'
    node: Literal['true','mean'] = 'true'
    bodies: list[str] = Field(default_factory=lambda: DEFAULT_BODIES.copy(),min_length=2,max_length=20)
    orbs: dict[str,float] = Field(default_factory=lambda:{'0':8,'60':4,'90':6,'120':6,'180':8})
    ruler_mode: Literal['traditional','modern'] = 'traditional'
    progression_method: Literal['naibod','kundig','kundig_argus'] = 'naibod'
    include_angles: bool = True
    declination_orb: float = Field(default=1,gt=0,le=5)

    @field_validator('bodies')
    @classmethod
    def known_bodies(cls,values):
        if len(set(values))!=len(values) or any(x not in BODY_IDS for x in values):
            raise ValueError('Choose distinct supported bodies.')
        if not {'sun','moon'} <= set(values):
            raise ValueError('Sun and Moon are required for the phase and timing methods.')
        return values

    @field_validator('orbs')
    @classmethod
    def valid_orbs(cls,values):
        if not values or any(k not in ('0','30','45','60','72','90','120','135','144','150','180') or not 0<v<=15 for k,v in values.items()):
            raise ValueError('Choose supported aspects with orbs above 0 and at most 15 degrees.')
        return values

class BirthInput(StrictModel):
    date: date
    time: ClockTime | None = None
    confidence: Literal['exact','approximate','unknown'] = 'exact'
    uncertainty_minutes: int = Field(default=30,ge=1,le=720)
    place_id: str | None = Field(default=None,max_length=20)
    place_name: str | None = Field(default=None,max_length=120)
    latitude: float | None = Field(default=None,ge=-89.9,le=89.9)
    longitude: float | None = Field(default=None,ge=-180,le=180)
    timezone: str | None = Field(default=None,max_length=80)
    fold: Literal[0,1] | None = None
    offset_minutes: int | None = Field(default=None,ge=-840,le=840)
    offset_source: str | None = Field(default=None,max_length=250)

    @model_validator(mode='after')
    def consistent(self):
        if not date(1500,1,1)<=self.date<=date(2099,12,31):
            raise ValueError('Supported dates are 1500–2099, Gregorian calendar.')
        if self.time is not None and self.time.tzinfo is not None:
            raise ValueError('Enter a local clock time without a UTC offset.')
        if self.confidence!='unknown' and self.time is None:
            raise ValueError('Enter the time, or choose unknown birth time.')
        if self.confidence=='unknown' and self.time is not None:
            raise ValueError('Unknown birth time must not contain a guessed clock time.')
        if self.place_id:
            if any(x is not None for x in (self.latitude,self.longitude,self.timezone)):
                raise ValueError('Choose a saved place or manual coordinates, not both.')
        elif any(x is None for x in (self.latitude,self.longitude,self.timezone)):
            raise ValueError('Choose a birthplace or enter coordinates and a time zone.')
        return self

class Target(StrictModel):
    date: date
    time: ClockTime = ClockTime(12)
    timezone: str = Field(default='UTC',max_length=80)
    fold: Literal[0,1] | None = None

    @model_validator(mode='after')
    def valid(self):
        if not date(1500,1,1)<=self.date<=date(2099,12,31) or self.time.tzinfo is not None:
            raise ValueError('Choose a valid local target date/time between 1500 and 2099.')
        return self

class ChartRequest(StrictModel):
    school: Literal['institut','university'] = 'institut'
    birth: BirthInput
    settings: Settings = Field(default_factory=Settings)
    mode: Literal['natal','solar_chart','event','transits','progressed','combined','solar_arc','synastry','composite','compare','solar_return'] = 'natal'
    target: Target | None = None
    other: BirthInput | None = None
    return_year: int | None = Field(default=None,ge=1500,le=2099)
    return_place_id: str | None = Field(default=None,max_length=20)

    @model_validator(mode='after')
    def necessary(self):
        if self.mode in ('transits','progressed','combined','solar_arc') and self.target is None:
            raise ValueError('Choose a target date.')
        if self.mode in ('synastry','composite','compare') and self.other is None:
            raise ValueError('Enter a second chart.')
        if self.mode=='solar_return' and self.return_year is None:
            raise ValueError('Choose a solar-return year.')
        if self.mode in ('progressed','combined','solar_arc','solar_return','event') and self.birth.confidence=='unknown':
            raise ValueError('This method needs a stated birth or event time. Use a natal or solar chart for unknown time.')
        return self

class EventsRequest(StrictModel):
    birth: BirthInput
    settings: Settings = Field(default_factory=Settings)
    start: date
    end: date
    planet: str = 'saturn'
    target_body: str = 'sun'

    @model_validator(mode='after')
    def bounds(self):
        if not date(1500,1,1)<=self.start<=self.end<=date(2099,12,31) or (self.end-self.start).days>366:
            raise ValueError('Choose a search interval of at most 366 days between 1500 and 2099.')
        if self.planet not in BODY_IDS[:10] or self.target_body not in self.settings.bodies+['ascendant','midheaven']:
            raise ValueError('Choose a supported transit planet and natal target.')
        if self.target_body in ('ascendant','midheaven') and self.birth.confidence=='unknown':
            raise ValueError('Unknown birth time has no reliable natal angles.')
        return self

class RectificationRequest(StrictModel):
    birth: BirthInput
    settings: Settings = Field(default_factory=Settings)
    shifts: list[float] = Field(default_factory=lambda:[0],min_length=1,max_length=5)
    events: list[date] = Field(default_factory=list,max_length=5)
    method: Literal['transits','progressed'] = 'transits'
    scope: Literal['angles','all'] = 'angles'
    orb: float = Field(default=1,gt=0,le=5)
    cut_mode: Literal['kundig','bonatti','both'] = 'both'
    radius_minutes: int = Field(default=60,ge=15,le=180)

    @model_validator(mode='after')
    def valid(self):
        if self.birth.confidence=='unknown':raise ValueError('Rectification needs a stated starting time.')
        if len(set(self.shifts))!=len(self.shifts) or any(abs(x)>180 or abs(x*60-round(x*60))>1e-7 for x in self.shifts):
            raise ValueError('Choose distinct candidates within ±180 minutes, with whole-second precision.')
        if any(not self.birth.date<=d<=date(2099,12,31) for d in self.events):raise ValueError('Events must follow birth and fall before 2100.')
        return self
