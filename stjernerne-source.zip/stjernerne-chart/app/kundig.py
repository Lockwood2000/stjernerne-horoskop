"""Kündig cut candidates, independently implemented from the published method.

See docs/KUNDIG.md. No proprietary ARGUS/CORREX code or data is used.
"""
from datetime import datetime, timedelta
from functools import lru_cache
import math
from .engine import kundig_geometry, position, CalculationError
from .rectification import candidate_timing

RULERS=('mars','venus','mercury','moon','sun','mercury',
        'venus','mars','jupiter','saturn','saturn','jupiter')
PAIRS=(('mars','venus'),('mercury','jupiter'),('moon','saturn'),('sun','saturn'))
SOURCE='https://www.electric-ephemeris.dk/correx.pdf'

def signed(value,period=360):
    return (value+period/2)%period-period/2

def bisect(fn,left,right):
    a=fn(left)
    for _ in range(45):
        mid=(left+right)/2
        b=fn(mid)
        if right-left<0.00002: return mid
        if a*b<=0: right=mid
        else: left=mid; a=b
    return (left+right)/2

def cut_roots(geometry,start,end):
    """Find each division separately, so even very close cuts are not skipped.

    Split at partner-axis crossings, where the ordered delimiting arcs change.
    On each continuous branch the meridian outruns the classical planets.
    """
    roots=[]
    for pair in PAIRS:
        def alignment(t):
            g=geometry(t)
            return signed(g['ra'][pair[0]]-g['ra'][pair[1]],180)
        grid=[start+(end-start)*i/max(1,math.ceil((end-start)/900))
              for i in range(max(1,math.ceil((end-start)/900))+1)]
        crossings=[]
        for a,b in zip(grid,grid[1:]):
            fa,fb=alignment(a),alignment(b)
            if abs(fa)<1e-10: crossings.append(a)
            elif fa*fb<0 and abs(fa-fb)<90: crossings.append(bisect(alignment,a,b))
        boundaries=sorted({start,end,*[t for t in crossings if start<t<end]})
        for source in pair:
            other=pair[1] if source==pair[0] else pair[0]
            for half in (0,180):
                for division in range(10):
                    def residual(t):
                        g=geometry(t)
                        a=g['ra'][source]+half
                        span=(g['ra'][other]-a)%180
                        return signed(g['armc']-a-span*division/10)
                    intervals=[(start,end)] if division==0 else list(zip(boundaries,boundaries[1:]))
                    for left,right in intervals:
                        a=left+(0.0001 if left!=start else 0)
                        b=right-(0.0001 if right!=end else 0)
                        fa,fb=residual(a),residual(b)
                        if abs(fa)<1e-8: t=a
                        elif abs(fb)<1e-8: t=b
                        elif fa<0<fb and fb-fa<180: t=bisect(residual,a,b)
                        else: continue
                        if abs(residual(t))>1e-5: continue
                        g=geometry(t)
                        sign=int(g['mc']//30)%12
                        if {RULERS[sign],RULERS[(sign+6)%12]}!=set(pair): continue
                        roots.append({'seconds':t,'partners':pair,'from_partner':source,
                                      'division':division,'upper':half==0})
    return sorted(roots,key=lambda r:r['seconds'])

def kundig_cuts(base,radius_minutes=60,cut_mode='kundig'):
    if cut_mode not in ('kundig','bonatti','both'):raise CalculationError('Ukendt snitmetode.')
    origin=datetime.fromisoformat(base['birth']['utc'])
    @lru_cache(maxsize=6000)
    def geometry(seconds):
        return kundig_geometry(origin+timedelta(seconds=seconds),base['place']['longitude'])
    roots=([{**r,'method':'kundig'} for r in cut_roots(geometry,-radius_minutes*60,radius_minutes*60)]
           if cut_mode!='bonatti' else [])
    if cut_mode!='kundig':
        from .bonatti import bonatti_geometry, bonatti_roots
        @lru_cache(maxsize=4000)
        def bonatti_at(seconds):
            return bonatti_geometry(origin+timedelta(seconds=seconds),base['place']['latitude'],base['place']['longitude'])
        roots += [{**r,'method':'bonatti'} for r in bonatti_roots(bonatti_at,-radius_minutes*60,radius_minutes*60)]
    grouped={}
    for root in roots:
        seconds=round(root['seconds'])
        utc=origin+timedelta(seconds=seconds)
        try: timing=candidate_timing(base,utc)
        except CalculationError: continue
        g=geometry(seconds)
        definition={k:v for k,v in root.items() if k not in ('seconds','partners')}
        if seconds not in grouped:grouped[seconds]={'shift_minutes':seconds/60,'shift_seconds':seconds,
            'local':timing['local'],'utc':timing['utc'],'fold':timing['fold'],
            'offset_minutes':timing['offset_minutes'],'mc':position(g['mc']),
            'ic':position(g['mc']+180),'partners':[],
            'definitions':[],'methods':[],'bonatti_contacts':[]}
        row=grouped[seconds]
        if root['method'] not in row['methods']:row['methods'].append(root['method'])
        row['definitions'].append(definition)
        if root['method']=='kundig':
            row['partners']=[{'id':key,'name':g['planets'][key]['name']} for key in root['partners']]
        else:
            bg=bonatti_at(seconds);p=bg['planets'][root['planet']]
            row['bonatti_contacts'].append({'axis':root['axis'],'planet':p['id'],'name':p['name'],
                'axis_longitude':bg['angles'][root['axis']],'planet_longitude':p['longitude']})
    for row in grouped.values():row['methods'].sort(key=('kundig','bonatti').index)
    nearest=set(sorted(grouped,key=abs)[:3])
    return {'candidates':[{**row,'nearest':s in nearest} for s,row in sorted(grouped.items())],
        'method':{'name':{'kundig':'Kündig-snit','bonatti':'Bonatti-snit','both':'Kündig- og Bonatti-snit'}[cut_mode],
                  'cut_mode':cut_mode,'variant':'ecliptic longitude axes; moving planets at each root',
                  'rulers':'traditional' if cut_mode!='bonatti' else None,
                  'divisions':10 if cut_mode!='bonatti' else None,
                  'coordinate':{'kundig':'right ascension','bonatti':'ecliptic longitude',
                                'both':'Kündig: right ascension; Bonatti: ecliptic longitude'}[cut_mode],
                  'planet_epoch':'each prospective cut','bonatti':cut_mode!='kundig',
                  'bonatti_bodies':'Sun through Pluto; no nodes, Chiron or dwarf planets',
                  'counts':{m:sum(m in row['methods'] for row in grouped.values()) for m in ('kundig','bonatti')},
                  'precision':'rounded to whole UTC seconds','radius_minutes':radius_minutes,
                  'source':('https://www.electric-ephemeris.dk/download/argus421.pdf' if cut_mode=='bonatti' else SOURCE),
                  'bonatti_source':'https://www.electric-ephemeris.dk/download/argus421.pdf',
                  'meaning':'Astrological time candidates; no automatic rectification or confidence score.'}}
