"""Kirsebom's publicly described longitude loop, with independently solved events.

Only events 4 and 6 are zero-speed stations. Same-degree families are 2/6,
3/5/7 and 4/8. Solar conjunctions 1/9 frame the inner-planet cycle; for outer
planets they can fall *inside* the shadow and are not forced into a false order.
"""
from copy import deepcopy
from datetime import datetime, timedelta, time, timezone
from functools import lru_cache
from .engine import positions_at, position, separation, house_for, CalculationError, VERSION
from .school_engine import natal, points, BODY_NUMBERS
from .school_workshops import workshop_settings
from .school_events import signed, root
from .techniques import YEAR_DAYS

UTC=timezone.utc
SYNODIC={'mercury':116,'venus':584,'mars':780,'jupiter':399,'saturn':378,'uranus':370,'neptune':368,'pluto':367}
SOURCES=[
 'https://www.astrologiskinstitut.dk/post/retrograde-planeter',
 'https://www.astrologiskinstitut.dk/post/retrograde-planeter-slojfen',
 'https://www.astrologiskinstitut.dk/post/det-sj%C3%A6ldne-sammenfald-mellem-merkur-og-venus-i-2025',
]

def body_pair(planet,utc):
    return positions_at(utc,bodies=[(0,'sun','Sun','sun'),(BODY_NUMBERS[planet],planet,planet,planet)])['planets']

@lru_cache(maxsize=64)
def cycle_at(planet,anchor_iso):
    """Search neighbouring cycles; all bracketing is on continuous small arcs.

    Two-day samples cannot skip a Mercury retrograde interval. Reject longitude
    sign flips across the antipode, and check direction at each crossing. The
    cache contains astronomy only, never natal charts or personal notes.
    """
    anchor=datetime.fromisoformat(anchor_iso)
    radius=timedelta(days=SYNODIC[planet]*1.8)
    start=anchor-radius;duration=2*radius.total_seconds()
    @lru_cache(maxsize=16000)
    def pair(t):return body_pair(planet,start+timedelta(seconds=t))
    def speed(t):return pair(t)[1]['speed']
    def elongation(t,angle=0):
        sun,p=pair(t);return signed(p['longitude']-sun['longitude']-angle)
    grid=list(range(0,int(duration),2*86400))+[duration]
    def roots(fn,a=0,b=duration,angular=False):
        knots=[a,*[t for t in grid if a<t<b],b];found=[]
        for x,y in zip(knots,knots[1:]):
            fx,fy=fn(x),fn(y)
            if angular and abs(fy-fx)>180:continue
            if abs(fx)<1e-10:t=x
            elif fx*fy<0:t=root(fn,x,y)
            elif abs(fy)<1e-10:t=y
            else:continue
            if not found or abs(t-found[-1])>1:found.append(t)
        return found
    inner=planet in ('mercury','venus')
    centres=[t for t in roots(lambda t:elongation(t,0 if inner else 180),angular=True) if speed(t)<0]
    if not centres:raise CalculationError('No complete retrograde cycle could be found.')
    centre=min(centres,key=lambda t:abs(t-radius.total_seconds()))
    stations=roots(speed)
    retro=[t for t in stations if t<centre and speed(t-60)>0 and speed(t+60)<0]
    direct=[t for t in stations if t>centre and speed(t-60)<0 and speed(t+60)>0]
    if not retro or not direct:raise CalculationError('The loop could not be bracketed by both stations.')
    sr=max(retro);sd=min(direct)
    def crossing(longitude,a,b,last=False):
        matches=[t for t in roots(lambda t:signed(pair(t)[1]['longitude']-longitude),a,b,True) if speed(t)>1e-7]
        if not matches:raise CalculationError('A direct passage through a loop degree is unavailable.')
        return matches[-1] if last else matches[0]
    lo=pair(sd)[1]['longitude'];hi=pair(sr)[1]['longitude'];meet=pair(centre)[1]['longitude']
    previous_sd=max([0,*[t for t in stations if t<sr and speed(t+60)>0]])
    next_sr=min([duration,*[t for t in stations if t>sd and speed(t+60)<0]])
    entry=crossing(lo,previous_sd,sr,last=True)
    warning=crossing(meet,previous_sd,sr,last=True)
    reactivate=crossing(meet,sd,next_sr)
    leave=crossing(hi,sd,next_sr)
    conjunctions=[t for t in roots(elongation,angular=True) if speed(t)>0]
    before=[t for t in conjunctions if t<centre];after=[t for t in conjunctions if t>centre]
    if not before or not after:raise CalculationError('The neighbouring solar conjunctions are unavailable.')
    times=[max(before),entry,warning,sr,centre,sd,reactivate,leave,min(after)]
    if not all(a<b for a,b in zip(times[1:8],times[2:8])):
        raise CalculationError('The seven loop passages are not in the expected order.')
    stages=[]
    for n,t in enumerate(times,1):
        sun,p=pair(t)
        stages.append({'number':n,'utc':(start+timedelta(seconds=t)).isoformat(),
                       **position(p['longitude']),'speed':p['speed'],
                       'stationary':n in (4,6),'retrograde':p['speed']<0 if n not in (4,6) else n==4,
                       'sun_longitude':sun['longitude'],
                       'family':[2,6] if n in (2,6) else [3,5,7] if n in (3,5,7) else [4,8] if n in (4,8) else [n]})
    def nav(values):
        if not values:return None
        t=min(values,key=lambda t:abs(t-centre))
        d=(start+timedelta(seconds=t)).date().isoformat()
        return d if '1500-01-01'<=d<='2099-12-31' else None
    return {'planet':planet,'stages':stages,'inner':inner,
            'conjunctions_frame_shadow':times[0]<entry and times[8]>leave,
            'previous':nav([t for t in centres if t<centre-1]),'next':nav([t for t in centres if t>centre+1]),
            'loop_days':(leave-entry)/86400,'retrograde_days':(sd-sr)/86400,
            'span_degrees':signed(hi-lo)}

def phase_at(stages,utc):
    if utc<datetime.fromisoformat(stages[1]['utc']) or utc>datetime.fromisoformat(stages[7]['utc']):return None
    return max(s['number'] for s in stages[1:8] if datetime.fromisoformat(s['utc'])<=utc)

def life_date(instant,born,mode):
    effective=born+(instant-born)*YEAR_DAYS if mode=='progressed' else instant
    return effective.isoformat() if born<=effective<datetime(2100,1,1,tzinfo=UTC) else None

def loop_workshop(request):
    settings=workshop_settings(request.settings,[request.planet])
    base=natal(request.birth,settings);born=datetime.fromisoformat(base['birth']['utc'])
    if request.mode=='natal':focus=born
    else:
        day=datetime.combine(request.date,time(12),UTC)
        if request.mode=='progressed' and day<born:
            raise CalculationError('The selected noon UTC precedes the birth instant. Choose a later date.')
        focus=born+(day-born)/YEAR_DAYS if request.mode=='progressed' else day
    anchor=datetime.combine(request.cycle_date,time(12),UTC) if request.cycle_date else focus
    data=deepcopy(cycle_at(request.planet,anchor.isoformat()))
    stages=data['stages'];sun,p=body_pair(request.planet,focus)
    phase=phase_at(stages,focus)
    branch=[2,3,4] if phase is not None and phase<4 else [4,5,6] if phase is not None and phase<6 else [6,7,8] if phase is not None else []
    # Degree proximity alone cannot tell the three passes apart; constrain by branch.
    near=[{'stage':n,'orb':separation(p['longitude'],stages[n-1]['longitude'])} for n in branch
          if separation(p['longitude'],stages[n-1]['longitude'])<=request.orb]
    near.sort(key=lambda x:x['orb'])
    cusps=[h['longitude'] for h in base['houses']]
    targets=points(base,settings.include_angles)
    for s in stages:
        instant=datetime.fromisoformat(s['utc'])
        s['life_utc']=life_date(instant,born,request.mode)
        s['house']=house_for(s['longitude'],cusps) if cusps else None
        s['contacts']=sorted([{'id':q['id'],'orb':separation(q['longitude'],s['longitude'])} for q in targets
                              if separation(q['longitude'],s['longitude'])<=request.orb],key=lambda q:q['orb'])
        if request.mode=='progressed' and base.get('uncertainty') and s['life_utc']:
            bounds=[datetime.fromisoformat(base['uncertainty'][k]) for k in ('from_utc','to_utc')]
            dates=sorted(b+(instant-b)*YEAR_DAYS for b in bounds)
            s['life_uncertainty']=[d.isoformat() for d in dates]
    boundaries=[]
    if base.get('uncertainty'):
        a=datetime.fromisoformat(base['uncertainty']['from_utc']);b=datetime.fromisoformat(base['uncertainty']['to_utc'])
        if request.mode=='progressed':a=a+(day-a)/YEAR_DAYS;b=b+(day-b)/YEAR_DAYS
        if request.mode!='transits':boundaries=[s['number'] for s in stages if a<=datetime.fromisoformat(s['utc'])<=b]
    data.update(mode=request.mode,focus_utc=focus.isoformat(),focus_date=request.date.isoformat() if request.date else None,
                focus_point=p,phase=phase,near=near,orb=request.orb,birth=base['birth'],uncertainty=base.get('uncertainty'),
                boundary_stages=boundaries,settings=settings.model_dump(),engine=VERSION,sources=SOURCES,
                method={'coordinates':'Apparent geocentric tropical ecliptic longitude; Swiss Ephemeris.',
                        'selection':'Retrograde solar conjunction (inner) or opposition (outer) nearest the focus instant, or the chosen cycle date.',
                        'phases':'Core loop 2–8; numbered phases are not all astronomical stations. Only 4 and 6 have zero longitudinal speed.',
                        'progressions':'One ephemeris day per tropical year; inverse dates use the same YEAR_DAYS constant as the chart engine. Dates before birth or after 2099 cannot be added to the lifeline.',
                        'outer':'For outer planets, solar conjunctions 1 and 9 may occur inside the shadow; dates are preserved, not forced into numeric order.',
                        'orb':'Conjunctions to selected natal points and branch-aware phase proximity, capped at 1.5 degrees.',
                        'precision':'Two-day bracketing; roots refined to 0.25 seconds; displayed in UTC.'})
    return data
