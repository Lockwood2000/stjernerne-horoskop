"""Bounded transit diary: exact aspects, orb boundaries, stations and sign entries.

The requested UTC interval is explicit. We split scans at speed reversals and
never present a bounded search as a complete lifetime transit cycle.
"""
from datetime import datetime,timedelta,timezone,time
from functools import lru_cache
from .engine import positions_at,CalculationError
from .school_engine import natal,points,BODY_NUMBERS,ASPECT_NAMES

def signed(x):return (x+180)%360-180

def root(fn,a,b):
    fa=fn(a)
    for _ in range(48):
        m=(a+b)/2;fm=fn(m)
        if b-a<0.25 or abs(fm)<1e-11:return m
        if fa*fm<=0:b=m
        else:a=m;fa=fm
    return (a+b)/2

def diary(request):
    base=natal(request.birth,request.settings)
    target=next((p for p in points(base) if p['id']==request.target_body),None)
    if target is None:raise CalculationError('This chart has no reliable position for the selected target.')
    start=datetime.combine(request.start,time(),timezone.utc)
    end=datetime.combine(request.end+timedelta(days=1),time(),timezone.utc)
    seconds=(end-start).total_seconds()
    @lru_cache(maxsize=16000)
    def state(t):
        return positions_at(start+timedelta(seconds=t),bodies=[(BODY_NUMBERS[request.planet],request.planet,request.planet,request.planet)])['planets'][0]
    def speed(t):return state(t)['speed']
    def longitude(t):return state(t)['longitude']
    grid=list(range(0,int(seconds),21600))+[seconds]
    stations=[]
    for a,b in zip(grid,grid[1:]):
        if speed(a)*speed(b)<0:stations.append(root(speed,a,b))
    spans=sorted(set([*grid,*stations]));events=[]
    def emit(t,kind,**extra):
        if not 0<=t<seconds:return
        if any(e['kind']==kind and e.get('angle')==extra.get('angle') and abs(e['_t']-t)<2 for e in events):return
        events.append({'_t':t,'kind':kind,'utc':(start+timedelta(seconds=t)).isoformat(),'longitude':longitude(t),**extra})
    def crossings(degree,callback):
        fn=lambda t:signed(longitude(t)-degree)
        for a,b in zip(spans,spans[1:]):
            fa,fb=fn(a),fn(b)
            if abs(fa)<1e-8:callback(a)
            if fa*fb<0 and abs(fa-fb)<180:callback(root(fn,a,b))
    for t in stations:emit(t,'station_direct' if speed(min(seconds,t+60))>0 else 'station_retrograde')
    for sign in range(12):
        crossings(sign*30,lambda t,sign=sign:emit(t,'sign_ingress',sign_after=int(longitude(min(seconds,t+2))//30)))
    intervals=[]
    for angle,orb in request.settings.orbs.items():
        angle=int(angle);offsets={angle%360,(-angle)%360}
        for offset in offsets:
            exact=(target['longitude']+offset)%360
            crossings(exact,lambda t,angle=angle:emit(t,'exact_aspect',angle=angle,aspect=ASPECT_NAMES[angle],target=request.target_body))
            edges=[]
            for degree in (exact-orb,exact+orb):crossings(degree,lambda t:edges.append(t))
            boundaries=sorted(set([0.,seconds,*edges]))
            for a,b in zip(boundaries,boundaries[1:]):
                if abs(signed(longitude((a+b)/2)-exact))<=orb:
                    intervals.append({'angle':angle,'from_utc':(start+timedelta(seconds=a)).isoformat(),'to_utc':(start+timedelta(seconds=b)).isoformat(),'start_clipped':a==0,'end_clipped':b==seconds})
            for t in edges:
                entering=abs(signed(longitude(min(seconds,t+2))-exact))<abs(signed(longitude(max(0,t-2))-exact))
                emit(t,'orb_enter' if entering else 'orb_exit',angle=angle,aspect=ASPECT_NAMES[angle],target=request.target_body)
    events.sort(key=lambda e:e['_t'])
    for e in events:e.pop('_t')
    return {'events':events,'intervals':intervals,'target':target,'planet':request.planet,'from_utc':start.isoformat(),'to_utc_exclusive':end.isoformat(),
            'method':'Six-hour scan split at detected stations; roots refined to 0.25 seconds. Dates in UTC. Intervals clipped to the chosen window. Not a complete multi-year cycle or a school-specific retrograde-loop method.',
            'birth_confidence':request.birth.confidence,'settings':request.settings.model_dump()}
