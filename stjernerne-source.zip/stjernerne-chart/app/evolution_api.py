from fastapi.responses import FileResponse, JSONResponse
from .engine import CalculationError
from .timing import TimeProblem
from .evolution import ROOT, EvolutionRequest, build_evolution


def register(app):
    @app.get('/evolution')
    def evolution_page():
        return FileResponse(ROOT/'static/evolution/index.html')

    @app.post('/api/evolution/chart')
    def evolution_chart(request: EvolutionRequest):
        try:
            return build_evolution(request)
        except TimeProblem as error:
            return JSONResponse({'error':{'code':error.code,'message':error.message,'choices':error.choices,'context':getattr(error,'context','birth')}},status_code=422)
        except CalculationError as error:
            return JSONResponse({'error':{'code':'calculation_unavailable','message':str(error)}},status_code=422)
