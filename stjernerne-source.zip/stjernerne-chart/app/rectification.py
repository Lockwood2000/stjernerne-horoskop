"""Birth-time exploration, not an automated inference of the actual birth time."""
from copy import deepcopy
from datetime import datetime, timezone, timedelta, time, date
from .engine import calculate, positions_at, ASPECTS, separation, CalculationError
from .timing import load_zone
from .techniques import secondary_progressions
from .solar_key import SOLAR_KEY_METHODS
SLOW = {'jupiter', 'saturn', 'uranus', 'neptune', 'pluto'}

def candidate_timing(base, utc):
    zone = timezone(timedelta(minutes=base['birth']['offset_minutes'])) if base['birth']['source'] == 'manual' else load_zone(base['birth']['timezone'])
    local = utc.astimezone(zone)
    if local.date() < date(1500, 1, 1) or utc > datetime.now(timezone.utc):
        raise CalculationError('The candidate must be between 1500 and now.')
    timing = deepcopy(base['birth'])
    timing.update(local=local.isoformat(), utc=utc.isoformat(), fold=local.fold, offset_minutes=local.utcoffset().total_seconds() / 60, abbreviation=local.tzname())
    timing['historical_review_required'] = local.year < 1970 or timing['source'] == 'manual'
    if local.year < 1970 and (not any(('Before 1970' in w for w in timing['warnings']))):
        timing['warnings'].append('Before 1970: check the local time zone history separately.')
    return timing

def shifted_chart(base, minutes, include_dwarfs=False):
    seconds = round(minutes * 60)
    minutes = seconds / 60
    utc = datetime.fromisoformat(base['birth']['utc']) + timedelta(seconds=seconds)
    timing = candidate_timing(base, utc)
    data = calculate(utc, base['place']['latitude'], base['place']['longitude'], include_dwarfs)
    return {**data, 'birth': timing, 'place': base['place'], 'display_title': 'Birth time rectification · candidate', 'rectification': {'shift_minutes': minutes, 'original_local': base['birth']['local'], 'original_utc': base['birth']['utc'], 'step_basis': 'elapsed UTC minutes'}}

def angle_contacts(planets, chart):
    found = []
    for p in planets:
        if p['id'] not in SLOW:
            continue
        for axis in ['ascendant', 'midheaven']:
            sep = separation(p['longitude'], chart[axis]['longitude'])
            for key, label, angle, _ in ASPECTS:
                orb = abs(sep - angle)
                if orb <= 2:
                    found.append({'transit': p['id'], 'natal': axis, 'type': key, 'label': label, 'angle': angle, 'orb': orb, 'max_orb': 2})
    return sorted(found, key=lambda a: a['orb'])

def progressed_contacts(progressed, natal):
    """Major ecliptic aspects involving axes, 1° at the sampled event time."""
    axes = lambda c: [{'id': k, 'name': n, **c[k]} for k, n in [('ascendant', 'AC'), ('midheaven', 'MC')]]
    planets = lambda c: [p for p in c['planets'] if p['id'] not in ('true_node', 'chiron', 'ceres', 'eris', 'haumea', 'makemake')]
    found = []
    for source, target, left, right in [('progressed', 'natal', axes(progressed), planets(natal)), ('progressed', 'natal', planets(progressed), axes(natal)), ('progressed', 'progressed', axes(progressed), planets(progressed))]:
        for a in left:
            for b in right:
                sep = separation(a['longitude'], b['longitude'])
                for key, label, angle, _ in ASPECTS:
                    orb = abs(sep - angle)
                    if orb <= 1:
                        found.append({'source': source, 'target': target, 'a': a['id'], 'b': b['id'], 'a_name': a['name'], 'b_name': b['name'], 'type': key, 'label': label, 'angle': angle, 'orb': orb, 'max_orb': 1})
    return sorted(found, key=lambda a: (a['orb'], a['a'], a['b']))

def event_comparison(base, shifts, dates, include_dwarfs=False, method='transits'):
    if method not in ('transits', *SOLAR_KEY_METHODS):
        raise CalculationError('Unknown comparison method.')
    charts = [shifted_chart(base, s, include_dwarfs) for s in dict.fromkeys(shifts)]
    if any((d < date.fromisoformat(c['birth']['local'][:10]) for d in dates for c in charts)):
        raise CalculationError('A life event cannot precede the candidate birth date.')
    events = []
    for d in dates:
        utc = datetime.combine(d, time(12), tzinfo=timezone.utc)
        if method in SOLAR_KEY_METHODS:
            rows = []
            for c in charts:
                progressed, _ = secondary_progressions(datetime.fromisoformat(c['birth']['utc']), utc, c, c['place']['latitude'], c['place']['longitude'], include_dwarfs, method)
                rows.append({'shift_minutes': c['rectification']['shift_minutes'], 'progressed': progressed, 'aspects': progressed_contacts(progressed, c)})
            events.append({'date': d.isoformat(), 'candidates': rows})
            continue
        planets = [p for p in positions_at(utc)['planets'] if p['id'] in SLOW]
        events.append({'date': d.isoformat(), 'timing': {'local': utc.isoformat(), 'utc': utc.isoformat(), 'timezone': 'UTC'}, 'planets': planets, 'candidates': [{'shift_minutes': c['rectification']['shift_minutes'], 'aspects': angle_contacts(planets, c)} for c in charts]})
    if method in SOLAR_KEY_METHODS:
        return {'charts': charts, 'events': events, 'method': {'id': method, 'sample_time': '12:00 UTC', 'orb': 1, 'meaning': 'Secondary planets and Kündig RA angles; major axis aspects at a single event-time sample. No exact-date search or rectification score.'}}
    return {'charts': charts, 'events': events, 'method': {'id': 'transits', 'sample_time': '12:00 UTC', 'orb': 2, 'bodies': ['jupiter', 'saturn', 'uranus', 'neptune', 'pluto'], 'targets': ['AC', 'MC'], 'meaning': 'A single daily sample, not exact transit times or a rectification score.'}}
