"""Birth-time exploration, not an automated inference of the actual birth time."""
from copy import deepcopy
from datetime import datetime, timezone, timedelta, time, date
from .engine import calculate, positions_at, ASPECTS, separation, CalculationError
from .timing import load_zone

SLOW={'jupiter','saturn','uranus','neptune','pluto'}

def shifted_chart(base,minutes,include_dwarfs=False):
    # Step along the UTC timeline. Local time may skip or repeat at a clock change.
    utc=datetime.fromisoformat(base['birth']['utc'])+timedelta(minutes=minutes)
    zone=(timezone(timedelta(minutes=base['birth']['offset_minutes']))
          if base['birth']['source']=='manual' else load_zone(base['birth']['timezone']))
    local=utc.astimezone(zone)
    if local.date()<date(1900,1,1) or utc>datetime.now(timezone.utc):
        raise CalculationError('Kandidaten skal ligge mellem 1900 og nu.')
    timing=deepcopy(base['birth'])
    timing.update(local=local.isoformat(),utc=utc.isoformat(),fold=local.fold,
                  offset_minutes=local.utcoffset().total_seconds()/60,abbreviation=local.tzname())
    timing['historical_review_required']=local.year<1970 or timing['source']=='manual'
    if local.year<1970 and not any('Før 1970' in w for w in timing['warnings']):
        timing['warnings'].append('Før 1970: lokal tidszonehistorik skal kontrolleres særskilt.')
    data=calculate(utc,base['place']['latitude'],base['place']['longitude'],include_dwarfs)
    return {**data,'birth':timing,'place':base['place'],
            'display_title':'Fødselstidskorrektion · kandidat',
            'rectification':{'shift_minutes':minutes,'original_local':base['birth']['local'],
                             'original_utc':base['birth']['utc'],'step_basis':'elapsed UTC minutes'}}

def angle_contacts(planets,chart):
    found=[]
    for p in planets:
        if p['id'] not in SLOW:continue
        for axis in ['ascendant','midheaven']:
            sep=separation(p['longitude'],chart[axis]['longitude'])
            for key,label,angle,_ in ASPECTS:
                orb=abs(sep-angle)
                if orb<=2:
                    found.append({'transit':p['id'],'natal':axis,'type':key,'label':label,
                                  'angle':angle,'orb':orb,'max_orb':2})
    return sorted(found,key=lambda a:a['orb'])

def event_comparison(base,shifts,dates,include_dwarfs=False):
    charts=[shifted_chart(base,s,include_dwarfs) for s in dict.fromkeys(shifts)]
    if any(d<date.fromisoformat(c['birth']['local'][:10]) for d in dates for c in charts):
        raise CalculationError('En livsbegivenhed må ikke ligge før kandidatens fødselsdato.')
    events=[]
    for d in dates:
        utc=datetime.combine(d,time(12),tzinfo=timezone.utc)
        planets=[p for p in positions_at(utc)['planets'] if p['id'] in SLOW]
        events.append({'date':d.isoformat(),'timing':{'local':utc.isoformat(),'utc':utc.isoformat(),'timezone':'UTC'},
                       'planets':planets,'candidates':[{'shift_minutes':c['rectification']['shift_minutes'],
                       'aspects':angle_contacts(planets,c)} for c in charts]})
    return {'charts':charts,'events':events,'method':{'sample_time':'12:00 UTC','orb':2,
            'bodies':['jupiter','saturn','uranus','neptune','pluto'],'targets':['AC','MC'],
            'meaning':'A single daily sample, not exact transit times or a rectification score.'}}
