"""Direct true ecliptic solar-arc directions, using the secondary progressed Sun.

No 1-degree/year shortcut. All natal longitudes, house cusps and ASC/MC receive
the same unwrapped arc. These are symbolic directions, not observed positions.
"""
from copy import deepcopy
from datetime import timedelta
import ctypes as C
import math
from .engine import BODIES, LOCK, SWIEPH, lib, positions_at, position, aspects_for, transit_aspects, CalculationError
from .techniques import YEAR_DAYS
from .solar_key import right_ascension

def solar_arc(birth_utc,target_utc,natal):
    if target_utc<birth_utc:
        raise CalculationError('Direktionsdatoen skal være efter fødselstidspunktet.')
    age=(target_utc-birth_utc).total_seconds()/(86400*YEAR_DAYS)
    stamp=birth_utc+timedelta(days=age)
    previous=natal['planets'][0]['longitude']
    arc=0.0
    # The Sun advances by less than 180 degrees in each bracket. Accumulating
    # positive increments preserves complete revolutions for very old dates.
    steps=max(1,math.ceil(age/90))
    for index in range(1,steps+1):
        current=positions_at(birth_utc+timedelta(days=age*index/steps),bodies=BODIES[:1])['planets'][0]
        arc+=(current['longitude']-previous)%360
        previous=current['longitude']
    if age==0:
        arc=0.0
    speed=current['speed']/YEAR_DAYS
    chart=deepcopy(natal)
    for planet in chart['planets']:
        planet['natal_speed']=planet['speed']
        planet['natal_retrograde']=planet['retrograde']
        planet.update(position(planet['longitude']+arc),speed=speed,retrograde=False)
    chart['houses']=[{'number':h['number'],**position(h['longitude']+arc)} for h in natal['houses']]
    for axis in ('ascendant','midheaven'):
        chart[axis]=position(natal[axis]['longitude']+arc)
    with LOCK:
        values=(C.c_double*6)();error=C.create_string_buffer(256)
        if lib.swe_calc(natal['calculation']['jd_tt'],-1,SWIEPH,values,error)<0:
            raise CalculationError('Ekliptikahældningen kunne ikke beregnes.')
    chart['armc']=right_ascension(chart['midheaven']['longitude'],values[0])
    chart['aspects']=aspects_for(chart['planets'])
    chart['natal_aspects']=transit_aspects(chart['planets'],natal['planets'])
    chart['technique']={'type':'solar_arc','target_utc':target_utc.isoformat(),
        'progressed_utc':stamp.isoformat(),'age_years':age,'days_per_year':YEAR_DAYS,
        'arc_degrees':arc,'arc_rate_degrees_per_lived_day':speed,
        'method':'direct true ecliptic solar arc from the secondary progressed Sun',
        'house_method':'all natal cusps and ASC/MC directed by the same ecliptic arc',
        'speed_unit':'symbolic degrees per lived day','coordinates':'directed natal ecliptic longitudes; latitude and distance remain natal'}
    chart['calculation']['coordinates']=chart['technique']['coordinates']
    chart['calculation']['house_motion']=chart['technique']['house_method']
    # The physical ephemeris instant used for the key, not the target sky.
    return chart,stamp
