"""Evolutionary overlay, sharing the retained school-chart engine and time model.

Planetary nodes are two independently calculated orbital intersection points.
Never manufacture the descending planetary node by adding 180 degrees.
"""
import ctypes as C
import hashlib
import json
import math
from datetime import datetime
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator, model_validator
from .engine import lib, LOCK, DP, SWIEPH, SPEED, VERSION, COMMIT, position, house_for, positions_at, CalculationError
from .school_models import StrictModel, BirthInput, Target, Settings
from .school_engine import natal, progressed, solar_arc, solar_return, place_for, target_time, positions, points, aspects, MODERN, TRADITIONAL
from .timing import TimeProblem
from .techniques import YEAR_DAYS

ROOT = Path(__file__).resolve().parents[1]
CORE = ['sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto','north_node','south_node']
PLANETS = {'mercury':2,'venus':3,'mars':4,'jupiter':5,'saturn':6,'uranus':7,'neptune':8,'pluto':9}
EXTRAS = {
    'chiron':(15,'Chiron'), 'ceres':(17,'Ceres'), 'eris':(146199,'Eris'),
    'haumea':(146108,'Haumea'), 'makemake':(146472,'Makemake'),
    'sedna':(100377,'Sedna'), 'quaoar':(60000,'Quaoar'),
    'orcus':(100482,'Orcus'), 'gonggong':(235088,'Gonggong'),
}
EXTRA_KEYS = Literal['chiron','ceres','eris','haumea','makemake','sedna','quaoar','orcus','gonggong']
METHODS = {'mean_barycentric':5,'osculating_heliocentric':2,'osculating_barycentric':4}
lib.swe_nod_aps.argtypes = [C.c_double,C.c_int32,C.c_int32,C.c_int32,DP,DP,DP,DP,C.c_char_p]
lib.swe_nod_aps.restype = C.c_int32


class ReturnPlace(StrictModel):
    place_id: str | None = Field(default=None,max_length=20)
    place_name: str | None = Field(default=None,max_length=120)
    latitude: float | None = Field(default=None,ge=-89.9,le=89.9)
    longitude: float | None = Field(default=None,ge=-180,le=180)
    timezone: str | None = Field(default=None,max_length=80)

    @model_validator(mode='after')
    def selected_place(self):
        if self.place_id:
            if any(x is not None for x in (self.latitude,self.longitude,self.timezone)):
                raise ValueError('Choose a saved return place or manual coordinates, not both.')
        elif any(x is None for x in (self.latitude,self.longitude,self.timezone)):
            raise ValueError('Choose a return place or enter its coordinates and time zone.')
        return self


class EvolutionRequest(StrictModel):
    birth: BirthInput
    house_system: Literal['O','P','W','E','R'] = 'O'
    lunar_node: Literal['true','mean'] = 'true'
    node_reference: Literal['geocentric','heliocentric'] = 'geocentric'
    node_method: Literal['mean_barycentric','osculating_heliocentric','osculating_barycentric'] = 'mean_barycentric'
    extras: list[EXTRA_KEYS] = Field(default_factory=lambda:list(EXTRAS),max_length=9)
    include_extra_nodes: bool = True
    node_orb: float = Field(default=3,gt=0,le=10)
    quincunx: bool = True
    include_progressions: bool = False
    timing_mode: Literal['secondary','solar_arc','solar_return'] = 'secondary'
    target: Target | None = None
    return_year: int | None = Field(default=None,ge=1500,le=2099)
    return_place: ReturnPlace | None = None
    ruler_mode: Literal['traditional','modern'] = 'modern'

    @field_validator('extras')
    @classmethod
    def distinct_extras(cls,value):
        if len(set(value))!=len(value):raise ValueError('Choose each extra body only once.')
        return value

    @model_validator(mode='after')
    def valid_progression(self):
        if self.include_progressions and self.timing_mode!='solar_return' and self.target is None:
            raise ValueError('Choose a target date and time for the timing overlay.')
        if self.include_progressions and self.timing_mode=='solar_return' and self.return_year is None:
            raise ValueError('Choose a solar-return year.')
        if self.include_progressions and self.birth.confidence=='unknown':
            raise ValueError('Timing overlays in this model require a stated birth time.')
        return self


def verify_extra_data():
    manifest=ROOT/'data/evolution-manifest.json'
    if not manifest.exists():return
    for entry in json.loads(manifest.read_text())['files']:
        p=ROOT/entry['path']
        if not p.exists() or hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:
            raise RuntimeError('Evolutionary ephemeris file missing or checksum mismatch: '+entry['path'])


verify_extra_data()


def english(p):
    # The shared position helper retains Danish sign names for the older API.
    names=['Aries','Taurus','Gemini','Cancer','Leo','Virgo','Libra','Scorpio','Sagittarius','Capricorn','Aquarius','Pisces']
    return {**p,'sign':names[p['sign_index']]}


def assigned(p,base):
    cusps=[h['longitude'] for h in base['houses']]
    return english({**p,'house':house_for(p['longitude'],cusps) if cusps else None})


def extra_positions(chart,utc,keys,base,warnings,progression=False):
    for key in keys:
        number,label=EXTRAS[key]
        try:
            p=positions_at(utc,bodies=[(number,key,label,key)])['planets'][0]
            if progression:
                p['ephemeris_speed']=p['speed'];p['speed']/=YEAR_DAYS
            chart['planets'].append(assigned(p,chart))
        except CalculationError:
            warnings.append(f'{label}: ephemeris data unavailable for this date; body omitted.')


def planetary_nodes(base,request,available_extras,warnings):
    entries=[(key,num,key.capitalize()) for key,num in PLANETS.items()]
    if request.include_extra_nodes:
        entries.extend((key,*EXTRAS[key]) for key in available_extras)
    result=[]
    flags=SWIEPH|SPEED|(8 if request.node_reference=='heliocentric' else 0)
    with LOCK:
        for key,number,label in entries:
            north=(C.c_double*6)();south=(C.c_double*6)();peri=(C.c_double*6)();aphe=(C.c_double*6)()
            error=C.create_string_buffer(256)
            # Confirm the source ephemeris instead of accepting a Moshier fallback.
            coords=(C.c_double*6)()
            used=lib.swe_calc(base['jd_tt'],number,SWIEPH|SPEED,coords,error)
            if used<0 or not used&SWIEPH:
                warnings.append(f'{label}: planetary-node ephemeris unavailable; nodes omitted.')
                continue
            status=lib.swe_nod_aps(base['jd_tt'],number,flags,METHODS[request.node_method],north,south,peri,aphe,error)
            if status<0 or not all(math.isfinite(x) for values in (north,south) for x in values):
                if key in PLANETS:raise CalculationError(f'Planetary nodes unavailable for {label}.')
                warnings.append(f'{label}: planetary nodes unavailable for this date; nodes omitted.')
                continue
            mean=request.node_method=='mean_barycentric' and key in PLANETS and key!='pluto'
            method='mean' if mean else 'osculating'
            if mean:
                basis='mean planetary theory'
            else:
                # Match the native routine's >6 AU heliocentric-distance test.
                distance=(C.c_double*6)()
                used=lib.swe_calc(base['jd_tt'],number,SWIEPH|SPEED|8|16,distance,error)
                if used<0 or not used&SWIEPH:raise CalculationError(f'Orbit reference unavailable for {label}.')
                barycentric=request.node_method!='osculating_heliocentric' and distance[2]>6
                basis='barycentric orbit' if barycentric else 'heliocentric orbit'
            pair={}
            for side,values in [('north',north),('south',south)]:
                pair[side]=assigned({'id':f'{key}_{side}_node','name':f'{label} {side} node','body':key,'side':side,
                    **position(values[0]),'latitude':values[1],'distance_au':values[2],
                    'speed':values[3],'retrograde':values[3]<0,'method':method,'orbit_basis':basis,
                    'reference':request.node_reference},base)
            result.append({'body':key,'name':label,'method':method,'orbit_basis':basis,**pair})
    return result


def build_evolution(request):
    settings=Settings(house_system=request.house_system,node=request.lunar_node,bodies=CORE.copy(),ruler_mode=request.ruler_mode)
    base=natal(request.birth,settings)
    warnings=base['birth']['warnings'].copy()
    birth_utc=datetime.fromisoformat(base['birth']['utc'])
    extra_positions(base,birth_utc,request.extras,base,warnings)
    base['planets']=[english(p) for p in base['planets']]
    base['houses']=[english(h) for h in base['houses']]
    for key in ('ascendant','midheaven'):
        if base[key]:base[key]=english(base[key])
    available=[p['id'] for p in base['planets'] if p['id'] in EXTRAS]
    node_pairs=planetary_nodes(base,request,available,warnings)
    node_points=[p[side] for p in node_pairs for side in ('north','south')]
    angles=['0','60','90','120','180']+(['150'] if request.quincunx else [])
    node_settings=Settings(bodies=CORE.copy(),orbs={k:request.node_orb for k in angles})
    node_aspects=aspects(node_points,points(base),node_settings)
    node_to_node=[a for a in aspects(node_points,[],node_settings,True)
                  if a['a'].rsplit('_',2)[0]!=a['b'].rsplit('_',2)[0]]
    # Both lunar modes are supplied for an actual numeric comparison.
    lunar={}
    for mode in ('true','mean'):
        lunar[mode]=[assigned(p,base) for p in positions(birth_utc,Settings(bodies=CORE.copy(),node=mode))['planets']
                     if p['id'] in ('north_node','south_node')]
    by_id={p['id']:p for p in base['planets']}
    pluto=by_id['pluto']
    polarity=assigned({'id':'pluto_polarity','name':'Pluto polarity point',**position(pluto['longitude']+180)},base)
    rulers=MODERN if request.ruler_mode=='modern' else TRADITIONAL
    focus={'pluto':pluto,'polarity':polarity,
           'south_node':by_id['south_node'],'north_node':by_id['north_node'],
           'south_ruler':by_id[rulers[by_id['south_node']['sign_index']]],
           'north_ruler':by_id[rulers[by_id['north_node']['sign_index']]],'ruler_mode':request.ruler_mode}
    timing=None;timing_aspects=[]
    if request.include_progressions:
        if request.timing_mode=='solar_return':
            where=place_for(request.return_place) if request.return_place else base['place']
            timing=solar_return(base,request.return_year,settings,where)
            stamp=datetime.fromisoformat(timing['birth']['utc'])
            extra_positions(timing,stamp,available,base,warnings)
            timing['technique'].update(year=request.return_year,
                place_choice='selected' if request.return_place else 'birthplace',
                solar_error_arcsec=abs((next(p['longitude'] for p in timing['planets'] if p['id']=='sun')-by_id['sun']['longitude']+180)%360-180)*3600)
        else:
            try:
                utc,_=target_time(request.target)
            except TimeProblem as error:
                error.context='target'
                raise
            if request.timing_mode=='solar_arc':
                timing=solar_arc(base,utc,settings)
                for p in timing['planets']:
                    p['latitude']=None;p['distance_au']=None
                born=datetime.fromisoformat(base['birth']['utc'])
                stamp=born+(utc-born)/YEAR_DAYS
                timing['technique'].update(target_utc=utc.isoformat(),ephemeris_utc=stamp.isoformat(),year_days=YEAR_DAYS)
            else:
                timing=progressed(base,utc,settings)
                stamp=datetime.fromisoformat(timing['birth']['utc'])
                extra_positions(timing,stamp,available,base,warnings,True)
        timing['planets']=[english(p) for p in timing['planets']]
        # Keep both the layer's own houses and its placement in natal houses explicit.
        cusps=[h['longitude'] for h in base['houses']]
        for p in timing['planets']:
            p['house_in_natal']=house_for(p['longitude'],cusps) if cusps else None
        timing['houses']=[english(h) for h in timing['houses']]
        for key in ('ascendant','midheaven'):
            if timing[key]:timing[key]=english(timing[key])
        timing_aspects=aspects(points(timing),points(base),node_settings)
        timing_aspects += [{**a,'target_layer':'planetary_nodes'} for a in aspects(points(timing),node_points,node_settings)]
    prog=timing if timing and request.timing_mode=='secondary' else None
    return {'contract':'stjernerne-evolution-1','natal':base,'planetary_nodes':node_pairs,
        'node_aspects':node_aspects,'node_to_node_aspects':node_to_node,'lunar_nodes':lunar,
        'focus':focus,'timing':timing,'timing_aspects':timing_aspects,
        'progressed':prog,'progression_aspects':timing_aspects if prog else [],
        'input':request.model_dump(mode='json'),'warnings':list(dict.fromkeys(warnings)),
        'calculation':{'engine':'Swiss Ephemeris','version':VERSION,'source_commit':COMMIT,
            'zodiac':'tropical','node_reference':request.node_reference,'node_method':request.node_method,
            'node_orb':request.node_orb,'node_epoch':'natal epoch','coordinates':'ecliptic, true equinox of date',
            'house_assignment':'ecliptic longitude in natal houses; heliocentric longitudes are a symbolic overlay',
            'progression':f'Direct secondary: one ephemeris day per {YEAR_DAYS} elapsed days; Naibod right ascension for axes',
            'solar_arc':f'Direct true solar arc: secondary progressed Sun minus natal Sun in tropical longitude, using {YEAR_DAYS} elapsed days per ephemeris day. Applied equally to natal planets, angles and cusps; symbolic, with no physical speed or retrograde status.',
            'solar_return':'Actual return to the natal tropical apparent geocentric solar longitude; no precession correction. Solved near the birthday in the selected year. Return houses and angles use the explicitly chosen return location; planetary nodes stay natal.',
            'planetary_node_note':'North and south orbital intersection points calculated independently. Pluto and small bodies use osculating nodes, including in the mean-where-available mode.',
            'interpretation_note':'Geometric indicators for practitioner interpretation. No automatic evolutionary-stage or past-life diagnosis.'}}
