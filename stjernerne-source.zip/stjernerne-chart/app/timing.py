from datetime import datetime, timezone, timedelta
from importlib.resources import files
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import tzdata

class TimeProblem(ValueError):

    def __init__(self, code, message, choices=None):
        super().__init__(message)
        self.code, self.message, self.choices = (code, message, choices or [])

def load_zone(key):
    if '..' in key or key.startswith('/') or '\\' in key:
        raise TimeProblem('invalid_timezone', 'Choose a valid IANA time zone.')
    try:
        with files('tzdata.zoneinfo').joinpath(key).open('rb') as handle:
            return ZoneInfo.from_file(handle, key=key)
    except (FileNotFoundError, ValueError, ZoneInfoNotFoundError, IsADirectoryError):
        raise TimeProblem('invalid_timezone', 'The time zone was not found in the database.')

def resolve_time(date_text, time_text, zone_key, fold=None, offset_minutes=None, offset_source=None):
    naive = datetime.fromisoformat(date_text + 'T' + time_text)
    if naive.tzinfo is not None:
        raise TimeProblem('invalid_time', 'Enter local time without a time zone suffix.')
    zone = load_zone(zone_key)
    warnings = []
    if naive.year < 1900:
        warnings.append('Historical date: the calculation uses the Gregorian calendar. Check whether the record uses the Julian calendar and convert the date before calculating if necessary. Local mean time may differ from later standard time.')
    if naive.year < 1970:
        warnings.append('Before 1970: check local time zone history and historical borders separately. IANA data alone is not a guarantee.')
    if offset_minutes is not None:
        if not offset_source or len(offset_source.strip()) < 8:
            raise TimeProblem('offset_source_required', 'Give the source of the historical UTC offset (at least 8 characters).')
        offset = timedelta(minutes=offset_minutes)
        utc = (naive - offset).replace(tzinfo=timezone.utc)
        local = naive.replace(tzinfo=timezone(offset))
        warnings.append('The UTC offset was entered manually. Check the documented source.')
        provenance = 'manual'
    else:
        candidates = {}
        for f in [0, 1]:
            local = naive.replace(tzinfo=zone, fold=f)
            utc = local.astimezone(timezone.utc)
            if utc.astimezone(zone).replace(tzinfo=None) == naive:
                candidates.setdefault(utc, (f, local))
        if not candidates:
            raise TimeProblem('nonexistent_time', 'This local time did not exist because of a clock change. Check the birth record.')
        if len(candidates) > 1 and fold is None:
            choices = [{'fold': f, 'utc': u.isoformat(), 'offset_minutes': int(l.utcoffset().total_seconds() / 60), 'abbreviation': l.tzname()} for u, (f, l) in sorted(candidates.items())]
            raise TimeProblem('ambiguous_time', 'This local time occurred twice. Choose the first or second occurrence.', choices)
        selected = next(((u, l) for u, (f, l) in candidates.items() if f == fold), None) if len(candidates) > 1 else next(((u, l) for u, (f, l) in candidates.items()))
        if selected is None:
            raise TimeProblem('invalid_fold', 'Choose a valid occurrence of the local time.')
        utc, local = selected
        provenance = 'iana'
    return (utc, {'local': local.isoformat(), 'utc': utc.isoformat(), 'timezone': zone_key, 'offset_minutes': local.utcoffset().total_seconds() / 60, 'abbreviation': local.tzname(), 'fold': local.fold, 'source': provenance, 'source_note': offset_source if provenance == 'manual' else None, 'tzdata_version': tzdata.__version__, 'iana_version': tzdata.IANA_VERSION, 'warnings': warnings, 'historical_review_required': naive.year < 1970 or provenance == 'manual'})
