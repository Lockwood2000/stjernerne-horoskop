from datetime import datetime, timezone, timedelta
from importlib.resources import files
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
import tzdata

class TimeProblem(ValueError):
    def __init__(self,code,message,choices=None):
        super().__init__(message)
        self.code,self.message,self.choices=code,message,choices or []

def load_zone(key):
    # Force the pinned package, never the host's potentially different timezone DB.
    if '..' in key or key.startswith('/') or '\\' in key:
        raise TimeProblem('invalid_timezone','Vælg en gyldig IANA-tidszone.')
    try:
        with files('tzdata.zoneinfo').joinpath(key).open('rb') as handle:
            return ZoneInfo.from_file(handle,key=key)
    except (FileNotFoundError,ValueError,ZoneInfoNotFoundError,IsADirectoryError):
        raise TimeProblem('invalid_timezone','Tidszonen findes ikke i databasen.')

def resolve_time(date_text,time_text,zone_key,fold=None,offset_minutes=None,offset_source=None):
    naive=datetime.fromisoformat(date_text+'T'+time_text)
    if naive.tzinfo is not None:
        raise TimeProblem('invalid_time','Indtast lokal tid uden tidszone i klokkeslættet.')
    zone=load_zone(zone_key)
    warnings=[]
    if naive.year<1900:
        warnings.append('Historisk dato: beregningen bruger gregoriansk kalender. Kontrollér, om registreringen bruger juliansk kalender, og omregn i så fald datoen før beregning. Lokal middeltid kan afvige fra senere zonetid.')
    if naive.year<1970:
        warnings.append('Før 1970: lokal tidszonehistorik og stedets daværende grænser skal kontrolleres særskilt. IANA-data alene er ikke en garanti.')
    if offset_minutes is not None:
        if not offset_source or len(offset_source.strip())<8:
            raise TimeProblem('offset_source_required','Angiv kilden til den historiske UTC-forskel (mindst 8 tegn).')
        offset=timedelta(minutes=offset_minutes)
        utc=(naive-offset).replace(tzinfo=timezone.utc)
        local=naive.replace(tzinfo=timezone(offset))
        warnings.append('Tidsforskellen er manuelt angivet. Kontrollér den dokumenterede kilde.')
        provenance='manual'
    else:
        candidates={}
        for f in [0,1]:
            local=naive.replace(tzinfo=zone,fold=f)
            utc=local.astimezone(timezone.utc)
            if utc.astimezone(zone).replace(tzinfo=None)==naive:
                candidates.setdefault(utc,(f,local))
        if not candidates:
            raise TimeProblem('nonexistent_time','Dette klokkeslæt fandtes ikke på stedet på grund af et urskift. Kontrollér fødselsregistreringen.')
        if len(candidates)>1 and fold is None:
            choices=[{'fold':f,'utc':u.isoformat(),'offset_minutes':int(l.utcoffset().total_seconds()/60),'abbreviation':l.tzname()} for u,(f,l) in sorted(candidates.items())]
            raise TimeProblem('ambiguous_time','Klokkeslættet forekom to gange. Vælg den første eller anden forekomst.',choices)
        selected=next(((u,l) for u,(f,l) in candidates.items() if f==fold),None) if len(candidates)>1 else next((u,l) for u,(f,l) in candidates.items())
        if selected is None:
            raise TimeProblem('invalid_fold','Vælg en gyldig forekomst af klokkeslættet.')
        utc,local=selected
        provenance='iana'
    return utc,{'local':local.isoformat(),'utc':utc.isoformat(),'timezone':zone_key,
        'offset_minutes':local.utcoffset().total_seconds()/60,'abbreviation':local.tzname(),
        'fold':local.fold,'source':provenance,'source_note':offset_source if provenance=='manual' else None,
        'tzdata_version':tzdata.__version__,'iana_version':tzdata.IANA_VERSION,'warnings':warnings,
        'historical_review_required':naive.year<1970 or provenance=='manual'}
