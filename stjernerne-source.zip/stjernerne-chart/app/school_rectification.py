from datetime import datetime,timedelta,time,timezone,date
from .school_engine import natal,positions,progressed,aspects,points,finish,empty_houses
from .school_models import BirthInput
from .timing import load_zone
from .kundig import kundig_cuts
from .engine import CalculationError

def candidate(birth,base,shift,settings):
    utc=datetime.fromisoformat(base['birth']['utc'])+timedelta(seconds=round(shift*60))
    zone=timezone(timedelta(minutes=birth.offset_minutes)) if birth.offset_minutes is not None else load_zone(base['place']['timezone'])
    local=utc.astimezone(zone)
    if not date(1500,1,1)<=local.date()<=date(2099,12,31):
        raise CalculationError('The candidate falls outside the supported date range, 1500–2099.')
    values=birth.model_dump();values.update(date=local.date(),time=local.time().replace(tzinfo=None),fold=local.fold)
    chart=natal(BirthInput.model_validate(values),settings)
    chart['shift_minutes']=shift;chart['original_utc']=base['birth']['utc']
    return chart

def compare(request):
    base=natal(request.birth,request.settings)
    charts=[candidate(request.birth,base,s,request.settings) for s in request.shifts]
    events=[]
    effective=request.settings.model_copy(update={'orbs':{k:min(v,request.orb) for k,v in request.settings.orbs.items()}})
    axes={'ascendant','midheaven'}
    major={'sun','moon','mercury','venus','mars','jupiter','saturn','uranus','neptune','pluto'}
    for day in request.events:
        utc=datetime.combine(day,time(12),timezone.utc);rows=[]
        for c in charts:
            if request.method=='progressed':moving=progressed(c,utc,request.settings)
            else:
                moving=positions(utc,request.settings);moving.update(empty_houses());moving.update(kind='transits',birth={'utc':utc.isoformat()},place=c['place']);finish(moving,request.settings)
            if request.scope=='angles':
                if request.method=='transits':
                    source=[p for p in moving['planets'] if p['id'] in {'jupiter','saturn','uranus','neptune','pluto'}]
                    target=[p for p in points(c) if p['id'] in axes]
                else:
                    source=[p for p in points(moving) if p['id'] in major|axes]
                    target=[p for p in points(c) if p['id'] in major|axes]
                contacts=[a for a in aspects(source,target,effective) if a['a'] in axes or a['b'] in axes]
            else:
                contacts=aspects(points(moving,request.settings.include_angles),points(c,request.settings.include_angles),effective)
            rows.append({'shift_minutes':c['shift_minutes'],'aspects':contacts,'moving':moving})
        events.append({'date':day.isoformat(),'utc':utc.isoformat(),'candidates':rows})
    return {'charts':charts,'events':events,'settings':request.settings.model_dump(),'effective_orbs':effective.orbs,'scope':request.scope,'method':request.method,'sample_time':'12:00 UTC','original_utc':base['birth']['utc'],
            'meaning':'Candidates are not ranked. Aspect counts and orbs are not confidence scores. Event dates are sampled at noon UTC; no actual event time or exact-event search is implied.'}

def cuts(request):
    return kundig_cuts(natal(request.birth,request.settings),request.radius_minutes,request.cut_mode)
