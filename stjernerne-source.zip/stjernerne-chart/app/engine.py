"""Small direct ctypes binding to official Swiss Ephemeris; no third-party wrapper.

Prototype source: AGPL-3.0-or-later. See LICENSE and docs/DECISIONS.md.
All calls are serialized because the native library has mutable global state.
"""
import ctypes as C
import hashlib
import json
import math
from pathlib import Path
import sys
import threading

ROOT = Path(__file__).resolve().parents[1]
EPHE = ROOT/'data/ephe'
LOCK = threading.RLock()
SWIEPH, SPEED = 2, 256
BODIES = [(0,'sun','Solen','☉'),(1,'moon','Månen','☽'),(2,'mercury','Merkur','☿'),
          (3,'venus','Venus','♀'),(4,'mars','Mars','♂'),(5,'jupiter','Jupiter','♃'),
          (6,'saturn','Saturn','♄'),(7,'uranus','Uranus','♅'),(8,'neptune','Neptun','♆'),
          (9,'pluto','Pluto','♇'),(11,'true_node','Nordknuden','☊')]
DWARFS = [(15,'chiron','Chiron','⚷'),(17,'ceres','Ceres','Ce'),(146199,'eris','Eris','Er'),(146108,'haumea','Haumea','Ha'),(146472,'makemake','Makemake','Mk')]
DWARF_IDS={b[1] for b in DWARFS}
SIGNS = ['Vædderen','Tyren','Tvillingerne','Krebsen','Løven','Jomfruen',
         'Vægten','Skorpionen','Skytten','Stenbukken','Vandbæreren','Fiskene']
ASPECTS = [('conjunction','Konjunktion',0,8),('sextile','Sekstil',60,4),
           ('square','Kvadrat',90,6),('trine','Trigon',120,6),('opposition','Opposition',180,8)]
DP = C.POINTER(C.c_double)
lib = C.CDLL(str(ROOT/'build'/('libswe.dylib' if sys.platform=='darwin' else 'libswe.so')))
lib.swe_set_ephe_path.argtypes = [C.c_char_p]
lib.swe_set_ephe_path.restype = None
lib.swe_version.argtypes = [C.c_char_p]
lib.swe_version.restype = C.c_char_p
lib.swe_utc_to_jd.argtypes = [C.c_int,C.c_int,C.c_int,C.c_int,C.c_int,C.c_double,C.c_int,DP,C.c_char_p]
lib.swe_utc_to_jd.restype = C.c_int
lib.swe_calc.argtypes = [C.c_double,C.c_int,C.c_int32,DP,C.c_char_p]
lib.swe_calc.restype = C.c_int32
lib.swe_sidtime.argtypes = [C.c_double]
lib.swe_sidtime.restype = C.c_double
lib.swe_houses_ex.argtypes = [C.c_double,C.c_int32,C.c_double,C.c_double,C.c_int,DP,DP]
lib.swe_houses_ex.restype = C.c_int
lib.swe_set_tid_acc.argtypes = [C.c_double]
lib.swe_set_tid_acc.restype = None
lib.swe_set_ephe_path(str(EPHE).encode())
# The downloaded DE441 data require DE441 tidal acceleration. The library's
# UTC conversion otherwise uses its older DE431 default before 1955.
lib.swe_set_tid_acc(-25.936)
buf = C.create_string_buffer(256)
VERSION = lib.swe_version(buf).decode()

class CalculationError(ValueError):
    pass

def verify_data():
    manifest = json.loads((ROOT/'data/upstream-manifest.json').read_text())
    for entry in manifest['files']:
        if entry['path'].startswith('data/ephe/'):
            file = ROOT/entry['path']
            if not file.exists() or hashlib.sha256(file.read_bytes()).hexdigest() != entry['sha256']:
                raise RuntimeError('Ephemeris data missing or checksum mismatch; refusing fallback.')
    return manifest['commit']

COMMIT = verify_data()

def position(lon):
    lon %= 360
    return {'longitude':lon,'sign':SIGNS[int(lon//30)],'sign_index':int(lon//30),'degree':lon%30}

def separation(a,b):
    return abs((a-b+180)%360-180)

def aspects_for(planets):
    result=[]
    for i,a in enumerate(planets):
        for b in planets[i+1:]:
            sep=separation(a['longitude'],b['longitude'])
            for key,label,angle,base_orb in ASPECTS:
                limit=min(base_orb,3) if {'true_node',*DWARF_IDS}.intersection((a['id'],b['id'])) else base_orb
                orb=abs(sep-angle)
                if orb <= limit:
                    result.append({'a':a['id'],'b':b['id'],'type':key,'label':label,'angle':angle,'orb':orb,'max_orb':limit})
    return sorted(result,key=lambda x:x['orb'])

def house_for(lon,cusps):
    # Ecliptic-longitude house assignment, not 3D mundane house position.
    for i,cusp in enumerate(cusps):
        if (lon-cusp)%360 < (cusps[(i+1)%12]-cusp)%360:
            return i+1
    raise CalculationError('Ugyldige husspidser.')

def calculate(utc,latitude,longitude,include_dwarfs=False):
    if abs(latitude)>=66:
        raise CalculationError('Placidus understøttes i denne MVP kun mellem 66° syd og 66° nord. Der skiftes ikke automatisk hussystem.')
    with LOCK:
        jd=(C.c_double*2)()
        error=C.create_string_buffer(256)
        status=lib.swe_utc_to_jd(utc.year,utc.month,utc.day,utc.hour,utc.minute,utc.second+utc.microsecond/1e6,1,jd,error)
        if status<0:
            raise CalculationError('Tidspunktet kunne ikke omregnes.')
        cusps=(C.c_double*13)()
        angles=(C.c_double*10)()
        status=lib.swe_houses_ex(jd[1],0,latitude,longitude,ord('P'),cusps,angles)
        if status<0:
            raise CalculationError('Placidus kan ikke beregnes her. Vælg et andet sted eller kontakt Stjernerne.')
        values=list(cusps)[1:]
        planets=positions_at(utc,include_dwarfs)['planets']
        for planet in planets: planet['house']=house_for(planet['longitude'],values)
    return {'planets':planets,'houses':[{'number':i+1,**position(lon)} for i,lon in enumerate(values)],
        'armc':angles[2],'ascendant':position(angles[0]),'midheaven':position(angles[1]),'aspects':aspects_for(planets),
        'calculation':{'engine':'Swiss Ephemeris','version':VERSION,'source_commit':COMMIT,
            'ephemeris':'Swiss compressed files / DE441','zodiac':'tropical','houses':'Placidus','node':'true',
            'coordinates':'geocentric apparent ecliptic, true equinox of date','jd_tt':jd[0],'jd_ut1':jd[1],
            'calendar':'Gregorian','house_assignment':'ecliptic longitude','tidal_acceleration':-25.936,
            'pre_1972_time_convention':'Swiss Ephemeris treats pre-1972 input as UT1',
            'orbs':dict((name,orb) for key,name,angle,orb in ASPECTS),'node_orb_max':3}}


def positions_at(utc,include_dwarfs=False,bodies=None):
    """Geocentric positions independent of observer location; no transit houses."""
    with LOCK:
        jd=(C.c_double*2)()
        error=C.create_string_buffer(256)
        status=lib.swe_utc_to_jd(utc.year,utc.month,utc.day,utc.hour,utc.minute,utc.second+utc.microsecond/1e6,1,jd,error)
        if status<0: raise CalculationError('Tidspunktet kunne ikke omregnes.')
        planets=[]
        for number,key,label,glyph in (bodies if bodies is not None else BODIES+(DWARFS if include_dwarfs else [])):
            coords=(C.c_double*6)()
            error=C.create_string_buffer(256)
            flags=lib.swe_calc(jd[0],number,SWIEPH|SPEED,coords,error)
            if flags<0 or not flags & SWIEPH:
                raise CalculationError(f'Efemeridedata for {label} er ikke tilgængelige på dette tidspunkt. Beregningen blev afbrudt.')
            planets.append({'id':key,'name':label,'glyph':glyph,**position(coords[0]),
                'latitude':coords[1],'distance_au':coords[2],'speed':coords[3],
                'retrograde':coords[3]<0,'flags':flags})
    return {'planets':planets,'jd_tt':jd[0],'jd_ut1':jd[1]}


def kundig_geometry(utc,longitude):
    """ARGUS-style meridian conjunctions: ecliptic latitude is deliberately zero.

    Positions are evaluated at each prospective cut, not frozen at birth or at
    the bounding culminations. Equal sidereal-time divisions use right ascension.
    """
    with LOCK:
        data=positions_at(utc,bodies=BODIES[:7])
        nut=(C.c_double*6)()
        error=C.create_string_buffer(256)
        if lib.swe_calc(data['jd_tt'],-1,0,nut,error)<0:
            raise CalculationError('Kündig-geometrien kunne ikke beregnes.')
        eps=math.radians(nut[0])
        armc=(lib.swe_sidtime(data['jd_ut1'])*15+longitude)%360
    planets={p['id']:p for p in data['planets']}
    ra={key:math.degrees(math.atan2(math.sin(math.radians(p['longitude']))*math.cos(eps),
                                   math.cos(math.radians(p['longitude']))))%360
        for key,p in planets.items()}
    mc=math.degrees(math.atan2(math.sin(math.radians(armc)),
                             math.cos(math.radians(armc))*math.cos(eps)))%360
    return {'armc':armc,'mc':mc,'ra':ra,'planets':planets}


def transit_aspects(transits,natal):
    """Cross-chart major aspects, 3° orb (2° for nodes). Natal points are fixed.
    Phase is instantaneous orb derivative, not a prediction of exact passage.
    """
    result=[]
    for t in transits:
        for n in natal:
            sep=separation(t['longitude'],n['longitude'])
            for key,label,angle,_ in ASPECTS:
                limit=2 if {'true_node',*DWARF_IDS}.intersection((t['id'],n['id'])) else 3
                orb=abs(sep-angle)
                if orb>limit: continue
                if orb<1e-7: phase='exact'
                elif abs(t['speed'])<1e-5: phase='stationary'
                else:
                    delta=(t['longitude']-n['longitude']+180)%360-180
                    derivative=(1 if sep>angle else -1)*(1 if delta>0 else -1)*t['speed']
                    phase='applying' if derivative<0 else 'separating'
                result.append({'transit':t['id'],'natal':n['id'],'type':key,'label':label,
                               'angle':angle,'orb':orb,'max_orb':limit,'phase':phase})
    return sorted(result,key=lambda a:a['orb'])


def synastry_aspects(a,b):
    """Static cross-chart geometry; no transit phase or compatibility scoring."""
    aspects=[]
    def points(c):
        return c['planets']+[{'id':'ascendant','name':'AC',**c['ascendant']},
                             {'id':'midheaven','name':'MC',**c['midheaven']}]
    restricted={'true_node','ascendant','midheaven',*DWARF_IDS}
    for x in points(a):
        for y in points(b):
            sep=separation(x['longitude'],y['longitude'])
            for key,label,angle,base_orb in ASPECTS:
                limit=min(base_orb,3) if restricted.intersection((x['id'],y['id'])) else base_orb
                orb=abs(sep-angle)
                if orb<=limit:
                    aspects.append({'a':x['id'],'b':y['id'],'type':key,'label':label,
                                    'angle':angle,'orb':orb,'max_orb':limit})
    return sorted(aspects,key=lambda x:(x['orb'],x['a'],x['b']))
