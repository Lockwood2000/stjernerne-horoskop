"""Solar longitude returns and direct secondary progressions with Naibod RA houses."""
import ctypes as C
from datetime import datetime,timedelta,timezone
from .engine import (lib,LOCK,DP,SWIEPH,BODIES,calculate,positions_at,position,
                     house_for,CalculationError,separation,transit_aspects)
from .solar_key import kundig_solar_key

YEAR_DAYS=365.2422
NAIBOD=0.98564733
lib.swe_houses_armc.argtypes=[C.c_double,C.c_double,C.c_double,C.c_int,DP,DP]
lib.swe_houses_armc.restype=C.c_int


def solar_return(birth_utc,natal,year,latitude,longitude,include_dwarfs=False):
    if year<birth_utc.year:raise CalculationError('Vælg et solreturår fra fødselsåret og frem.')
    try:anchor=birth_utc.replace(year=year)
    except ValueError:anchor=birth_utc.replace(year=year,day=28)
    target=natal['planets'][0]['longitude']
    stamp=anchor
    for _ in range(12):
        sun=positions_at(stamp,bodies=BODIES[:1])['planets'][0]
        error=(sun['longitude']-target+180)%360-180
        if abs(error)<1e-8:break
        stamp-=timedelta(days=error/sun['speed'])
    else:raise CalculationError('Solreturen konvergerede ikke.')
    if abs((stamp-anchor).total_seconds())>5*86400:
        raise CalculationError('Solreturen ligger uden for det forventede fødselsdagsinterval.')
    chart=calculate(stamp,latitude,longitude,include_dwarfs)
    chart['technique']={'type':'solar','year':year,'utc':stamp.isoformat(),
                        'solar_error_arcsec':separation(chart['planets'][0]['longitude'],target)*3600,
                        'method':'tropical apparent geocentric solar longitude; no precession correction'}
    return chart,stamp


def secondary_progressions(birth_utc,target_utc,natal,latitude,longitude,include_dwarfs=False,house_method='naibod'):
    if house_method not in ('naibod','kundig'):raise CalculationError('Ukendt progressionsmetode.')
    if target_utc<birth_utc:raise CalculationError('Progressionsdatoen skal være efter fødselstidspunktet.')
    age=(target_utc-birth_utc).total_seconds()/(86400*YEAR_DAYS)
    stamp=birth_utc+timedelta(days=age)
    chart=calculate(stamp,latitude,longitude,include_dwarfs)
    key=kundig_solar_key(natal) if house_method=='kundig' else None
    rate=key['degrees_per_year'] if key else NAIBOD
    armc=(natal['armc']+rate*age)%360
    with LOCK:
        values=(C.c_double*6)();error=C.create_string_buffer(256)
        if lib.swe_calc(chart['calculation']['jd_tt'],-1,SWIEPH,values,error)<0:
            raise CalculationError('Ekliptikahældningen kunne ikke beregnes.')
        eps=values[0]
        cusps=(C.c_double*13)();angles=(C.c_double*10)()
        if lib.swe_houses_armc(armc,latitude,eps,ord('P'),cusps,angles)<0:
            raise CalculationError('Progressionshuse kunne ikke beregnes med Placidus.')
    longs=list(cusps)[1:]
    chart.update(armc=armc,ascendant=position(angles[0]),midheaven=position(angles[1]),
                 houses=[{'number':i+1,**position(lon)} for i,lon in enumerate(longs)])
    for planet in chart['planets']:
        planet['house']=house_for(planet['longitude'],longs)
        planet['ephemeris_speed']=planet['speed']
        planet['speed']/=YEAR_DAYS # per lived day; retrograde sign is unchanged
    chart['technique']={'type':'progressed','target_utc':target_utc.isoformat(),'progressed_utc':stamp.isoformat(),
                        'age_years':age,'days_per_year':YEAR_DAYS,'house_method':('Kündig' if key else 'Naibod')+' in right ascension',
                        'house_method_id':house_method,'degrees_per_year':rate,'arc_degrees':rate*age,
                        'naibod_degrees_per_year':NAIBOD,'armc':armc,'obliquity':eps,
                        'speed_unit':'degrees per lived day'}
    if key:chart['technique']['solar_key']=key
    chart['natal_aspects']=transit_aspects(chart['planets'],natal['planets'])
    return chart,stamp
