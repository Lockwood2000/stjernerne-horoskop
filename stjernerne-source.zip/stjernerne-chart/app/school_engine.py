"""Teaching calculations built on the existing, pinned Swiss Ephemeris binding.

No school-wide method is implied by the editable starting profiles. All numerical
conventions travel with the result. Symbolic charts are labelled as such.
"""
import ctypes as C
from datetime import datetime, timedelta, timezone
from itertools import combinations
import math
from pathlib import Path
import sqlite3
from .engine import lib, LOCK, SWIEPH, SPEED, DP, VERSION, COMMIT, positions_at, position, house_for, separation, CalculationError
from .timing import resolve_time, load_zone, TimeProblem
from .techniques import YEAR_DAYS, NAIBOD
from .solar_key import kundig_solar_key
from .school_models import Settings, BirthInput, HOUSE_NAMES

ROOT=Path(__file__).resolve().parents[1]
EQUATORIAL=2048
BODY_NUMBERS={'sun':0,'moon':1,'mercury':2,'venus':3,'mars':4,'jupiter':5,'saturn':6,'uranus':7,'neptune':8,'pluto':9,'north_node':11,'chiron':15,'ceres':17,'pallas':18,'juno':19,'vesta':20,'eris':146199,'haumea':146108,'makemake':146472}
LABELS={'sun':'Sun','moon':'Moon','mercury':'Mercury','venus':'Venus','mars':'Mars','jupiter':'Jupiter','saturn':'Saturn','uranus':'Uranus','neptune':'Neptune','pluto':'Pluto','north_node':'North Node','south_node':'South Node','chiron':'Chiron','ceres':'Ceres','pallas':'Pallas','juno':'Juno','vesta':'Vesta','eris':'Eris','haumea':'Haumea','makemake':'Makemake'}
TRADITIONAL=['mars','venus','mercury','moon','sun','mercury','venus','mars','jupiter','saturn','saturn','jupiter']
MODERN=['mars','venus','mercury','moon','sun','mercury','venus','pluto','jupiter','saturn','uranus','neptune']
EXALT={'sun':0,'moon':1,'mercury':5,'venus':11,'mars':9,'jupiter':3,'saturn':6}
ASPECT_NAMES={0:'conjunction',30:'semisextile',45:'semisquare',60:'sextile',72:'quintile',90:'square',120:'trine',135:'sesquiquadrate',144:'biquintile',150:'quincunx',180:'opposition'}

def place_for(birth):
    if birth.place_id:
        with sqlite3.connect(f'file:{ROOT}/data/places.sqlite?mode=ro',uri=True) as con:
            con.row_factory=sqlite3.Row
            row=con.execute('SELECT * FROM places WHERE id=?',(birth.place_id,)).fetchone()
        if row is None:
            raise CalculationError('Choose a place from the search results.')
        return dict(row)
    return {'name':birth.place_name or 'Manual coordinates','latitude':birth.latitude,'longitude':birth.longitude,'timezone':birth.timezone}

def timing_for(birth,place):
    clock=birth.time.isoformat() if birth.time else '12:00:00'
    utc,timing=resolve_time(birth.date.isoformat(),clock,place['timezone'],birth.fold,birth.offset_minutes,birth.offset_source)
    timing.update(confidence=birth.confidence,nominal_time_only=birth.confidence!='exact')
    if birth.confidence=='unknown':
        timing['warnings'].append('Unknown birth time: local noon is a calculation reference only. Angles and birth houses are omitted; positions may vary during the day.')
    elif birth.confidence=='approximate':
        timing['warnings'].append(f'Approximate birth time: ±{birth.uncertainty_minutes} minutes. Angles and house assignments are provisional.')
    return utc,timing

def obliquity(jd):
    with LOCK:
        values=(C.c_double*6)(); error=C.create_string_buffer(256)
        if lib.swe_calc(jd,-1,SWIEPH,values,error)<0:
            raise CalculationError('Obliquity is unavailable.')
        return values[0]

def positions(utc,settings):
    selected=[key for key in settings.bodies if key!='south_node']
    if 'south_node' in settings.bodies and 'north_node' not in selected:
        selected.append('north_node')
    entries=[(10 if key=='north_node' and settings.node=='mean' else BODY_NUMBERS[key],key,LABELS[key],key) for key in selected]
    data=positions_at(utc,bodies=entries)
    eps=obliquity(data['jd_tt'])
    with LOCK:
        for p,entry in zip(data['planets'],entries):
            values=(C.c_double*6)();error=C.create_string_buffer(256)
            flags=lib.swe_calc(data['jd_tt'],entry[0],SWIEPH|SPEED|EQUATORIAL,values,error)
            if flags<0 or not flags&SWIEPH:
                raise CalculationError('Declination data is unavailable.')
            p.update(declination=values[1],declination_speed=values[4],out_of_bounds=abs(values[1])>eps)
    if 'south_node' in settings.bodies:
        north=next(p for p in data['planets'] if p['id']=='north_node')
        data['planets'].append({**north,**position(north['longitude']+180),'id':'south_node','name':'South Node','latitude':-north['latitude'],'declination':-north['declination'],'declination_speed':-north['declination_speed']})
    data['planets']=[p for key in settings.bodies for p in data['planets'] if p['id']==key]
    data['obliquity']=eps
    return data

def houses_at(jd,lat,lon,system,armc=None,eps=None):
    if system in ('P','K') and abs(lat)>=66:
        raise CalculationError('Placidus/Koch is restricted to latitudes below 66° in this version. Select Whole Sign or Equal explicitly.')
    with LOCK:
        cusps=(C.c_double*13)();angles=(C.c_double*10)()
        status=(lib.swe_houses_ex(jd,0,lat,lon,ord(system),cusps,angles) if armc is None else lib.swe_houses_armc(armc,lat,eps,ord(system),cusps,angles))
        if status<0:
            raise CalculationError('The selected house system is unavailable here; no fallback has been used.')
    return {'houses':[{'number':i+1,**position(x)} for i,x in enumerate(list(cusps)[1:])],
            'ascendant':position(angles[0]),'midheaven':position(angles[1]),'armc':angles[2]}

def empty_houses():
    return {'houses':[],'ascendant':None,'midheaven':None,'armc':None}

def points(chart,include_angles=True):
    return chart['planets']+([{'id':key,'name':label,**chart[key]} for key,label in [('ascendant','AC'),('midheaven','MC')] if chart.get(key)] if include_angles else [])

def aspects(a,b,settings,same=False):
    result=[]
    pairs=combinations(a,2) if same else ((x,y) for x in a for y in b)
    for x,y in pairs:
        if same and {x['id'],y['id']}=={'north_node','south_node'}:
            continue
        distance=separation(x['longitude'],y['longitude'])
        for angle,limit in settings.orbs.items():
            angle=int(angle);orb=abs(distance-angle)
            if orb<=limit+1e-10:
                result.append({'a':x['id'],'b':y['id'],'angle':angle,'type':ASPECT_NAMES[angle],'orb':orb,'max_orb':limit})
    return sorted(result,key=lambda x:(x['orb'],x['a'],x['b']))

def parallels(a,b,settings,same=False):
    rows=[]
    pairs=combinations(a,2) if same else ((x,y) for x in a for y in b)
    for x,y in pairs:
        if x.get('declination') is None or y.get('declination') is None or same and {x['id'],y['id']}=={'north_node','south_node'}:
            continue
        for kind,orb in [('parallel',abs(x['declination']-y['declination'])),('contraparallel',abs(x['declination']+y['declination']))]:
            if orb<=settings.declination_orb:
                rows.append({'a':x['id'],'b':y['id'],'type':kind,'orb':orb})
    return sorted(rows,key=lambda x:x['orb'])

def phase(planets):
    by_id={p['id']:p for p in planets}
    angle=(by_id['moon']['longitude']-by_id['sun']['longitude'])%360
    return {'angle':angle,'index':int(angle//45),'basis':'Moon minus Sun in this chart, eight 45° sectors'}

def teaching(chart,settings):
    rulers=TRADITIONAL if settings.ruler_mode=='traditional' else MODERN
    by_id={p['id']:p for p in chart['planets']}
    counts={'elements':[0]*4,'qualities':[0]*3,'polarities':[0]*2,'counted_bodies':[]}
    for p in chart['planets']:
        s=p['sign_index'];key=p['id']
        p['dispositor']=rulers[s]
        p['rules_houses']=[h['number'] for h in chart['houses'] if rulers[h['sign_index']]==key]
        p['dignities']=[]
        if TRADITIONAL[s]==key:p['dignities'].append('domicile')
        if TRADITIONAL[(s+6)%12]==key:p['dignities'].append('detriment')
        if key in EXALT:
            if s==EXALT[key]:p['dignities'].append('exaltation')
            if s==(EXALT[key]+6)%12:p['dignities'].append('fall')
        chain=[];cursor=key
        while cursor in by_id and cursor not in chain:
            chain.append(cursor);cursor=rulers[by_id[cursor]['sign_index']]
        p['dispositor_chain']=chain+[cursor]
        if key in list(BODY_NUMBERS)[:10]:
            counts['elements'][s%4]+=1;counts['qualities'][s%3]+=1;counts['polarities'][s%2]+=1;counts['counted_bodies'].append(key)
    counts['dignity_basis']='Traditional domicile, detriment, exaltation and fall only; no terms, faces or triplicity scoring.'
    return counts

def pattern_list(planets,settings):
    ps=[p for p in planets if p['id'] in list(BODY_NUMBERS)[:10]]
    edges={(frozenset((a['a'],a['b'])),a['angle']) for a in aspects(ps,ps,settings,True)}
    has=lambda a,b,angle:(frozenset((a['id'],b['id'])),angle) in edges
    found=[]
    for group in combinations(ps,3):
        for apex in group:
            left,right=[x for x in group if x is not apex]
            kind=None
            if has(left,right,180) and has(apex,left,90) and has(apex,right,90):kind='t_square'
            if has(left,right,60) and has(apex,left,150) and has(apex,right,150):kind='yod'
            if has(left,right,120) and has(apex,left,60) and has(apex,right,60):kind='talent_triangle'
            if kind:found.append({'type':kind,'bodies':[apex['id'],left['id'],right['id']]})
        if all(has(a,b,120) for a,b in combinations(group,2)):
            found.append({'type':'grand_trine','bodies':[p['id'] for p in group]})
    for group in combinations(ps,4):
        if sum(has(a,b,180) for a,b in combinations(group,2))==2 and sum(has(a,b,90) for a,b in combinations(group,2))==4:
            found.append({'type':'grand_cross','bodies':[p['id'] for p in group]})
        for tail in group:
            tri=[p for p in group if p is not tail]
            if all(has(a,b,120) for a,b in combinations(tri,2)) and sum(has(tail,p,180) for p in tri)==1 and sum(has(tail,p,60) for p in tri)==2:
                found.append({'type':'kite','bodies':[p['id'] for p in group]})
    return found

def finish(chart,settings):
    cusps=[x['longitude'] for x in chart['houses']]
    for p in chart['planets']:
        p['house']=house_for(p['longitude'],cusps) if cusps else None
    chart['aspects']=aspects(points(chart,settings.include_angles),[],settings,True)
    chart['parallels']=parallels(chart['planets'],[],settings,True)
    chart['phase']=phase(chart['planets'])
    chart['teaching']=teaching(chart,settings)
    chart['patterns']=pattern_list(chart['planets'],settings)
    chart['settings']=settings.model_dump()
    return chart

def natal(birth,settings,solar=False):
    place=place_for(birth);utc,timing=timing_for(birth,place)
    data=positions(utc,settings)
    data.update(empty_houses() if birth.confidence=='unknown' or solar else houses_at(data['jd_ut1'],place['latitude'],place['longitude'],settings.house_system))
    if solar:
        lon=next(p['longitude'] for p in data['planets'] if p['id']=='sun')
        data['houses']=[{'number':i+1,**position(lon+i*30)} for i in range(12)]
        data['synthetic_houses']='Sun as cusp 1, equal 30° houses; not actual birth houses or a solar return.'
    data.update(birth=timing,place=place,kind='solar_chart' if solar else 'natal',calculation={'engine':'Swiss Ephemeris','version':VERSION,'source_commit':COMMIT,'jd_tt':data['jd_tt'],'zodiac':'tropical','houses':HOUSE_NAMES[settings.house_system] if data['ascendant'] else ('solar equal' if solar else 'omitted'),'node':settings.node})
    if birth.confidence!='exact':
        if birth.confidence=='unknown':
            zone=load_zone(place['timezone'])
            if birth.offset_minutes is not None:zone=timezone(timedelta(minutes=birth.offset_minutes))
            start=datetime.combine(birth.date,datetime.min.time(),tzinfo=zone).astimezone(timezone.utc)
            end=datetime.combine(birth.date+timedelta(days=1),datetime.min.time(),tzinfo=zone).astimezone(timezone.utc)
        else:start,end=utc-timedelta(minutes=birth.uncertainty_minutes),utc+timedelta(minutes=birth.uncertainty_minutes)
        samples=[positions(start+(end-start)*i/24,settings) for i in range(25)]
        for p in data['planets']:
            diffs=[(next(q['longitude'] for q in sample['planets'] if q['id']==p['id'])-p['longitude']+180)%360-180 for sample in samples]
            p['sampled_range']={'from':(p['longitude']+min(diffs))%360,'to':(p['longitude']+max(diffs))%360,'width':max(diffs)-min(diffs)}
        data['uncertainty']={'from_utc':start.isoformat(),'to_utc':end.isoformat(),'sample_count':25,'meaning':'Sampled position range; not a rigorous bound between samples. All derived teaching indicators use the nominal time.'}
    return finish(data,settings)

def target_time(target):
    return resolve_time(target.date.isoformat(),target.time.isoformat(),target.timezone,target.fold)

def progressed(base,utc,settings):
    born=datetime.fromisoformat(base['birth']['utc'])
    if utc<born:raise CalculationError('The progression date must follow birth.')
    age=(utc-born).total_seconds()/(86400*YEAR_DAYS);stamp=born+timedelta(days=age)
    data=positions(stamp,settings)
    key=kundig_solar_key(base,settings.progression_method) if settings.progression_method!='naibod' else None
    rate=key['degrees_per_year'] if key else NAIBOD
    data.update(houses_at(data['jd_ut1'],base['place']['latitude'],base['place']['longitude'],settings.house_system,(base['armc']+rate*age)%360,data['obliquity']))
    for p in data['planets']:
        p['ephemeris_speed']=p['speed'];p['speed']/=YEAR_DAYS;p['declination_speed']/=YEAR_DAYS
    data.update(kind='progressed',birth={'utc':stamp.isoformat(),'confidence':base['birth']['confidence']},place=base['place'],technique={'target_utc':utc.isoformat(),'ephemeris_utc':stamp.isoformat(),'year_days':YEAR_DAYS,'age_years':age,'axis_method':settings.progression_method,'degrees_per_year':rate,'axis_arc_degrees':rate*age,'axis_basis':'Natal ARMC plus key times elapsed tropical years; birth latitude and progressed obliquity.','solar_key':key})
    return finish(data,settings)

def solar_arc(base,utc,settings):
    prog=progressed(base,utc,settings)
    sun=lambda c:next(p['longitude'] for p in c['planets'] if p['id']=='sun')
    arc=(sun(prog)-sun(base))%360
    data={'planets':[{**p,**position(p['longitude']+arc),'declination':None,'declination_speed':None,'out_of_bounds':None,'speed':None,'retrograde':None} for p in base['planets']],
          'houses':[{**h,**position(h['longitude']+arc)} for h in base['houses']],
          'ascendant':position(base['ascendant']['longitude']+arc),'midheaven':position(base['midheaven']['longitude']+arc),'armc':None,
          'kind':'solar_arc','birth':{'utc':utc.isoformat(),'confidence':base['birth']['confidence']},'place':base['place'],
          'technique':{'arc':arc,'target_utc':utc.isoformat(),'ephemeris_utc':prog['technique']['ephemeris_utc'],'year_days':YEAR_DAYS,'natal_sun_longitude':sun(base),'progressed_sun_longitude':sun(prog),'method':'Direct true solar arc: progressed Sun minus natal Sun in tropical ecliptic longitude. Applied equally to natal planets, angles and cusps. No directed declinations or physical retrograde status.'}}
    return finish(data,settings)

def midpoint(a,b):
    delta=(b-a+180)%360-180
    if abs(abs(delta)-180)<1e-8:raise CalculationError('An exact opposition has two equally valid midpoints. This composite needs an explicit midpoint convention for that case.')
    return (a+delta/2)%360

def composite(a,b,settings):
    ps=[]
    for x,y in zip(a['planets'],b['planets']):
        ps.append({'id':x['id'],'name':x['name'],**position(midpoint(x['longitude'],y['longitude'])),'latitude':(x['latitude']+y['latitude'])/2,'speed':None,'retrograde':None,'declination':None,'out_of_bounds':None})
    houses=empty_houses()
    if a['armc'] is not None and b['armc'] is not None:
        houses=houses_at(a['jd_ut1'],(a['place']['latitude']+b['place']['latitude'])/2,0,settings.house_system,midpoint(a['armc'],b['armc']),(a['obliquity']+b['obliquity'])/2)
    data={**houses,'planets':ps,'kind':'composite','birth':{'confidence':'unknown' if not houses['houses'] else 'approximate' if 'approximate' in (a['birth']['confidence'],b['birth']['confidence']) else 'exact'},'place':a['place'],
          'technique':{'method':'Short-arc longitude midpoints; houses from short-arc midpoint ARMC, mean birth latitude and mean obliquity. Symbolic chart, no physical speed or declination. Houses omitted if either birth time is unknown.'}}
    return finish(data,settings)

def solar_return(base,year,settings,place=None):
    born=datetime.fromisoformat(base['birth']['utc'])
    # Choose the birthday in the recorded local calendar. A New Year's birth
    # may belong to a different UTC year; replacing the UTC year picks the
    # adjacent annual return in that case. This is only the search anchor.
    local_born=datetime.fromisoformat(base['birth'].get('local',born.isoformat()))
    if year<local_born.year:raise CalculationError('The return year must not precede birth.')
    try:stamp=local_born.replace(year=year).astimezone(timezone.utc)
    except ValueError:stamp=local_born.replace(year=year,day=28).astimezone(timezone.utc)
    anchor=stamp;target=next(p['longitude'] for p in base['planets'] if p['id']=='sun')
    for _ in range(15):
        sun=positions_at(stamp,bodies=[(0,'sun','Sun','sun')])['planets'][0]
        error=(sun['longitude']-target+180)%360-180
        if abs(error)<1e-8:break
        stamp-=timedelta(days=error/sun['speed'])
    else:raise CalculationError('The solar return did not converge.')
    if abs((stamp-anchor).total_seconds())>5*86400:raise CalculationError('Solar return outside the expected interval.')
    where=place or base['place'];data=positions(stamp,settings)
    data.update(houses_at(data['jd_ut1'],where['latitude'],where['longitude'],settings.house_system))
    residual=separation(next(p['longitude'] for p in data['planets'] if p['id']=='sun'),target)
    data.update(kind='solar_return',birth={'utc':stamp.isoformat(),'local':stamp.astimezone(load_zone(where['timezone'])).isoformat(),'confidence':base['birth']['confidence']},place=where,technique={'method':'Tropical geocentric apparent solar longitude; no precession correction. Selected location determines houses.','year':year,'year_basis':'Return nearest the birthday in the recorded birth calendar; 29 February uses 28 February as search anchor only.','location_basis':'selected_place' if place else 'birthplace','utc':stamp.isoformat(),'residual_degrees':residual,'natal_sun_longitude':target})
    return finish(data,settings)

def build(request):
    s=request.settings;base=natal(request.birth,s,request.mode=='solar_chart')
    layers=[base];cross=[];other=None
    if request.mode=='event':base['kind']='event'
    if request.mode in ('transits','progressed','combined','solar_arc'):
        utc,timing=target_time(request.target)
        if request.mode in ('progressed','combined'):layers.append(progressed(base,utc,s))
        if request.mode=='solar_arc':layers.append(solar_arc(base,utc,s))
        if request.mode in ('transits','combined'):
            trans=positions(utc,s);trans.update(empty_houses());trans.update(kind='transits',birth=timing,place=base['place']);layers.append(finish(trans,s))
        for idx,layer in enumerate(layers[1:],1):
            cross.append({'from':idx,'to':0,'aspects':aspects(points(layer,s.include_angles),points(base,s.include_angles),s),'parallels':parallels(layer['planets'],base['planets'],s)})
        if len(layers)==3:
            cross.append({'from':2,'to':1,'aspects':aspects(layers[2]['planets'],points(layers[1],s.include_angles),s),'parallels':parallels(layers[2]['planets'],layers[1]['planets'],s)})
    elif request.mode in ('synastry','composite','compare'):
        other=natal(request.other,s)
        if request.mode=='composite':layers=[composite(base,other,s)]
        else:layers.append(other)
        if request.mode=='synastry':
            cross=[{'from':1,'to':0,'aspects':aspects(points(other,s.include_angles),points(base,s.include_angles),s),'parallels':parallels(other['planets'],base['planets'],s)}]
            for source,target in [(base,other),(other,base)]:
                cusps=[h['longitude'] for h in target['houses']]
                for p in source['planets']:p['house_in_other']=house_for(p['longitude'],cusps) if cusps else None
    elif request.mode=='solar_return':
        place=place_for(BirthInput(date=request.birth.date,time=request.birth.time,confidence=request.birth.confidence,place_id=request.return_place_id)) if request.return_place_id else None
        layers=[solar_return(base,request.return_year,s,place)]
    return {'contract':'school-chart-1','school':request.school,'mode':request.mode,'settings':s.model_dump(),'layers':layers,'cross_aspects':cross,'birth_places':[base['place']]+([other['place']] if other else []),'birth_times':[base['birth']]+([other['birth']] if other else []),'input':request.model_dump(mode='json'),'warnings':list(dict.fromkeys(base['birth']['warnings']+(other['birth']['warnings'] if other else []))),'method_note':'Editable teaching profile; no endorsement or universal school defaults are implied.'}
