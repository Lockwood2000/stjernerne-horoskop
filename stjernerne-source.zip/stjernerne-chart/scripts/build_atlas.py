"""Offline GeoNames snapshot: cities >=15000 globally, >=500 in Nordic countries."""
from pathlib import Path
import json
import sqlite3
import unicodedata
import geonamescache

ROOT = Path(__file__).resolve().parents[1]
def normalize(s):
    s = s.lower().translate(str.maketrans({'ø':'o','æ':'ae','ð':'d','þ':'th'}))
    return ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c))

def main():
    gc = geonamescache.GeonamesCache(min_city_population=500)
    countries = gc.get_countries()
    cities = gc.get_cities()
    db = ROOT/'data/places.sqlite'
    if db.exists():
        db.unlink()
    con = sqlite3.connect(db)
    con.executescript('CREATE TABLE places (id TEXT PRIMARY KEY, name TEXT, country TEXT, region TEXT, latitude REAL, longitude REAL, timezone TEXT, population INTEGER); CREATE VIRTUAL TABLE search USING fts5(id UNINDEXED, names, tokenize="unicode61 remove_diacritics 2");')
    nordics = {'DK','SE','NO','FI','IS','FO','GL'}
    names = {'2618425':'København','2624652':'Aarhus'}
    count = 0
    for key, c in cities.items():
        if c['population'] < 15000 and c['countrycode'] not in nordics:
            continue
        name = names.get(key, c['name'])
        country = countries[c['countrycode']]['name']
        con.execute('INSERT INTO places VALUES (?,?,?,?,?,?,?,?)', (key,name,country,c['admin1code'],c['latitude'],c['longitude'],c['timezone'],c['population']))
        aliases = ' '.join([name,country,c['countrycode'],*c['alternatenames']])
        con.execute('INSERT INTO search VALUES (?,?)', (key,normalize(aliases)))
        count += 1
    con.commit()
    con.close()
    (ROOT/'data/atlas-manifest.json').write_text(json.dumps({'count':count,'source':'GeoNames via geonamescache 3.0.2','license':'CC-BY-4.0','coverage':'Cities >=15000 worldwide; >=500 in DK, SE, NO, FI, IS, FO, GL. Manual coordinates available.','url':'https://www.geonames.org/','historical_boundaries':'Not a historical atlas. IANA zone assignment requires local verification for historical births.'},indent=2)+'\n')
    print(f'Built offline atlas with {count} places')
if __name__ == '__main__':
    main()
