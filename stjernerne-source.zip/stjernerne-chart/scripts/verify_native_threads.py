"""Linux build regression: ephemeris path and DE441 settings across API workers."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from app.engine import calculate,separation

stamps=[datetime(y,6,15,12,30,tzinfo=timezone.utc) for y in (1900,1950,1990,2026)]
def calc(stamp):return calculate(stamp,55.67594,12.56553,True)
reference=[calc(stamp) for stamp in stamps]
with ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(calc,stamps))
for a,b in zip(reference,results):
    assert len(b['planets'])==16
    for p,q in zip(a['planets'],b['planets']):
        assert q['flags']&2
        assert separation(p['longitude'],q['longitude'])<1e-10
    assert a['calculation']['jd_tt']==b['calculation']['jd_tt']
print('Native worker-thread verification passed: 4 epochs, 16 bodies, DE441, no fallback.')
