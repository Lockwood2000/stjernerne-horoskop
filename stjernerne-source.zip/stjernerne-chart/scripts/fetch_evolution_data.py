"""Fetch four individual Swiss-format asteroid files from the retained mirror."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
FILES=['ast90/se90377.se1','ast50/se50000.se1','ast90/se90482.se1','ast225/s225088.se1']


def fetch(name):
    url='https://ephe.scryr.io/ephe/'+name
    data=urllib.request.urlopen(url,timeout=45).read()
    if len(data)<1000 or data.lstrip().startswith(b'<'):raise ValueError('Invalid ephemeris file')
    path=ROOT/'data/ephe'/name
    path.parent.mkdir(exist_ok=True)
    path.write_bytes(data)
    print(name,len(data),'bytes',flush=True)
    return {'path':'data/ephe/'+name,'url':url,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}


if __name__=='__main__':
    with ThreadPoolExecutor(max_workers=4) as pool:
        entries=list(pool.map(fetch,FILES))
    (ROOT/'data/evolution-manifest.json').write_text(json.dumps({
        'source':'Swiss Ephemeris asteroid files, downloaded from the same ephe.scryr.io mirror used by the retained generator',
        'files':entries},indent=2)+'\n')
