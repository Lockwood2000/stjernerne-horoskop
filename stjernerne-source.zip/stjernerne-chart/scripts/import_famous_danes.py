"""Read the reviewed workbook; preserve archive values and provenance."""
import json, sys, zipfile, xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from pathlib import Path

ns={'m':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
def coordinate(value):
    degrees, minutes, direction=value.split()
    return (int(degrees)+int(minutes)/60)*(-1 if direction in ('S','W') else 1)
def offset(value):
    hours, minutes, direction=value.split()
    return (int(hours)*60+int(minutes))*(-1 if direction=='W' else 1)
def extract(path):
    with zipfile.ZipFile(path) as z:
        strings=[''.join(e.itertext()) for e in ET.fromstring(z.read('xl/sharedStrings.xml')).findall('m:si',ns)]
        sheet=ET.fromstring(z.read('xl/worksheets/sheet1.xml'))
        records=[]
        for row in sheet.findall('m:sheetData/m:row',ns):
            if int(row.attrib['r'])<10: continue
            cells={}
            for c in row:
                col=''.join(x for x in c.attrib['r'] if x.isalpha())
                v=c.find('m:v',ns); value=v.text if v is not None else ''
                if c.attrib.get('t')=='s':value=strings[int(value)]
                elif c.attrib.get('t')=='inlineStr':value=''.join(c.find('m:is',ns).itertext())
                cells[col]=value
            if not cells.get('A'):continue
            d=cells['B'].split('T')[0]
            if '-' not in d:d=(datetime(1899,12,30)+timedelta(days=float(d))).date().isoformat()
            seconds=round(float(cells['C'])*86400)
            t=f'{seconds//3600:02d}:{seconds//60%60:02d}:{seconds%60:02d}'
            records.append(dict(id=f'archive-{len(records)+1}',name=cells['A'],date=d,time=t,
                place=cells['D'],rating=cells['E'],zone=cells['F'],latitude=coordinate(cells['G']),
                longitude=coordinate(cells['H']),offset=offset(cells['F']),note=cells.get('I',''),
                sources=[x for x in cells.get('J','').splitlines() if x.startswith('https://')]))
        return records
if __name__=='__main__':
    records=extract(sys.argv[1]);assert len(records)==189
    output=Path(__file__).resolve().parents[1]/'static/famous-danes.json'
    output.write_text(json.dumps(records,ensure_ascii=False,indent=2)+'\n')
    print(f'{len(records)} reviewed records exported; {sum(r["date"]<"1900-01-01" for r in records)} before 1900.')
