"""Generate auditable same-engine CLI fixture and an independent-engine comparison."""
from datetime import datetime,timezone
import json
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.engine import calculate,separation,COMMIT,VERSION
import astronomy

epoch='1990-06-15T12:30:00'
args=[str(ROOT/'build/swetest'),'-b15.6.1990','-utc12:30:00','-p0123456789t','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPls','-g,','-head','-house12.56553,55.67594,P']
output=subprocess.check_output(args,text=True)
(ROOT/'tests/swetest-reference.txt').write_text(output)
rows=[s.split(',') for s in output.splitlines()]
fixture={'source':'Official swetest CLI (same engine; validates binding, not independent astronomy)',
    'command':'swetest -b15.6.1990 -utc12:30:00 -p0123456789t -eswe -tidacc-25.936 -edirdata/ephe -fPls -g, -head -house12.56553,55.67594,P',
    'swisseph_commit':COMMIT,'version':VERSION,'utc':epoch,'latitude':55.67594,'longitude':12.56553,
    'planets':[{'name':s[0].strip(),'longitude':float(s[1]),'speed':float(s[2])} for s in rows[:11]],
    'houses':[float(s[1]) for s in rows[11:23]],'ascendant':float(rows[23][1]),'midheaven':float(rows[24][1])}
(ROOT/'tests/reference.json').write_text(json.dumps(fixture,indent=2)+'\n')
comparisons=[]
for t in ['1900-01-01T12:00:00','1950-07-01T00:00:00',epoch,'2000-01-01T12:00:00','2024-02-29T23:59:59']:
    result=calculate(datetime.fromisoformat(t).replace(tzinfo=timezone.utc),55.67594,12.56553)
    for planet in result['planets'][:-1]:
        other=astronomy.Ecliptic(astronomy.GeoVector(getattr(astronomy.Body,planet['id'].capitalize()),astronomy.Time(t+'Z'),True))
        comparisons.append({'utc':t,'body':planet['id'],'swiss_longitude':planet['longitude'],'astronomy_engine_longitude':other.elon,'difference_arcseconds':separation(other.elon,planet['longitude'])*3600})
report={'reference_engine':'Astronomy Engine 2.1.19 (independent algorithms; MIT)','coordinate_convention':'Apparent geocentric true ecliptic/equinox of date; each engine uses its own time model','tolerance_arcseconds':60,'max_difference_arcseconds':max(r['difference_arcseconds'] for r in comparisons),'comparisons':comparisons,'not_covered':'True Node and all Placidus cusps lack a second independent engine comparison. AC/MC have independent geometry tests.'}
(ROOT/'docs/verification.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'{len(comparisons)} comparisons; max difference {report["max_difference_arcseconds"]:.4f} arcseconds')
