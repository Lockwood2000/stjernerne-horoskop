"""Build the pinned, unmodified Swiss Ephemeris C library and reference CLI."""
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'vendor/swisseph'
OUT = ROOT / 'build'
OUT.mkdir(exist_ok=True)
sources = ['swecl.c', 'swedate.c', 'swehel.c', 'swehouse.c', 'swejpl.c',
           'swemmoon.c', 'swemplan.c', 'sweph.c', 'swephlib.c']
shared = '-dynamiclib' if sys.platform == 'darwin' else '-shared'
lib = 'libswe.dylib' if sys.platform == 'darwin' else 'libswe.so'
# All calls are serialized by the binding's process-wide RLock.
# Linux TLS must be disabled so initialization also applies to API worker threads.
base = ['cc', '-O2', '-fPIC', '-DTLSOFF', '-I', str(SRC)]
subprocess.run(base + [shared] + [str(SRC/s) for s in sources] + ['-lm', '-o', str(OUT/lib)], check=True)
subprocess.run(base + [str(SRC/'swetest.c')] + [str(SRC/s) for s in sources] + ['-lm', '-o', str(OUT/'swetest')], check=True)
print(f'Built {lib} and swetest')
