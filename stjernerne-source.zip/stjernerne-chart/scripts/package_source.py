"""Create the Corresponding Source offered at /source; never include local secrets."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'source' / 'stjernerne-source.zip'
# Explicit allowlist. Work directories, credentials, logs and personal data are excluded.
DIRECTORIES = ('app', 'static', 'data', 'vendor', 'scripts', 'tests', 'docs', 'third-party-licenses', 'deploy')
FILES = ('LICENSE', 'COPYING', 'THIRD_PARTY.md', 'README.md', 'Dockerfile', '.dockerignore',
         'requirements.lock', 'requirements-dev.lock', 'package.json', 'render.yaml', 'Start lokalt.command')

def package():
    OUT.parent.mkdir(exist_ok=True)
    members = [ROOT / name for name in FILES if (ROOT / name).is_file()]
    for directory in DIRECTORIES:
        members.extend(p for p in (ROOT / directory).rglob('*') if p.is_file()
                       and not any(x in ('__pycache__', '.git', '.pytest_cache') for x in p.parts)
                       and p.suffix != '.pyc')
    with ZipFile(OUT, 'w', ZIP_DEFLATED) as archive:
        for path in sorted(members):
            archive.write(path, 'stjernerne-chart/' + path.relative_to(ROOT).as_posix())
    print(f'{OUT.name}: {len(members)} files, {OUT.stat().st_size:,} bytes')

if __name__ == '__main__':
    package()
