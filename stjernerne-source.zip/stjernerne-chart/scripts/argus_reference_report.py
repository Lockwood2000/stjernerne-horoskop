"""Print an audit against externally transcribed ARGUS values; never rewrite them."""
from datetime import datetime
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.engine import separation
from app.main import Birth, chart
from app.techniques import secondary_progressions


def degrees(dms):
    return dms[0] + dms[1] / 60 + dms[2] / 3600


def compute(birth, target_utc):
    natal = chart(Birth(**birth))
    variants = {}
    for method in ('kundig_argus', 'kundig'):
        result, _ = secondary_progressions(datetime.fromisoformat(natal['birth']['utc']),
            datetime.fromisoformat(target_utc), natal, birth['latitude'], birth['longitude'], False, method)
        variants[method] = {
            'solar_key_degrees_per_year': result['technique']['degrees_per_year'],
            'natal_sun_longitude': result['technique']['solar_key']['sun_longitude'],
            'natal_armc': natal['armc'], 'age_years': result['technique']['age_years'],
            'progressed_armc': result['armc'],
            'progressed_mc': result['midheaven']['longitude'],
            'progressed_ac': result['ascendant']['longitude'],
        }
    return natal, variants


def report():
    reference = json.loads((ROOT / 'tests/argus-progressions-published-reference.json').read_text())
    natal, variants = compute(reference['birth'], reference['target_utc'])
    for variant in variants.values():
        rows = []
        for row in reference['printed_aspects']:
            actual_body = next(p['longitude'] for p in natal['planets'] if p['id'] == row['natal_body'])
            axis = variant['progressed_mc' if row['progressed_axis'] == 'midheaven' else 'progressed_ac']
            actual_orb = abs(separation(axis, actual_body) - row['angle_degrees']) * 3600
            printed_orb = degrees(row['orb_dms']) * 3600
            rows.append({**row, 'actual_orb_arcseconds': actual_orb,
                'difference_from_printed_arcseconds': actual_orb - printed_orb,
                'matches_at_half_printed_minute': abs(actual_orb - printed_orb) <= 30})
        variant['published_aspect_comparison'] = rows
    second_birth = {'date': '1990-06-15', 'time': '14:30:00',
        'place_name': 'København, faste testkoordinater', 'latitude': 55.67594,
        'longitude': 12.56553, 'timezone': 'Europe/Copenhagen'}
    _, second_variants = compute(second_birth, '2026-10-15T12:00:00+00:00')
    return {
        'reference_source': reference['source'],
        'status': 'Matches two published axis orbs at minute precision; exact ARGUS key and axes still require a direct program output.',
        'external_key_number_available': False,
        'manual_example': {'birth': reference['birth'], 'target_utc': reference['target_utc'], 'variants': variants},
        'second_case_for_direct_argus_check': {'birth': second_birth,
            'target_utc': '2026-10-15T12:00:00+00:00', 'variants': second_variants,
            'provenance': 'Application results awaiting independent ARGUS values, NOT external expected values.'}}


if __name__ == '__main__':
    print(json.dumps(report(), ensure_ascii=False, indent=2))
