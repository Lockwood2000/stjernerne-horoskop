# Stjernerne · fødselshoroskopgenerator

**Publiceret prototype, 13. oktober 2026: https://stjernerne-horoskop.onrender.com · Render Free · ingen betalte services tilføjet.**

Selvstændig dansk webapp med Python/FastAPI-server og en lille direkte binding til den officielle Swiss Ephemeris C-motor. Frontend bruger HTML, CSS, JavaScript-moduler og SVG. Ingen frontend-build, database med fødselsdata, API-nøgler eller eksterne opslag under brug.

## Prøv prototypen

På denne Mac: dobbeltklik på `Start lokalt.command`. Den bruger det allerede installerede lokale miljø, starter på **http://127.0.0.1:8765**, og åbner siden. Terminalvinduet skal være åbent. Stop med Ctrl+C.

Fra en ny checkout (Python 3.12+, C-compiler):

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python scripts/build_native.py
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8765 --no-access-log --no-proxy-headers
```

Der er allerede et fiktivt eksempel indlæst: København, 15. juni 1990 kl. 14.30. Eksemplet beregnes af serveren; det er ikke en fast illustration. Indlejringsprøve: **http://127.0.0.1:8765/embed-test**.

## Implementeret

- Dato og præcist lokalt klokkeslæt, inkl. sekunder; 1900 til nutiden, gregoriansk kalender.
- Offline søgning i **37.186 steder**, inkl. danske/alternative stednavne. Atlas dækker byer med mindst 15.000 indbyggere globalt og mindst 500 i Norden. Manuel breddegrad, længdegrad og IANA-zone som alternativ.
- Fastlåst IANA 2026e / `tzdata==2026.5`, historiske offsetregler, eksplicit valg af gentaget klokkeslæt, afvisning af ikke-eksisterende tid og dokumenteret manuel UTC-korrektion.
- Sol, Måne, Merkur–Pluto, sand nordknude, Chiron, Ceres, Eris, Haumea og Makemake, geocentriske tropiske længder, bredder, hastighed og retrogradstatus.
- Placidus, AC/MC, 12 husspidser og placering i hus ud fra ekliptisk længde.
- Konjunktion, sekstil, kvadrat, trigon og opposition med dokumenterede orbisgrænser.
- Responsivt SVG-hjul, tabeller, tilgængelige faner, SVG-download og indlejringshøjde via `postMessage` med afsenderkontrol.
- Validering på serveren, grænse for requeststørrelse, rate limit, host-/origin-kontrol, CSP og ingen lagring af fødselsdata.

## Bevidste begrænsninger

**Historisk korrekthed er ikke universelt verificeret.** Før 1970 vises krav om særskilt kontrol af lokal tidshistorik. Nutidens sted→tidszone-kobling er ikke et historisk atlas. Brug dokumenteret manuel offset ved afvigelser. Swiss Ephemeris behandler tid før 1972 som UT1. Gammel lokal middeltid og kalenderkonvertering kræver særskilt behandling.

Placidus afvises ved |breddegrad| ≥ 66°; der skiftes ikke lydløst til et andet hussystem. Den konservative grænse kan senere erstattes af en godkendt alternativ huspolitik. Ingen Lilith, fortolkninger, login eller gemte horoskoper i denne MVP. Transitter med afspilning, solretur og sekundære progressioner er implementeret.

Denne version er publiceret som en separat prototype og kan også køres lokalt. AGPL-sporet og offentlig udgivelse er godkendt af ejeren. Produktion kræver verificeret hosting uden uautoriserede udgifter, HTTPS, samlet rate limit ved flere instanser, passende driftslogning uden fødselsdata og test på en godkendt Squarespace-side. Der er ingen ubekræftet påstand om produktionsegnet drift eller juridisk godkendelse.

## Dokumentation og tests

- [Arkitektur, licens, økonomi og næste trin](docs/DECISIONS.md)
- [Verifikation og testcases](docs/TESTING.md)
- [Squarespace-integration](docs/SQUARESPACE.md)
- [Afhængigheder og kreditering](THIRD_PARTY.md)
- [Uafhængige numeriske sammenligninger](docs/verification.json)

```sh
.venv/bin/python -m pip install -r requirements-dev.lock
.venv/bin/python -m pytest -q
node --test tests/*.test.mjs
```

`scripts/reference_report.py` regenererer referencefilerne eksplicit. Kør den kun ved bevidst opdatering af beregningsgrundlaget; normale tests ændrer ikke referencerne. `scripts/build_atlas.py` regenererer det medfølgende atlas fra den fastlåste GeoNames-pakke.

## Projektets data og ejerskab

Alt projektmateriale ligger i denne mappe og kan flyttes til Stjernernes eget repository og hosting. C-kilde og hovedefemerider er fastlåst til commit `aacf962d19d79f8bc921dbcdaacf306d85be1917`; downloadadresser og SHA-256 står i `data/upstream-manifest.json`. Ejeren har valgt AGPL-sporet. De ekstra asteroidfiler har egne fastlåste checksums og upstream-adresser. Kildepakken genereres med `python scripts/package_source.py` og tilbydes via `/source`. Tredjepartsrettigheder bevares.

## Transitter

Prototypen har nu en ydre transitring, dato/tidszonevalg, Nu og ± dag/uge samt en klikbar aspektoversigt. Se [TRANSITS.md](docs/TRANSITS.md) for brug, beregningsregler og validering. Seneste tests: **116 Python + 7 JavaScript**. Se [TECHNIQUES.md](docs/TECHNIQUES.md) for solretur, progressioner og ekstra himmellegemer og [DEPLOYMENT.md](docs/DEPLOYMENT.md) for udgivelse.

## Synastri

Vælg Synastri under Horoskoptype. Person A bruger den første formular; person B har sin egen. To ringe, valg af indre ring/huse, aspekter inklusive AC/MC og gensidige husplaceringer. Se [SYNASTRI.md](docs/SYNASTRI.md) for metode og tests.
