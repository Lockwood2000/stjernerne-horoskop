# Stjernerne · Evolutionary Astrology

A working English-language evolutionary overlay on the retained Stjernerne
chart and school engines. All charts and planetary nodes use the pinned native
Swiss Ephemeris 2.10.03 library and actual ephemeris files.

## Open the model

Run **Start locally.command**, then visit:

- <http://127.0.0.1:8776/evolution> — the evolutionary workspace.
- <http://127.0.0.1:8776/university> — copied English school generator; select
  **Evolutionary overlay ☊** to use its current chart.
- <http://127.0.0.1:8776/institut> — copied Danish school generator with the same overlay.
- <http://127.0.0.1:8776/> — retained workshop with an overlay button for its natal chart.

These are isolated copies. The source workspaces and other published Stjernerne
services are not edited. The Python backend uses the retained Docker/FastAPI
deployment, with the release source offered through `/source`.

For a dedicated online instance, set `EVOLUTION_HOME=1` to open this workspace
at `/` as well as `/evolution`. Without that setting the local workshop root
is preserved. `deploy/render.yaml` describes a separate Free service; actual
workspace quotas and zero extra cost must be verified before creation. The
deployment status, URL, source hash and public checks are recorded separately
in `publication/release.json` when publishing is complete.

For a clean installation, Python 3.12 and a C compiler are required:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-dev.lock
.venv/bin/python scripts/build_native.py
.venv/bin/python scripts/package_source.py
PUBLIC_ORIGIN=http://127.0.0.1:8776 .venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8776
```

The launcher can also reuse the existing local generator's virtual environment.
Stop the server with Control-C in its terminal.

## Print a chart

Select **Print** above the chart or in the large view. The preview uses a
dedicated, single-page A4 landscape layout with the vector wheel, the selected
planetary-node pairs, birth details and calculation conventions. It keeps the
same overlay choices as the chart on screen.

Select **Print / Save PDF** to open the browser's print dialog, then choose a
printer or PDF destination. The standard browser print command uses the same
layout. Closing the preview returns to the chart without changing its settings.

## Implemented

- Porphyry (retained default), Placidus, Equal House (twelve 30° houses from
  the Ascendant), Regiomontanus and Whole Sign houses.
- True and Mean lunar nodes; comparison of both modes.
- Both planetary nodes for Mercury through Pluto, calculated independently.
- Chiron, Ceres, Eris, Haumea, Makemake, Sedna, Quaoar, Orcus and Gonggong,
  including planetary nodes. Individual node pairs can be toggled on the wheel.
- Geocentric orbital intersection points or heliocentric node longitudes.
- Mean where supported, heliocentric osculating, or osculating with barycentric
  outer-body orbits. Actual per-body methods are returned in the API.
- Direct secondary progressions with a 365.2422-day year and Naibod right
  ascension for progressed axes. Planetary nodes stay at the birth epoch.
- True solar arc from the secondary progressed Sun, applied equally to all
  natal planets, angles and cusps. Target date, clock time and IANA time zone
  are selectable for both secondary progressions and solar arc.
- Solar return at the actual recurrence of the natal tropical apparent
  geocentric Sun longitude. Choose a year and explicitly use the birthplace,
  an atlas return city, or manual return coordinates and time zone. Return
  houses use that location. The Method tab records local/UTC time and residual.
- Pluto polarity point, lunar-node sign rulers and a selected planet's
  south-node / natal-planet / north-node panel.
- Node-to-natal, node-to-node, timing-to-natal and timing-to-node
  aspect tables; adjustable 1–5° UI orbs and optional quincunxes.
- A position-layer selector with each layer's planets, house cusps and angles,
  and a separate natal-house column for timing layers. The purple outer ring
  shows the active timing method, its planets, house ticks and ASC/MC.
- Unknown birth time omits angles and house assignments. Ambiguous local
  times require choosing an occurrence; unavailable houses never silently change.
- Clockwise polar house cusps are respected in planet/node house assignments
  and in all local wheels and print labels, including Regiomontanus.
- Interactive SVG wheel, vector download, input/result JSON export/import,
  notes and one browser-local saved chart.
- A4 landscape print preview with a vector wheel and a readable node-position
  table. Print controls are available in both chart sizes.
- A reusable same-origin iframe bridge mounted in both copied school generators.

## Observatory design refinement

The 17 October design pass adds a warm ivory, forest-green and muted brass
visual system, a Sun/Moon/Ascendant summary, reading-view presets, a large
interactive chart dialog, stronger degree labels and a separate outer band
for progressed planets. The selected planet is highlighted in both chart
sizes. The mobile layout puts the chart first and provides shortcuts to birth
details and overlay settings. Notes can be saved directly beside the editor.

Unknown-time warnings and changed settings remain visible above the chart.
Progressions are disabled until a birth time is stated. SVG exports include
the calculation conventions and view settings as metadata. The drawing uses
hand-authored SVG; the numerical calculation conventions are unchanged.

Dense overlays (seven or more node pairs) place names and degrees in two
spaced side columns. Coloured dots and leader lines retain each node's exact
longitude. Labels remain interactive, and progression layers have separate
space outside their ring. The large view scales the entire wheel to the
available width and height without scrolling. On narrow panels with enough
vertical space, a compact table also shows every selected body's north and
south node, including its degree and abbreviated sign. Selecting a position
shows its full precision in the dialog footer.
The large chart uses larger, heavier node labels and darker north/south
colours. The narrow-panel position table uses 14-pixel body names and
13-pixel positions (12 pixels on shorter panels), with alternating row
backgrounds. Its compact header reserves space for the complete wheel.

## Calculation conventions

`app/evolution.py` imports the shared time, position, house and secondary
progression functions. It adds a serialized `ctypes` binding to `swe_nod_aps`.
Mean mode uses `SE_NODBIT_MEAN | SE_NODBIT_OSCU_BAR` (5): Mercury through
Neptune use mean nodes; Pluto and small bodies use osculating nodes, with
barycentric orbits for outer bodies. This is deliberately not labelled “True
Node” for all planets.

Geocentric planetary south nodes are **not** obtained by adding 180° to north
nodes. Heliocentric longitudes placed in natal houses are explicitly a symbolic
overlay on a geocentric birth chart. Pluto's polarity point, by contrast, is
defined as natal Pluto + 180°. Positions use tropical ecliptic longitude and
the true equinox of date. House assignment uses ecliptic longitude, not 3D
mundane position.

Solar and terrestrial nodes are not invented. The reference is the ecliptic.
Missing optional body data produce an explicit omission warning. The core
data cover 1500–2099; some retained outer-body files have a narrower range.
Downloaded data are checksum-verified. The new files use the same
`ephe.scryr.io` mirror as the retained outer-body ephemerides; see
`data/evolution-manifest.json` for exact URLs and hashes.

## Integration

See [docs/EVOLUTION-INTEGRATION.md](docs/EVOLUTION-INTEGRATION.md) for the API,
embedding contract, compatibility notes and deployment requirements.

## Validation

```sh
.venv/bin/python -m pytest -q -p no:cacheprovider
node --test tests/*.test.mjs
```

The new `tests/test_evolution.py` compares node longitudes against the official
`swetest` executable with matching epoch and speed flags, checks coordinate
references, validates lunar-node switching and progression timing, verifies
all additional bodies, and tests error handling and unknown-time behavior.
See [docs/EVOLUTION-QA.md](docs/EVOLUTION-QA.md) for recorded results.

## Source and licence

The retained application and this extension are AGPL-3.0-or-later; preserve
`LICENSE`, `COPYING` and `THIRD_PARTY.md`. `/source` serves the corresponding
source archive, generated by `scripts/package_source.py`. Existing commercial
licensing decisions remain outside this local prototype.

Astronomical calculations and the practitioner's interpretation remain
separate. The model does not infer evolutionary stages or past lives.
