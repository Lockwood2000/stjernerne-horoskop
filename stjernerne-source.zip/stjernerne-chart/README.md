# Stjernerne · fødselshoroskopgenerator

**Publiceret prototype, 13. oktober 2026: https://stjernerne-horoskop.onrender.com · Render Free · ingen betalte services tilføjet.**

Selvstændig dansk webapp med Python/FastAPI-server og en lille direkte binding til den officielle Swiss Ephemeris C-motor. Frontend bruger HTML, CSS, JavaScript-moduler og SVG. Ingen frontend-build, serverdatabase med fødselsdata, API-nøgler eller eksterne opslag under brug.

## Prøv prototypen

På denne Mac: dobbeltklik på `Start lokalt.command`. Den bruger det allerede installerede lokale miljø, starter på **http://127.0.0.1:8765**, og åbner siden. Terminalvinduet skal være åbent. Stop med Ctrl+C.

Fra en ny checkout (Python 3.12+, C-compiler):

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.lock
.venv/bin/python scripts/build_native.py
.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8765 --no-access-log --no-proxy-headers
```

Der er allerede et fiktivt eksempel indlæst: København, 15. juni 1990 kl. 14.30. Eksemplet beregnes af serveren; det er ikke en fast illustration. Indlejringsprøve: **http://127.0.0.1:8765/embed-test**.

## Implementeret

- Dato og præcist lokalt klokkeslæt, inkl. sekunder; 1900 til nutiden, gregoriansk kalender.
- Offline søgning i **37.186 steder**, inkl. danske/alternative stednavne. Atlas dækker byer med mindst 15.000 indbyggere globalt og mindst 500 i Norden. Manuel breddegrad, længdegrad og IANA-zone som alternativ.
- Fastlåst IANA 2026e / `tzdata==2026.5`, historiske offsetregler, eksplicit valg af gentaget klokkeslæt, afvisning af ikke-eksisterende tid og dokumenteret manuel UTC-korrektion.
- Sol, Måne, Merkur–Pluto, sand nordknude, Chiron, Ceres, Eris, Haumea og Makemake, geocentriske tropiske længder, bredder, hastighed og retrogradstatus.
- Placidus, AC/MC, 12 husspidser og placering i hus ud fra ekliptisk længde.
- Konjunktion, sekstil, kvadrat, trigon og opposition med dokumenterede orbisgrænser.
- Responsivt SVG-hjul, tabeller, tilgængelige faner, SVG-download og indlejringshøjde via `postMessage` med afsenderkontrol.
- Validering på serveren, grænse for requeststørrelse, rate limit, host-/origin-kontrol, CSP og ingen lagring af fødselsdata på serveren.

## Bevidste begrænsninger

**Historisk korrekthed er ikke universelt verificeret.** Før 1970 vises krav om særskilt kontrol af lokal tidshistorik. Nutidens sted→tidszone-kobling er ikke et historisk atlas. Brug dokumenteret manuel offset ved afvigelser. Swiss Ephemeris behandler tid før 1972 som UT1. Gammel lokal middeltid og kalenderkonvertering kræver særskilt behandling.

Placidus afvises ved |breddegrad| ≥ 66°; der skiftes ikke lydløst til et andet hussystem. Den konservative grænse kan senere erstattes af en godkendt alternativ huspolitik. Ingen Lilith, fortolkninger eller login i denne MVP. Transitter med afspilning, solretur og sekundære progressioner er implementeret.

Denne version er publiceret som en separat prototype og kan også køres lokalt. AGPL-sporet og offentlig udgivelse er godkendt af ejeren. Produktion kræver verificeret hosting uden uautoriserede udgifter, HTTPS, samlet rate limit ved flere instanser, passende driftslogning uden fødselsdata og test på en godkendt Squarespace-side. Der er ingen ubekræftet påstand om produktionsegnet drift eller juridisk godkendelse.

## Dokumentation og tests

- [Arkitektur, licens, økonomi og næste trin](docs/DECISIONS.md)
- [Verifikation og testcases](docs/TESTING.md)
- [Squarespace-integration](docs/SQUARESPACE.md)
- [Afhængigheder og kreditering](THIRD_PARTY.md)
- [Uafhængige numeriske sammenligninger](docs/verification.json)

```sh
.venv/bin/python -m pip install -r requirements-dev.lock
.venv/bin/python -m pytest -q
node --test tests/*.test.mjs
```

`scripts/reference_report.py` regenererer referencefilerne eksplicit. Kør den kun ved bevidst opdatering af beregningsgrundlaget; normale tests ændrer ikke referencerne. `scripts/build_atlas.py` regenererer det medfølgende atlas fra den fastlåste GeoNames-pakke.

## Projektets data og ejerskab

Alt projektmateriale ligger i denne mappe og kan flyttes til Stjernernes eget repository og hosting. C-kilde og hovedefemerider er fastlåst til commit `aacf962d19d79f8bc921dbcdaacf306d85be1917`; downloadadresser og SHA-256 står i `data/upstream-manifest.json`. Ejeren har valgt AGPL-sporet. De ekstra asteroidfiler har egne fastlåste checksums og upstream-adresser. Kildepakken genereres med `python scripts/package_source.py` og tilbydes via `/source`. Tredjepartsrettigheder bevares.

## Transitter

Prototypen har nu en ydre transitring, dato/tidszonevalg, Nu og ± dag/uge samt en klikbar aspektoversigt. Se [TRANSITS.md](docs/TRANSITS.md) for brug, beregningsregler og validering. Seneste tests: **123 Python + 16 JavaScript**. Se [TECHNIQUES.md](docs/TECHNIQUES.md) for solretur, progressioner og ekstra himmellegemer og [DEPLOYMENT.md](docs/DEPLOYMENT.md) for udgivelse.

## Synastri

Vælg Synastri under Horoskoptype. Person A bruger den første formular; person B har sin egen. To ringe, valg af indre ring/huse, aspekter inklusive AC/MC og gensidige husplaceringer. Se [SYNASTRI.md](docs/SYNASTRI.md) for metode og tests.

## Fødselstidskorrektion

Tidskyder ±3 timer, minutknapper, fem kandidater og fem daterede livsbegivenheder. Originalen bevares. Sammenligning af langsomme transitter til AC/MC uden sikkerhedsscore; se [RECTIFICATION.md](docs/RECTIFICATION.md). Sessionen kan gemmes lokalt i Mine horoskoper.

## Mine horoskoper

Navngivet lokalt bibliotek med fødselsdata, horoskoptype, tidskandidater og livsbegivenheder. Genåbning, opdatering, papirkurv/gendannelse og valideret JSON-backup/import. Ingen konto eller serverlagring; se [LIBRARY.md](docs/LIBRARY.md).

## Enkel navigation

Genveje til fødselsoplysninger, hjul og Mine horoskoper. Horoskoptyper vælges
med forklarende knapper. Indstillinger og fødselsformular kan foldes sammen;
hjulet kan åbnes i en stor dialog med zoom og tastaturbetjening.


Kündigs metode: beregn snittidspunkter omkring originalen, vis dem i hjulet, behold dem som tidskandidater og sammenlign med livsbegivenheder. Sekunder bevares i bibliotek og backup/import. Traditionelle MC/IC-herskere og ekliptiske meridiankonjunktioner; se docs/KUNDIG.md for metode og afgrænsning. Kündigs individuelle solnøgle kan vælges til progressive akser og begivenhedssammenligning. Nøglen bruger den hele zodiakgrad, fødselssolen står i, omregnet til rektascension. Metodevalg følger bibliotek og backup/import; ældre gemte valg bevares. Se docs/SOLAR-KEY.md for præcis konvention og afgrænsning. Bonatti-snit kan vises alene eller sammen med Kündig-snit. Aksekonjunktioner for Solen til Pluto markeres med planet og AC/DC/MC/IC. Sammenfald samles til ét sekund med begge mærker; mærkerne følger kandidater, begivenhedstabeller og backup/import. Se docs/BONATTI.md for metodekonvention og kontrol.


Kündig-guiden har tre trin: find snit, vælg tidspunkter, og sammenlign med livsbegivenheder. Startknappen vælger Kündig-snit; næste knap vælger den individuelle solnøgle. Ordliste, tydeligt næste trin og hjælp til tabellen gør forløbet lettere at følge. Manuel tidsflytning er valgfri. Se docs/USABILITY.md for gennemgangen og dens grænser; der er ikke foretaget fuld numerisk sammenligning med ARGUS eller en brugertest med en uøvet person.

En efterfølgende uafhængig krydskontrol genfinder fire publicerede ARGUS-snit med ét sekund tidligere vist tid, også på liveversionen. Syv publicerede solnøgler stemmer med helgradsvarianten, som skal skelnes fra den centrerede variant beskrevet for ARGUS. 17 referencetests og i alt 192 Python-tests bestod. Se docs/CROSSCHECK.md for kilder, tolerancer og begrænsninger. Beregningskoden er uændret.

Nyeste tilføjelse: vælg mellem Kündig · hel grad og ARGUS · centreret til progressioner og livsbegivenheder. Begge nøgler, AC og MC kan sammenlignes på samme dato, og den valgte metode kan vises i hjulet. Metodevalget følger bibliotek og backup/import; tidligere Kündig-valg beholder helgradsmetoden. 207 Python-tests og 33 JavaScript-tests bestod. Se docs/SOLAR-KEY-VARIANTS.md.


## Hussystemer og solar arc · 17. oktober 2026

Placidus, Equal House fra ASC og Regiomontanus kan nu vælges. Sekundære progressioner, ægte solar arc og solretur følger valget og kan gemmes. Se [beregningskonventioner og test](docs/HOUSE-SYSTEMS-AND-DIRECTIONS.md).
