#!/bin/zsh
set -eu
cd -- "$(dirname -- "$0")"
export PYTHONDONTWRITEBYTECODE=1
export PUBLIC_ORIGIN=http://127.0.0.1:8776
EVOLUTION_PYTHON=.venv/bin/python
if [[ ! -x "$EVOLUTION_PYTHON" ]]; then
  EVOLUTION_PYTHON=/Users/johanneslockwood/Documents/Codex/2026-10-13/referenced-chatgpt-conversation-this-is-an/work/venv/bin/python
fi
if [[ ! -x "$EVOLUTION_PYTHON" ]]; then
  print 'Create .venv and install requirements-dev.lock first; see README.md.'
  exit 1
fi
print 'Evolutionary Astrology: http://127.0.0.1:8776/evolution'
print 'Stop with Control-C. If the address is already running, open it in your browser.'
exec "$EVOLUTION_PYTHON" -m uvicorn app.main:app --host 127.0.0.1 --port 8776
