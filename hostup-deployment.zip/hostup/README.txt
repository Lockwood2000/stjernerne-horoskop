STJERNERNE - HOSTUP NANO TRIAL

Scope: one fixed-cycle monthly Nano VPS only, maximum USD 7 including tax.
No PAYG, automatic credit top-ups, paid add-ons, or extra bandwidth purchases.
The account, terms and payment require the user's approval. This package does
not create a hosting account, place an order, or configure provider billing.

Before payment:
- Verify Nano, quantity 1, 1 Month, USD, Ubuntu 24.04, total currently USD 4.23
  including 25% VAT, included IPv4 and standard resources only.
- The public SSH key in the cart allows setup from the user's local computer.
  Its private counterpart stays outside the source package and public repository.
- Confirm manual payment/disabled card auto-charge; no automatic balance top-up.
  Card payment may authorize future charges by default (HostUp terms 4.3).
- User approves the final checkout; do not accept provider terms silently.

Installation after approved purchase:
1. Verify the server IP and SSH host-key fingerprint through the provider's
   console before the first SSH connection. Never disable host-key checking.
2. Use a stable final hostname. Point its DNS A record to the assigned IPv4.
   Avoid a new domain purchase. DNS/hostname approval remains pending.
3. Copy this bundle to the new server. Copy trial.env.example to trial.env and
   set TRIAL_HOST to that approved hostname (no protocol or slash).
4. Run install.sh as root only on the new, otherwise unused Ubuntu 24.04 VPS.
   It installs Docker from its official signed repository, enables the local
   firewall while preserving SSH, and starts the app plus Caddy HTTPS proxy.
5. Check docker compose --env-file trial.env ps and the final HTTPS URL.
   Certificate data uses persistent Docker volumes on the included server disk.
   The program runs without root, with read-only app files and bounded logs.
   Only loopback 127.0.0.1:8765 serves the app; the local proxy is trusted for
   per-visitor request limiting. Caddy listens publicly on ports 80 and 443.

Acceptance on the real server:
- Health: /api/health reports five generators.
- All five pages load: /da/, /en/, /school/institut, /school/university,
  /evolution/. Birthplace search, exact times, zones and all 17 node pairs work.
- Run 40 result-parity cases and bounded mixed/heavy request checks using the
  existing scripts. Inspect real Linux memory and latency, not Mac estimates.
- Through SSH, inspect local /api/trial/resources and docker stats.
- Browser: import fictional JSON backups, reopen/recalculate, export again,
  preserve notes and trash, print including all 17 node pairs.
- Reboot the trial VPS once and verify automatic recovery and HTTPS.
- Verify manual billing state in HostUp before treating the trial as complete.

Migration:
Keep original Render services unchanged while testing. Select the final HTTPS
hostname before importing real records: browser storage is tied to the origin.
Export existing records from each old generator, keep the JSON backups, and
import them with /flyt. Server backups do not contain browser-local charts.

One-month trial:
Record paid-through date from the actual invoice. Do not renew or buy anything
else without the user's instruction. Verify the provider's available renewal or
end-of-period cancellation control with the user before scheduling deletion.
No monitoring automation or future purchase is created by this package.

Current limits:
The container build, real certificate issuance, provider billing controls and
performance must still be tested on the newly approved server. Local proxy
preflight passed; this is not a claim of a completed HostUp deployment.

Sources:
https://hostup.se/legal/terms-of-service-en.pdf
https://hostup.se/legal/acceptable-use-policy-en.pdf
https://docs.docker.com/engine/install/ubuntu/
https://docs.docker.com/engine/network/drivers/host/
https://caddyserver.com/docs/automatic-https
