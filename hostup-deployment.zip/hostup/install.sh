#!/usr/bin/env bash
# Install only on the new, approved Ubuntu 24.04 trial VPS, after payment.
set -euo pipefail
if [[ "$(uname -s)" != Linux || "$(id -u)" != 0 ]]; then
    echo 'Run as root on the new Ubuntu 24.04 trial VPS.' >&2
    exit 1
fi
source /etc/os-release
if [[ "$ID" != ubuntu || "$VERSION_ID" != 24.04 ]]; then
    echo 'This installer requires Ubuntu 24.04.' >&2
    exit 1
fi
cd -- "$(dirname -- "$0")"
if [[ ! -s trial.env ]]; then
    echo 'Create trial.env with the approved final TRIAL_HOST before installation.' >&2
    exit 1
fi
# Read one hostname as data. Never source an editable environment file as code.
trial_host=$(sed -n 's/^TRIAL_HOST=//p' trial.env)
if [[ ${#trial_host} -gt 253 || ! "$trial_host" =~ ^([a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,63}$ ]]; then
    echo 'TRIAL_HOST must be a public DNS hostname without protocol, port or path.' >&2
    exit 1
fi
if [[ "$trial_host" == *.invalid || "$trial_host" == *.local || "$trial_host" == *.test || "$trial_host" == *.example ]]; then
    echo 'Replace the example hostname with the approved public DNS hostname.' >&2
    exit 1
fi
sha256sum --check SHA256SUMS
if command -v docker >/dev/null 2>&1; then
    echo 'Docker already exists. Inspect this server before applying a fresh-server installer.' >&2
    exit 1
fi
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl ufw unattended-upgrades
install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
chmod a+r /etc/apt/keyrings/docker.asc
docker_arch=$(dpkg --print-architecture)
cat > /etc/apt/sources.list.d/docker.sources <<EOF
Types: deb
URIs: https://download.docker.com/linux/ubuntu
Suites: noble
Components: stable
Architectures: $docker_arch
Signed-By: /etc/apt/keyrings/docker.asc
EOF
apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
systemctl enable --now docker
# Host networking plus a loopback-only app avoids publishing a bypass port.
# Preserve SSH access before enabling the firewall on this fresh server.
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw --force enable
install -m 0755 -d /etc/apt/apt.conf.d
cat > /etc/apt/apt.conf.d/20auto-upgrades <<'EOF'
APT::Periodic::Update-Package-Lists "1";
APT::Periodic::Unattended-Upgrade "1";
EOF
cat > /etc/apt/apt.conf.d/52stjernerne-reboot-policy <<'EOF'
Unattended-Upgrade::Automatic-Reboot "false";
EOF
docker compose --env-file trial.env config --quiet
docker compose --env-file trial.env build app
docker compose --env-file trial.env up -d
docker compose --env-file trial.env ps
echo 'Installation started. Verify public HTTPS, calculations, imports, print, and resource use before cutover.'
