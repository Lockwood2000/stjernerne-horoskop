# House systems and symbolic directions · 17 October 2026

Both existing Stjernerne workshops retain Placidus as their default. `Birth.house_system` accepts Swiss codes `P` (Placidus), `E` (Equal House: cusp 1 at ASC, then 30° per house) and `R` (Regiomontanus). An omitted value in an old request or backup retains Placidus. Unknown codes are rejected; there is no silent fallback.

Placidus retains the previous latitude restriction |latitude| < 66°. Equal House and Regiomontanus support higher latitudes, including Tromsø, but ±90° is explicitly rejected. Swiss Regiomontanus can return reverse cusp order inside the polar circle. Planet house assignment and the wheel's house-number midpoints follow that order. Equal House's tenth cusp need not equal MC.

## Secondary progressions

One ephemeris day after birth represents one lived tropical year of 365.2422 days. Target UTC is resolved explicitly. Planet positions use the secondary ephemeris instant. Existing Naibod (0.98564733° RA/year), whole-degree Kündig and centred ARGUS angle keys remain available. Selected P/E/R houses are constructed from the progressed ARMC, birthplace latitude and progressed obliquity. Solar-key comparison still uses the chosen system; no existing key convention changes.

## Solar arc

The direct true tropical ecliptic solar arc is the secondary progressed Sun's longitude minus its natal longitude. Positive increments are accumulated in brackets shorter than 180° of solar motion, preserving full revolutions for old births. This is not the 1°/year shortcut. The same arc directs every natal planet, all natal cusps and ASC/MC. The chosen natal house system is retained; own-house membership and internal aspect geometry are unchanged by the common rotation. All directed points have the positive symbolic arc speed; original retrograde status is retained separately as `natal_retrograde`. Latitude and distance remain natal, not physical positions on the target date. Target date and the secondary key instant are both recorded.

## Solar return

The existing convergent apparent geocentric solar-longitude solver is retained. The selected year means the actual return near that birthday. The UI explicitly offers the birthplace checkbox or a selected atlas location. The return instant and solar longitude are independent of location; local time, ASC/MC and the selected P/E/R houses reflect the return location. Location is preserved in the saved inputs. Numerical tests require solar error below 0.001 arcsecond.

## Preservation and verification

A house-system change stages a recomputation before replacing the current session. Kept candidates, life-event labels/dates, an unfinished event draft, selected chart type/date, tab and open panels are preserved. A ready candidate/event comparison is recalculated. Existing records are not migrated or overwritten automatically; the user still chooses Save changes.

Input-only version-1 backups remain accepted. Explicit P/E/R selections, both synastry participants and solar-arc dates round-trip. SVG downloads include the house-system label, technique and relevant date. There was no PDF export in these workshops to extend.

Tests cover old default behaviour; analytical equal cusps; P/E/R natal, secondary progression, solar arc and relocated solar return; circumpolar reverse Regiomontanus assignment; no fallback at Tromsø or poles; canonical candidate seconds; and input backup validation. Equal and Regiomontanus cusp values are compared against the bundled official Swiss `swetest` CLI at northern, southern, equatorial and high-latitude sites. Existing independent Astronomy Engine and published ARGUS reference tests remain in place. These changes do not turn birth-time rectification into proof of an actual birth time or add an independent ARGUS installation result.

Sources: Swiss Ephemeris programmer documentation, sections 15.2–15.4 and bundled `swehouse.c` (house codes E/P/R, polar Regiomontanus convention): https://www.astro.com/swisseph/swephprg.htm . Existing solar-key convention references remain in SOLAR-KEY-VARIANTS.md.

AGPL corresponding source is repackaged for each existing service; no paid service or extra hosting is introduced. The school and evolution-chart codebases are outside this change.
