"""Supported tropical house systems; omitted values retain the original default.

Swiss Ephemeris codes: P = Placidus, E = equal 30-degree houses from ASC,
R = Regiomontanus. Placidus retains |latitude| < 66; E/R support higher latitudes, excluding ±90.
"""
HOUSE_SYSTEMS = {'P': 'Placidus', 'E': 'Equal House', 'R': 'Regiomontanus'}
def selected_system(chart):
    return chart.get('calculation', {}).get('house_system', 'P')
