"""Solar longitude returns and direct secondary progressions with Naibod RA houses."""
from .engine import validate_house_system
from .houses import selected_system
import ctypes as C
from datetime import datetime, timedelta, timezone
from .engine import lib, LOCK, DP, SWIEPH, BODIES, calculate, positions_at, position, house_for, CalculationError, separation, transit_aspects
from .solar_key import kundig_solar_key, SOLAR_KEY_METHODS, SOLAR_KEY_LABELS
YEAR_DAYS = 365.2422
NAIBOD = 0.98564733
lib.swe_houses_armc.argtypes = [C.c_double, C.c_double, C.c_double, C.c_int, DP, DP]
lib.swe_houses_armc.restype = C.c_int

def solar_return(birth_utc, natal, year, latitude, longitude, include_dwarfs=False):
    if year < birth_utc.year:
        raise CalculationError('Choose a solar return year from the birth year onwards.')
    try:
        anchor = birth_utc.replace(year=year)
    except ValueError:
        anchor = birth_utc.replace(year=year, day=28)
    target = natal['planets'][0]['longitude']
    stamp = anchor
    for _ in range(12):
        sun = positions_at(stamp, bodies=BODIES[:1])['planets'][0]
        error = (sun['longitude'] - target + 180) % 360 - 180
        if abs(error) < 1e-08:
            break
        stamp -= timedelta(days=error / sun['speed'])
    else:
        raise CalculationError('The solar return did not converge.')
    if abs((stamp - anchor).total_seconds()) > 5 * 86400:
        raise CalculationError('The solar return falls outside the expected birthday interval.')
    chart = calculate(stamp,latitude,longitude,include_dwarfs,selected_system(natal))
    chart['technique'] = {'type': 'solar', 'year': year, 'utc': stamp.isoformat(), 'solar_error_arcsec': separation(chart['planets'][0]['longitude'], target) * 3600, 'method': 'tropical apparent geocentric solar longitude; no precession correction'}
    return (chart, stamp)

def axes_at(armc,latitude,eps,house_system="P"):
    validate_house_system(house_system,latitude)
    with LOCK:
        cusps = (C.c_double * 13)()
        angles = (C.c_double * 10)()
        if lib.swe_houses_armc(armc, latitude, eps, ord(house_system), cusps, angles) < 0:
            raise CalculationError('Progressed houses could not be calculated.')
    return {'armc': armc, 'ascendant': position(angles[0]), 'midheaven': position(angles[1]), 'houses': [{'number': i + 1, **position(lon)} for i, lon in enumerate(list(cusps)[1:])]}

def secondary_progressions(birth_utc, target_utc, natal, latitude, longitude, include_dwarfs=False, house_method='naibod'):
    if house_method not in ('naibod', *SOLAR_KEY_METHODS):
        raise CalculationError('Unknown progression method.')
    if target_utc < birth_utc:
        raise CalculationError('The progression date must follow the birth time.')
    age = (target_utc - birth_utc).total_seconds() / (86400 * YEAR_DAYS)
    stamp = birth_utc + timedelta(days=age)
    chart = calculate(stamp,latitude,longitude,include_dwarfs,selected_system(natal))
    key = kundig_solar_key(natal, house_method) if house_method in SOLAR_KEY_METHODS else None
    rate = key['degrees_per_year'] if key else NAIBOD
    armc = (natal['armc'] + rate * age) % 360
    with LOCK:
        values = (C.c_double * 6)()
        error = C.create_string_buffer(256)
        if lib.swe_calc(chart['calculation']['jd_tt'], -1, SWIEPH, values, error) < 0:
            raise CalculationError('The obliquity could not be calculated.')
        eps = values[0]
    chart.update(axes_at(armc,latitude,eps,selected_system(natal)))
    longs = [h['longitude'] for h in chart['houses']]
    for planet in chart['planets']:
        planet['house'] = house_for(planet['longitude'], longs)
        planet['ephemeris_speed'] = planet['speed']
        planet['speed'] /= YEAR_DAYS
    chart['technique'] = {'type': 'progressed', 'target_utc': target_utc.isoformat(), 'progressed_utc': stamp.isoformat(), 'age_years': age, 'days_per_year': YEAR_DAYS, 'house_method': (SOLAR_KEY_LABELS[house_method] if key else 'Naibod') + ' in right ascension', 'house_method_id': house_method, 'degrees_per_year': rate, 'arc_degrees': rate * age, 'naibod_degrees_per_year': NAIBOD, 'armc': armc, 'obliquity': eps, 'speed_unit': 'degrees per lived day'}
    if key:
        chart['technique']['solar_key'] = key
        variants = []
        for method in SOLAR_KEY_METHODS:
            other_key = key if method == house_method else kundig_solar_key(natal, method)
            other_rate = other_key['degrees_per_year']
            other = chart if method == house_method else axes_at((natal["armc"]+other_rate*age)%360,latitude,eps,selected_system(natal))
            variants.append({'house_method_id': method, 'label': SOLAR_KEY_LABELS[method], 'solar_key': other_key, 'degrees_per_year': other_rate, 'arc_degrees': other_rate * age, **{k: other[k] for k in ('armc', 'ascendant', 'midheaven')}})
        whole, centered = variants
        signed = lambda a, b: (a - b + 180) % 360 - 180
        chart['technique']['solar_key_comparison'] = {'variants': variants, 'difference_from_whole': {'key_arcseconds_per_year': (centered['degrees_per_year'] - whole['degrees_per_year']) * 3600, 'arc_arcseconds': (centered['arc_degrees'] - whole['arc_degrees']) * 3600, 'ascendant_arcseconds': signed(centered['ascendant']['longitude'], whole['ascendant']['longitude']) * 3600, 'midheaven_arcseconds': signed(centered['midheaven']['longitude'], whole['midheaven']['longitude']) * 3600}}
    chart['natal_aspects'] = transit_aspects(chart['planets'], natal['planets'])
    return (chart, stamp)
