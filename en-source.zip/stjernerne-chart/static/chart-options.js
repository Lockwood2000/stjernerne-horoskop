export const houseLabel=value=>({P:'Placidus',E:'Equal House',R:'Regiomontanus'}[typeof value==='string'?value:value?.calculation?.house_system]||value?.calculation?.houses||'Placidus');
export function techniqueHelp(mode,system){
  if(mode==='solar')return "Solar return is calculated at the Sun’s actual return to its natal tropical longitude. Choose the year and your location at the return; the checkbox explicitly selects the birthplace. Location and the selected house system determine angles and houses.";
  if(mode==='solar_arc')return "Direct solar arc: 1 ephemeris day after birth = 1 lived year of 365.2422 days. The arc is the secondary progressed Sun’s tropical longitude minus the natal Sun’s longitude. All natal planets, cusps and ASC/MC receive the same ecliptic arc. These are symbolic directions, not the sky on the target date; no fixed 1°/year or Naibod/Kündig angle key is used. The original houses at the birthplace form the basis.";
  return "Direct secondary progression: 1 day after birth = 1 lived year of 365.2422 days. Angles and "+houseLabel(system)+" houses use the selected angle key in right ascension. Enter the target time in UTC; birthplace coordinates are retained.";
}
export function arcStatus(data){return 'Solar arc · '+data.technique.target.local.slice(0,10)+' · '+data.technique.arc_degrees.toFixed(6)+'° · '+houseLabel(data);}
