// Restore validated birth inputs without emitting input events or changing the original.
export function fillBirthForm(prefix,birth,chart){
  const $=id=>document.getElementById(prefix+id),manual=!birth.place_id;
  $('house-system').value=birth.house_system||'P';$('date').value=birth.date;$('time').value=birth.time;$('include-dwarfs').checked=birth.include_dwarfs;
  $('manual-place').checked=manual;$('manual-fields').disabled=!manual;$('place-search').disabled=manual;
  for(const id of ['latitude','longitude','timezone'])$(id).required=manual;
  $('manual-name').value=birth.place_name||chart.place.name;
  $('latitude').value=chart.place.latitude;$('longitude').value=chart.place.longitude;$('timezone').value=chart.place.timezone;
  $('place-search').value=chart.place.name+(chart.place.country?', '+chart.place.country:'');
  $('place-hint').textContent=`${chart.place.name} · ${chart.place.latitude}°, ${chart.place.longitude}° · ${chart.place.timezone}`;
  $('place-results').hidden=true;$('error').hidden=true;
  $('manual-offset').checked=birth.offset_minutes!==undefined;$('offset-fields').disabled=birth.offset_minutes===undefined;
  for(const id of ['offset-minutes','offset-source'])$(id).required=birth.offset_minutes!==undefined;
  $('offset-minutes').value=birth.offset_minutes??60;$('offset-source').value=birth.offset_source||'';
  $('fold-panel').hidden=birth.fold===undefined;$('fold').replaceChildren(new Option("Choose an occurrence …",''),new Option("First occurrence",'0'),new Option("Second occurrence",'1'));$('fold').value=birth.fold===undefined?'':String(birth.fold);
}
