"""House selection, true solar arc and relocated return contracts.

Equal cusps and solar-arc geometry are checked analytically, beyond API labels.
The existing Swiss reference fixtures continue to guard the default Placidus path.
"""
from datetime import datetime, timezone, timedelta
import math
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.engine import calculate, separation, CalculationError, positions_at, BODIES
from app.techniques import YEAR_DAYS, secondary_progressions, solar_return
from app.solar_arc import solar_arc

UTC=timezone.utc
BIRTH=datetime(1990,6,15,13,30,tzinfo=UTC)
TARGET=datetime(2026,10,17,12,tzinfo=UTC)
LAT,LON=51.50853,-0.12574
PAYLOAD={'date':'1990-06-15','time':'14:30:00','place_id':'2643743','include_dwarfs':True}
CLIENT=TestClient(app,client=('192.0.2.216',1234))

def natal(system='P'):
    return calculate(BIRTH,LAT,LON,True,system)

def test_default_and_explicit_placidus_are_identical():
    assert calculate(BIRTH,LAT,LON,True)==natal('P')

@pytest.mark.parametrize('system',['P','E','R'])
def test_house_choice_changes_cusps_not_sky_or_axes(system):
    c=natal(system);base=natal()
    assert c['calculation']['house_system']==system
    assert c['ascendant']==base['ascendant'] and c['midheaven']==base['midheaven']
    assert [p['longitude'] for p in c['planets']]==[p['longitude'] for p in base['planets']]
    if system!='P':
        assert abs(c['houses'][1]['longitude']-base['houses'][1]['longitude'])>0.01
    if system=='E':
        for i,h in enumerate(c['houses']):
            assert separation(h['longitude'],c['ascendant']['longitude']+30*i)<1e-10
        assert separation(c['houses'][9]['longitude'],c['midheaven']['longitude'])>0.1
    else:
        assert separation(c['houses'][9]['longitude'],c['midheaven']['longitude'])<1e-10

@pytest.mark.parametrize('system',['P','E','R'])
@pytest.mark.parametrize('key',['naibod','kundig','kundig_argus'])
def test_secondary_progressions_keep_the_selected_houses(system,key):
    c,stamp=secondary_progressions(BIRTH,TARGET,natal(system),LAT,LON,True,key)
    age=(TARGET-BIRTH).total_seconds()/86400/YEAR_DAYS
    assert abs((stamp-BIRTH).total_seconds()/86400-age)<1e-10
    assert c['calculation']['house_system']==system
    if system=='E':
        assert all(separation(h['longitude'],c['ascendant']['longitude']+30*i)<1e-10 for i,h in enumerate(c['houses']))
    else:
        assert separation(c['houses'][9]['longitude'],c['midheaven']['longitude'])<1e-10

@pytest.mark.parametrize('system',['P','E','R'])
def test_true_solar_arc_rotates_every_point_and_preserves_own_houses(system):
    base=natal(system);c,stamp=solar_arc(BIRTH,TARGET,base)
    sun=positions_at(stamp,bodies=BODIES[:1])['planets'][0]
    expected=(sun['longitude']-base['planets'][0]['longitude'])%360
    assert abs(c['technique']['arc_degrees']-expected)<1e-10
    assert abs(expected-c['technique']['age_years'])>0.01 # not a 1°/year shortcut
    assert c['calculation']['house_system']==system
    for p,old in zip(c['planets'],base['planets']):
        assert separation(p['longitude'],old['longitude']+expected)<1e-10
        assert p['house']==old['house'] and not p['retrograde'] and p['speed']>0
    for h,old in zip(c['houses'],base['houses']):
        assert separation(h['longitude'],old['longitude']+expected)<1e-10
    for axis in ('ascendant','midheaven'):
        assert separation(c[axis]['longitude'],base[axis]['longitude']+expected)<1e-10
    assert natal(system)==base # no mutation

def test_zero_age_and_full_revolution_are_not_confused():
    base=natal('E');zero,_=solar_arc(BIRTH,BIRTH,base)
    assert zero['technique']['arc_degrees']==0
    old=datetime(1500,1,1,12,tzinfo=UTC)
    n=calculate(old,LAT,LON,False,'E')
    c,_=solar_arc(old,datetime(2000,1,1,12,tzinfo=UTC),n)
    assert 480<c['technique']['arc_degrees']<510
    with pytest.raises(CalculationError):solar_arc(BIRTH,BIRTH-timedelta(seconds=1),base)

@pytest.mark.parametrize('system',['P','E','R'])
def test_relocated_solar_return_has_the_same_exact_sun_and_selected_houses(system):
    base=natal(system)
    a,ta=solar_return(BIRTH,base,2026,LAT,LON,True)
    b,tb=solar_return(BIRTH,base,2026,40.71427,-74.00597,True)
    assert ta==tb
    assert a['calculation']['house_system']==b['calculation']['house_system']==system
    assert a['technique']['solar_error_arcsec']<0.001
    assert b['technique']['solar_error_arcsec']<0.001
    assert separation(a['planets'][0]['longitude'],base['planets'][0]['longitude'])*3600<0.001
    assert separation(a['ascendant']['longitude'],b['ascendant']['longitude'])>1

@pytest.mark.parametrize('system',['P','E','R'])
def test_api_preserves_system_in_all_computed_modes_and_candidates(system):
    birth={**PAYLOAD,'house_system':system}
    assert CLIENT.post('/api/chart',json=birth).json()['calculation']['house_system']==system
    for mode in ('progressed','solar_arc','solar'):
        body={'birth':birth,'mode':mode}
        body.update({'year':2026,'location':{'place_id':'5128581'}} if mode=='solar' else {'target':{'date':'2026-10-17','time':'12:00:00','timezone':'UTC'}})
        response=CLIENT.post('/api/technique',json=body)
        assert response.status_code==200,response.text
        c=response.json()
        assert c['chart_type']==mode and c['calculation']['house_system']==system
        if mode=='solar':assert c['place']['id']=='5128581'
    candidate=CLIENT.post('/api/rectify',json={'birth':birth,'shift_minutes':-142/60}).json()
    assert candidate['calculation']['house_system']==system
    compare=CLIENT.post('/api/rectify/compare',json={'birth':birth,'shifts':[0,-142/60],'events':['2020-06-01'],'method':'kundig_argus'}).json()
    assert all(c['calculation']['house_system']==system for c in compare['charts'])
    assert all(c['progressed']['calculation']['house_system']==system for c in compare['events'][0]['candidates'])

def test_synastry_supports_individual_house_choices():
    r=CLIENT.post('/api/synastry',json={'a':{**PAYLOAD,'house_system':'E'},'b':{**PAYLOAD,'house_system':'R'}})
    assert r.status_code==200
    assert r.json()['a']['calculation']['house_system']=='E'
    assert r.json()['b']['calculation']['house_system']=='R'

@pytest.mark.parametrize('case',[{'mode':'solar_arc'},{'mode':'solar_arc','year':2026},{'mode':'solar_arc','target':{'date':'2026-10-17','time':'12:00','timezone':'UTC'},'house_method':'kundig'}])
def test_solar_arc_requires_date_and_rejects_incompatible_keys(case):
    assert CLIENT.post('/api/technique',json={'birth':PAYLOAD,**case}).status_code==422

def test_unknown_house_system_is_rejected_without_substitution():
    assert CLIENT.post('/api/chart',json={**PAYLOAD,'house_system':'X'}).status_code==422

@pytest.mark.parametrize('system',['E','R'])
@pytest.mark.parametrize('lat,lon',[(51.50853,-0.12574),(-33.8688,151.2093),(0,0),(69.65,18.96)])
def test_selected_house_cusps_match_official_swiss_cli(system,lat,lon):
    import subprocess
    from app.engine import ROOT
    c=calculate(BIRTH,lat,lon,False,system)
    output=subprocess.check_output([str(ROOT/'build/swetest'),'-b15.6.1990greg','-utc13:30:00',
        '-p0','-eswe','-tidacc-25.936',f'-edir{ROOT}/data/ephe','-fPl','-g,','-head',f'-house{lon},{lat},{system}'],text=True)
    rows=[line.split(',') for line in output.splitlines() if ',' in line]
    assert len(rows)>=15
    for house,row in zip(c['houses'],rows[1:13]):
        assert separation(house['longitude'],float(row[1]))<1e-6

@pytest.mark.parametrize('system',['E','R'])
def test_high_latitude_native_houses_progressions_returns_and_directions(system):
    from app.techniques import axes_at
    from app.engine import house_for
    n=calculate(BIRTH,69.65,18.96,False,system)
    assert n['calculation']['house_system']==system
    p,_=secondary_progressions(BIRTH,TARGET,n,69.65,18.96,False,'kundig_argus')
    assert p['calculation']['house_system']==system
    r,_=solar_return(BIRTH,n,2026,69.65,18.96,False)
    assert r['technique']['solar_error_arcsec']<0.001
    a,_=solar_arc(BIRTH,TARGET,n)
    assert a['calculation']['house_system']==system
    for pole in [-90,90]:
        with pytest.raises(CalculationError):calculate(BIRTH,pole,18.96,False,system)
        with pytest.raises(CalculationError):axes_at(100,pole,23.44,system)
    with pytest.raises(CalculationError,match='Placidus'):calculate(BIRTH,69.65,18.96,False,'P')
    with pytest.raises(CalculationError,match='Placidus'):axes_at(100,69.65,23.44,'P')

def test_circumpolar_reverse_regiomontanus_assigns_each_house_correctly():
    from app.engine import house_for,cusp_direction
    stamp=datetime(2000,6,15,0,tzinfo=UTC)
    chart=calculate(stamp,69.65,18.96,False,'R')
    cusps=[h['longitude'] for h in chart['houses']]
    assert cusp_direction(cusps)==-1
    for i,cusp in enumerate(cusps):
        midpoint=(cusp-((cusp-cusps[(i+1)%12])%360)/2)%360
        assert house_for(midpoint,cusps)==i+1
    directed,_=solar_arc(stamp,datetime(2026,6,15,0,tzinfo=UTC),chart)
    assert [p['house'] for p in chart['planets']]==[p['house'] for p in directed['planets']]

@pytest.mark.parametrize('system',['E','R'])
def test_high_latitude_birth_time_candidates_and_bonatti_do_not_fallback(system):
    b={'date':'2000-06-15','time':'02:00:00','place_name':'Tromso test','latitude':69.65,'longitude':18.96,'timezone':'Europe/Oslo','house_system':system}
    r=CLIENT.post('/api/rectify/kundig',json={'birth':b,'radius_minutes':30,'cut_mode':'both'})
    assert r.status_code==200,r.text
    c=CLIENT.post('/api/rectify',json={'birth':b,'shift_minutes':1})
    assert c.status_code==200 and c.json()['calculation']['house_system']==system
