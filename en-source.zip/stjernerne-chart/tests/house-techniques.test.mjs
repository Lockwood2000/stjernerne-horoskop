import test from 'node:test';
import assert from 'node:assert/strict';
import {session,encodeBackup,decodeBackup} from '../static/library-model.js';
const base=()=>({birth:{date:'1990-06-15',time:'14:30:00',place_id:'2643743',include_dwarfs:true},mode:'natal',rectification:{shifts:[0,-142/60],current:0,events:[{label:'Moving home',date:'2020-06-01'}]}});
test('old backups remain accepted with the original implicit Placidus default',()=>{const old=base();assert.deepEqual(session(old),old);});
test('each house choice and true solar arc date survive backup and import',()=>{
 for(const house_system of ['P','E','R']){const value=base();value.birth.house_system=house_system;value.mode='solar_arc';value.technique={mode:'solar_arc',target:{date:'2026-10-17',time:'12:00:00',timezone:'UTC'}};const rows=[{name:'Solar arc',session:value,trashed:false}];assert.deepEqual(decodeBackup(encodeBackup(rows)),rows);}
});
test('synastry keeps both independently chosen systems and original birth inputs',()=>{const value=base();value.birth.house_system='E';value.mode='synastry';value.synastry={birth:{...base().birth,house_system:'R'},order:'b'};assert.deepEqual(session(value),value);});
test('bad house codes and a secondary angle key on solar arc are rejected',()=>{for(const code of ['X','WholeSign','',null,0]){const value=base();value.birth.house_system=code;assert.throws(()=>session(value));}const value=base();value.mode='solar_arc';value.technique={mode:'solar_arc',target:{date:'2026-10-17',time:'12:00:00',timezone:'UTC'},house_method:'kundig'};assert.throws(()=>session(value));});
