#!/bin/zsh
set -eu
cd "$(dirname "$0")"
if [[ -x .venv/bin/python ]]; then
  task_python=.venv/bin/python
elif [[ -x ../../venv/bin/python ]]; then
  task_python=../../venv/bin/python
else
  print 'Set up the environment as described in README.md first.'
  read 'task_reply?Press Return to close.'
  exit 1
fi
if [[ ! -f build/libswe.dylib && ! -f build/libswe.so ]]; then
  "$task_python" scripts/build_native.py
fi
print 'English test app: http://127.0.0.1:8771'
print 'Keep this window open. Stop with Ctrl+C.'
(sleep 2; open 'http://127.0.0.1:8771') &
export PUBLIC_ORIGIN=http://127.0.0.1:8771
exec "$task_python" -m uvicorn app.main:app --host 127.0.0.1 --port 8771 --no-access-log --no-proxy-headers
