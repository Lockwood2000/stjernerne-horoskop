export const canonical=value=>JSON.stringify(sort(value));
function sort(v){if(Array.isArray(v))return v.map(sort);if(v&&typeof v==='object')return Object.fromEntries(Object.keys(v).sort().map(k=>[k,sort(v[k])]));return v;}
export function evolutionFile(value){
 if(!value||value.contract!=='stjernerne-evolution-file-1'||!value.input?.birth||typeof value.name!=='string'||value.name.length>80||typeof value.notes!=='string'||value.notes.length>10000)throw Error('Ugyldig evolutionær fil.');
 if(!/^\d{4}-\d{2}-\d{2}$/.test(value.input.birth.date)||!value.view||!Array.isArray(value.view.visible_nodes))throw Error('Ufuldstændig evolutionær fil.');
 // Keep input, notes and view only. Supplied calculation results are never imported.
 return {contract:value.contract,name:value.name,notes:value.notes,place_label:String(value.place_label||'').slice(0,120),input:structuredClone(value.input),view:structuredClone(value.view)};
}
export function signature(kind,row){
 if(kind==='library')return canonical({name:row.name,session:row.session,trashed:!!row.trashed});
 if(kind==='evolution')return canonical(evolutionFile(row));
 const {id,revision,updated,...content}=row;return canonical(content);
}
export function unseen(kind,incoming,existing){const seen=new Set(existing.map(r=>signature(kind,r)));return incoming.filter(r=>{const s=signature(kind,r);if(seen.has(s))return false;seen.add(s);return true;});}
export function completeStudy(record,defaults){
 const clean=structuredClone(record);
 // Older files may omit settings introduced by a later UI. Preserve every stated
 // choice; fill only missing keys from that same school's existing defaults.
 clean.request.settings={...structuredClone(defaults),...(clean.request.settings||{})};
 return clean;
}
