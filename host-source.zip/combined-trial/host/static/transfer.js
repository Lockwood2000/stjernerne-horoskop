import {evolutionFile,signature,unseen,completeStudy} from './transfer-model.js';
const $=id=>document.getElementById(id),EVOKEY='stjernerne.evolution.saved.v1',HISTORY='stjernerne.combined.evolution.imports.v1';
let pending=[],inspection=0;
const text=(tag,value)=>{const e=document.createElement(tag);e.textContent=value;return e;};
function history(){const raw=JSON.parse(localStorage.getItem(HISTORY)||'[]');if(!Array.isArray(raw))throw Error('Det lokale flyttearkiv kunne ikke læses.');return raw.map(evolutionFile);}
function saveEvolution(records,active=false){
 const previous=history(),current=localStorage.getItem(EVOKEY);
 if(current){const old=evolutionFile(JSON.parse(current));if(unseen('evolution',[old],previous).length)previous.push(old);}
 const fresh=unseen('evolution',records,previous);localStorage.setItem(HISTORY,JSON.stringify([...previous,...fresh]));
 if(active)localStorage.setItem(EVOKEY,JSON.stringify(records[0]));
 return fresh.length;
}
function showHistory(){
 $('history').replaceChildren();const rows=history();
 if(!rows.length)$('history').append(text('p','Ingen evolutionære filer er flyttet endnu.'));
 for(const row of rows){const box=text('div','');box.className='history-row';box.append(text('p',row.name+' · '+row.input.birth.date));const open=text('a','Åbn i generatoren →');open.href='/evolution/';open.onclick=()=>{saveEvolution([row],true);};box.append(open);$('history').append(box);}
}
async function inspect(){
 const revision=++inspection,targetChoice=$('library-target').value,items=[],labels=[];
 pending=[];$('import').disabled=true;$('preview').replaceChildren();$('status').textContent='';
 try{
  const files=[...$('files').files];if(files.length>100)throw Error('Vælg højst 100 filer ad gangen.');
  for(const f of files){
   if(f.size>2_000_000)throw Error(f.name+': Filen er større end 2 MB.');
   const raw=await f.text(),v=JSON.parse(raw);let item;
   if(['stjernerne-horoskoper','stjernerne-chart-workshop-en-test'].includes(v.format)){
    const target=v.format==='stjernerne-chart-workshop-en-test'?'en':targetChoice,model=await import('/'+target+'/static/library-model.js');
    // Explicit destination is allowed for a legacy/common-format export.
    if(v.format!==model.FORMAT)v.format=model.FORMAT;
    item={kind:'library',target,rows:model.decodeBackup(JSON.stringify(v))};
   }else if(v.format==='stjernerne-school-chart'){
    const model=await import('/school/static/school/model.js'),parsed=model.decodeFile(raw),r=completeStudy(parsed,model.defaults(parsed.request.school));item={kind:'school',target:r.request.school,rows:[r]};
   }else if(v.contract==='stjernerne-evolution-file-1')item={kind:'evolution',target:'evolution',rows:[evolutionFile(v)]};
   else throw Error(f.name+': Ukendt filformat. Brug generatorens JSON-eksport.');
   if(revision!==inspection)return;
   items.push(item);labels.push(text('li',`${f.name} → ${item.target} · ${item.rows.length} horoskop(er): ${item.rows.map(r=>r.name).join(', ')}`));
  }
  if(revision!==inspection)return;
  pending=items;$('preview').replaceChildren(...labels);
  $('import').disabled=!pending.length;
 }catch(e){if(revision!==inspection)return;pending=[];$('preview').replaceChildren();$('status').textContent=e.message;}
}
$('files').onchange=inspect;$('library-target').onchange=inspect;
$('import').onclick=async()=>{
 $('import').disabled=true;let imported=0,skipped=0;
 try{
  // Validate the entire input before the first write. Each edition retains its own store.
  const plan=[];
  for(const item of pending){
   if(item.kind==='library'){
    const store=await import('/'+item.target+'/static/library-store.js'),existing=await store.listRecords(),prior=plan.filter(p=>p.target===item.target).flatMap(p=>p.rows),rows=unseen('library',item.rows,[...existing,...prior]);
    if(existing.length+prior.length+rows.length>100)throw Error(item.target+': Biblioteket kan højst indeholde 100 horoskoper.');
    plan.push({...item,rows,store});skipped+=item.rows.length-rows.length;
   }else if(item.kind==='school'){
    const store=await import('/school/static/school/store.js'),model=await import('/school/static/school/model.js'),existing=(await store.listRecords()).map(model.validateRecord),prior=plan.filter(p=>p.kind==='school').flatMap(p=>p.rows),rows=unseen('school',item.rows,[...existing,...prior]);
    if(existing.length+prior.length+rows.length>100)throw Error('Skolebiblioteket kan højst indeholde 100 arbejder.');
    plan.push({...item,rows,store});skipped+=item.rows.length-rows.length;
   }else{
    const prior=plan.filter(p=>p.kind==='evolution').flatMap(p=>p.rows),rows=unseen('evolution',item.rows,[...history(),...prior]);plan.push({...item,rows});skipped+=item.rows.length-rows.length;
   }
  }
  for(const item of plan){
   if(!item.rows.length)continue;
   if(item.kind==='library')await item.store.changeRecord({type:'import',records:item.rows});
   else if(item.kind==='school')for(const row of item.rows)await item.store.saveRecord(row);
   else saveEvolution(item.rows);
   imported+=item.rows.length;
  }
  $('status').textContent=`Flytningen er færdig. ${imported} importeret. ${skipped} identiske registreringer sprunget over. Eksisterende horoskoper er bevaret.`;showHistory();
 }catch(e){$('status').textContent=`${imported} importeret før stop. ${e.message} Du kan prøve igen; identiske registreringer springes over.`;}
 finally{$('import').disabled=!pending.length;}
};
try{showHistory();}catch(e){$('status').textContent=e.message;}
