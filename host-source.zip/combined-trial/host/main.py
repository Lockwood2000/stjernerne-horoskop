"""Single-process trial host. Edition engines and browser stores remain isolated."""
from importlib import import_module
from pathlib import Path
import json
import os
import resource
import sys
import time
from fastapi import FastAPI
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

ROOT=Path(__file__).resolve().parents[1]
START=time.monotonic()
# EVOLUTION_HOME is specific to its original service, not the combined router.
os.environ.pop('EVOLUTION_HOME',None)
apps={key:import_module(f'editions.{key}.app.main').app for key in ('da','en','school','evolution')}
portal=FastAPI(docs_url=None,redoc_url=None,openapi_url=None)

@portal.get('/')
def home(): return FileResponse(ROOT/'host/static/index.html')

@portal.get('/flyt')
def transfer(): return FileResponse(ROOT/'host/static/transfer.html')

@portal.get('/api/health')
def health(): return {'status':'ok','generators':5,'edition_packages':4,'trial':True}

def read_limit(path):
    try:return Path(path).read_text().strip()
    except OSError:return None

@portal.get('/api/trial/resources')
def resources():
    usage=resource.getrusage(resource.RUSAGE_SELF)
    peak=usage.ru_maxrss/(1024 if sys.platform!='darwin' else 1024*1024)
    rss=None
    if sys.platform=='linux':
        try:rss=int(Path('/proc/self/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')/1048576
        except (OSError,ValueError):pass
    return dict(uptime_seconds=time.monotonic()-START,rss_mb=rss,peak_rss_mb=peak,
                process_cpu_seconds=usage.ru_utime+usage.ru_stime,
                memory_limit=read_limit('/sys/fs/cgroup/memory.max'),
                memory_current=read_limit('/sys/fs/cgroup/memory.current'),
                memory_peak=read_limit('/sys/fs/cgroup/memory.peak'),
                cpu_quota=read_limit('/sys/fs/cgroup/cpu.max'))

@portal.get('/source')
def source():
    names={'da':'Stjernerne · dansk','en':'Stjernerne · English','school':'Institut & University','evolution':'Evolutionary Astrology','host':'Fælles vært og flyttefunktion'}
    links=''.join(f'<li><a href="/sources/{key}-source.zip">{name}</a></li>' for key,name in names.items())
    return HTMLResponse('<!doctype html><html lang="da"><meta charset="utf-8"><title>Kildekode</title><main><h1>Komplet kildekode · AGPL</h1><p>De fire originale kildepakker samt værtens kildekode, URL-tilpasninger, byggevejledning og tests. Bevarede tredjepartslicenser følger hver pakke.</p><ul>'+links+'</ul><a href="/">Til prøveversionen</a></main></html>')

portal.mount('/assets',StaticFiles(directory=ROOT/'host/static'))
portal.mount('/sources',StaticFiles(directory=ROOT/'inputs'))

class TrialHost:
    async def __call__(self,scope,receive,send):
        if scope['type']!='http':return await portal(scope,receive,send)
        path=scope['path']
        key=path.split('/')[1] if '/' in path else ''
        if key not in apps:return await portal(scope,receive,send)
        prefix='/'+key
        if path==prefix:return await RedirectResponse(prefix+'/',status_code=307)(scope,receive,send)
        relative=path[len(prefix):]
        if relative=='/source':return await RedirectResponse('/source',status_code=307)(scope,receive,send)
        if key=='evolution' and relative=='/':relative='/evolution'
        if key=='school' and relative=='/':relative='/institut'
        child={**scope,'path':relative,'raw_path':relative.encode(),'root_path':''}
        async def adjusted(event):
            if event['type']=='http.response.start':
                headers=[]
                for name,value in event.get('headers',[]):
                    if name.lower() in (b'location',b'service-worker-allowed') and value.startswith(b'/'):
                        value=prefix.encode()+value
                    headers.append((name,value))
                event={**event,'headers':headers}
            await send(event)
        await apps[key](child,receive,adjusted)

app=TrialHost()
