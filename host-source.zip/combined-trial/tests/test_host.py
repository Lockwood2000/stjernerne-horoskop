import hashlib
import json
from pathlib import Path
import re
import sys
from zipfile import ZipFile
import pytest
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from host.main import app,apps
from scripts.cases import cases
from scripts.assemble import prefix_text

@pytest.mark.parametrize('edition,name,path,payload',cases())
def test_all_preserved_modes_match_frozen_edition(edition,name,path,payload):
    with TestClient(app) as client,TestClient(apps[edition]) as original:
        before=original.post(path,json=payload)
        after=client.post('/'+edition+path,json=payload)
        assert before.status_code==200,(name,before.text)
        assert after.status_code==200,(name,after.text)
        assert after.json()==before.json()

@pytest.mark.parametrize('url',('/da/','/en/','/school/institut','/school/university','/evolution/'))
def test_pages_and_all_html_assets_resolve(url):
    with TestClient(app) as client:
        response=client.get(url);assert response.status_code==200
        for asset in re.findall(r'(?:href|src)="(/[^"#]+)"',response.text):
            assert client.get(asset).status_code==200,asset

def test_immutable_python_and_data():
    provenance=json.loads((ROOT/'inputs/provenance.json').read_text())
    for key,info in provenance['editions'].items():
        archive=ROOT/'inputs'/info['source']
        assert hashlib.sha256(archive.read_bytes()).hexdigest()==info['sha256']
        with ZipFile(archive) as z:
            for name in z.namelist():
                parts=Path(name).parts
                if len(parts)<2:continue
                relative=Path(*parts[1:])
                if relative.parts[0] in ('app','data') and not name.endswith('/'):
                    assert (ROOT/'editions'/key/relative).read_bytes()==z.read(name)

def test_scoped_pwa_and_dynamic_school_navigation():
    with TestClient(app) as client:
        manifest=client.get('/school/static/school/pwa/manifest.webmanifest').json()
        assert manifest['scope']=='/school/institut'
        assert manifest['start_url']=='/school/institut'
        worker=client.get('/school/institut-sw.js')
        assert worker.headers['service-worker-allowed']=='/school/institut'
        source=client.get('/school/static/school/app.js').text
        assert "'/school/'+school" in source
        assert "location.pathname==='/school/university'" in source

def test_guards_still_enforce_origin_and_body_limit():
    with TestClient(app) as client:
        for edition in apps:
            response=client.post('/'+edition+'/api/chart',json={},headers={'Origin':'https://foreign.example'})
            assert response.status_code==403
            response=client.post('/'+edition+'/api/chart',content='x'*9000,headers={'Content-Type':'application/json'})
            assert response.status_code==413

def test_url_transform_preserves_relative_and_external_assets():
    assert prefix_text("fetch('/api/chart')",'/da')=="fetch('/da/api/chart')"
    assert prefix_text("'/' + school",'/school')=="'/school/' + school"
    assert prefix_text("'https://example.com/api/'",'/da')=="'https://example.com/api/'"
    assert prefix_text("import './wheel.js'",'/da')=="import './wheel.js'"

def test_polar_correction_preserved_in_all_editions():
    polar={'date':'2026-06-21','time':'00:00:00','latitude':69.6492,'longitude':18.9553,'timezone':'UTC'}
    with TestClient(app) as client:
        for edition in ('da','en'):
            response=client.post('/'+edition+'/api/chart',json={**polar,'house_system':'R','include_dwarfs':False})
            assert response.status_code==200,response.text
            assert response.json()['planets'][0]['house']==11
        for profile in ('institut','university'):
            response=client.post('/school/api/school/chart',json={'birth':polar,'school':profile,'settings':{'house_system':'R'}})
            assert response.status_code==200,response.text
            assert response.json()['layers'][0]['planets'][0]['house']==11
        response=client.post('/evolution/api/evolution/chart',json={'birth':polar,'house_system':'R'})
        assert response.status_code==200,response.text
        assert response.json()['natal']['planets'][0]['house']==11
        assert len(response.json()['planetary_nodes'])==17
