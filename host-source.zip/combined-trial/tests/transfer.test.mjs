import test from 'node:test';
import assert from 'node:assert/strict';
import {evolutionFile,unseen,signature,completeStudy} from '../host/static/transfer-model.js';
test('library duplicate detection retains trash, times and timing settings',()=>{
 const a={name:'Test',session:{birth:{time:'14:30:25'},technique:{mode:'solar_arc'}},trashed:false};
 assert.equal(unseen('library',[a,structuredClone(a)],[]).length,1);
 assert.equal(unseen('library',[a],[{...a,id:'existing',revision:7}]).length,0);
 assert.equal(unseen('library',[{...a,trashed:true}],[a]).length,1);
});
test('school comparison ignores storage metadata and preserves nested study content',()=>{
 const a={name:'Study',notes:{synthesis:'Keep this'},workshops:{reflections:{south:'Keep'}},request:{school:'institut',target:{time:'12:34:56',timezone:'Europe/London'}}};
 assert.equal(unseen('school',[a],[{...a,id:'old',updated:'today',revision:3}]).length,0);
 assert.notEqual(signature('school',a),signature('school',{...a,notes:{synthesis:'Different'}}));
});
test('evolution import keeps all selected nodes and notes, discards untrusted results',()=>{
 const v={contract:'stjernerne-evolution-file-1',name:'Example',notes:'Keep notes',place_label:'Copenhagen',input:{birth:{date:'1990-06-15',time:'14:30:00'},timing_mode:'solar_arc'},view:{visible_nodes:Array.from({length:17},(_,i)=>String(i)),show_nodes:true},result:{forged:'result'}};
 const clean=evolutionFile(v);assert.equal(clean.view.visible_nodes.length,17);assert.equal(clean.notes,'Keep notes');assert.ok(!('result' in clean));assert.equal(v.result.forged,'result');
 assert.equal(unseen('evolution',[clean,clean],[]).length,1);
});
test('reject unsupported or overlong evolution files',()=>{
 assert.throws(()=>evolutionFile({contract:'other'}));
 assert.throws(()=>evolutionFile({contract:'stjernerne-evolution-file-1',input:{birth:{date:'1990-06-15'}},name:'X',notes:'x'.repeat(10001),view:{visible_nodes:[]}}));
});
test('older study settings receive missing UI defaults without altering stated choices',()=>{
 const row={request:{school:'institut',settings:{house_system:'R',orbs:{0:3}}},notes:{chart:'Preserve'}};
 const full=completeStudy(row,{house_system:'P',bodies:['sun','moon'],orbs:{0:8,180:8}});
 assert.deepEqual(full.request.settings,{house_system:'R',bodies:['sun','moon'],orbs:{0:3}});
 assert.equal(full.notes.chart,'Preserve');assert.equal(row.request.settings.bodies,undefined);
});
