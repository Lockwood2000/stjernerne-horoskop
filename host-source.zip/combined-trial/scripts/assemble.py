"""Assemble isolated frozen editions. Only browser URL prefixes are adapted."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ROOTS = ('api', 'static', 'source', 'embed-test', 'schools', 'institut-sw.js',
         'institut', 'university', 'evolution')
URL = re.compile(r'''(["'`])/(?:(''' + '|'.join(re.escape(x) for x in ROOTS) + r'''))(?=[/"'`?#])''')

def prefix_text(text, prefix, home=None):
    text = URL.sub(lambda m: m[1] + prefix + '/' + m[2], text)
    if prefix == '/school':
        # The original links are /institut and /university. Their profile IDs
        # must stay unchanged after those links gain the hosting prefix.
        text = text.replace("a.getAttribute('href').slice(1)",
                            "a.getAttribute('href').slice('/school/'.length)")
    # Exact root navigation; leave protocol-relative and external links intact.
    return re.sub(r'''(["'`])/(\1)''', lambda m: m[1] + prefix + '/' + m[2], text)

def assemble(build=True):
    provenance = json.loads((ROOT/'inputs/provenance.json').read_text())
    output = ROOT/'editions'
    output.mkdir(exist_ok=True)
    (output/'__init__.py').touch()
    changes = {}
    for key, info in provenance['editions'].items():
        archive = ROOT/'inputs'/info['source']
        assert hashlib.sha256(archive.read_bytes()).hexdigest() == info['sha256']
        target = output/key
        if target.exists(): shutil.rmtree(target)
        target.mkdir()
        (target/'__init__.py').touch()
        changes[key] = []
        with ZipFile(archive) as z:
            for entry in z.infolist():
                parts = Path(entry.filename).parts
                if len(parts)<2: continue
                relative=Path(*parts[1:])
                assert '..' not in relative.parts and not relative.is_absolute()
                path=target/relative
                if entry.is_dir(): path.mkdir(parents=True,exist_ok=True);continue
                path.parent.mkdir(parents=True,exist_ok=True)
                data=z.read(entry)
                if relative.parts[0]=='static' and path.suffix in {'.html','.js','.css','.webmanifest'}:
                    original=data.decode()
                    home='/school/institut' if key=='school' else f'/{key}/'
                    revised=prefix_text(original,f'/{key}',home)
                    if original!=revised: changes[key].append(str(relative))
                    data=revised.encode()
                path.write_bytes(data)
        # The two school views intentionally share their existing profile-aware store.
        # Each other edition already has a different storage name.
        if build:
            subprocess.run([sys.executable,'scripts/build_native.py'],cwd=target,check=True)
            subprocess.run([sys.executable,'scripts/verify_native_threads.py'],cwd=target,check=True)
        else:
            native=ROOT/'native-cache'/key
            if native.exists(): shutil.copytree(native,target/'build',dirs_exist_ok=True)
    locks=[(output/key/'requirements.lock').read_bytes() for key in changes]
    assert len(set(locks))==1, 'Dependency versions differ; explicit reconciliation required.'
    (ROOT/'requirements.lock').write_bytes(locks[0])
    (ROOT/'reports/assembly.json').write_text(json.dumps(dict(
        source=provenance,changed_frontend_files=changes,
        python_calculation_sources_changed=False,
        isolation='Four separate Python packages/native libraries; five UI profiles.'),indent=2)+'\n')

if __name__=='__main__': assemble('--no-build' not in sys.argv)
