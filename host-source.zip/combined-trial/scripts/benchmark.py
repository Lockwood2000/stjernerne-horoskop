"""Bounded mixed-user benchmark; verify the host, not an assumed CPU allocation."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime,timezone
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
import argparse
import hashlib
import json
import statistics
import time
from cases import cases

ROOT=Path(__file__).resolve().parents[1]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('url');parser.add_argument('--label',required=True)
    args=parser.parse_args();base=args.url.rstrip('/')
    def get(path):
        with urlopen(base+path,timeout=60) as r:return json.load(r)
    def call(item):
        edition,name,path,payload=item;start=time.perf_counter()
        req=Request(base+'/'+edition+path,data=json.dumps(payload).encode(),headers={'Content-Type':'application/json','Origin':base})
        try:
            with urlopen(req,timeout=60) as response:
                data=response.read();status=response.status
            parsed=json.loads(data)
            # Every response is compared with its serial baseline, catching cross-engine state races.
            digest=hashlib.sha256(json.dumps(parsed,sort_keys=True).encode()).hexdigest()
            return dict(edition=edition,name=name,status=status,seconds=time.perf_counter()-start,sha256=digest)
        except Exception as e:return dict(edition=edition,name=name,status=getattr(e,'code',0),seconds=time.perf_counter()-start,error=str(e))
    start_resources=get('/api/trial/resources')
    baseline=[call(c) for c in cases()]
    expected={(r['edition'],r['name']):r.get('sha256') for r in baseline}
    assert all(r['status']==200 for r in baseline),baseline
    # 20 representative timing requests, distributed across all five profiles.
    mixed=[c for c in cases() if c[1] in ('natal','progressed','solar_arc','solar','secondary','solar_return','institut-natal','institut-progressed','institut-solar_arc','institut-solar_return','university-natal','university-progressed','university-solar_arc','university-solar_return')]
    stages=[]
    for concurrency in (1,5,10):
        started=time.perf_counter()
        with ThreadPoolExecutor(max_workers=concurrency) as pool:results=list(pool.map(call,mixed*2))
        elapsed=time.perf_counter()-started
        for r in results:r['matches_serial']=r.get('sha256')==expected.get((r['edition'],r['name'])) and r['status']==200
        times=sorted(r['seconds'] for r in results)
        stages.append(dict(concurrent_requests=concurrency,requests=len(results),elapsed_seconds=elapsed,requests_per_second=len(results)/elapsed,p50_seconds=statistics.median(times),p95_seconds=times[min(len(times)-1,int(len(times)*.95))],max_seconds=max(times),errors=sum(not r['matches_serial'] for r in results),results=results,resources=get('/api/trial/resources')))
    final=get('/api/trial/resources')
    report=dict(url=base,label=args.label,checked_at=datetime.now(timezone.utc).isoformat(),baseline=baseline,stages=stages,resources_before=start_resources,resources_after=final,
        acceptance=dict(all_five_profiles_exercised=True,no_calculation_mismatches=all(s['errors']==0 for s in stages),interactive_5_concurrent_p95_under_2_seconds=stages[1]['p95_seconds']<2,
                        actual_paid_plan_verified=False),
        limit='This report verifies observed performance at the measured allocation. A local or Free result is not a paid 0.5 CPU Render measurement. It is not a prolonged production capacity guarantee.')
    path=ROOT/'reports'/('benchmark-'+args.label+'.json');path.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:report[k] for k in ('url','label','acceptance','resources_after')},indent=2))
    print(json.dumps([dict(concurrency=s['concurrent_requests'],p95=s['p95_seconds'],max=s['max_seconds'],errors=s['errors']) for s in stages],indent=2))
if __name__=='__main__':main()
