"""Fictional, deterministic cross-edition trial scenarios."""
BIRTH={'date':'1990-06-15','time':'14:30:00','place_id':'2618425'}
OTHER={'date':'1992-03-20','time':'10:15:00','place_id':'2643743'}
TARGET={'date':'2026-10-17','time':'18:45:30','timezone':'Europe/Copenhagen'}

def cases():
    rows=[]
    for edition in ('da','en'):
        birth={**BIRTH,'house_system':'R','include_dwarfs':True}
        rows.append((edition,'natal','/api/chart',birth))
        for mode in ('progressed','solar_arc','solar'):
            body={'birth':birth,'mode':mode}
            body.update({'year':2026,'location':{'place_id':'2643743'}} if mode=='solar' else {'target':TARGET})
            rows.append((edition,mode,'/api/technique',body))
        rows.extend([
            (edition,'transits','/api/transits',{'birth':birth,'transit':TARGET}),
            (edition,'synastry','/api/synastry',{'a':birth,'b':{**OTHER,'include_dwarfs':True,'house_system':'R'}}),
            (edition,'rectify','/api/rectify',{'birth':birth,'shift_minutes':1.25}),
        ])
    for profile in ('institut','university'):
        for mode in ('natal','solar_chart','event','transits','progressed','combined','solar_arc','synastry','composite','compare','solar_return'):
            body={'school':profile,'birth':BIRTH,'settings':{'house_system':'R'},'mode':mode}
            if mode in ('transits','progressed','combined','solar_arc'):body['target']=TARGET
            if mode in ('synastry','composite','compare'):body['other']=OTHER
            if mode=='solar_return':body.update(return_year=2026,return_place_id='2643743')
            rows.append(('school',profile+'-'+mode,'/api/school/chart',body))
    for mode in ('natal','secondary','solar_arc','solar_return'):
        body={'birth':BIRTH,'house_system':'R'}
        if mode!='natal':body.update(include_progressions=True,timing_mode=mode,target=TARGET)
        if mode=='solar_return':body.update(return_year=2026,return_place={'place_id':'2643743'})
        rows.append(('evolution',mode,'/api/evolution/chart',body))
    return rows
