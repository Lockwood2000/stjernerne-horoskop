from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
files=[]
for folder in ('host','scripts','tests'):
    files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc',))
files.extend(ROOT/name for name in ('Dockerfile','render.yaml','README.md','requirements.lock','LICENSE','COPYING','THIRD_PARTY.md'))
files.append(ROOT/'inputs/provenance.json')
with ZipFile(ROOT/'inputs/host-source.zip','w',ZIP_DEFLATED) as z:
    for p in sorted(files):z.write(p,'combined-trial/'+str(p.relative_to(ROOT)))
print(hashlib.sha256((ROOT/'inputs/host-source.zip').read_bytes()).hexdigest())
