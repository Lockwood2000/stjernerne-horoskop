"""Stage the approved source and VPS deployment helpers; never include credentials."""
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[1]
RELEASE = json.loads((ROOT / 'reports/release.json').read_text())
DIST = ROOT / 'dist'
STAGE = DIST / 'hostup-nano-trial'
STAGE.mkdir(parents=True, exist_ok=True)

# Exact allowlist; private keys, reports, browser exports and local envs are excluded.
files = {'Dockerfile': ROOT / 'Dockerfile'}
for name in ('da-source.zip', 'en-source.zip', 'school-source.zip',
             'evolution-source.zip', 'host-source.zip'):
    path = ROOT / 'inputs' / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == RELEASE['source_files_verified'][name], name
    files[name] = path
for name in ('compose.yaml', 'Caddyfile', 'trial.env.example', 'install.sh', 'README.txt'):
    files[name] = ROOT / 'deploy/hostup' / name
assert hashlib.sha256(files['Dockerfile'].read_bytes()).hexdigest() == RELEASE['source_files_verified']['Dockerfile']

checksums = []
for name, source in sorted(files.items()):
    destination = STAGE / name
    shutil.copyfile(source, destination)
    destination.chmod(0o755 if name == 'install.sh' else 0o644)
    checksums.append(hashlib.sha256(destination.read_bytes()).hexdigest() + '  ' + name)
(STAGE / 'SHA256SUMS').write_text('\n'.join(checksums) + '\n')

archive = DIST / 'hostup-nano-trial.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for name in sorted([*files, 'SHA256SUMS']):
        tar.add(STAGE / name, arcname='hostup-nano-trial/' + name, recursive=False)
manifest = {'archive': str(archive), 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'files': sorted([*files, 'SHA256SUMS']),
            'source_matches_approved_public_release': True,
            'private_keys_or_actual_env_included': False,
            'deployed': False, 'billing_configured': False}
(ROOT / 'reports/hostup-installation-bundle.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
