"""Freeze the four public source releases behind the five existing generators."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from hashlib import sha256
from pathlib import Path
from urllib.request import urlopen
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]
EDITIONS = {
    'da': ('https://stjernerne-horoskop.onrender.com', 'main'),
    'en': ('https://stjernerne-chart-workshop-test.onrender.com', 'english-test'),
    'school': ('https://stjernerne-school-workshops.onrender.com', 'school-workshops'),
    'evolution': ('https://stjernerne-evolution.onrender.com', 'evolution-chart'),
}

def freeze(item):
    key, (url, branch) = item
    with urlopen(url + '/source', timeout=120) as response:
        data = response.read()
    path = ROOT / 'inputs' / (key + '-source.zip')
    path.write_bytes(data)
    return key, dict(url=url, branch=branch, source=path.name,
                     sha256=sha256(data).hexdigest(), bytes=len(data))

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=4) as pool:
        editions = dict(pool.map(freeze, EDITIONS.items()))
    remote = subprocess.check_output(['git', 'ls-remote', '--heads',
        'https://github.com/Lockwood2000/stjernerne-horoskop.git',
        *[v[1] for v in EDITIONS.values()]], text=True)
    heads = {ref.rsplit('/', 1)[-1]: commit for commit, ref in
             (line.split() for line in remote.splitlines())}
    for edition in editions.values():
        edition['observed_branch_head'] = heads[edition['branch']]
    report = dict(frozen_at=datetime.now(timezone.utc).isoformat(), editions=editions)
    (ROOT / 'inputs' / 'provenance.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))
